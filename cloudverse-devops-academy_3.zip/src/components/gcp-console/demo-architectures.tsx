"use client";

import * as React from "react";
import { Rocket, Trash2, Loader2, DollarSign, Layers, Sparkles, Waypoints } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useDemoArchitectureStore, DemoRun } from "@/store/demo-architecture-store";
import { useIamStore } from "@/store/iam-store";
import { ArchitectureDiagram } from "@/components/gcp-console/architecture-diagram";
import { ResourceConfig } from "@/types/gcp";
import { cn, formatCurrency } from "@/lib/utils";
import { DEMO_ARCHITECTURES, DemoArchitecture } from "@/lib/gcp-console/demo-architectures";
import { toast } from "sonner";

// Literal Tailwind class lookup — never construct classes dynamically.
const RUN_BADGE_CLASS = "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
const DEPLOYING_BADGE_CLASS = "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400";

interface DeployProgress {
  index: number;
  total: number;
  label: string;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function estimateBundleCost(bundle: DemoArchitecture): number {
  return bundle.resources.reduce((sum, spec) => {
    const def = getResourceDef(spec.type);
    if (!def) return sum;
    const config = { ...def.defaultConfig, ...spec.configOverrides } as ResourceConfig;
    return sum + def.estimateMonthlyCost(config);
  }, 0);
}

export function DemoArchitectures() {
  const createResource = useGcpConsoleStore((s) => s.createResource);
  const deleteResource = useGcpConsoleStore((s) => s.deleteResource);

  // Which bundle (by id) is currently mid-deploy — used to disable every other
  // deploy button so two bundles can never be rolled out concurrently.
  const [deployingId, setDeployingId] = React.useState<string | null>(null);
  const [progress, setProgress] = React.useState<Record<string, DeployProgress>>({});
  const runs = useDemoArchitectureStore((s) => s.runs);
  const recordRun = useDemoArchitectureStore((s) => s.recordRun);
  const clearRun = useDemoArchitectureStore((s) => s.clearRun);

  const handleDeploy = React.useCallback(
    async (bundle: DemoArchitecture) => {
      if (deployingId) return;
      setDeployingId(bundle.id);

      // Random-looking prefix so repeated demo runs never collide, e.g. "web-app-a1b2".
      const prefix = `${bundle.slug}-${Math.random().toString(36).slice(2, 6)}`;
      const total = bundle.resources.length;
      const createdIds: string[] = [];

      for (let i = 0; i < total; i++) {
        const spec = bundle.resources[i];
        const def = getResourceDef(spec.type);
        if (!def) continue;

        setProgress((prev) => ({ ...prev, [bundle.id]: { index: i + 1, total, label: def.label } }));

        const name = `${prefix}${spec.nameSuffix}`;
        const config = { ...def.defaultConfig, ...spec.configOverrides, name } as ResourceConfig;
        createdIds.push(createResource(spec.type, config));

        if (i < total - 1) await sleep(400);
      }

      recordRun(bundle.id, createdIds);
      setProgress((prev) => {
        const next = { ...prev };
        delete next[bundle.id];
        return next;
      });
      setDeployingId(null);
      toast.success(`${bundle.name} deployed — ${createdIds.length} resources live in the Console`);
    },
    [createResource, deployingId, recordRun],
  );

  const handleTeardown = React.useCallback(
    (bundle: DemoArchitecture) => {
      const run = runs[bundle.id];
      if (!run) return;
      run.resourceIds.forEach((id) => deleteResource(id));
      clearRun(bundle.id);
      toast.info(`${bundle.name} torn down — resources removed from the Console`);
    },
    [deleteResource, runs, clearRun],
  );

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Sparkles className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-lg font-semibold leading-tight">Demo Architectures</h2>
          <p className="text-sm text-muted-foreground">
            Spin up a complete, realistic architecture in seconds — perfect for live client demos. Pick a bundle
            below and every resource it needs rolls out automatically, in order.
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-2">
        {DEMO_ARCHITECTURES.map((bundle) => (
          <DemoArchitectureCard
            key={bundle.id}
            bundle={bundle}
            progress={progress[bundle.id]}
            run={runs[bundle.id]}
            disabled={deployingId !== null && deployingId !== bundle.id}
            onDeploy={() => handleDeploy(bundle)}
            onTeardown={() => handleTeardown(bundle)}
          />
        ))}
      </div>
    </div>
  );
}

function DemoArchitectureCard({
  bundle,
  progress,
  run,
  disabled,
  onDeploy,
  onTeardown,
}: {
  bundle: DemoArchitecture;
  progress: DeployProgress | undefined;
  run: DemoRun | undefined;
  disabled: boolean;
  onDeploy: () => void;
  onTeardown: () => void;
}) {
  const Icon = bundle.icon;
  const isDeploying = progress !== undefined;
  const isDeployed = run !== undefined;
  const estimatedCost = React.useMemo(() => estimateBundleCost(bundle), [bundle]);

  const allResources = useGcpConsoleStore((s) => s.resources);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const [diagramOpen, setDiagramOpen] = React.useState(false);
  const runResources = React.useMemo(() => {
    if (!run) return [];
    const ids = new Set(run.resourceIds);
    return allResources.filter((r) => ids.has(r.id));
  }, [allResources, run]);

  return (
    <Card className="flex flex-col transition-shadow hover:shadow-md">
      <CardHeader className="flex-row items-start gap-3 space-y-0">
        <span className="mt-0.5 inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <CardTitle>{bundle.name}</CardTitle>
          <CardDescription className="mt-1 font-medium text-foreground/80">{bundle.tagline}</CardDescription>
        </div>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col gap-3">
        <p className="text-sm text-muted-foreground">{bundle.description}</p>

        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="secondary" className="gap-1 text-[10px]">
            <Layers className="h-3 w-3" /> {bundle.resources.length} resources
          </Badge>
          <Badge variant="secondary" className="gap-1 text-[10px]">
            <DollarSign className="h-3 w-3" /> ~{formatCurrency(estimatedCost)}/mo
          </Badge>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {bundle.resources.map((spec, i) => {
            const def = getResourceDef(spec.type);
            if (!def) return null;
            return (
              <span
                key={`${spec.type}-${i}`}
                className="inline-flex items-center gap-1 rounded-full border border-border bg-card/40 py-0.5 pl-1 pr-2 text-[11px] text-muted-foreground"
              >
                <ResourceIcon type={def.type} color={def.color} size={11} className="h-5 w-5" />
                {def.shortLabel}
              </span>
            );
          })}
        </div>
      </CardContent>

      <CardFooter className="flex flex-col items-stretch gap-2">
        {isDeploying && progress ? (
          <div className="flex w-full flex-col gap-2">
            <div className="flex items-center justify-between gap-2">
              <Badge className={cn("gap-1 text-[10px]", DEPLOYING_BADGE_CLASS)}>
                <Loader2 className="h-3 w-3 animate-spin" />
                Creating {progress.index} of {progress.total} — {progress.label}...
              </Badge>
            </div>
            <Progress value={(progress.index / progress.total) * 100} />
          </div>
        ) : isDeployed && run ? (
          <div className="flex w-full flex-col gap-2">
            <Badge className={cn("w-fit gap-1 text-[10px]", RUN_BADGE_CLASS)}>
              Deployed just now — {run.resourceCount} resources
            </Badge>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 gap-1.5" onClick={() => setDiagramOpen(true)}>
                <Waypoints className="h-4 w-4" /> View Diagram
              </Button>
              <Button variant="outline" className="flex-1 gap-1.5 text-danger hover:bg-danger/10" onClick={onTeardown}>
                <Trash2 className="h-4 w-4" /> Tear down this demo
              </Button>
            </div>
          </div>
        ) : (
          <Button className="w-full gap-1.5" disabled={disabled} onClick={onDeploy}>
            <Rocket className="h-4 w-4" /> Deploy this architecture
          </Button>
        )}
      </CardFooter>

      <Dialog open={diagramOpen} onOpenChange={setDiagramOpen}>
        <DialogContent className="max-h-[85vh] max-w-5xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{bundle.name} — Architecture Diagram</DialogTitle>
            <DialogDescription>
              Exactly what was just deployed for this demo — great to walk a client through live.
            </DialogDescription>
          </DialogHeader>
          <ArchitectureDiagram
            resources={runResources}
            serviceAccounts={serviceAccounts.map((sa) => ({ id: sa.id, name: sa.name, email: sa.email }))}
          />
        </DialogContent>
      </Dialog>
    </Card>
  );
}

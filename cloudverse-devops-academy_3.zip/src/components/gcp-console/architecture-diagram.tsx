"use client";

import { KeyRound } from "lucide-react";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";
import { ConsoleResource } from "@/store/gcp-console-store";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Layout constants
// ---------------------------------------------------------------------------

const LANE_WIDTH = 210;
const ROW_HEIGHT = 96;
const CARD_WIDTH = 180;
const CARD_HEIGHT = 64;
const MARGIN_X = 24;
const MARGIN_TOP = 24;
const IDENTITY_BAND_HEIGHT = 56;

interface Lane {
  key: string;
  label: string;
  types: string[];
}

const LANES: Lane[] = [
  { key: "networking", label: "Networking", types: ["vpc", "subnet", "router", "nat", "dns", "vpn", "interconnect", "lb"] },
  { key: "security", label: "Security", types: ["armor"] },
  { key: "compute", label: "Compute & Containers", types: ["vm", "mig", "gke"] },
  { key: "data", label: "Data", types: ["cloudsql", "redis", "gcs"] },
  { key: "cicd", label: "CI/CD & Messaging", types: ["artifact_registry", "cloud_build", "pubsub"] },
];

// Only source -> target type pairs we ever draw an edge between.
const EDGE_RULES: [string, string][] = [
  ["vpc", "subnet"],
  ["subnet", "router"],
  ["router", "nat"],
  ["subnet", "lb"],
  ["lb", "mig"],
  ["lb", "gke"],
  ["armor", "lb"],
  ["vpn", "vpc"],
  ["interconnect", "vpc"],
  ["dns", "lb"],
  ["mig", "cloudsql"],
  ["mig", "redis"],
  ["gke", "cloudsql"],
  ["gke", "redis"],
  ["cloud_build", "artifact_registry"],
  ["cloud_build", "gke"],
  ["gcs", "pubsub"],
  ["pubsub", "cloudsql"],
];

// Same 4 tokens used elsewhere in this app — literal map, never a template string.
const COLOR_DOT_CLASS: Record<string, string> = {
  "gcp-blue": "bg-gcp-blue",
  "gcp-red": "bg-gcp-red",
  "gcp-yellow": "bg-gcp-yellow",
  "gcp-green": "bg-gcp-green",
};

const COLOR_BORDER_CLASS: Record<string, string> = {
  "gcp-blue": "border-t-gcp-blue",
  "gcp-red": "border-t-gcp-red",
  "gcp-yellow": "border-t-gcp-yellow",
  "gcp-green": "border-t-gcp-green",
};

interface PlacedNode {
  resource: ConsoleResource;
  laneIndex: number;
  x: number;
  y: number;
}

interface LayoutResult {
  lanes: { label: string; x: number }[];
  nodes: PlacedNode[];
  width: number;
  height: number;
  maxRows: number;
}

function computeLayout(resources: ConsoleResource[]): LayoutResult {
  const buckets = LANES.map((lane) => resources.filter((r) => lane.types.includes(r.type)));
  const activeLaneIdxs = buckets.map((b, i) => (b.length > 0 ? i : -1)).filter((i) => i >= 0);

  const lanes: { label: string; x: number }[] = [];
  const nodes: PlacedNode[] = [];
  let maxRows = 0;

  activeLaneIdxs.forEach((laneIdx, renderIdx) => {
    const x = MARGIN_X + renderIdx * LANE_WIDTH;
    lanes.push({ label: LANES[laneIdx].label, x });
    const bucket = buckets[laneIdx];
    maxRows = Math.max(maxRows, bucket.length);
    bucket.forEach((resource, rowIdx) => {
      nodes.push({
        resource,
        laneIndex: renderIdx,
        x,
        y: MARGIN_TOP + rowIdx * ROW_HEIGHT,
      });
    });
  });

  const width = activeLaneIdxs.length > 0 ? MARGIN_X * 2 + activeLaneIdxs.length * LANE_WIDTH : 0;
  const height = MARGIN_TOP * 2 + Math.max(maxRows, 1) * ROW_HEIGHT;

  return { lanes, nodes, width, height, maxRows };
}

interface Edge {
  from: PlacedNode;
  to: PlacedNode;
}

function buildEdges(nodes: PlacedNode[]): Edge[] {
  const firstByType = new Map<string, PlacedNode>();
  for (const node of nodes) {
    if (!firstByType.has(node.resource.type)) firstByType.set(node.resource.type, node);
  }
  const edges: Edge[] = [];
  for (const [fromType, toType] of EDGE_RULES) {
    const from = firstByType.get(fromType);
    const to = firstByType.get(toType);
    if (from && to) edges.push({ from, to });
  }
  return edges;
}

function cardCenter(node: PlacedNode) {
  return {
    cx: node.x + CARD_WIDTH / 2,
    left: node.x,
    right: node.x + CARD_WIDTH,
    top: node.y,
    bottom: node.y + CARD_HEIGHT,
    midY: node.y + CARD_HEIGHT / 2,
  };
}

function EdgePath({ edge, offsetY }: { edge: Edge; offsetY: number }) {
  const from = cardCenter(edge.from);
  const to = cardCenter(edge.to);

  // Elbow: exit right edge of source, enter left edge of target (or the
  // reverse when the target lane is to the left/same lane as the source).
  const sameLane = edge.from.laneIndex === edge.to.laneIndex;
  const forward = to.left >= from.right || sameLane;

  const startX = forward ? from.right : from.left;
  const startY = from.midY + offsetY;
  const endX = forward ? to.left : to.right;
  const endY = to.midY + offsetY;
  const midX = sameLane ? startX + 26 : (startX + endX) / 2;

  const d = sameLane
    ? `M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${startX} ${endY}`
    : `M ${startX} ${startY} L ${midX} ${startY} L ${midX} ${endY} L ${endX} ${endY}`;

  return (
    <path
      d={d}
      fill="none"
      stroke="hsl(var(--border))"
      strokeWidth={1.5}
      markerEnd="url(#arch-diagram-arrow)"
    />
  );
}

function NodeCard({
  node,
  serviceAccounts,
}: {
  node: PlacedNode;
  serviceAccounts: { id: string; name: string; email: string }[];
}) {
  const { resource } = node;
  const def = getResourceDef(resource.type);
  if (!def) return null;

  const saId = resource.config.serviceAccountId;
  const attachedSa =
    typeof saId === "string" && saId.length > 0 ? serviceAccounts.find((sa) => sa.id === saId) : undefined;

  return (
    <div
      className={cn(
        "absolute flex items-center gap-2 rounded-xl border border-t-4 bg-card px-2.5 py-2 shadow-sm",
        COLOR_BORDER_CLASS[def.color] ?? COLOR_BORDER_CLASS["gcp-blue"],
        resource.status === "error" && "ring-2 ring-gcp-red/70",
      )}
      style={{ left: node.x, top: node.y, width: CARD_WIDTH, height: CARD_HEIGHT }}
      title={`${resource.name} (${def.label})`}
    >
      <ResourceIcon type={def.type} color={def.color} size={16} className="h-7 w-7" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-semibold leading-tight">{resource.name}</p>
        <p className="truncate text-[10px] text-muted-foreground leading-tight">{def.shortLabel}</p>
      </div>
      {resource.status === "error" && (
        <span className="h-2 w-2 shrink-0 rounded-full bg-gcp-red" aria-label="Error" />
      )}
      {attachedSa && (
        <span
          className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-gcp-yellow text-black shadow"
          title={`Runs as ${attachedSa.name}`}
        >
          <KeyRound size={10} strokeWidth={2.5} />
        </span>
      )}
    </div>
  );
}

export function ArchitectureDiagram({
  resources,
  serviceAccounts = [],
}: {
  resources: ConsoleResource[];
  serviceAccounts?: { id: string; name: string; email: string }[];
}) {
  if (resources.length === 0) {
    return (
      <div className="flex min-h-[220px] items-center justify-center rounded-xl border border-dashed border-border bg-muted/30 px-6 text-center text-sm text-muted-foreground">
        No resources yet — create something in the Console to see it appear here.
      </div>
    );
  }

  const layout = computeLayout(resources);
  const edges = buildEdges(layout.nodes);

  const attachedSaIds = new Set(
    layout.nodes
      .map((n) => n.resource.config.serviceAccountId)
      .filter((v): v is string => typeof v === "string" && v.length > 0),
  );
  const identitiesInUse = serviceAccounts.filter((sa) => attachedSaIds.has(sa.id));
  const showIdentityBand = identitiesInUse.length > 0;

  const canvasWidth = layout.width;
  const canvasHeight = layout.height + (showIdentityBand ? IDENTITY_BAND_HEIGHT : 0);
  const nodeOffsetY = showIdentityBand ? IDENTITY_BAND_HEIGHT : 0;

  const categoriesPresent = Array.from(
    new Set(
      layout.nodes
        .map((n) => getResourceDef(n.resource.type)?.category)
        .filter((c): c is ResourceCategory => Boolean(c)),
    ),
  );

  return (
    <div className="space-y-3">
      <div className="min-h-[260px] overflow-x-auto rounded-xl border border-border bg-muted/20 p-2">
        <div className="relative" style={{ width: canvasWidth, height: canvasHeight }}>
          {/* Lane headers */}
          {layout.lanes.map((lane) => (
            <div
              key={lane.label}
              className="absolute top-0 truncate text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
              style={{ left: lane.x, width: CARD_WIDTH, top: nodeOffsetY - 18 }}
            >
              {lane.label}
            </div>
          ))}

          {/* Identity band */}
          {showIdentityBand && (
            <div className="absolute left-0 top-0 flex items-center gap-2" style={{ width: canvasWidth, height: IDENTITY_BAND_HEIGHT - 12 }}>
              {identitiesInUse.map((sa) => (
                <span
                  key={sa.id}
                  className="flex items-center gap-1 rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-medium"
                >
                  <KeyRound size={11} className="text-gcp-yellow" />
                  {sa.name}
                </span>
              ))}
            </div>
          )}

          {/* Edge overlay */}
          <svg
            className="pointer-events-none absolute left-0 top-0"
            width={canvasWidth}
            height={canvasHeight}
            style={{ overflow: "visible" }}
          >
            <defs>
              <marker
                id="arch-diagram-arrow"
                viewBox="0 0 8 8"
                refX="7"
                refY="4"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M0,0 L8,4 L0,8 Z" fill="hsl(var(--border))" />
              </marker>
            </defs>
            {edges.map((edge, i) => (
              <EdgePath key={`${edge.from.resource.id}-${edge.to.resource.id}-${i}`} edge={edge} offsetY={nodeOffsetY} />
            ))}
            {showIdentityBand &&
              identitiesInUse.map((sa) =>
                layout.nodes
                  .filter((n) => n.resource.config.serviceAccountId === sa.id)
                  .map((n) => {
                    const c = cardCenter(n);
                    const topX = c.left + 12;
                    return (
                      <line
                        key={`${sa.id}-${n.resource.id}`}
                        x1={topX}
                        y1={IDENTITY_BAND_HEIGHT - 16}
                        x2={topX}
                        y2={c.top + nodeOffsetY}
                        stroke="hsl(var(--border))"
                        strokeWidth={1.5}
                        strokeDasharray="4 3"
                      />
                    );
                  }),
              )}
          </svg>

          {/* Nodes */}
          {layout.nodes.map((node) => (
            <NodeCard
              key={node.resource.id}
              node={{ ...node, y: node.y + nodeOffsetY }}
              serviceAccounts={serviceAccounts}
            />
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 px-1 text-[11px] text-muted-foreground">
        {categoriesPresent.map((cat) => {
          const meta = CATEGORY_META[cat];
          return (
            <span key={cat} className="flex items-center gap-1.5">
              <span className={cn("h-2 w-2 rounded-full", COLOR_DOT_CLASS[meta.color] ?? COLOR_DOT_CLASS["gcp-blue"])} />
              {meta.label}
            </span>
          );
        })}
        {showIdentityBand && (
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-px w-4 border-t border-dashed border-muted-foreground" />
            runs as this identity
          </span>
        )}
      </div>
    </div>
  );
}

export type ResourceCategory =
  | "networking"
  | "compute"
  | "storage"
  | "database"
  | "containers"
  | "cicd"
  | "security"
  | "messaging";

export type ConfigFieldType =
  | "text"
  | "select"
  | "number"
  | "boolean"
  | "textarea"
  | "tags"
  | "slider";

export interface ConfigFieldOption {
  label: string;
  value: string;
}

export interface ConfigField {
  key: string;
  label: string;
  type: ConfigFieldType;
  options?: ConfigFieldOption[];
  min?: number;
  max?: number;
  step?: number;
  placeholder?: string;
  helpText?: string;
  required?: boolean;
}

export type ResourceConfig = Record<string, string | number | boolean | string[]>;

export interface CanvasNodeData {
  resourceType: string;
  label: string;
  config: ResourceConfig;
  [key: string]: unknown;
}

export interface TerraformContext {
  config: ResourceConfig;
  nodeId: string;
  label: string;
  slug: string;
  allNodes: { id: string; type: string; label: string; config: ResourceConfig }[];
  connections: { source: string; target: string }[];
}

export interface GcpResourceDef {
  type: string;
  label: string;
  shortLabel: string;
  category: ResourceCategory;
  color: string;
  description: string;
  learningNotes: string;
  tooltip: string;
  docsUrl: string;
  terraformResourceType: string;
  configFields: ConfigField[];
  defaultConfig: ResourceConfig;
  generateTerraform: (ctx: TerraformContext) => string;
  estimateMonthlyCost: (config: ResourceConfig) => number;
  troubleshooting: { issue: string; cause: string; fix: string }[];
  quiz: { question: string; options: string[]; answerIndex: number; explanation: string; difficulty?: "beginner" | "intermediate" | "advanced" }[];
  validConnectionTargets?: string[];
}

export const CATEGORY_META: Record<ResourceCategory, { label: string; color: string }> = {
  networking: { label: "Networking", color: "gcp-blue" },
  compute: { label: "Compute", color: "gcp-green" },
  storage: { label: "Storage", color: "gcp-yellow" },
  database: { label: "Databases", color: "gcp-red" },
  containers: { label: "Containers", color: "gcp-green" },
  cicd: { label: "CI/CD", color: "gcp-blue" },
  security: { label: "Security", color: "gcp-red" },
  messaging: { label: "Messaging", color: "gcp-yellow" },
};

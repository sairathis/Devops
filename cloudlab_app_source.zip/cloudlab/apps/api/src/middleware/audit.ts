import type { FastifyInstance } from "fastify";
import { nanoid } from "nanoid";
import { db } from "../db/client.js";
import { auditLogs } from "../db/schema.js";
import { HttpError } from "../errors.js";

/**
 * THIS IS A CORE REQUIREMENT (spec section 16): every request produces an
 * audit event automatically, whether or not the route handler ever thinks
 * about auditing. Routes MAY enrich req.audit (action, resource, before/after
 * state) for a more meaningful entry, but a plain unannotated request still
 * gets logged with a generic action derived from method+path. There is no
 * code path through this server that skips the write.
 */
export function registerAudit(app: FastifyInstance) {
  app.addHook("onRequest", async (req) => {
    req.requestId = nanoid(12);
    req.startTimeMs = Date.now();
    req.audit = {};
  });

  app.setErrorHandler((err: Error, req, reply) => {
    if (err instanceof HttpError) {
      req.lastError = { code: err.body.code, message: err.body.message };
      reply.status(err.status).send({ ...err.body, requestId: req.requestId });
      return;
    }
    // Plugins we don't control (e.g. @fastify/rate-limit -- see server.ts's
    // errorResponseBuilder) throw a plain object/Error carrying its own
    // `statusCode` rather than our HttpError class. Honor that instead of
    // always coercing to 500, or a real 429/403 from the rate limiter would
    // silently come out of this API as a 500.
    const thrown = err as unknown as { statusCode?: number; code?: string; message?: string };
    if (typeof thrown.statusCode === "number" && thrown.statusCode >= 400 && thrown.statusCode < 500) {
      req.lastError = { code: thrown.code ?? "REQUEST_ERROR", message: thrown.message ?? err.message };
      const { statusCode, ...body } = thrown as Record<string, unknown>;
      reply.status(thrown.statusCode).send({ ...body, requestId: req.requestId });
      return;
    }
    req.log.error(err);
    req.lastError = { code: "INTERNAL_ERROR", message: err.message };
    reply.status(500).send({
      code: "INTERNAL_ERROR",
      message: "Something went wrong processing this request.",
      what: err.message,
      why: "An unhandled exception occurred in the API server.",
      diagnose: `Search server logs for requestId ${req.requestId}.`,
      fix: "Retry; if it persists, this is a bug -- please report it.",
      requestId: req.requestId,
    });
  });

  app.addHook("onResponse", async (req, reply) => {
    // CORS preflight (OPTIONS) requests are answered by @fastify/cors's own
    // onRequest hook -- registered ahead of this plugin's onRequest hook
    // below, so it short-circuits the chain and this plugin's hook (which
    // sets req.audit/req.startTimeMs) never runs for them. That used to
    // throw here (`req.audit.action` on an undefined req.audit) on every
    // single preflight in the app -- a real, previously-reported bug that
    // never broke the client-facing 204 (this hook runs after the response
    // is already sent) but did spam the server logs and skip the insert
    // below anyway. A preflight isn't a real action worth an audit row, so
    // just skip it outright rather than logging a synthetic one.
    if (req.method === "OPTIONS" || !req.audit) return;
    const durationMs = Date.now() - req.startTimeMs;
    const action = req.audit.action ?? `${req.method.toLowerCase()}:${req.routeOptions?.url ?? req.url}`;
    const status = reply.statusCode < 400 ? "SUCCESS" : "ERROR";
    try {
      await db.insert(auditLogs).values({
        orgId: req.audit.orgId ?? null,
        projectId: req.audit.projectId ?? null,
        userId: req.userId ?? null,
        ip: req.ip,
        userAgent: req.headers["user-agent"] ?? null,
        requestId: req.requestId,
        action,
        resourceType: req.audit.resourceType ?? null,
        resourceId: req.audit.resourceId ?? null,
        resourceName: req.audit.resourceName ?? null,
        previousState: req.audit.previousState ?? null,
        newState: req.audit.newState ?? null,
        status,
        error: req.lastError?.message ?? null,
        apiEndpoint: req.url,
        httpMethod: req.method,
        source: (req.headers["x-cloudlab-source"] as string) ?? "api",
        authMethod: req.userId ? "bearer" : null,
        durationMs,
      });
    } catch (auditErr) {
      // Audit logging must never take the API down, but it must be loud.
      req.log.error({ auditErr }, "audit log write failed");
    }
  });
}

import type { FastifyInstance } from "fastify";
import { and, desc, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { resourceTestRuns } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { getResource } from "../resources/model.js";
import { validationError } from "../errors.js";

const VALID_KINDS = new Set(["vm", "cloud_run", "gcs", "registry_image", "k8s_deployment"]);

interface TestStepResult {
  label: string;
  ok: boolean;
  detail: string;
}

/**
 * Persists the outcome of a real per-resource test (VM exec, Cloud Run
 * invoke, or bucket PUT/GET/DELETE round-trip -- see
 * apps/console/src/lib/cloudlab/test-actions.ts, the single place that
 * actually runs these against the live Docker-backed resource) and lets a
 * reopened RealTestPanel show the prior result instead of a blank slate.
 * This route never runs a test itself -- the console already did that
 * against the real resource-specific endpoints (exec, invoke, objects/:key)
 * before calling here -- it only records what genuinely happened, the same
 * "thin proxy to a real event" shape as resourceMetrics/resourceEvents.
 */
export function registerTestRunRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.get<{ Params: { projectId: string; resourceId: string }; Querystring: { limit?: string } }>(
      "/api/v1/projects/:projectId/resources/:resourceId/test-runs",
      async (req, reply) => {
        const { projectId, resourceId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "projects.get");
        await getResource(projectId, resourceId); // 404s if it's not this project's resource
        const limit = Math.max(1, Math.min(200, Number(req.query.limit) || 20));
        const rows = await db
          .select()
          .from(resourceTestRuns)
          .where(and(eq(resourceTestRuns.resourceId, resourceId), eq(resourceTestRuns.projectId, projectId)))
          .orderBy(desc(resourceTestRuns.ranAt))
          .limit(limit);
        reply.send(rows);
      },
    );

    app.post<{
      Params: { projectId: string; resourceId: string };
      Body: { kind?: string; ok?: boolean; steps?: TestStepResult[] };
    }>(
      "/api/v1/projects/:projectId/resources/:resourceId/test-runs",
      async (req, reply) => {
        const { projectId, resourceId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "projects.get");
        const { kind, ok, steps } = req.body ?? {};
        if (typeof kind !== "string" || !VALID_KINDS.has(kind)) {
          throw validationError(`kind must be one of: ${[...VALID_KINDS].join(", ")}`);
        }
        if (typeof ok !== "boolean") throw validationError("ok (boolean) is required");
        if (!Array.isArray(steps)) throw validationError("steps (array) is required");

        await getResource(projectId, resourceId); // 404s if it's not this project's resource

        const [row] = await db
          .insert(resourceTestRuns)
          .values({ resourceId, projectId, kind, ok, steps, ranBy: req.userId! })
          .returning();

        req.audit.action = "observability.testRuns.record";
        req.audit.projectId = projectId;
        req.audit.resourceId = resourceId;

        reply.status(201).send(row);
      },
    );
  });
}

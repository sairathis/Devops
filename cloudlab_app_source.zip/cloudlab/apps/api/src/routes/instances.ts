import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, getResourceById, createOperation, setResourceStatus } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict, notFound } from "../errors.js";
import { runCommand, getLogs, getStats } from "../adapters/docker/instance.js";
import { config } from "../config.js";
import { hasSharedVpcGrant } from "../iam/sharedVpc.js";
import { DEFAULT_ZONE, DEFAULT_MACHINE_TYPE, isValidZone, regionOfZone, GCP_REGIONS, MACHINE_TYPES } from "@cloudlab/shared";

// Milestone 15 (Shared VPC): resolves the target network the normal
// same-project way first; only falls back to the cross-project path when a
// real shared_vpc_attachment in the network's own (host) project explicitly
// names this project as the service project for this exact network. Every
// other resource type stays exactly as isolated as before -- this is the
// one deliberate, checked exception, not a general relaxation.
async function resolveTargetNetwork(projectId: string, networkId: string) {
  try {
    return await getResource(projectId, networkId);
  } catch (err) {
    const network = await getResourceById(networkId).catch(() => null);
    if (!network || network.type !== "network" || network.projectId === projectId) throw err;
    const granted = await hasSharedVpcGrant(network.projectId, projectId, networkId);
    if (!granted) throw notFound("network", networkId);
    return network;
  }
}

export function registerInstanceRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.get("/api/v1/projects/:projectId/instances/zones", async (_req, reply) => {
    // Milestone 16: same idea as /subnets/regions -- one server-side catalog
    // the console and any CLI both read, instead of a duplicated list that
    // can drift.
    reply.send({ regions: GCP_REGIONS, machineTypes: MACHINE_TYPES });
  });

  app.post<{ Params: { projectId: string }; Body: { name: string; networkId: string; subnetId?: string; zone?: string; machineType?: string; publish?: boolean; diskIds?: string[]; startupScript?: string } }>(
    "/api/v1/projects/:projectId/instances",
    async (req, reply) => {
      const { projectId } = req.params;
      await requireProjectPermission(req.userId!, projectId, "compute.instances.create");
      const { name, networkId, subnetId, zone, machineType, publish, diskIds, startupScript } = req.body ?? {};
      if (!name || !networkId) throw validationError("name and networkId are required");

      const resolvedZone = zone ?? DEFAULT_ZONE;
      if (!isValidZone(resolvedZone)) {
        throw validationError(`'${resolvedZone}' is not a known zone. Use one of: ${GCP_REGIONS.flatMap((r) => r.zones).join(", ")}.`);
      }
      const resolvedMachineType = machineType ?? DEFAULT_MACHINE_TYPE;
      if (!MACHINE_TYPES.some((m) => m.name === resolvedMachineType)) {
        throw validationError(`'${resolvedMachineType}' is not a known machine type. Use one of: ${MACHINE_TYPES.map((m) => m.name).join(", ")}.`);
      }

      for (const diskId of diskIds ?? []) {
        const disk = await getResource(projectId, diskId);
        if (disk.type !== "disk") throw validationError(`'${diskId}' is not a disk resource`);
        if (disk.status !== "READY") throw conflict(`Disk '${disk.name}' is not READY yet (status: ${disk.status}).`);
      }

      const network = await resolveTargetNetwork(projectId, networkId);
      if (network.type !== "network") throw validationError(`'${networkId}' is not a network resource`);
      if (network.status !== "READY") {
        throw conflict(`Network '${network.name}' is not READY yet (status: ${network.status}).`, {
          what: "The target network has not finished provisioning.",
          why: "Instances can only attach to a network once it is READY.",
          fix: `Wait for network '${network.name}' to become READY, then retry.`,
        });
      }
      if (subnetId) {
        const subnet = await getResource(projectId, subnetId);
        if (subnet.type !== "subnet") throw validationError(`'${subnetId}' is not a subnet resource`);
        if (subnet.status !== "READY") {
          throw conflict(`Subnet '${subnet.name}' is not READY yet (status: ${subnet.status}).`);
        }
        if ((subnet.spec as { networkId?: string }).networkId !== networkId) {
          throw validationError(`Subnet '${subnet.name}' does not belong to network '${network.name}'`);
        }
        // Real GCP constraint: an instance's zone must fall inside the
        // region its subnet was created in -- a subnet is regional, so a
        // zone from a different region genuinely cannot reach it.
        const subnetRegion = (subnet.spec as { region?: string }).region ?? subnet.region;
        if (subnetRegion && subnetRegion !== regionOfZone(resolvedZone)) {
          throw validationError(
            `Zone '${resolvedZone}' is in region '${regionOfZone(resolvedZone)}', but subnet '${subnet.name}' is in region '${subnetRegion}'. Pick a zone in the subnet's region, or a subnet in the instance's region.`,
          );
        }
      }

      const resource = await createResource({
        projectId,
        name,
        type: "instance",
        region: regionOfZone(resolvedZone),
        spec: { networkId, subnetId, zone: resolvedZone, machineType: resolvedMachineType, image: config.guestImage, publish: publish !== false, diskIds: diskIds ?? [], startupScript },
        createdBy: req.userId!,
      });
      const operation = await createOperation({ projectId, resourceId: resource.id, type: "instance.create", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("instance.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "instance.create" });

      req.audit.action = "compute.instances.create";
      req.audit.projectId = projectId;
      req.audit.resourceType = "instance";
      req.audit.resourceId = resource.id;
      req.audit.resourceName = resource.name;
      req.audit.newState = resource;

      reply.status(202).send({ resource, operationId: operation.id });
    },
  );

  app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/instances", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "compute.instances.list");
    reply.send(await listResources(req.params.projectId, "instance"));
  });

  app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instances/:id", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "compute.instances.get");
    reply.send(await getResource(req.params.projectId, req.params.id));
  });

  for (const action of ["start", "stop"] as const) {
    app.post<{ Params: { projectId: string; id: string } }>(
      `/api/v1/projects/:projectId/instances/:id/${action}`,
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, `compute.instances.${action}`);
        const resource = await getResource(projectId, id);

        await setResourceStatus(id, action === "start" ? "PROVISIONING" : "STOPPING");
        const operation = await createOperation({ projectId, resourceId: id, type: `instance.${action}`, createdBy: req.userId! });
        await operationsQueue.add(`instance.${action}`, { operationId: operation.id, projectId, resourceId: id, type: `instance.${action}` as const });

        req.audit.action = `compute.instances.${action}`;
        req.audit.projectId = projectId;
        req.audit.resourceType = "instance";
        req.audit.resourceId = id;
        req.audit.previousState = { status: resource.status };

        reply.status(202).send({ operationId: operation.id });
      },
    );
  }

  // Milestone 11: fault injection. A real docker kill -SIGKILL against this
  // instance's actual container -- see apps/worker/src/processors/instanceFault.ts
  // for what genuinely happens and why it stays down until a real Start.
  app.post<{ Params: { projectId: string; id: string } }>(
    "/api/v1/projects/:projectId/instances/:id/faults/crash",
    async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "compute.instances.fault");
      const resource = await getResource(projectId, id);
      if (resource.status !== "READY") throw conflict(`instance must be READY to crash it (currently ${resource.status})`);

      const operation = await createOperation({ projectId, resourceId: id, type: "instance.crash", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("instance.crash", { operationId: operation.id, projectId, resourceId: id, type: "instance.crash" });

      req.audit.action = "compute.instances.fault";
      req.audit.projectId = projectId;
      req.audit.resourceType = "instance";
      req.audit.resourceId = id;
      req.audit.previousState = { status: resource.status };

      reply.status(202).send({ operationId: operation.id });
    },
  );

  app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instances/:id", async (req, reply) => {
    const { projectId, id } = req.params;
    await requireProjectPermission(req.userId!, projectId, "compute.instances.delete");
    await getResource(projectId, id);

    await setResourceStatus(id, "DELETING");
    const operation = await createOperation({ projectId, resourceId: id, type: "instance.delete", createdBy: req.userId!, requestId: req.requestId });
    await operationsQueue.add("instance.delete", { operationId: operation.id, projectId, resourceId: id, type: "instance.delete" });

    req.audit.action = "compute.instances.delete";
    req.audit.projectId = projectId;
    req.audit.resourceType = "instance";
    req.audit.resourceId = id;

    reply.status(202).send({ operationId: operation.id });
  });

  app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instances/:id/logs", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "compute.instances.get");
    const resource = await getResource(req.params.projectId, req.params.id);
    if (resource.status === "CREATING" || resource.status === "PROVISIONING") {
      reply.send({ logs: "" });
      return;
    }
    const logs = await getLogs(req.params.id);
    reply.send({ logs });
  });

  app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instances/:id/stats", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "compute.instances.get");
    const resource = await getResource(req.params.projectId, req.params.id);
    if (resource.status !== "READY") {
      reply.send({ cpuPercent: 0, memUsageMb: 0, memLimitMb: 0, networkRxBytes: 0, networkTxBytes: 0, sampledAt: new Date().toISOString(), note: `instance is ${resource.status}, not READY` });
      return;
    }
    reply.send(await getStats(req.params.id));
  });

  app.post<{ Params: { projectId: string; id: string }; Body: { command: string } }>(
    "/api/v1/projects/:projectId/instances/:id/exec",
    async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.instances.exec");
      const { command } = req.body ?? {};
      if (!command) throw validationError("command is required");
      const resource = await getResource(req.params.projectId, req.params.id);
      if (resource.status !== "READY") {
        throw conflict(`Instance '${resource.name}' is not READY (status: ${resource.status}); cannot exec.`);
      }

      const result = await runCommand(req.params.id, command);

      req.audit.action = "compute.instances.exec";
      req.audit.projectId = req.params.projectId;
      req.audit.resourceType = "instance";
      req.audit.resourceId = req.params.id;
      req.audit.newState = { command, exitCode: result.exitCode };

      reply.send(result);
    },
  );
  });
}

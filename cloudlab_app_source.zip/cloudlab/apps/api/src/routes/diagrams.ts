import type { FastifyInstance } from "fastify";
import { and, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { architectureDiagrams } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { validationError, notFound } from "../errors.js";

// Architecture Builder's saved diagrams -- replaces CloudVerse's
// localStorage-only `saveProject/loadProject/deleteProject` (see
// src/store/architecture-store.ts in apps/console) with real rows scoped to
// a real CloudLab project, so a diagram survives a browser reset and is
// visible to anyone else on the project.
export function registerDiagramRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/diagrams", async (req, reply) => {
      const { projectId } = req.params;
      await requireProjectPermission(req.userId!, projectId, "architecture.diagrams.read");
      const rows = await db
        .select()
        .from(architectureDiagrams)
        .where(eq(architectureDiagrams.projectId, projectId));
      reply.send(rows);
    });

    app.post<{ Params: { projectId: string }; Body: { name: string; nodes: unknown; edges: unknown } }>(
      "/api/v1/projects/:projectId/diagrams",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "architecture.diagrams.create");
        const { name, nodes, edges } = req.body ?? {};
        if (!name) throw validationError("name is required");
        const [created] = await db
          .insert(architectureDiagrams)
          .values({ projectId, userId: req.userId!, name, nodes: nodes ?? [], edges: edges ?? [] })
          .returning();
        reply.status(201).send(created);
      },
    );

    app.put<{ Params: { projectId: string; id: string }; Body: { name?: string; nodes?: unknown; edges?: unknown } }>(
      "/api/v1/projects/:projectId/diagrams/:id",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "architecture.diagrams.update");
        const [existing] = await db
          .select()
          .from(architectureDiagrams)
          .where(and(eq(architectureDiagrams.id, id), eq(architectureDiagrams.projectId, projectId)))
          .limit(1);
        if (!existing) throw notFound("diagram", id);

        const { name, nodes, edges } = req.body ?? {};
        const [updated] = await db
          .update(architectureDiagrams)
          .set({
            name: name ?? existing.name,
            nodes: nodes ?? existing.nodes,
            edges: edges ?? existing.edges,
            updatedAt: new Date(),
          })
          .where(eq(architectureDiagrams.id, id))
          .returning();
        reply.send(updated);
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>(
      "/api/v1/projects/:projectId/diagrams/:id",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "architecture.diagrams.delete");
        const [existing] = await db
          .select()
          .from(architectureDiagrams)
          .where(and(eq(architectureDiagrams.id, id), eq(architectureDiagrams.projectId, projectId)))
          .limit(1);
        if (!existing) throw notFound("diagram", id);
        await db.delete(architectureDiagrams).where(eq(architectureDiagrams.id, id));
        reply.status(204).send();
      },
    );
  });
}

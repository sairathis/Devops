import type { FastifyInstance } from "fastify";
import { and, eq, sql } from "drizzle-orm";
import { db } from "../db/client.js";
import {
  academyUserStats,
  academyModuleProgress,
  academyQuizScores,
  academyBadges,
  academyCertificationTopics,
} from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { validationError } from "../errors.js";

// ---------------------------------------------------------------------------
// CloudVerse DevOps Academy learning layer: module progress, XP/streaks,
// quiz scores, badges, certification-path completion -- all real rows keyed
// to the authenticated user (req.userId from a real JWT), replacing what
// used to be Zustand `persist` state living only in the browser's
// localStorage. See db/schema.ts for why this is real-but-client-reported,
// unlike the `resources` table.
// ---------------------------------------------------------------------------

function todayUtc(): string {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD
}

function daysBetween(a: string, b: string): number {
  const msPerDay = 24 * 60 * 60 * 1000;
  return Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / msPerDay);
}

async function getOrCreateStats(userId: string) {
  const [existing] = await db.select().from(academyUserStats).where(eq(academyUserStats.userId, userId)).limit(1);
  if (existing) return existing;
  const [created] = await db
    .insert(academyUserStats)
    .values({ userId })
    .onConflictDoNothing()
    .returning();
  if (created) return created;
  const [row] = await db.select().from(academyUserStats).where(eq(academyUserStats.userId, userId)).limit(1);
  return row;
}

export function registerAcademyRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    // ---- Full snapshot, used to hydrate the console's stores on load ----
    app.get("/api/v1/academy/progress", async (req, reply) => {
      const userId = req.userId!;
      const [stats, modules, quizzes, badges, certTopics] = await Promise.all([
        getOrCreateStats(userId),
        db.select().from(academyModuleProgress).where(eq(academyModuleProgress.userId, userId)),
        db.select().from(academyQuizScores).where(eq(academyQuizScores.userId, userId)),
        db.select().from(academyBadges).where(eq(academyBadges.userId, userId)),
        db.select().from(academyCertificationTopics).where(eq(academyCertificationTopics.userId, userId)),
      ]);

      reply.send({
        totalXp: stats?.totalXp ?? 0,
        level: Math.floor((stats?.totalXp ?? 0) / 500) + 1,
        streakDays: stats?.streakDays ?? 0,
        lastActiveDate: stats?.lastActiveDate ?? null,
        modules: Object.fromEntries(
          modules.map((m) => [m.moduleId, { moduleId: m.moduleId, percent: m.percent, xp: m.xp, lastVisited: m.lastVisitedAt }]),
        ),
        quizScores: Object.fromEntries(quizzes.map((q) => [q.subjectKey, { correct: q.correct, total: q.total }])),
        badges: badges.map((b) => ({ id: b.badgeKey, label: b.label, description: b.description, icon: b.icon, earnedAt: b.earnedAt })),
        completedTopics: Object.fromEntries(certTopics.map((c) => [`${c.pathId}:${c.topicId}`, true])),
      });
    });

    // ---- Module progress (percent only ever ratchets forward) ----
    app.post<{ Params: { moduleId: string }; Body: { percent: number } }>(
      "/api/v1/academy/modules/:moduleId/progress",
      async (req, reply) => {
        const userId = req.userId!;
        const { moduleId } = req.params;
        const { percent } = req.body ?? { percent: undefined as unknown as number };
        if (typeof percent !== "number" || percent < 0 || percent > 100) {
          throw validationError("percent must be a number between 0 and 100");
        }

        // A single atomic upsert rather than select-then-insert-or-update:
        // the latter has a check-then-act race (two concurrent requests for
        // the same user+module — e.g. React 18 dev StrictMode double-firing
        // the mount effect that reports initial progress — can both see "no
        // existing row" and both try to INSERT, and the loser 500s on the
        // unique constraint). onConflictDoUpdate lets Postgres itself
        // serialize the ratchet-forward via GREATEST(...) against the row
        // that would have been inserted ("excluded").
        const [row] = await db
          .insert(academyModuleProgress)
          .values({ userId, moduleId, percent })
          .onConflictDoUpdate({
            target: [academyModuleProgress.userId, academyModuleProgress.moduleId],
            set: {
              percent: sql`GREATEST(${academyModuleProgress.percent}, excluded.percent)`,
              lastVisitedAt: new Date(),
            },
          })
          .returning({ percent: academyModuleProgress.percent });
        reply.send({ moduleId, percent: row.percent });
      },
    );

    // ---- XP + server-derived streak ----
    app.post<{ Body: { amount: number; moduleId?: string } }>("/api/v1/academy/xp", async (req, reply) => {
      const userId = req.userId!;
      const { amount, moduleId } = req.body ?? { amount: undefined as unknown as number };
      if (typeof amount !== "number" || amount <= 0 || amount > 10000) {
        throw validationError("amount must be a positive number");
      }

      const stats = await getOrCreateStats(userId);
      const today = todayUtc();
      let streakDays = stats.streakDays;
      if (!stats.lastActiveDate) {
        streakDays = 1;
      } else {
        const diff = daysBetween(stats.lastActiveDate, today);
        if (diff === 0) streakDays = Math.max(1, stats.streakDays);
        else if (diff === 1) streakDays = stats.streakDays + 1;
        else if (diff > 1) streakDays = 1;
        // diff < 0 (clock skew): leave streak untouched
      }

      const totalXp = stats.totalXp + amount;
      await db
        .update(academyUserStats)
        .set({ totalXp, streakDays, lastActiveDate: today, updatedAt: new Date() })
        .where(eq(academyUserStats.userId, userId));

      if (moduleId) {
        // Same atomic-upsert reasoning as the /progress route above — avoid
        // a check-then-act race between concurrent XP awards for the same
        // user+module.
        await db
          .insert(academyModuleProgress)
          .values({ userId, moduleId, xp: amount, percent: 0 })
          .onConflictDoUpdate({
            target: [academyModuleProgress.userId, academyModuleProgress.moduleId],
            set: {
              xp: sql`${academyModuleProgress.xp} + excluded.xp`,
              lastVisitedAt: new Date(),
            },
          });
      }

      reply.send({ totalXp, level: Math.floor(totalXp / 500) + 1, streakDays, lastActiveDate: today });
    });

    // ---- Quiz scores (per resource type / module subject) ----
    app.post<{ Body: { subjectKey: string; correct: boolean } }>("/api/v1/academy/quiz", async (req, reply) => {
      const userId = req.userId!;
      const { subjectKey, correct } = req.body ?? {};
      if (!subjectKey || typeof correct !== "boolean") {
        throw validationError("subjectKey and correct (boolean) are required");
      }

      // Atomic upsert — same check-then-act race as module progress above
      // (two quiz answers submitted back-to-back could otherwise both read
      // "no existing row" and collide on insert).
      const [row] = await db
        .insert(academyQuizScores)
        .values({ userId, subjectKey, correct: correct ? 1 : 0, total: 1 })
        .onConflictDoUpdate({
          target: [academyQuizScores.userId, academyQuizScores.subjectKey],
          set: {
            correct: sql`${academyQuizScores.correct} + excluded.correct`,
            total: sql`${academyQuizScores.total} + excluded.total`,
            updatedAt: new Date(),
          },
        })
        .returning({ correct: academyQuizScores.correct, total: academyQuizScores.total });
      reply.send({ subjectKey, correct: row.correct, total: row.total });
    });

    // ---- Badges (idempotent: awarding the same badgeKey twice is a no-op) ----
    app.post<{ Body: { badgeKey: string; label: string; description: string; icon: string } }>(
      "/api/v1/academy/badges",
      async (req, reply) => {
        const userId = req.userId!;
        const { badgeKey, label, description, icon } = req.body ?? {};
        if (!badgeKey || !label) throw validationError("badgeKey and label are required");

        // insert().onConflictDoNothing().returning() instead of
        // select-then-insert: avoids the same check-then-act race as module
        // progress / quiz scores above (badges can legitimately be "awarded"
        // from more than one place in the UI in quick succession).
        const [created] = await db
          .insert(academyBadges)
          .values({ userId, badgeKey, label, description: description ?? "", icon: icon ?? "award" })
          .onConflictDoNothing()
          .returning();
        if (created) {
          reply.status(201).send({ id: created.badgeKey, label: created.label, description: created.description, icon: created.icon, earnedAt: created.earnedAt, alreadyEarned: false });
          return;
        }

        const [existing] = await db
          .select()
          .from(academyBadges)
          .where(and(eq(academyBadges.userId, userId), eq(academyBadges.badgeKey, badgeKey)))
          .limit(1);
        reply.send({ id: existing.badgeKey, label: existing.label, description: existing.description, icon: existing.icon, earnedAt: existing.earnedAt, alreadyEarned: true });
      },
    );

    // ---- Certification path topic completion ----
    app.post<{ Params: { pathId: string; topicId: string } }>(
      "/api/v1/academy/certifications/:pathId/topics/:topicId",
      async (req, reply) => {
        const userId = req.userId!;
        const { pathId, topicId } = req.params;
        await db
          .insert(academyCertificationTopics)
          .values({ userId, pathId, topicId })
          .onConflictDoNothing();
        reply.send({ pathId, topicId, completed: true });
      },
    );

    app.delete<{ Params: { pathId: string; topicId: string } }>(
      "/api/v1/academy/certifications/:pathId/topics/:topicId",
      async (req, reply) => {
        const userId = req.userId!;
        const { pathId, topicId } = req.params;
        await db
          .delete(academyCertificationTopics)
          .where(
            and(
              eq(academyCertificationTopics.userId, userId),
              eq(academyCertificationTopics.pathId, pathId),
              eq(academyCertificationTopics.topicId, topicId),
            ),
          );
        reply.send({ pathId, topicId, completed: false });
      },
    );
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { getResource } from "../resources/model.js";
import { validationError, conflict } from "../errors.js";

// Real object-level PUT/GET/LIST/DELETE against a bucket's already-real
// per-bucket object-store container (infra/bucket-image/store.go -- a genuine
// Go HTTP server doing real disk I/O, published on a real host port by
// apps/worker/src/processors/bucket.ts). That server has always been real;
// it just had no route in CloudLab's own API forwarding to it, so nothing in
// either console could reach it. These routes are a thin, synchronous proxy
// -- no operation/queue involved, the same pattern already used for Cloud
// Run's "invoke".
interface BucketMetadata {
  containerId?: string;
  hostPort?: string;
  endpoint?: string;
}

// processBucketCreate (apps/worker/src/processors/bucket.ts) records the
// container/endpoint via setResourceStatus's `metadata` merge, not `spec`
// (spec is reserved for user-supplied/desired config; metadata is
// runtime-observed state) -- read it from the same place it was written.
async function requireReadyBucketEndpoint(projectId: string, id: string): Promise<string> {
  const resource = await getResource(projectId, id);
  if (resource.type !== "bucket") throw validationError(`'${id}' is not a bucket resource`);
  if (resource.status !== "READY") throw conflict(`Bucket '${resource.name}' is not READY (status: ${resource.status})`);
  const metadata = (resource.metadata as BucketMetadata) ?? {};
  if (!metadata.endpoint) throw conflict(`Bucket '${resource.name}' has no real object-store endpoint recorded.`);
  return metadata.endpoint;
}

export function registerBucketObjectRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    // List every real object currently stored in this bucket.
    app.get<{ Params: { projectId: string; id: string } }>(
      "/api/v1/projects/:projectId/buckets/:id/objects",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "storage.buckets.get");
        const endpoint = await requireReadyBucketEndpoint(projectId, id);
        const res = await fetch(`${endpoint}/`, { signal: AbortSignal.timeout(5000) });
        const body = await res.json().catch(() => null);
        reply.status(res.status).send(body);
      },
    );

    // Upload (or overwrite) one real object -- a genuine PUT to the store's disk.
    app.put<{ Params: { projectId: string; id: string; key: string }; Body: { content: string } }>(
      "/api/v1/projects/:projectId/buckets/:id/objects/:key",
      async (req, reply) => {
        const { projectId, id, key } = req.params;
        await requireProjectPermission(req.userId!, projectId, "storage.buckets.create");
        const { content } = req.body ?? {};
        if (typeof content !== "string") throw validationError("content (string) is required");
        const endpoint = await requireReadyBucketEndpoint(projectId, id);
        const res = await fetch(`${endpoint}/${encodeURIComponent(key)}`, {
          method: "PUT",
          body: content,
          signal: AbortSignal.timeout(5000),
        });
        const etag = res.headers.get("etag");

        req.audit.action = "storage.buckets.putObject";
        req.audit.projectId = projectId;
        req.audit.resourceType = "bucket";
        req.audit.resourceId = id;
        req.audit.newState = { key, bytes: content.length, etag };

        reply.status(res.status).send({ key, bytes: content.length, etag, ok: res.ok });
      },
    );

    // Download one real object's content back.
    app.get<{ Params: { projectId: string; id: string; key: string } }>(
      "/api/v1/projects/:projectId/buckets/:id/objects/:key",
      async (req, reply) => {
        const { projectId, id, key } = req.params;
        await requireProjectPermission(req.userId!, projectId, "storage.buckets.get");
        const endpoint = await requireReadyBucketEndpoint(projectId, id);
        const res = await fetch(`${endpoint}/${encodeURIComponent(key)}`, { signal: AbortSignal.timeout(5000) });
        if (!res.ok) {
          reply.status(res.status).send({ message: res.status === 404 ? "Object not found" : "Object store error" });
          return;
        }
        const content = await res.text();
        reply.send({ key, content, etag: res.headers.get("etag") });
      },
    );

    // Delete one real object.
    app.delete<{ Params: { projectId: string; id: string; key: string } }>(
      "/api/v1/projects/:projectId/buckets/:id/objects/:key",
      async (req, reply) => {
        const { projectId, id, key } = req.params;
        await requireProjectPermission(req.userId!, projectId, "storage.buckets.delete");
        const endpoint = await requireReadyBucketEndpoint(projectId, id);
        const res = await fetch(`${endpoint}/${encodeURIComponent(key)}`, { method: "DELETE", signal: AbortSignal.timeout(5000) });

        req.audit.action = "storage.buckets.deleteObject";
        req.audit.projectId = projectId;
        req.audit.resourceType = "bucket";
        req.audit.resourceId = id;
        req.audit.newState = { key, deleted: res.ok };

        reply.status(res.ok ? 200 : res.status).send({ key, deleted: res.ok });
      },
    );
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

export function registerImageRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{
      Params: { projectId: string };
      Body: { name: string; registryId: string; tag?: string; dockerfile: string; contextFiles?: { path: string; content: string }[] };
    }>(
      "/api/v1/projects/:projectId/images",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "registry.images.create");
        const { name, registryId, tag, dockerfile, contextFiles } = req.body ?? {};
        if (!name || !registryId || !dockerfile) throw validationError("name, registryId and dockerfile are required");
        const registry = await getResource(projectId, registryId);
        if (registry.type !== "registry") throw validationError(`'${registryId}' is not a registry resource`);
        if (registry.status !== "READY") throw conflict(`Registry '${registry.name}' is not READY yet (status: ${registry.status}).`);
        if (contextFiles && (!Array.isArray(contextFiles) || contextFiles.some((f) => typeof f?.path !== "string" || typeof f?.content !== "string"))) {
          throw validationError("contextFiles must be an array of { path, content } strings");
        }

        const resource = await createResource({
          projectId,
          name,
          type: "container_image",
          // contextFiles are extra build-context entries beyond the
          // Dockerfile itself -- lets a real `COPY <src> <dest>` instruction
          // actually resolve (e.g. Docker Lab's COPY package.json rows)
          // instead of only ever working for self-referential
          // `COPY Dockerfile ...` tricks. See processContainerImageCreate.
          spec: { registryId, name, tag: tag || "latest", dockerfile, contextFiles: contextFiles ?? [] },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "container_image.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("container_image.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "container_image.create" });

        req.audit.action = "registry.images.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "container_image";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/images", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.images.list");
      reply.send(await listResources(req.params.projectId, "container_image"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/images/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.images.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/images/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "registry.images.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "container_image.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("container_image.delete", { operationId: operation.id, projectId, resourceId: id, type: "container_image.delete" });

      req.audit.action = "registry.images.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "container_image";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

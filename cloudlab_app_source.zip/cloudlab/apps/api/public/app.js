// CloudLab console -- plain ES modules, no build step, no framework.
// Talks to the same REST API a CLI or Terraform provider would use.

const root = document.getElementById("app");

// Milestone 16: mirrors packages/shared's GCP_REGIONS/MACHINE_TYPES -- the
// server is still the source of truth and validates every request against
// its own copy, this is just so the region/zone/machine-type dropdowns
// below have something to render before the first API round trip.
const GCP_REGIONS = [
  { region: "us-central1", location: "Iowa, USA", zones: ["us-central1-a", "us-central1-b", "us-central1-c"] },
  { region: "us-east1", location: "South Carolina, USA", zones: ["us-east1-b", "us-east1-c", "us-east1-d"] },
  { region: "europe-west1", location: "Belgium", zones: ["europe-west1-b", "europe-west1-c", "europe-west1-d"] },
  { region: "asia-south1", location: "Mumbai, India", zones: ["asia-south1-a", "asia-south1-b", "asia-south1-c"] },
  { region: "australia-southeast1", location: "Sydney, Australia", zones: ["australia-southeast1-a", "australia-southeast1-b", "australia-southeast1-c"] },
];
const GCP_ZONES = GCP_REGIONS.flatMap((r) => r.zones);
const MACHINE_TYPES = [
  { name: "e2-micro", vcpus: 1, memoryMb: 512, description: "1 shared vCPU, 512 MB memory" },
  { name: "e2-small", vcpus: 1, memoryMb: 1024, description: "1 shared vCPU, 1 GB memory" },
  { name: "e2-medium", vcpus: 1, memoryMb: 2048, description: "1 vCPU, 2 GB memory" },
  { name: "e2-standard-2", vcpus: 2, memoryMb: 4096, description: "2 vCPUs, 4 GB memory" },
  { name: "e2-standard-4", vcpus: 4, memoryMb: 8192, description: "4 vCPUs, 8 GB memory" },
];
function regionOfZone(zone) { return zone.replace(/-[a-z]$/, ""); }

const state = {
  token: localStorage.getItem("cloudlab_token") || null,
  user: JSON.parse(localStorage.getItem("cloudlab_user") || "null"),
  orgs: [],
  projects: [],
  orgId: localStorage.getItem("cloudlab_org") || null,
  projectId: localStorage.getItem("cloudlab_project") || null,
  project: null,
  tab: "dashboard",
  networks: [],
  subnets: [],
  firewallRules: [],
  dnsRecords: [],
  loadBalancers: [],
  disks: [],
  registries: [],
  images: [],
  buckets: [],
  databases: [],
  secrets: [],
  k8sClusters: [],
  k8sDeployments: [],
  pipelines: [],
  pipelineRuns: [],
  serviceAccounts: [],
  instanceTemplates: [],
  managedInstanceGroups: [],
  natGateways: [],
  vpcPeerings: [],
  sharedVpcAttachments: [],
  bigqueryDatasets: [],
  bigqueryQueryResults: {}, // resourceId -> { sql, rows, error } -- survives render()'s full DOM rebuild; see renderBigquery
  composerEnvironments: [],
  cloudRunServices: [],
  alerts: [],
  scenarios: [],
  instances: [],
  activity: { items: [], page: 1, pageSize: 50, total: 0, hasMore: false },
  audit: { items: [], page: 1, pageSize: 50, total: 0, hasMore: false },
  graph: { nodes: [], edges: [] },
  iam: { roles: [], bindings: [] },
  pendingOps: {}, // resourceId -> { operationId, status, steps: [] }
  error: null,
  authMode: "login",
  ws: null,
};

// ---------------------------------------------------------------- API layer

async function api(path, opts = {}) {
  const headers = { "content-type": "application/json", ...(opts.headers || {}) };
  if (state.token) headers.authorization = `Bearer ${state.token}`;
  const res = await fetch(`/api/v1${path}`, { ...opts, headers });
  const isJson = res.headers.get("content-type")?.includes("application/json");
  const body = isJson ? await res.json() : await res.text();
  if (!res.ok) {
    const err = new Error(body?.message || res.statusText);
    err.body = body;
    throw err;
  }
  return body;
}

function setToken(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem("cloudlab_token", token);
  localStorage.setItem("cloudlab_user", JSON.stringify(user));
}

function logout() {
  state.token = null;
  state.user = null;
  state.orgId = null;
  state.projectId = null;
  stopStatsPolling();
  stopLiveTerminal();
  closeWs();
  localStorage.removeItem("cloudlab_token");
  localStorage.removeItem("cloudlab_user");
  localStorage.removeItem("cloudlab_org");
  localStorage.removeItem("cloudlab_project");
  render();
}

// -------------------------------------------------------------- WebSocket

function connectWs() {
  closeWs();
  if (!state.projectId) return;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws?token=${encodeURIComponent(state.token)}&projectId=${state.projectId}`);
  ws.addEventListener("message", (evt) => {
    let msg;
    try { msg = JSON.parse(evt.data); } catch { return; }
    handleWsMessage(msg);
  });
  state.ws = ws;
}

function closeWs() {
  state.ws?.close();
  state.ws = null;
}

// Maps every resource type to the state array its table renders from, so a
// WS resource.update patches the exact row a create form is waiting on
// live -- previously this only recognized "network" and "instance",
// leaving every other resource's table (including all 9 Milestone-15
// types) to update only on the next manual refresh/tab-switch, an
// inconsistency real GCP's own live-updating console would never have.
const RESOURCE_TYPE_TO_STATE_KEY = {
  network: "networks",
  subnet: "subnets",
  firewall_rule: "firewallRules",
  dns_record: "dnsRecords",
  load_balancer: "loadBalancers",
  disk: "disks",
  registry: "registries",
  container_image: "images",
  bucket: "buckets",
  database: "databases",
  secret: "secrets",
  k8s_cluster: "k8sClusters",
  k8s_deployment: "k8sDeployments",
  pipeline: "pipelines",
  pipeline_run: "pipelineRuns",
  instance: "instances",
  service_account: "serviceAccounts",
  instance_template: "instanceTemplates",
  managed_instance_group: "managedInstanceGroups",
  nat_gateway: "natGateways",
  vpc_peering: "vpcPeerings",
  shared_vpc_attachment: "sharedVpcAttachments",
  bigquery_dataset: "bigqueryDatasets",
  composer_environment: "composerEnvironments",
  cloud_run_service: "cloudRunServices",
};

function handleWsMessage(msg) {
  if (msg.type === "resource.update" && msg.resource) {
    const stateKey = RESOURCE_TYPE_TO_STATE_KEY[msg.resource.type];
    const list = stateKey ? state[stateKey] : undefined;
    if (!list) return; // unknown/derived type -- nothing to patch
    const idx = list.findIndex((r) => r.id === msg.resource.id);
    if (idx >= 0) list[idx] = msg.resource;
    else list.push(msg.resource);
    if (msg.resource.status !== "PENDING" && msg.resource.status !== "CREATING") {
      // once terminal-ish, drop the inline pending panel shortly after
    }
    // The architecture diagram is a point-in-time render of real graph
    // data (see renderArchitecture/buildProjectGraph) rather than something
    // patched field-by-field from WS events -- but leaving it stale while
    // the tab is open would defeat the point of a *live* topology view, so
    // debounce a real re-fetch of /architecture whenever it's the active
    // tab and something in the project just changed.
    if (state.tab === "architecture") scheduleArchitectureRefresh();
    renderMain();
  } else if (msg.type === "operation.step") {
    const entry = findPendingByOp(msg.operationId);
    if (entry) {
      entry.steps.push(msg.step);
      renderMain();
    }
  } else if (msg.type === "operation.update") {
    const entry = findPendingByOp(msg.operationId);
    if (entry) {
      entry.status = msg.status;
      entry.error = msg.error;
      renderMain();
      if (msg.status === "SUCCEEDED" || msg.status === "FAILED") {
        setTimeout(() => {
          delete state.pendingOps[entry.resourceId];
          renderMain();
        }, 4000);
      }
    }
  }
}

function findPendingByOp(operationId) {
  return Object.values(state.pendingOps).find((p) => p.operationId === operationId);
}

let architectureRefreshTimer = null;
function scheduleArchitectureRefresh() {
  clearTimeout(architectureRefreshTimer);
  architectureRefreshTimer = setTimeout(async () => {
    if (state.tab !== "architecture" || !state.projectId) return;
    try {
      state.graph = await api(`/projects/${state.projectId}/architecture`);
      renderMain();
    } catch { /* best-effort live refresh; next poll or tab switch will catch up */ }
  }, 500);
}

function trackOperation(resourceId, operationId) {
  state.pendingOps[resourceId] = { resourceId, operationId, status: "PENDING", steps: [] };
}

// ------------------------------------------------------------------ Utils

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return node;
}

function badge(status) {
  return el("span", { class: `badge ${status}` }, status);
}

const SVG_NS = "http://www.w3.org/2000/svg";
function svg(tag, attrs = {}, children = []) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return node;
}

function fmtTime(iso) {
  return new Date(iso).toLocaleString();
}

let errorAutoDismissTimer = null;
async function withErrorHandling(fn) {
  clearTimeout(errorAutoDismissTimer);
  try {
    state.error = null;
    await fn();
  } catch (err) {
    state.error = err.body?.message ? `${err.body.code}: ${err.body.message}` : err.message;
    // A validation/conflict error stays up long enough to actually read even
    // though renderMain() now redraws it faithfully on every background WS
    // tick (see renderMain()'s comment) -- but it shouldn't linger forever,
    // so it clears itself after a bit, same as the toast a real console uses.
    errorAutoDismissTimer = setTimeout(() => {
      state.error = null;
      renderMain();
    }, 10000);
  }
  render();
}

// A single error banner used by every screen that can show state.error --
// dismissible immediately, or it clears itself (see withErrorHandling).
function errorBanner() {
  if (!state.error) return null;
  return el("div", { class: "error-banner" }, [
    el("span", {}, state.error),
    el("button", { class: "dismiss", title: "Dismiss", onclick: () => { clearTimeout(errorAutoDismissTimer); state.error = null; renderMain(); } }, "×"),
  ]);
}

// ------------------------------------------------------------------ Views

function renderAuth() {
  const isLogin = state.authMode === "login";
  const form = el("form", {
    class: "stack",
    onsubmit: (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form));
      withErrorHandling(async () => {
        const body = isLogin
          ? await api("/auth/login", { method: "POST", body: JSON.stringify({ email: data.email, password: data.password }) })
          : await api("/auth/register", { method: "POST", body: JSON.stringify(data) });
        setToken(body.token, body.user);
        await loadOrgs();
      });
    },
  }, [
    !isLogin ? el("label", { class: "field" }, ["Name", el("input", { name: "name", required: "true" })]) : null,
    el("label", { class: "field" }, ["Email", el("input", { name: "email", type: "email", required: "true" })]),
    el("label", { class: "field" }, ["Password", el("input", { name: "password", type: "password", minlength: "8", required: "true" })]),
    el("button", { class: "btn primary", type: "submit" }, isLogin ? "Log in" : "Create account"),
  ]);

  return el("div", { class: "center-screen" }, [
    el("div", { class: "card narrow" }, [
      el("h1", {}, ["Cloud", el("span", { style: "color:var(--accent)" }, "Lab")]),
      el("p", { class: "subtitle" }, ["A GCP-like console backed by real infrastructure."]),
      errorBanner(),
      form,
      el("p", { class: "subtitle", style: "margin-top:14px" }, [
        isLogin ? "No account yet? " : "Already have an account? ",
        el("a", { href: "#", onclick: (e) => { e.preventDefault(); state.authMode = isLogin ? "register" : "login"; render(); } }, isLogin ? "Register" : "Log in"),
      ]),
    ]),
  ]);
}

function renderTopbar() {
  const orgSelect = el("select", {
    onchange: (e) => withErrorHandling(async () => {
      state.orgId = e.target.value;
      localStorage.setItem("cloudlab_org", state.orgId);
      state.projectId = null;
      await loadProjects();
    }),
  }, state.orgs.map((o) => el("option", { value: o.id, selected: o.id === state.orgId ? "true" : null }, o.name)));

  const projectSelect = el("select", {
    onchange: (e) => withErrorHandling(async () => {
      await selectProject(e.target.value);
    }),
  }, [
    el("option", { value: "" }, "Select a project..."),
    ...state.projects.filter((p) => p.orgId === state.orgId).map((p) =>
      el("option", { value: p.id, selected: p.id === state.projectId ? "true" : null }, p.name)),
  ]);

  return el("div", { class: "topbar" }, [
    el("div", { class: "brand" }, ["Cloud", el("span", { class: "dot" }, "Lab")]),
    state.orgs.length ? orgSelect : null,
    state.orgId ? projectSelect : null,
    el("div", { class: "spacer" }),
    el("span", { class: "user" }, state.user?.email || ""),
    el("button", { class: "btn small", onclick: logout }, "Log out"),
  ]);
}

const NAV_ITEMS = [
  ["dashboard", "Dashboard"],
  ["networks", "Networking"],
  ["firewall", "Firewall"],
  ["dns", "DNS"],
  ["loadbalancers", "Load Balancers"],
  ["disks", "Disks"],
  ["instances", "Compute"],
  ["registry", "Registry"],
  ["storage", "Storage"],
  ["databases", "Databases"],
  ["secrets", "Secrets"],
  ["kubernetes", "Kubernetes"],
  ["cicd", "CI/CD"],
  ["serviceaccounts", "Service Accounts"],
  ["instancegroups", "Instance Groups"],
  ["natpeering", "NAT & Peering"],
  ["bigquery", "BigQuery"],
  ["composer", "Composer"],
  ["cloudrun", "Cloud Run"],
  ["observability", "Observability"],
  ["architecture", "Architecture"],
  ["learning", "Learning"],
  ["activity", "Activity"],
  ["audit", "Audit Log"],
  ["iam", "IAM"],
];

function renderNav() {
  return el("div", { class: "nav" }, NAV_ITEMS.map(([key, label]) =>
    el("a", {
      href: "#", class: state.tab === key ? "active" : "",
      onclick: (e) => {
        e.preventDefault();
        stopStatsPolling();
        stopLiveTerminal();
        if (key !== "architecture") graphSelectedId = null;
        state.tab = key;
        renderMain();
        // Architecture/Activity/Audit/IAM are point-in-time snapshots only
        // refreshed via refreshTabData(), never patched by WS messages like
        // networks/instances are -- so without this, switching to one of
        // these tabs shows whatever was true when the project was first
        // opened. Networks/Compute are deliberately excluded: they hold
        // create-resource forms, and re-rendering mid-fetch would wipe out
        // whatever the user is currently typing.
        if (["architecture", "activity", "audit", "iam", "firewall", "dns", "loadbalancers", "disks", "registry", "learning", "serviceaccounts", "instancegroups", "natpeering", "bigquery", "composer", "cloudrun"].includes(key)) refreshTabData();
      },
    }, label)));
}

function renderOrgPicker() {
  const nameInput = el("input", { placeholder: "Organization name" });
  return el("div", { class: "center-screen" }, [
    el("div", { class: "card narrow" }, [
      el("h1", {}, ["Welcome, ", state.user?.name]),
      el("p", { class: "subtitle" }, ["Create or pick an organization to get started."]),
      errorBanner(),
      el("div", { class: "stack" }, [
        ...state.orgs.map((o) => el("button", { class: "btn", style: "text-align:left", onclick: () => withErrorHandling(async () => {
          state.orgId = o.id;
          localStorage.setItem("cloudlab_org", o.id);
          await loadProjects();
        }) }, o.name)),
      ]),
      el("div", { class: "row", style: "margin-top:14px" }, [
        nameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const org = await api("/organizations", { method: "POST", body: JSON.stringify({ name: nameInput.value }) });
          state.orgs.push(org);
          state.orgId = org.id;
          localStorage.setItem("cloudlab_org", org.id);
          await loadProjects();
        }) }, "Create"),
      ]),
    ]),
  ]);
}

function renderProjectPicker() {
  const nameInput = el("input", { placeholder: "Project name" });
  const projectsInOrg = state.projects.filter((p) => p.orgId === state.orgId);
  return el("div", { class: "center-screen" }, [
    el("div", { class: "card narrow" }, [
      el("h1", {}, ["Projects"]),
      errorBanner(),
      el("div", { class: "stack" }, projectsInOrg.length
        ? projectsInOrg.map((p) => el("button", { class: "btn", style: "text-align:left", onclick: () => withErrorHandling(() => selectProject(p.id)) }, p.name))
        : [el("p", { class: "muted" }, "No projects yet.")]),
      el("div", { class: "row", style: "margin-top:14px" }, [
        nameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const project = await api("/projects", { method: "POST", body: JSON.stringify({ orgId: state.orgId, name: nameInput.value }) });
          state.projects.push(project);
          await selectProject(project.id);
        }) }, "Create"),
      ]),
    ]),
  ]);
}

async function selectProject(projectId) {
  state.projectId = projectId;
  localStorage.setItem("cloudlab_project", projectId);
  state.project = await api(`/projects/${projectId}`);
  connectWs();
  await refreshTabData();
}

// ---- Dashboard / Networks / Instances / Architecture / Activity / Audit / IAM

function renderDashboard() {
  return el("div", {}, [
    el("h1", {}, [state.project?.name]),
    el("p", { class: "subtitle" }, [`Your role: `, el("span", { class: "pill" }, state.project?.myRole)]),
    el("div", { class: "grid-2" }, [
      el("div", { class: "stat-tile" }, [
        el("div", { class: "stat-label" }, "Networks"),
        el("div", { class: "stat-value stat-accent" }, String(state.networks.length)),
        el("p", { class: "muted" }, `${state.networks.filter((n) => n.status === "READY").length} ready`),
      ]),
      el("div", { class: "stat-tile" }, [
        el("div", { class: "stat-label" }, "Instances"),
        el("div", { class: "stat-value stat-accent" }, String(state.instances.length)),
        el("p", { class: "muted" }, `${state.instances.filter((i) => i.status === "READY").length} ready`),
      ]),
    ]),
  ]);
}

function renderPendingPanel(resourceId) {
  const p = state.pendingOps[resourceId];
  if (!p) return null;
  return el("ul", { class: "steps" }, p.steps.map((s) =>
    el("li", { class: s.status }, [el("span", { class: "dot" }), `${s.name}${s.message ? " -- " + s.message : ""}`])));
}

function renderNetworks() {
  const nameInput = el("input", { placeholder: "vpc-main" });
  // No IPAM/subnet-allocator exists yet (see ROADMAP known limitations), so a
  // fixed default CIDR would collide with any other network still using it.
  // Suggesting a random /24 out of 172.30.0.0/16 keeps demo/dev usage smooth
  // without pretending we've built real quota-aware allocation.
  const suggestedCidr = `172.30.${Math.floor(Math.random() * 254)}.0/24`;
  const cidrInput = el("input", { placeholder: suggestedCidr, value: suggestedCidr });

  const rows = state.networks.length
    ? state.networks.filter((n) => n.status !== "DELETED").map((n) => {
        const activeFault = n.metadata?.activeFault;
        return el("tr", {}, [
          el("td", {}, [
            n.name, renderPendingPanel(n.id),
            activeFault ? el("div", { class: "muted", style: "font-size:11px;margin-top:3px" }, `blackholed -- auto-reverts ${fmtTime(activeFault.expiresAt)}`) : null,
          ]),
          el("td", {}, badge(n.status)),
          el("td", { class: "mono muted" }, n.spec?.cidr || ""),
          el("td", { class: "muted" }, fmtTime(n.createdAt)),
          el("td", { class: "row" }, [
            n.status === "READY"
              ? el("button", { class: "btn small", title: "Real fault injection: iptables-drops all traffic on this network's bridge for 30s (see Milestone 11 in the roadmap for why this is a full blackhole rather than partial degradation)", onclick: () => withErrorHandling(async () => {
                  const res = await api(`/projects/${state.projectId}/networks/${n.id}/faults/blackhole`, { method: "POST", body: JSON.stringify({ durationSeconds: 30 }) });
                  trackOperation(n.id, res.operationId);
                }) }, "Blackhole 30s")
              : n.status === "DEGRADED" && activeFault
              ? el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
                  const res = await api(`/projects/${state.projectId}/networks/${n.id}/faults/blackhole/cancel`, { method: "POST" });
                  trackOperation(n.id, res.operationId);
                }) }, "Cancel fault")
              : null,
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/networks/${n.id}`, { method: "DELETE" });
              trackOperation(n.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No networks yet.")])];

  return el("div", {}, [
    el("h1", {}, "Networking"),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a VPC network"),
      el("div", { class: "row" }, [
        nameInput, cidrInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/networks`, { method: "POST", body: JSON.stringify({ name: nameInput.value, cidr: cidrInput.value }) });
          state.networks.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create network"),
      ]),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "CIDR", "Created", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
    renderSubnetsSection(),
  ]);
}

function renderSubnetsSection() {
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const nameInput = el("input", { placeholder: "subnet-a" });
  const netSelect = el("select", {}, readyNetworks.length
    ? readyNetworks.map((n) => el("option", { value: n.id, "data-cidr": n.spec?.cidr }, n.name))
    : [el("option", { value: "" }, "-- create a network first --")]);
  const cidrInput = el("input", { placeholder: "172.30.0.0/26" });
  const regionSelect = el("select", { title: "Region -- a subnet is regional, same as real GCP" },
    GCP_REGIONS.map((r) => el("option", { value: r.region }, `${r.region} (${r.location})`)));

  const rows = state.subnets.length
    ? state.subnets.filter((s) => s.status !== "DELETED").map((s) => {
        const parent = state.networks.find((n) => n.id === s.spec?.networkId);
        return el("tr", {}, [
          el("td", {}, [s.name, renderPendingPanel(s.id)]),
          el("td", {}, badge(s.status)),
          el("td", { class: "mono muted" }, s.spec?.cidr || ""),
          el("td", { class: "muted" }, s.region || s.spec?.region || ""),
          el("td", { class: "muted" }, parent?.name || s.spec?.networkId || ""),
          el("td", {}, [
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/subnets/${s.id}`, { method: "DELETE" });
              trackOperation(s.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "6" }, "No subnets yet.")])];

  return el("div", { class: "card section" }, [
    el("h2", {}, "Subnets"),
    el("p", { class: "muted" }, "A sub-range of a VPC's CIDR, scoped to one region. Instances created inside a subnet get a real static IP assigned within that range."),
    el("div", { class: "row wrap" }, [
      nameInput, netSelect, regionSelect, cidrInput,
      el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
        const res = await api(`/projects/${state.projectId}/subnets`, { method: "POST", body: JSON.stringify({ name: nameInput.value, networkId: netSelect.value, cidr: cidrInput.value, region: regionSelect.value }) });
        state.subnets.push(res.resource);
        trackOperation(res.resource.id, res.operationId);
      }) }, "Create subnet"),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "CIDR", "Region", "Network", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function renderFirewall() {
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const nameInput = el("input", { placeholder: "allow-http" });
  const netSelect = el("select", {}, readyNetworks.length
    ? readyNetworks.map((n) => el("option", { value: n.id }, n.name))
    : [el("option", { value: "" }, "-- create a network first --")]);
  const dirSelect = el("select", {}, [el("option", { value: "ingress" }, "ingress"), el("option", { value: "egress" }, "egress")]);
  const actionSelect = el("select", {}, [el("option", { value: "ALLOW" }, "ALLOW"), el("option", { value: "DENY" }, "DENY")]);
  const protoSelect = el("select", {}, [el("option", { value: "tcp" }, "tcp"), el("option", { value: "udp" }, "udp"), el("option", { value: "all" }, "all")]);
  const portInput = el("input", { placeholder: "80 or 8000:9000" });
  const cidrInput = el("input", { placeholder: "0.0.0.0/0", value: "0.0.0.0/0" });

  const rows = state.firewallRules.length
    ? state.firewallRules.filter((r) => r.status !== "DELETED").map((r) => el("tr", {}, [
        el("td", {}, [r.name, renderPendingPanel(r.id)]),
        el("td", {}, badge(r.status)),
        el("td", {}, r.spec?.direction),
        el("td", {}, el("span", { class: "pill", style: r.spec?.action === "ALLOW" ? "background:#dcfce7;color:#15803d" : "background:#fee2e2;color:#b91c1c" }, r.spec?.action)),
        el("td", { class: "mono muted" }, `${r.spec?.protocol}${r.spec?.portRange ? ":" + r.spec.portRange : ""} ${r.spec?.cidr || ""}`),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/firewall-rules/${r.id}`, { method: "DELETE" });
            trackOperation(r.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "6" }, "No firewall rules yet.")])];

  return el("div", {}, [
    el("h1", {}, "Firewall"),
    el("p", { class: "subtitle" }, "Real iptables rules on the DOCKER-USER chain -- a DENY rule genuinely drops matching packets at the kernel."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a rule"),
      el("div", { class: "row wrap" }, [
        nameInput, netSelect, dirSelect, actionSelect, protoSelect, portInput, cidrInput,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/firewall-rules`, { method: "POST", body: JSON.stringify({
            name: nameInput.value, networkResourceId: netSelect.value, direction: dirSelect.value,
            action: actionSelect.value, protocol: protoSelect.value, portRange: portInput.value || undefined, cidr: cidrInput.value,
          }) });
          state.firewallRules.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create rule"),
      ]),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "Direction", "Action", "Match", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function renderDns() {
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const nameInput = el("input", { placeholder: "web-a-record" });
  const netSelect = el("select", {}, readyNetworks.length
    ? readyNetworks.map((n) => el("option", { value: n.id }, n.name))
    : [el("option", { value: "" }, "-- create a network first --")]);
  const hostInput = el("input", { placeholder: "web.internal" });
  const ipInput = el("input", { placeholder: "172.30.0.10" });

  const rows = state.dnsRecords.length
    ? state.dnsRecords.filter((r) => r.status !== "DELETED").map((r) => el("tr", {}, [
        el("td", {}, [r.name, renderPendingPanel(r.id)]),
        el("td", {}, badge(r.status)),
        el("td", { class: "mono" }, r.spec?.hostname || ""),
        el("td", { class: "mono muted" }, r.spec?.ip || ""),
        el("td", { class: "muted" }, r.metadata?.resolverIp || "--"),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/dns-records/${r.id}`, { method: "DELETE" });
            trackOperation(r.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "6" }, "No DNS records yet.")])];

  return el("div", {}, [
    el("h1", {}, "DNS"),
    el("p", { class: "subtitle" }, "Backed by a real UDP DNS server per network (cloudlab/dns-resolver) that answers these records and forwards everything else."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a record"),
      el("div", { class: "row" }, [
        nameInput, netSelect, hostInput, ipInput,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/dns-records`, { method: "POST", body: JSON.stringify({ name: nameInput.value, networkId: netSelect.value, hostname: hostInput.value, ip: ipInput.value }) });
          state.dnsRecords.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create record"),
      ]),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "Hostname", "IP", "Resolver", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function renderLoadBalancers() {
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const nameInput = el("input", { placeholder: "web-lb" });
  const netSelect = el("select", {}, readyNetworks.length
    ? readyNetworks.map((n) => el("option", { value: n.id }, n.name))
    : [el("option", { value: "" }, "-- create a network first --")]);

  const readyInstances = state.instances.filter((i) => i.status === "READY");
  const rows = state.loadBalancers.length
    ? state.loadBalancers.filter((lb) => lb.status !== "DELETED").map((lb) => {
        const backendSelect = el("select", { class: "small" }, readyInstances.length
          ? readyInstances.map((i) => el("option", { value: i.id }, i.name))
          : [el("option", { value: "" }, "-- no ready instances --")]);
        return el("tr", {}, [
          el("td", {}, [lb.name, renderPendingPanel(lb.id)]),
          el("td", {}, badge(lb.status)),
          el("td", {}, lb.metadata?.publicUrl ? el("a", { href: lb.metadata.publicUrl, target: "_blank" }, lb.metadata.publicUrl) : el("span", { class: "muted" }, "--")),
          el("td", { class: "muted" }, String(lb.metadata?.backendCount ?? 0)),
          el("td", { class: "row" }, [
            backendSelect,
            el("button", { class: "btn small", disabled: readyInstances.length ? null : "true", onclick: () => withErrorHandling(async () => {
              const current = lb.spec?.backendInstanceIds || [];
              if (!backendSelect.value || current.includes(backendSelect.value)) return;
              const res = await api(`/projects/${state.projectId}/load-balancers/${lb.id}/backends`, {
                method: "PATCH", body: JSON.stringify({ backendInstanceIds: [...current, backendSelect.value] }),
              });
              lb.spec.backendInstanceIds = [...current, backendSelect.value];
              trackOperation(lb.id, res.operationId);
            }) }, "Add backend"),
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/load-balancers/${lb.id}`, { method: "DELETE" });
              trackOperation(lb.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No load balancers yet.")])];

  return el("div", {}, [
    el("h1", {}, "Load Balancers"),
    el("p", { class: "subtitle" }, "A real HTTP reverse proxy container doing round-robin over healthy backends, with active /healthz checks -- see cloudlab/lb-proxy."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a load balancer"),
      el("p", { class: "muted" }, "Backends can be attached afterwards from the Compute tab."),
      el("div", { class: "row" }, [
        nameInput, netSelect,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/load-balancers`, { method: "POST", body: JSON.stringify({ name: nameInput.value, networkId: netSelect.value, backendInstanceIds: [] }) });
          state.loadBalancers.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create load balancer"),
      ]),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "Public URL", "Backends", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function renderDisks() {
  const nameInput = el("input", { placeholder: "data-disk-1" });
  const sizeInput = el("input", { placeholder: "10", type: "number", style: "width:80px" });

  const rows = state.disks.length
    ? state.disks.filter((d) => d.status !== "DELETED").map((d) => el("tr", {}, [
        el("td", {}, [d.name, renderPendingPanel(d.id)]),
        el("td", {}, badge(d.status)),
        el("td", { class: "muted" }, `${d.spec?.sizeGb ?? "?"} GB`),
        el("td", { class: "mono muted" }, d.metadata?.volumeName || ""),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/disks/${d.id}`, { method: "DELETE" });
            trackOperation(d.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No disks yet.")])];

  return el("div", {}, [
    el("h1", {}, "Disks"),
    el("p", { class: "subtitle" }, "Real Docker named volumes -- genuine persistent storage, attachable to instances at creation time."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a disk"),
      el("div", { class: "row" }, [
        nameInput, sizeInput, el("span", { class: "muted" }, "GB"),
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/disks`, { method: "POST", body: JSON.stringify({ name: nameInput.value, sizeGb: Number(sizeInput.value) || 10 }) });
          state.disks.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create disk"),
      ]),
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "Size", "Volume", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function renderRegistry() {
  const regNameInput = el("input", { placeholder: "main-registry" });
  const readyRegistries = state.registries.filter((r) => r.status === "READY");

  const regRows = state.registries.length
    ? state.registries.filter((r) => r.status !== "DELETED").map((r) => el("tr", {}, [
        el("td", {}, [r.name, renderPendingPanel(r.id)]),
        el("td", {}, badge(r.status)),
        el("td", { class: "mono muted" }, r.metadata?.registryHost || ""),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/registries/${r.id}`, { method: "DELETE" });
            trackOperation(r.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No registries yet.")])];

  const imgNameInput = el("input", { placeholder: "myapp" });
  const imgTagInput = el("input", { placeholder: "latest", style: "width:100px" });
  const regSelect = el("select", {}, readyRegistries.length
    ? readyRegistries.map((r) => el("option", { value: r.id }, `${r.name} (${r.metadata?.registryHost})`))
    : [el("option", { value: "" }, "-- create a registry first --")]);
  const dockerfileInput = el("textarea", {
    rows: "5", style: "width:100%;font-family:var(--mono);font-size:12px",
    placeholder: "FROM alpine:3\nRUN echo building > /note.txt\nCMD [\"cat\", \"/note.txt\"]",
  }, "FROM scratch\nCOPY Dockerfile /Dockerfile\n");

  const imgRows = state.images.length
    ? state.images.filter((i) => i.status !== "DELETED").map((img) => el("tr", {}, [
        el("td", {}, [img.name, renderPendingPanel(img.id)]),
        el("td", {}, badge(img.status)),
        el("td", { class: "mono muted", style: "max-width:340px;overflow-x:auto;display:block" }, img.metadata?.pullCommand || ""),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/images/${img.id}`, { method: "DELETE" });
            trackOperation(img.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No images yet.")])];

  return el("div", {}, [
    el("h1", {}, "Registry"),
    el("p", { class: "subtitle" }, "A real Docker Distribution v2 registry -- genuine docker build/push/pull, not a simulated catalog."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a registry"),
      el("div", { class: "row" }, [
        regNameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/registries`, { method: "POST", body: JSON.stringify({ name: regNameInput.value }) });
          state.registries.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create registry"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Host", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, regRows),
      ]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Build & push an image"),
      el("p", { class: "muted" }, "Runs a real docker build from the Dockerfile below, then pushes the result to the selected registry."),
      el("div", { class: "row wrap", style: "margin-bottom:10px" }, [imgNameInput, imgTagInput, regSelect]),
      dockerfileInput,
      el("div", { style: "margin-top:10px" }, [
        el("button", { class: "btn primary", disabled: readyRegistries.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/images`, { method: "POST", body: JSON.stringify({
            name: imgNameInput.value, tag: imgTagInput.value || "latest", registryId: regSelect.value, dockerfile: dockerfileInput.value,
          }) });
          state.images.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Build & push"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Pull command", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, imgRows),
      ]),
    ]),
  ]);
}

function renderStorage() {
  const nameInput = el("input", { placeholder: "app-uploads" });
  const readyBuckets = state.buckets.filter((b) => b.status === "READY");

  const rows = state.buckets.length
    ? state.buckets.filter((b) => b.status !== "DELETED").map((b) => el("tr", {}, [
        el("td", {}, [b.name, renderPendingPanel(b.id)]),
        el("td", {}, badge(b.status)),
        el("td", { class: "mono muted" }, b.metadata?.endpoint || ""),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/buckets/${b.id}`, { method: "DELETE" });
            trackOperation(b.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No buckets yet.")])];

  const bucketSelect = el("select", {}, readyBuckets.length
    ? readyBuckets.map((b) => el("option", { value: b.metadata?.endpoint }, `${b.name} (${b.metadata?.endpoint})`))
    : [el("option", { value: "" }, "-- create a bucket first --")]);
  const keyInput = el("input", { placeholder: "greeting.txt" });
  const bodyInput = el("textarea", { rows: "3", style: "width:100%", placeholder: "object contents to upload" });
  const objectList = el("pre", { class: "mono", style: "margin-top:10px;white-space:pre-wrap" }, "");

  async function refreshObjects() {
    if (!bucketSelect.value) { objectList.textContent = ""; return; }
    const res = await fetch(`${bucketSelect.value}/`);
    const data = await res.json();
    objectList.textContent = JSON.stringify(data.objects, null, 2);
  }

  return el("div", {}, [
    el("h1", {}, "Storage"),
    el("p", { class: "subtitle" }, "A real object store per bucket -- genuine PUT/GET/DELETE/LIST over HTTP, verifiable with curl against the endpoint shown below (CloudLab's own object protocol, not AWS-signature-compatible S3 -- see ROADMAP.md)."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a bucket"),
      el("div", { class: "row" }, [
        nameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/buckets`, { method: "POST", body: JSON.stringify({ name: nameInput.value }) });
          state.buckets.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create bucket"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Endpoint", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, rows),
      ]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Try it: upload / list objects"),
      el("p", { class: "muted" }, "Talks directly to the bucket's own HTTP endpoint from your browser -- exactly what a real client would do, not routed through the platform API."),
      el("div", { class: "row wrap", style: "margin-bottom:10px" }, [bucketSelect, keyInput]),
      bodyInput,
      el("div", { class: "row", style: "margin-top:10px" }, [
        el("button", { class: "btn primary", disabled: readyBuckets.length ? null : "true", onclick: () => withErrorHandling(async () => {
          await fetch(`${bucketSelect.value}/${keyInput.value}`, { method: "PUT", body: bodyInput.value });
          await refreshObjects();
        }) }, "PUT object"),
        el("button", { class: "btn", disabled: readyBuckets.length ? null : "true", onclick: () => withErrorHandling(refreshObjects) }, "List objects"),
      ]),
      objectList,
    ]),
  ]);
}

function renderDatabases() {
  const nameInput = el("input", { placeholder: "orders-db" });
  const dbNameInput = el("input", { placeholder: "appdb (optional)" });

  const rows = state.databases.length
    ? state.databases.filter((d) => d.status !== "DELETED").map((d) => el("tr", {}, [
        el("td", {}, [d.name, renderPendingPanel(d.id)]),
        el("td", {}, badge(d.status)),
        el("td", { class: "mono muted" }, d.metadata?.connectionString || ""),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/databases/${d.id}`, { method: "DELETE" });
            trackOperation(d.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No databases yet.")])];

  return el("div", {}, [
    el("h1", {}, "Databases"),
    el("p", { class: "subtitle" }, "A real, dedicated PostgreSQL 16 server per database resource -- genuine initdb + postmaster, connectible with any Postgres client via the connection string shown once it's READY."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a database"),
      el("div", { class: "row" }, [
        nameInput, dbNameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/databases`, { method: "POST", body: JSON.stringify({ name: nameInput.value, databaseName: dbNameInput.value || undefined }) });
          state.databases.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create database"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Connection string", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, rows),
      ]),
    ]),
  ]);
}

// Revealed secret values, keyed by secret id. Kept at module scope (like
// statsLive/statsPollInstanceId above for the instance-detail view) rather
// than as a DOM node captured in the Reveal button's onclick closure: this
// whole page's renderMain() reruns on every WS "resource.update"/
// "operation.*" tick for the *entire project* (see the comment above
// statsPollInterval), which is frequent in a busy project. A captured
// `revealArea` span goes stale the moment any such tick lands between the
// click and the reveal fetch resolving -- the write still "succeeds" but
// lands on a detached node nobody sees, so Reveal looked broken even though
// the real decrypt call itself returned the correct plaintext every time.
// Driving the row's rendered content from this map instead means any
// re-render (WS-triggered or not) still shows the value.
const revealedSecrets = {};

function renderSecrets() {
  const nameInput = el("input", { placeholder: "api-key" });
  const valueInput = el("input", { type: "password", placeholder: "secret value" });

  const rows = state.secrets.length
    ? state.secrets.filter((s) => s.status !== "DELETED").map((s) => {
        const revealedValue = Object.prototype.hasOwnProperty.call(revealedSecrets, s.id) ? `= "${revealedSecrets[s.id]}"` : "";
        return el("tr", {}, [
          el("td", {}, [s.name, renderPendingPanel(s.id)]),
          el("td", {}, badge(s.status)),
          el("td", { class: "mono muted" }, [`${s.spec?.valueLength ?? "?"} bytes encrypted (AES-256-GCM)`, " ", el("span", { class: "mono muted" }, revealedValue)]),
          el("td", {}, [
            el("button", { class: "btn small", disabled: s.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/secrets/${s.id}/reveal`);
              revealedSecrets[s.id] = res.value;
              renderMain();
            }) }, "Reveal"),
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/secrets/${s.id}`, { method: "DELETE" });
              trackOperation(s.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No secrets yet.")])];

  return el("div", {}, [
    el("h1", {}, "Secrets"),
    el("p", { class: "subtitle" }, "Real AES-256-GCM envelope encryption. The value is encrypted the instant you submit it and is never stored or logged as plaintext -- Reveal is a separate, permission-gated, audited decrypt."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a secret"),
      el("div", { class: "row" }, [
        nameInput, valueInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/secrets`, { method: "POST", body: JSON.stringify({ name: nameInput.value, value: valueInput.value }) });
          state.secrets.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
          valueInput.value = "";
        }) }, "Create secret"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Value", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, rows),
      ]),
    ]),
  ]);
}

// ---- Milestone 15: GCP Platform/DevOps architect pass ---------------------
// Service Accounts, Instance Templates + Managed Instance Groups, NAT
// Gateway + VPC Peering + Shared VPC, BigQuery, Composer, Cloud Run. Each
// panel follows the exact same simple table+form pattern as
// renderDatabases/renderSecrets above -- real create calls against the real
// API, real status polling via refreshTabData.

function renderServiceAccounts() {
  const nameInput = el("input", { placeholder: "CI Runner" });
  const idInput = el("input", { placeholder: "ci-runner-sa" });

  const rows = state.serviceAccounts.length
    ? state.serviceAccounts.filter((s) => s.status !== "DELETED").map((s) => {
        const keyArea = el("span", { class: "mono muted" }, "");
        return el("tr", {}, [
          el("td", {}, [s.name, renderPendingPanel(s.id)]),
          el("td", {}, badge(s.status)),
          el("td", { class: "mono muted" }, s.metadata?.email || ""),
          el("td", {}, [
            el("button", { class: "btn small", disabled: s.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/service-accounts/${s.id}/key`);
              keyArea.textContent = `key ${res.private_key_id}`;
              alert(`Real RSA-2048 private key (JSON key file contents):\n\n${JSON.stringify(res, null, 2)}`);
            }) }, "Download key"),
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/service-accounts/${s.id}`, { method: "DELETE" });
              trackOperation(s.id, res.operationId);
            }) }, "Delete"),
            keyArea,
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No service accounts yet.")])];

  return el("div", {}, [
    el("h1", {}, "IAM Service Accounts"),
    el("p", { class: "subtitle" }, "A real machine identity per resource -- a genuine 2048-bit RSA keypair generated on create, the private key AES-256-GCM encrypted at rest. Mirrors GCP IAM service accounts."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a service account"),
      el("div", { class: "row" }, [
        nameInput, idInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/service-accounts`, { method: "POST", body: JSON.stringify({ name: nameInput.value, accountId: idInput.value }) });
          state.serviceAccounts.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create service account"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Email", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, rows),
      ]),
    ]),
  ]);
}

function renderInstanceGroups() {
  const templateNameInput = el("input", { placeholder: "web-template" });
  const migNameInput = el("input", { placeholder: "web-mig" });
  const targetSizeInput = el("input", { type: "number", value: "2", min: "1", max: "10", style: "width:70px" });
  const readyTemplates = state.instanceTemplates.filter((t) => t.status === "READY");
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const templateSelect = el("select", {}, readyTemplates.map((t) => el("option", { value: t.id }, t.name)));
  const networkSelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));

  const templateRows = state.instanceTemplates.length
    ? state.instanceTemplates.filter((t) => t.status !== "DELETED").map((t) => el("tr", {}, [
        el("td", {}, [t.name, renderPendingPanel(t.id)]),
        el("td", {}, badge(t.status)),
        el("td", { class: "mono muted" }, t.spec?.image || ""),
        el("td", {}, [el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/instance-templates/${t.id}`, { method: "DELETE" });
          trackOperation(t.id, res.operationId);
        }) }, "Delete")]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No instance templates yet.")])];

  const migRows = state.managedInstanceGroups.length
    ? state.managedInstanceGroups.filter((g) => g.status !== "DELETED").map((g) => {
        const resizeInput = el("input", { type: "number", value: String(g.spec?.targetSize ?? 1), min: "1", max: "10", style: "width:60px" });
        return el("tr", {}, [
          el("td", {}, [g.name, renderPendingPanel(g.id)]),
          el("td", {}, badge(g.status)),
          el("td", { class: "mono muted" }, `${g.metadata?.liveCount ?? "?"} / ${g.spec?.targetSize ?? "?"} live`),
          el("td", {}, [
            resizeInput,
            el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/managed-instance-groups/${g.id}/resize`, { method: "POST", body: JSON.stringify({ targetSize: Number(resizeInput.value) }) });
              trackOperation(g.id, res.operationId);
            }) }, "Resize"),
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/managed-instance-groups/${g.id}`, { method: "DELETE" });
              trackOperation(g.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No managed instance groups yet.")])];

  return el("div", {}, [
    el("h1", {}, "Instance Templates & Managed Instance Groups"),
    el("p", { class: "subtitle" }, "A template is a stored blueprint; a group stamps out real containers from it and a reconciler (every 10s) keeps the live count pinned to target size, restarting anything that crashes -- point a Load Balancer at a group's id to get a self-healing backend pool."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create an instance template"),
      el("div", { class: "row" }, [
        templateNameInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/instance-templates`, { method: "POST", body: JSON.stringify({ name: templateNameInput.value }) });
          state.instanceTemplates.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create template"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Image", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, templateRows),
      ]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a managed instance group"),
      el("div", { class: "row" }, [
        migNameInput, templateSelect, networkSelect, targetSizeInput,
        el("button", { class: "btn primary", disabled: readyTemplates.length && readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/managed-instance-groups`, { method: "POST", body: JSON.stringify({ name: migNameInput.value, instanceTemplateId: templateSelect.value, networkId: networkSelect.value, targetSize: Number(targetSizeInput.value) }) });
          state.managedInstanceGroups.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create group"),
      ]),
      readyTemplates.length ? null : el("p", { class: "muted" }, "Create a READY instance template first."),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Members", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, migRows),
      ]),
    ]),
  ]);
}

function renderNatPeering() {
  const natNameInput = el("input", { placeholder: "nat-default" });
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const natNetworkSelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));
  const peerNameInput = el("input", { placeholder: "peer-a-b" });
  const peerASelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));
  const peerBSelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));
  const svpcNameInput = el("input", { placeholder: "attach-service-project" });
  const svpcServiceProjectInput = el("input", { placeholder: "service project id" });
  const svpcNetworkSelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));

  const natRows = state.natGateways.length
    ? state.natGateways.filter((g) => g.status !== "DELETED").map((g) => el("tr", {}, [
        el("td", {}, [g.name, renderPendingPanel(g.id)]),
        el("td", {}, badge(g.status)),
        el("td", { class: "mono muted" }, g.metadata?.natCidr || ""),
        el("td", {}, [el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/nat-gateways/${g.id}`, { method: "DELETE" });
          trackOperation(g.id, res.operationId);
        }) }, "Delete")]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No NAT gateways yet.")])];

  const peerRows = state.vpcPeerings.length
    ? state.vpcPeerings.filter((p) => p.status !== "DELETED").map((p) => el("tr", {}, [
        el("td", {}, [p.name, renderPendingPanel(p.id)]),
        el("td", {}, badge(p.status)),
        el("td", {}, [el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/vpc-peerings/${p.id}`, { method: "DELETE" });
          trackOperation(p.id, res.operationId);
        }) }, "Delete")]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "3" }, "No VPC peerings yet.")])];

  const svpcRows = state.sharedVpcAttachments.length
    ? state.sharedVpcAttachments.filter((a) => a.status !== "DELETED").map((a) => el("tr", {}, [
        el("td", {}, [a.name, renderPendingPanel(a.id)]),
        el("td", {}, badge(a.status)),
        el("td", { class: "mono muted" }, a.spec?.serviceProjectId || ""),
        el("td", {}, [el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/shared-vpc-attachments/${a.id}`, { method: "DELETE" });
          trackOperation(a.id, res.operationId);
        }) }, "Delete")]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No Shared VPC attachments from this (host) project yet.")])];

  return el("div", {}, [
    el("h1", {}, "NAT Gateway, VPC Peering & Shared VPC"),
    el("p", { class: "subtitle" }, "Real host-level iptables rules -- a NAT gateway genuinely toggles internet egress for a network, a peering genuinely opens routing between two networks, and a Shared VPC attachment genuinely grants one other project the right to attach instances to a network here (enforced, not a label)."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a NAT gateway"),
      el("div", { class: "row" }, [
        natNameInput, natNetworkSelect,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/nat-gateways`, { method: "POST", body: JSON.stringify({ name: natNameInput.value, networkResourceId: natNetworkSelect.value }) });
          state.natGateways.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create NAT gateway"),
      ]),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", "CIDR", ""].map((h) => el("th", {}, h)))), el("tbody", {}, natRows)]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a VPC peering"),
      el("div", { class: "row" }, [
        peerNameInput, peerASelect, peerBSelect,
        el("button", { class: "btn primary", disabled: readyNetworks.length >= 2 ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/vpc-peerings`, { method: "POST", body: JSON.stringify({ name: peerNameInput.value, networkAId: peerASelect.value, networkBId: peerBSelect.value }) });
          state.vpcPeerings.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create peering"),
      ]),
      readyNetworks.length >= 2 ? null : el("p", { class: "muted" }, "Create two READY networks first."),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", ""].map((h) => el("th", {}, h)))), el("tbody", {}, peerRows)]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Grant a Shared VPC attachment (this project as host)"),
      el("div", { class: "row" }, [
        svpcNameInput, svpcServiceProjectInput, svpcNetworkSelect,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/shared-vpc-attachments`, { method: "POST", body: JSON.stringify({ name: svpcNameInput.value, serviceProjectId: svpcServiceProjectInput.value, networkResourceId: svpcNetworkSelect.value }) });
          state.sharedVpcAttachments.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Grant attachment"),
      ]),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", "Service project", ""].map((h) => el("th", {}, h)))), el("tbody", {}, svpcRows)]),
    ]),
  ]);
}

function renderBigquery() {
  const nameInput = el("input", { placeholder: "analytics-ds" });
  const datasetIdInput = el("input", { placeholder: "analytics (optional)" });

  const rows = state.bigqueryDatasets.length
    ? state.bigqueryDatasets.filter((d) => d.status !== "DELETED").map((d) => {
        // withErrorHandling() always calls render() -- a full root.replaceChildren()
        // rebuild -- right after its async callback resolves, so a query result
        // (or the SQL someone typed) can only survive that rebuild by living in
        // `state`, never as a plain local variable/DOM-node reference like an
        // earlier version of this form tried (the result would flash and then
        // vanish the instant the button's own click handler finished).
        const saved = state.bigqueryQueryResults[d.id];
        const sqlInput = el("input", { placeholder: "SELECT 1", style: "width:260px", value: saved?.sql ?? "", oninput: (e) => {
          state.bigqueryQueryResults[d.id] = { ...state.bigqueryQueryResults[d.id], sql: e.target.value };
        } });
        const resultText = saved?.error ? `ERROR: ${saved.error}` : saved?.rows ? JSON.stringify(saved.rows, null, 2) : "";
        const resultArea = el("pre", { class: "mono muted", style: "white-space:pre-wrap;max-width:420px" }, resultText);
        return el("tr", {}, [
          el("td", {}, [d.name, renderPendingPanel(d.id)]),
          el("td", {}, badge(d.status)),
          el("td", { class: "mono muted" }, d.metadata?.datasetId || ""),
          el("td", {}, [
            sqlInput,
            el("button", { class: "btn small", disabled: d.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
              const sql = sqlInput.value || "SELECT 1";
              try {
                const res = await api(`/projects/${state.projectId}/bigquery-datasets/${d.id}/query`, { method: "POST", body: JSON.stringify({ sql }) });
                state.bigqueryQueryResults[d.id] = { sql, rows: res.rows, error: null };
              } catch (err) {
                state.bigqueryQueryResults[d.id] = { sql, rows: null, error: err.body?.message ?? err.message };
              }
            }) }, "Run query"),
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/bigquery-datasets/${d.id}`, { method: "DELETE" });
              trackOperation(d.id, res.operationId);
            }) }, "Delete"),
            resultArea,
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No datasets yet.")])];

  return el("div", {}, [
    el("h1", {}, "BigQuery Datasets"),
    el("p", { class: "subtitle" }, "Honest substitute: a genuinely dedicated real PostgreSQL 16 server per dataset with a real SQL query endpoint -- not BigQuery's actual distributed columnar engine, but every query below genuinely executes against real data."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a dataset"),
      el("div", { class: "row" }, [
        nameInput, datasetIdInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/bigquery-datasets`, { method: "POST", body: JSON.stringify({ name: nameInput.value, datasetId: datasetIdInput.value || undefined }) });
          state.bigqueryDatasets.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create dataset"),
      ]),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", "Dataset", "Query"].map((h) => el("th", {}, h)))), el("tbody", {}, rows)]),
    ]),
  ]);
}

function renderComposer() {
  const nameInput = el("input", { placeholder: "nightly-etl" });
  const scheduleInput = el("input", { placeholder: "*/5 * * * *", value: "*/5 * * * *" });
  const readyPipelines = state.pipelines.filter((p) => p.status === "READY");
  const pipelineSelect = el("select", {}, readyPipelines.map((p) => el("option", { value: p.id }, p.name)));

  const rows = state.composerEnvironments.length
    ? state.composerEnvironments.filter((e) => e.status !== "DELETED").map((e) => el("tr", {}, [
        el("td", {}, [e.name, renderPendingPanel(e.id)]),
        el("td", {}, badge(e.status)),
        el("td", { class: "mono muted" }, e.spec?.schedule || ""),
        el("td", { class: "mono muted" }, String(e.metadata?.triggerCount ?? 0)),
        el("td", {}, [el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/composer-environments/${e.id}`, { method: "DELETE" });
          trackOperation(e.id, res.operationId);
        }) }, "Delete")]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No scheduled environments yet.")])];

  return el("div", {}, [
    el("h1", {}, "Composer Environments"),
    el("p", { class: "subtitle" }, "Wraps a real CI/CD pipeline with a real 5-field UTC cron schedule -- a scheduler loop (checked every 60s) genuinely triggers real pipeline runs on schedule, with no human clicking Run."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a scheduled environment"),
      el("div", { class: "row" }, [
        nameInput, pipelineSelect, scheduleInput,
        el("button", { class: "btn primary", disabled: readyPipelines.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/composer-environments`, { method: "POST", body: JSON.stringify({ name: nameInput.value, pipelineId: pipelineSelect.value, schedule: scheduleInput.value }) });
          state.composerEnvironments.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create environment"),
      ]),
      readyPipelines.length ? null : el("p", { class: "muted" }, "Create a READY pipeline under CI/CD first."),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", "Schedule (UTC)", "Triggers", ""].map((h) => el("th", {}, h)))), el("tbody", {}, rows)]),
    ]),
  ]);
}

function renderCloudRun() {
  const nameInput = el("input", { placeholder: "hello-service" });
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const networkSelect = el("select", {}, readyNetworks.map((n) => el("option", { value: n.id }, n.name)));
  const idleInput = el("input", { type: "number", value: "60", min: "10", max: "3600", style: "width:80px" });

  const rows = state.cloudRunServices.length
    ? state.cloudRunServices.filter((s) => s.status !== "DELETED").map((s) => el("tr", {}, [
        el("td", {}, [s.name, renderPendingPanel(s.id)]),
        el("td", {}, badge(s.status)),
        el("td", {}, el("span", { class: `badge ${s.metadata?.state === "RUNNING" ? "READY" : "STOPPED"}` }, s.metadata?.state || "IDLE")),
        el("td", {}, [
          el("button", { class: "btn small", disabled: s.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/cloud-run-services/${s.id}/invoke`, { method: "POST" });
            alert(`Invoke result:\n${JSON.stringify(res, null, 2)}`);
            await refreshTabData();
          }) }, "Invoke"),
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/cloud-run-services/${s.id}`, { method: "DELETE" });
            trackOperation(s.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No Cloud Run services yet.")])];

  return el("div", {}, [
    el("h1", {}, "Cloud Run Services"),
    el("p", { class: "subtitle" }, "Real scale-to-zero: no container exists until the first real Invoke request cold-starts one; an idle checker (every 15s) genuinely stops it again after the configured idle timeout."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a service"),
      el("div", { class: "row" }, [
        nameInput, networkSelect, idleInput,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/cloud-run-services`, { method: "POST", body: JSON.stringify({ name: nameInput.value, networkId: networkSelect.value, idleTimeoutSeconds: Number(idleInput.value) }) });
          state.cloudRunServices.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create service"),
      ]),
      el("table", { style: "margin-top:14px" }, [el("thead", {}, el("tr", {}, ["Name", "Status", "Container", ""].map((h) => el("th", {}, h)))), el("tbody", {}, rows)]),
    ]),
  ]);
}

function renderKubernetes() {
  const clusterNameInput = el("input", { placeholder: "prod-cluster" });
  const nodeCountInput = el("input", { type: "number", value: "2", min: "1", max: "10", style: "width:70px" });
  const readyClusters = state.k8sClusters.filter((c) => c.status === "READY");

  const clusterRows = state.k8sClusters.length
    ? state.k8sClusters.filter((c) => c.status !== "DELETED").map((c) => el("tr", {}, [
        el("td", {}, [c.name, renderPendingPanel(c.id)]),
        el("td", {}, badge(c.status)),
        el("td", { class: "mono muted" }, `${c.metadata?.nodeCount ?? c.spec?.nodeCount ?? "?"} node(s)`),
        el("td", {}, [
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/k8s-clusters/${c.id}`, { method: "DELETE" });
            trackOperation(c.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No clusters yet.")])];

  const depNameInput = el("input", { placeholder: "web-frontend" });
  const clusterSelect = el("select", {}, readyClusters.length
    ? readyClusters.map((c) => el("option", { value: c.id }, c.name))
    : [el("option", { value: "" }, "-- create a cluster first --")]);
  const imageInput = el("input", { placeholder: "cloudlab/guest:latest (default)" });
  const replicasInput = el("input", { type: "number", value: "2", min: "1", max: "20", style: "width:70px" });

  const depRows = state.k8sDeployments.length
    ? state.k8sDeployments.filter((d) => d.status !== "DELETED").map((d) => {
        const scaleInput = el("input", { type: "number", value: String(d.spec?.replicas ?? d.metadata?.replicas ?? 1), min: "1", max: "20", style: "width:60px" });
        return el("tr", {}, [
          el("td", {}, [d.name, renderPendingPanel(d.id)]),
          el("td", {}, badge(d.status)),
          el("td", { class: "mono muted" }, d.metadata?.clusterName || ""),
          el("td", { class: "mono muted" }, d.metadata?.image || d.spec?.image || ""),
          el("td", {}, [
            scaleInput,
            el("button", { class: "btn small", disabled: d.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/k8s-deployments/${d.id}/scale`, { method: "POST", body: JSON.stringify({ replicas: Number(scaleInput.value) }) });
              trackOperation(d.id, res.operationId);
            }) }, "Scale"),
          ]),
          el("td", {}, [
            el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/k8s-deployments/${d.id}`, { method: "DELETE" });
              trackOperation(d.id, res.operationId);
            }) }, "Delete"),
          ]),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No deployments yet.")])];

  return el("div", {}, [
    el("h1", {}, "Kubernetes"),
    el("p", { class: "subtitle" }, "CloudLab's own container-orchestration layer, modeled on Kubernetes' cluster/node/pod/deployment concepts -- not real Kubernetes (every container registry is network-blocked in this sandbox, which real kind/k3s both need on first boot). Real containers as nodes and pods, a real reconciliation loop that restarts a pod within ~10s if it dies -- try `docker kill` on a pod container and watch it come back."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a cluster"),
      el("div", { class: "row" }, [
        clusterNameInput,
        el("span", { class: "muted" }, "nodes:"), nodeCountInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/k8s-clusters`, { method: "POST", body: JSON.stringify({ name: clusterNameInput.value, nodeCount: Number(nodeCountInput.value) }) });
          state.k8sClusters.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create cluster"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Nodes", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, clusterRows),
      ]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a deployment"),
      el("div", { class: "row wrap" }, [
        depNameInput, clusterSelect, imageInput,
        el("span", { class: "muted" }, "replicas:"), replicasInput,
        el("button", { class: "btn primary", disabled: readyClusters.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const res = await api(`/projects/${state.projectId}/k8s-deployments`, { method: "POST", body: JSON.stringify({
            name: depNameInput.value, clusterId: clusterSelect.value, image: imageInput.value || undefined, replicas: Number(replicasInput.value),
          }) });
          state.k8sDeployments.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create deployment"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Cluster", "Image", "Replicas", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, depRows),
      ]),
    ]),
  ]);
}

function renderCicd() {
  const nameInput = el("input", { placeholder: "build-and-test" });
  const stagesInput = el("textarea", {
    rows: "4", style: "width:100%;font-family:var(--mono);font-size:12px",
    placeholder: "one stage per line, as  name: command\nbuild: echo building > /workspace/artifact.txt\ntest: grep building /workspace/artifact.txt",
  }, "build: echo building > /workspace/artifact.txt\ntest: grep building /workspace/artifact.txt\n");
  const readyPipelines = state.pipelines.filter((p) => p.status === "READY");

  function parseStages() {
    return stagesInput.value.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
      const idx = line.indexOf(":");
      if (idx < 0) throw new Error(`stage line "${line}" must look like "name: command"`);
      return { name: line.slice(0, idx).trim(), command: line.slice(idx + 1).trim() };
    });
  }

  const pipelineRows = state.pipelines.length
    ? state.pipelines.filter((p) => p.status !== "DELETED").map((p) => el("tr", {}, [
        el("td", {}, [p.name, renderPendingPanel(p.id)]),
        el("td", {}, badge(p.status)),
        el("td", { class: "mono muted" }, `${p.spec?.stages?.length ?? 0} stage(s)`),
        el("td", {}, [
          el("button", { class: "btn small primary", disabled: p.status === "READY" ? null : "true", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/pipeline-runs`, { method: "POST", body: JSON.stringify({ pipelineId: p.id }) });
            state.pipelineRuns.push(res.resource);
            trackOperation(res.resource.id, res.operationId);
          }) }, "Run"),
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/pipelines/${p.id}`, { method: "DELETE" });
            trackOperation(p.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No pipelines yet.")])];

  const runRows = state.pipelineRuns.length
    ? [...state.pipelineRuns].filter((r) => r.status !== "DELETED").reverse().map((r) => {
        const stages = r.metadata?.stages || [];
        const detail = el("pre", { class: "mono muted", style: "white-space:pre-wrap;margin-top:6px" },
          stages.map((s) => `${s.status === "PASSED" ? "✓" : s.status === "FAILED" ? "✗" : "–"} ${s.name} (${s.durationMs}ms)${s.output ? "\n    " + s.output.trim().split("\n").join("\n    ") : ""}`).join("\n"));
        return el("tr", {}, [
          el("td", {}, [r.name, renderPendingPanel(r.id)]),
          el("td", {}, badge(r.status)),
          el("td", { class: "mono muted" }, r.metadata?.pipelineName || ""),
          el("td", {}, stages.length ? detail : ""),
        ]);
      })
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "4" }, "No runs yet.")])];

  return el("div", {}, [
    el("h1", {}, "CI/CD"),
    el("p", { class: "subtitle" }, "A real CI runner: each run gets a fresh container (busybox shell, an ephemeral shared /workspace volume) and executes your stages in order via real docker exec, failing fast and skipping the rest on the first non-zero exit -- genuine command execution and exit codes, not a simulated pass/fail table."),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create a pipeline"),
      el("div", { class: "row" }, [nameInput]),
      stagesInput,
      el("div", { style: "margin-top:10px" }, [
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const stages = parseStages();
          const res = await api(`/projects/${state.projectId}/pipelines`, { method: "POST", body: JSON.stringify({ name: nameInput.value, stages }) });
          state.pipelines.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create pipeline"),
      ]),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Name", "Status", "Stages", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, pipelineRows),
      ]),
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Runs"),
      el("table", { style: "margin-top:14px" }, [
        el("thead", {}, el("tr", {}, ["Run", "Status", "Pipeline", "Stage results"].map((h) => el("th", {}, h)))),
        el("tbody", {}, runRows),
      ]),
    ]),
  ]);
}

function renderObservability() {
  const openAlerts = state.alerts.filter((a) => a.status === "OPEN");
  const resolvedAlerts = state.alerts.filter((a) => a.status !== "OPEN").slice(0, 20);

  function alertRow(a) {
    return el("tr", {}, [
      el("td", {}, el("span", { class: `badge ${a.severity === "CRITICAL" ? "FAILED" : "DEGRADED"}` }, a.severity)),
      el("td", { class: "mono muted" }, a.ruleKey),
      el("td", {}, a.message),
      el("td", { class: "muted" }, fmtTime(a.firedAt)),
      el("td", {}, a.status === "OPEN"
        ? el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
            await api(`/projects/${state.projectId}/alerts/${a.id}/resolve`, { method: "POST" });
            state.alerts = await api(`/projects/${state.projectId}/alerts`);
            renderMain();
          }) }, "Resolve")
        : el("span", { class: "muted" }, a.resolvedAt ? `resolved ${fmtTime(a.resolvedAt)}` : "resolved")),
    ]);
  }

  const readyInstances = state.instances.filter((i) => i.status === "READY");
  const metricsSelect = el("select", {}, readyInstances.length
    ? readyInstances.map((i) => el("option", { value: i.id }, i.name))
    : [el("option", { value: "" }, "-- no running instances --")]);
  const metricsOutput = el("pre", { class: "mono muted", style: "white-space:pre-wrap;margin-top:10px" }, "");

  const traceInput = el("input", { placeholder: "paste a request ID from the Audit Log tab" });
  const traceOutput = el("pre", { class: "mono muted", style: "white-space:pre-wrap;margin-top:10px" }, "");

  return el("div", {}, [
    el("h1", {}, "Observability"),
    el("p", { class: "subtitle" }, "Real metrics (persisted every 15s from the same docker container.stats() the console's instance panel reads live), alerts derived from real resource status and metric thresholds, and request traces correlated by the request ID every audit log entry and async operation already carries."),
    el("div", { class: "card section" }, [
      el("h2", {}, `Alerts (${openAlerts.length} open)`),
      el("table", { style: "margin-top:10px" }, [
        el("thead", {}, el("tr", {}, ["Severity", "Rule", "Message", "Fired", ""].map((h) => el("th", {}, h)))),
        el("tbody", {}, openAlerts.length ? openAlerts.map(alertRow) : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No open alerts.")])]),
      ]),
      resolvedAlerts.length ? el("details", { style: "margin-top:10px" }, [
        el("summary", { class: "muted" }, `${resolvedAlerts.length} recently resolved`),
        el("table", { style: "margin-top:6px" }, [el("tbody", {}, resolvedAlerts.map(alertRow))]),
      ]) : null,
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Metrics"),
      el("div", { class: "row" }, [
        metricsSelect,
        el("button", { class: "btn primary", disabled: readyInstances.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const samples = await api(`/projects/${state.projectId}/metrics/${metricsSelect.value}?minutes=30`);
          metricsOutput.textContent = samples.length
            ? samples.map((s) => `${fmtTime(s.sampledAt)}  cpu=${s.cpuPercent}%  mem=${s.memUsageMb}/${s.memLimitMb}MB  rx=${s.networkRxBytes}B  tx=${s.networkTxBytes}B`).join("\n")
            : "No samples yet -- the collector runs every 15s, check back shortly.";
        }) }, "Load last 30 minutes"),
      ]),
      metricsOutput,
    ]),
    el("div", { class: "card section" }, [
      el("h2", {}, "Trace a request"),
      el("div", { class: "row" }, [
        traceInput,
        el("button", { class: "btn primary", onclick: () => withErrorHandling(async () => {
          const trace = await api(`/projects/${state.projectId}/traces/${traceInput.value.trim()}`);
          traceOutput.textContent = JSON.stringify(trace, null, 2);
        }) }, "Look up trace"),
      ]),
      traceOutput,
    ]),
  ]);
}

function renderLearning() {
  function stepRow(step) {
    return el("li", { class: `scenario-step ${step.passed ? "passed" : "pending"}` }, [
      el("span", { class: "scenario-step-check" }, step.passed ? "✓" : "○"),
      el("div", { class: "scenario-step-body" }, [
        el("div", { class: "scenario-step-title" }, step.title),
        el("div", { class: "muted small" }, step.instructions),
        step.passed && step.evidence ? el("div", { class: "scenario-step-evidence" }, step.evidence) : null,
      ]),
    ]);
  }

  function scenarioCard(s) {
    const donePct = Math.round((s.steps.filter((st) => st.passed).length / s.steps.length) * 100);
    return el("div", { class: "card section scenario-card" }, [
      el("div", { class: "row", style: "justify-content:space-between;align-items:flex-start" }, [
        el("div", {}, [
          el("h2", {}, s.title),
          el("p", { class: "subtitle" }, s.description),
        ]),
        s.claimedAt
          ? el("span", { class: "badge READY" }, `Completed ${fmtTime(s.claimedAt)}`)
          : el("span", { class: "muted" }, `${donePct}% verified`),
      ]),
      el("ul", { class: "scenario-steps" }, s.steps.map(stepRow)),
      !s.claimedAt
        ? el("button", {
            class: "btn primary", disabled: s.completed ? null : "true",
            onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/scenarios/${s.key}/claim`, { method: "POST" });
              state.scenarios = state.scenarios.map((sc) => sc.key === s.key ? { ...sc, ...res.scenario, claimedAt: res.claimedAt } : sc);
              renderMain();
            }),
          }, s.completed ? "Claim completion" : "Complete every step to claim")
        : null,
    ]);
  }

  return el("div", {}, [
    el("h1", {}, "Learning"),
    el("p", { class: "subtitle" }, "Every step below is checked live against real project state -- creating a resource, running an operation, firing a real alert. Nothing here can be checked off by hand; “Claim completion” just re-runs the same checks server-side and records when they first all genuinely passed."),
    ...state.scenarios.map(scenarioCard),
  ]);
}

function renderInstances() {
  const nameInput = el("input", { placeholder: "web-01" });
  const readyNetworks = state.networks.filter((n) => n.status === "READY");
  const netSelect = el("select", { id: "network-select" }, readyNetworks.length
    ? readyNetworks.map((n) => el("option", { value: n.id }, n.name))
    : [el("option", { value: "" }, "-- create a network first --")]);
  const readySubnets = state.subnets.filter((s) => s.status === "READY");
  const subnetSelect = el("select", { id: "subnet-select" }, [
    el("option", { value: "" }, "-- no subnet (whole network) --"),
    ...readySubnets.map((s) => el("option", { value: s.id, "data-region": s.region || s.spec?.region || "" }, `${s.name} (${s.spec?.cidr})`)),
  ]);
  const zoneSelect = el("select", { id: "zone-select", title: "Zone -- must be in the same region as the chosen subnet, if any" },
    GCP_REGIONS.map((r) => el("optgroup", { label: `${r.region} (${r.location})` }, r.zones.map((z) => el("option", { value: z }, z)))));
  // Picking a subnet narrows the zone choice to that subnet's own region,
  // the same real constraint the server enforces -- see routes/instances.ts.
  subnetSelect.addEventListener("change", () => {
    const region = subnetSelect.selectedOptions[0]?.dataset.region;
    if (region) {
      const match = GCP_REGIONS.find((r) => r.region === region)?.zones[0];
      if (match) zoneSelect.value = match;
    }
  });
  const machineTypeSelect = el("select", { id: "machine-type-select", title: "Machine type -- a real Docker CPU/memory limit, not just a label" },
    MACHINE_TYPES.map((m) => el("option", { value: m.name }, `${m.name} (${m.description})`)));
  const readyDisks = state.disks.filter((d) => d.status === "READY");
  const diskSelect = el("select", { multiple: "true", size: "3", style: "min-width:160px" }, readyDisks.length
    ? readyDisks.map((d) => el("option", { value: d.id }, `${d.name} (${d.spec?.sizeGb}GB)`))
    : [el("option", { value: "", disabled: "true" }, "-- no disks yet --")]);
  const startupInput = el("textarea", { placeholder: "optional startup script, e.g. echo hello > /mnt/disk-1/hello.txt", rows: "2", style: "width:100%;font-family:var(--mono);font-size:12px" });

  const rows = state.instances.length
    ? state.instances.filter((i) => i.status !== "DELETED").map((inst) => el("tr", {}, [
        el("td", {}, [
          el("a", { href: "#", onclick: (e) => { e.preventDefault(); openInstanceDetail(inst.id); } }, inst.name),
          renderPendingPanel(inst.id),
        ]),
        el("td", {}, badge(inst.status)),
        el("td", { class: "muted" }, inst.spec?.zone || inst.region || ""),
        el("td", { class: "muted" }, [
          inst.spec?.machineType || "",
          inst.metadata?.cpuCapped ? el("div", { style: "font-size:11px" }, `capped to ${inst.metadata.appliedCpus} vCPU -- host limit`) : null,
        ]),
        el("td", {}, inst.metadata?.publicUrl ? el("a", { href: inst.metadata.publicUrl, target: "_blank" }, inst.metadata.publicUrl) : el("span", { class: "muted" }, "--")),
        el("td", { class: "muted" }, fmtTime(inst.createdAt)),
        el("td", { class: "row" }, [
          inst.status === "READY"
            ? el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
                const res = await api(`/projects/${state.projectId}/instances/${inst.id}/stop`, { method: "POST" });
                trackOperation(inst.id, res.operationId);
              }) }, "Stop")
            : inst.status === "STOPPED"
            ? el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
                const res = await api(`/projects/${state.projectId}/instances/${inst.id}/start`, { method: "POST" });
                trackOperation(inst.id, res.operationId);
              }) }, "Start")
            : null,
          el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
            const res = await api(`/projects/${state.projectId}/instances/${inst.id}`, { method: "DELETE" });
            trackOperation(inst.id, res.operationId);
          }) }, "Delete"),
        ]),
      ]))
    : [el("tr", { class: "empty-row" }, [el("td", { colspan: "7" }, "No instances yet.")])];

  return el("div", {}, [
    el("h1", {}, "Compute"),
    el("div", { class: "card section" }, [
      el("h2", {}, "Create an instance"),
      el("div", { class: "row wrap" }, [
        nameInput, netSelect, subnetSelect, zoneSelect, machineTypeSelect, diskSelect,
        el("button", { class: "btn primary", disabled: readyNetworks.length ? null : "true", onclick: () => withErrorHandling(async () => {
          const diskIds = Array.from(diskSelect.selectedOptions).map((o) => o.value).filter(Boolean);
          const res = await api(`/projects/${state.projectId}/instances`, { method: "POST", body: JSON.stringify({
            name: nameInput.value, networkId: netSelect.value, subnetId: subnetSelect.value || undefined,
            zone: zoneSelect.value, machineType: machineTypeSelect.value,
            diskIds, startupScript: startupInput.value || undefined,
          }) });
          state.instances.push(res.resource);
          trackOperation(res.resource.id, res.operationId);
        }) }, "Create instance"),
      ]),
      startupInput,
    ]),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Name", "Status", "Zone", "Machine type", "Public URL", "Created", ""].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows),
    ]),
  ]);
}

function openInstanceDetail(instanceId) {
  state.tab = `instance:${instanceId}`;
  renderMain();
}

let statsPollInterval = null;
// Which instance the running interval belongs to, and the *current* render's
// DOM spans it should write into. Split out from the interval itself so a
// same-instance re-render (see stopLiveTerminal's comment above -- this view
// redraws from scratch on every WS tick for the whole project) can just
// repoint statsLive at the freshly created spans instead of tearing the
// interval down and restarting it. Before this, each such re-render replaced
// cpuVal/memVal/netVal with brand new (still "--") spans and reset the poll,
// so if renders kept arriving faster than one 3s cycle could complete, "Live
// resource usage" could get stuck showing "--" indefinitely despite the
// numbers being real and available the whole time.
let statsPollInstanceId = null;
let statsLive = { cpuEl: null, memEl: null, netEl: null };
function stopStatsPolling() {
  if (statsPollInterval) { clearInterval(statsPollInterval); statsPollInterval = null; }
  statsPollInstanceId = null;
}

// The live terminal WebSocket must survive at module scope, not as a local
// inside renderInstanceDetail: that function re-runs on every WS
// "resource.update"/"operation.*" tick for the *whole project* (see
// handleWsMessage -> renderMain(), which rebuilds whatever view is current),
// not just when the user actually navigates. Before this fix, a plain local
// `let termSocket` meant every one of those unrelated background re-renders
// (another resource elsewhere finishing provisioning, an operation step,
// etc.) silently opened a brand new /ws/terminal connection -- and a brand
// new backend PTY/exec session -- without ever closing the previous one,
// while also discarding whatever the user had just typed into that shell.
// Tracking the socket + which instance it belongs to here lets a same-
// instance re-render reuse the live connection (just re-pointing its output
// at the freshly rendered <div>), and lets real navigation away close it
// exactly once.
let liveTerminalSocket = null;
let liveTerminalInstanceId = null;
function stopLiveTerminal() {
  if (liveTerminalSocket) { liveTerminalSocket.close(); liveTerminalSocket = null; liveTerminalInstanceId = null; }
}

function renderInstanceDetail(instanceId) {
  if (statsPollInstanceId && statsPollInstanceId !== instanceId) stopStatsPolling(); // switched to a different instance
  if (liveTerminalInstanceId && liveTerminalInstanceId !== instanceId) stopLiveTerminal(); // switched to a different instance
  const inst = state.instances.find((i) => i.id === instanceId);
  if (!inst) { state.tab = "instances"; return renderInstances(); }

  const logsBox = el("pre", { class: "terminal", id: "instance-logs", style: "height:160px" }, "loading logs...");
  api(`/projects/${state.projectId}/instances/${instanceId}/logs`).then((r) => { logsBox.textContent = r.logs || "(no logs yet)"; });

  const cmdInput = el("input", { placeholder: "hostname && uname -a", style: "flex:1" });
  const execOut = el("pre", { class: "terminal", id: "exec-output", style: "height:100px" }, "$ ");
  const execRow = el("div", { class: "terminal-input" }, [
    cmdInput,
    el("button", { class: "btn", onclick: async () => {
      // Deliberately NOT routed through withErrorHandling(): that helper
      // always ends with a full render(), which rebuilds this whole detail
      // view from scratch -- wiping the output we just appended to execOut
      // and tearing down/reconnecting the live terminal's WebSocket as a
      // side effect. This panel is self-contained: it can show its own
      // result (and its own error) without forcing a page-wide rebuild.
      const command = cmdInput.value;
      execOut.textContent += `\n$ ${command}\n`;
      cmdInput.value = "";
      try {
        const res = await api(`/projects/${state.projectId}/instances/${instanceId}/exec`, { method: "POST", body: JSON.stringify({ command }) });
        execOut.textContent += res.output;
      } catch (err) {
        execOut.textContent += `[error] ${err.body?.message || err.message}\n`;
      }
      execOut.scrollTop = execOut.scrollHeight;
    } }, "Run"),
  ]);

  const termOut = el("div", { class: "terminal", id: "instance-terminal" }, "connecting terminal...\n");
  const termInput = el("input", { placeholder: "type a command, press Enter", style: "flex:1" });
  function pointTerminalOutputAt(target) {
    // Re-run on every render of this same instance's detail view (including
    // the WS-triggered background ones) so the one live socket always writes
    // into whichever <div id="instance-terminal"> is currently in the DOM --
    // the previous render's node was just discarded.
    liveTerminalSocket.onmessage = async (evt) => {
      const text = evt.data instanceof Blob ? await evt.data.text() : evt.data;
      target.textContent += text;
      target.scrollTop = target.scrollHeight;
    };
    liveTerminalSocket.onclose = () => { target.textContent += "\n[session closed]"; };
  }
  if (liveTerminalInstanceId === instanceId && liveTerminalSocket && liveTerminalSocket.readyState <= WebSocket.OPEN) {
    termOut.textContent = "(reconnected to the same live session -- scrollback above this point was on the previous view)\n";
    pointTerminalOutputAt(termOut);
  } else {
    stopLiveTerminal();
    liveTerminalInstanceId = instanceId;
    const proto = location.protocol === "https:" ? "wss" : "ws";
    liveTerminalSocket = new WebSocket(`${proto}://${location.host}/ws/terminal?token=${encodeURIComponent(state.token)}&instanceId=${instanceId}`);
    termOut.textContent = "";
    pointTerminalOutputAt(termOut);
  }
  const termRow = el("div", { class: "terminal-input" }, [
    termInput,
    el("button", { class: "btn", onclick: () => { liveTerminalSocket?.send(termInput.value + "\n"); termInput.value = ""; } }, "Send"),
  ]);
  termInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { liveTerminalSocket?.send(termInput.value + "\n"); termInput.value = ""; } });

  const cpuVal = el("span", {}, "--");
  const memVal = el("span", {}, "--");
  const netVal = el("span", {}, "--");
  // Always point the persistent poll (if one is already running for this
  // instance) at these freshest spans, whether or not we start a new
  // interval below -- this is what lets a same-instance re-render recover
  // instead of resetting.
  statsLive = { cpuEl: cpuVal, memEl: memVal, netEl: netVal };
  if (inst.status === "READY") {
    if (statsPollInstanceId !== instanceId) {
      statsPollInstanceId = instanceId;
      const poll = () => api(`/projects/${state.projectId}/instances/${instanceId}/stats`).then((s) => {
        if (statsPollInstanceId !== instanceId) return; // stopped/switched while this fetch was in flight
        if (statsLive.cpuEl) statsLive.cpuEl.textContent = `${s.cpuPercent}%`;
        if (statsLive.memEl) statsLive.memEl.textContent = `${s.memUsageMb} / ${s.memLimitMb} MB`;
        if (statsLive.netEl) statsLive.netEl.textContent = `↓${(s.networkRxBytes / 1024).toFixed(1)} KB ↑${(s.networkTxBytes / 1024).toFixed(1)} KB`;
      }).catch(() => {});
      poll();
      statsPollInterval = setInterval(poll, 3000);
    }
    // else: already polling this exact instance -- statsLive above just got
    // repointed at the new spans, so the next tick (at most 3s away, same
    // cadence as before) fills them in without losing continuity.
  } else if (statsPollInstanceId === instanceId) {
    stopStatsPolling(); // instance left READY (stopped/crashed/deleting) while we were watching it
  }

  const lastFault = inst.metadata?.lastFault;

  return el("div", {}, [
    el("a", { href: "#", onclick: (e) => { e.preventDefault(); stopStatsPolling(); stopLiveTerminal(); state.tab = "instances"; renderMain(); } }, "← back to Compute"),
    el("h1", { style: "margin-top:10px" }, inst.name),
    el("div", { class: "row", style: "margin-bottom:16px" }, [badge(inst.status), el("span", { class: "muted mono" }, inst.id)]),
    el("div", { class: "grid-2" }, [
      el("div", {}, [
        el("h2", {}, "Overview"),
        el("table", {}, [
          el("tr", {}, [el("td", {}, "Zone"), el("td", { class: "mono" }, inst.spec?.zone || "--")]),
          el("tr", {}, [el("td", {}, "Machine type"), el("td", {}, [
            inst.spec?.machineType || "--",
            inst.metadata?.cpuCapped ? el("span", { class: "muted" }, ` (capped to ${inst.metadata.appliedCpus} vCPU -- this host doesn't have enough CPUs for the full machine type)`) : null,
          ])]),
          el("tr", {}, [el("td", {}, "Internal IP"), el("td", { class: "mono" }, inst.metadata?.ip || "--")]),
          el("tr", {}, [el("td", {}, "Public URL"), el("td", {}, inst.metadata?.publicUrl ? el("a", { href: inst.metadata.publicUrl, target: "_blank" }, inst.metadata.publicUrl) : "--")]),
          el("tr", {}, [el("td", {}, "Container ID"), el("td", { class: "mono" }, (inst.metadata?.containerId || "--").slice(0, 12))]),
        ]),
        el("h2", { style: "margin-top:18px" }, "Live resource usage"),
        el("p", { class: "muted" }, "Real numbers from the Docker Engine's own accounting, polled every 3s -- not simulated."),
        el("table", {}, [
          el("tr", {}, [el("td", {}, "CPU"), el("td", { class: "mono" }, cpuVal)]),
          el("tr", {}, [el("td", {}, "Memory"), el("td", { class: "mono" }, memVal)]),
          el("tr", {}, [el("td", {}, "Network I/O"), el("td", { class: "mono" }, netVal)]),
        ]),
        inst.metadata?.startupOutput ? el("div", {}, [
          el("h2", { style: "margin-top:18px" }, `Startup script output (exit ${inst.metadata.startupExitCode})`),
          el("pre", { class: "terminal", style: "height:100px" }, inst.metadata.startupOutput),
        ]) : null,
      ]),
      el("div", {}, [
        el("h2", {}, "Run a command"),
        execOut, execRow,
      ]),
    ]),
    el("div", { class: "section" }, [
      el("h2", {}, "Fault injection"),
      el("p", { class: "muted" }, "A real docker kill -SIGKILL against this instance's actual container -- it stays down (Docker's restart policy does not bring back an operator-killed container) until you Start it again, same as a crashed real VM."),
      el("div", { class: "row" }, [
        inst.status === "READY"
          ? el("button", { class: "btn small danger", onclick: () => withErrorHandling(async () => {
              const res = await api(`/projects/${state.projectId}/instances/${instanceId}/faults/crash`, { method: "POST" });
              trackOperation(instanceId, res.operationId);
            }) }, "Crash (SIGKILL)")
          : el("span", { class: "muted" }, "instance must be READY to crash it"),
      ]),
      lastFault ? el("p", { class: "muted", style: "font-size:12px;margin-top:8px" },
        `Last fault: ${lastFault.type} at ${fmtTime(lastFault.injectedAt || lastFault.finishedAt)}${lastFault.exitCode !== undefined ? ` (exit code ${lastFault.exitCode})` : ""}`) : null,
    ]),
    el("div", { class: "section" }, [el("h2", {}, "Troubleshoot"), renderTroubleshootPanel(instanceId)]),
    el("div", { class: "section" }, [el("h2", {}, "Logs"), logsBox]),
    el("div", { class: "section" }, [el("h2", {}, "Terminal (real docker exec, Tty-attached)"), termOut, termRow]),
  ]);
}

// Milestone 11: a generic, resource-type-agnostic diagnostic panel over
// GET /resources/:id/troubleshoot -- real recorded history (status
// transitions, alerts, operations) plus, for instances, a live Docker
// inspect() taken at the moment the button is clicked. Self-contained like
// the exec panel above: it renders its own result without triggering a
// full-page rebuild.
function renderTroubleshootPanel(resourceId) {
  const resultBox = el("div", { class: "muted" }, "Click Run diagnostics to check this resource's real current state against its history.");
  const button = el("button", { class: "btn small", onclick: async () => {
    button.disabled = true;
    resultBox.replaceChildren("running diagnostics...");
    try {
      const r = await api(`/projects/${state.projectId}/resources/${resourceId}/troubleshoot`);
      resultBox.replaceChildren(renderTroubleshootResult(r));
    } catch (err) {
      resultBox.replaceChildren(el("span", { class: "error-banner" }, err.body?.message || err.message));
    } finally {
      button.disabled = false;
    }
  } }, "Run diagnostics");
  return el("div", {}, [button, el("div", { style: "margin-top:10px" }, resultBox)]);
}

function renderTroubleshootResult(r) {
  return el("div", { class: "stack" }, [
    r.drift ? el("div", { class: "error-banner" }, r.drift) : el("div", { class: "muted" }, "No drift detected between the database and live infrastructure."),
    r.live ? el("div", {}, [
      el("strong", {}, "Live infrastructure state (read right now):"),
      el("pre", { class: "terminal", style: "height:auto;padding:8px" }, JSON.stringify(r.live, null, 2)),
    ]) : null,
    el("div", {}, [
      el("strong", {}, "Recent status history:"),
      r.recentEvents.length ? el("ul", { class: "steps" }, r.recentEvents.map((e) =>
        el("li", { class: "DONE" }, [el("span", { class: "dot" }), `${e.fromStatus || "(created)"} → ${e.toStatus}${e.message ? " -- " + e.message : ""} (${fmtTime(e.createdAt)})`])))
        : el("span", { class: "muted" }, " none"),
    ]),
    el("div", {}, [
      el("strong", {}, "Alerts:"),
      r.alerts.length ? el("ul", {}, r.alerts.map((a) => el("li", {}, [badge(a.severity === "CRITICAL" ? "FAILED" : "DEGRADED"), ` ${a.ruleKey}: ${a.message} (${a.status})`])))
        : el("span", { class: "muted" }, " none"),
    ]),
    el("div", {}, [
      el("strong", {}, "Recent operations:"),
      r.recentOperations.length ? el("ul", {}, r.recentOperations.map((o) => el("li", {}, [badge(o.status), ` ${o.type} (${fmtTime(o.createdAt)})`])))
        : el("span", { class: "muted" }, " none"),
    ]),
  ]);
}

// Milestone 10: the graph payload from GET /architecture (apps/api/src/
// resources/graph.ts) was always real -- rebuilt from `resources` +
// `resource_relationships` on every request -- but the console only ever
// rendered it as a wrapped list of cards plus a text list of "A -> kind ->
// B" lines underneath, with no actual lines connecting anything. This is
// a real node-link diagram over that same data: a deterministic layered
// layout (tier = a resource type's real position in the dependency chain,
// e.g. every subnet/instance is laid out to the right of the network it
// points at) computed client-side, and real SVG paths drawn between real
// node centers for every resource_relationships row -- not a hand-placed
// diagram. Layout positions are a rendering choice; the topology itself
// (which nodes exist, which edges connect them) is 100% server data.

const ARCH_TYPE_TIER = {
  network: 0,
  subnet: 1, firewall_rule: 1, dns_record: 1, registry: 1,
  disk: 2, database: 2, bucket: 2, secret: 2, container_image: 2,
  instance: 3, k8s_cluster: 3,
  k8s_deployment: 4, load_balancer: 4,
  pipeline: 5,
  pipeline_run: 6,
};
const ARCH_TIER_LABELS = [
  "Network fabric", "Network config", "Storage & images",
  "Compute & clusters", "Deployments & LBs", "Pipelines", "Pipeline runs",
];
const ARCH_EDGE_STYLE = {
  contains: { stroke: "var(--accent)", dash: "" },
  connects_to: { stroke: "var(--accent-light)", dash: "" },
  depends_on: { stroke: "var(--ink-soft)", dash: "5,4" },
  routes_to: { stroke: "var(--green)", dash: "" },
};
const ARCH_STATUS_FILL = {
  READY: ["var(--green-bg)", "var(--green)"],
  SUCCEEDED: ["var(--green-bg)", "var(--green)"],
  FAILED: ["var(--red-bg)", "var(--red)"],
  DEGRADED: ["var(--red-bg)", "var(--red)"],
  STOPPED: ["var(--grey-bg)", "var(--grey-ink)"],
  DELETED: ["var(--grey-bg)", "var(--grey-ink)"],
};
function archStatusColors(status) {
  return ARCH_STATUS_FILL[status] || ["var(--amber-bg)", "var(--amber)"];
}

let graphSelectedId = null; // transient UI-only selection, not persisted state

function computeArchLayout(nodes, edges) {
  const resourceNodes = nodes.filter((n) => n.type !== "project");
  const byTier = new Map();
  for (const n of resourceNodes) {
    const tier = ARCH_TYPE_TIER[n.type] ?? 7;
    if (!byTier.has(tier)) byTier.set(tier, []);
    byTier.get(tier).push(n);
  }
  for (const list of byTier.values()) list.sort((a, b) => a.label.localeCompare(b.label));

  const colWidth = 220, rowHeight = 74, boxW = 176, boxH = 50, marginX = 30, marginY = 26;
  const tiers = [...byTier.keys()].sort((a, b) => a - b);
  const maxRows = Math.max(1, ...tiers.map((t) => byTier.get(t).length));
  const positioned = new Map();
  for (const tier of tiers) {
    const list = byTier.get(tier);
    list.forEach((n, i) => {
      positioned.set(n.id, {
        node: n, tier,
        x: marginX + tier * colWidth,
        y: marginY + i * rowHeight,
        w: boxW, h: boxH,
      });
    });
  }
  const width = tiers.length ? marginX * 2 + (Math.max(...tiers) + 1) * colWidth - (colWidth - boxW) : boxW + marginX * 2;
  const height = marginY * 2 + maxRows * rowHeight - (rowHeight - boxH);
  const relevantEdges = edges.filter((e) => positioned.has(e.from) && positioned.has(e.to));
  return { positioned, tiers, width: Math.max(width, 300), height: Math.max(height, 200), edges: relevantEdges };
}

function renderArchitecture() {
  const { nodes, edges } = state.graph;
  const layout = computeArchLayout(nodes, edges);
  const { positioned, tiers, width, height } = layout;

  const neighborIds = new Set();
  if (graphSelectedId) {
    neighborIds.add(graphSelectedId);
    for (const e of layout.edges) {
      if (e.from === graphSelectedId) neighborIds.add(e.to);
      if (e.to === graphSelectedId) neighborIds.add(e.from);
    }
  }
  const dim = (id) => graphSelectedId && !neighborIds.has(id);

  const defs = svg("defs", {}, Object.entries(ARCH_EDGE_STYLE).map(([kind, style]) =>
    svg("marker", { id: `arrow-${kind}`, viewBox: "0 0 10 10", refX: "9", refY: "5", markerWidth: "7", markerHeight: "7", orient: "auto-start-reverse" }, [
      svg("path", { d: "M0,0 L10,5 L0,10 z", fill: style.stroke }),
    ])));

  // markers can't reference CSS custom properties portably via presentation
  // attributes in every browser, so resolve them to concrete colors once here.
  const resolved = getComputedStyle(document.documentElement);
  const resolveColor = (v) => v.startsWith("var(") ? resolved.getPropertyValue(v.slice(4, -1)).trim() || "#64748b" : v;
  for (const marker of defs.querySelectorAll("marker path")) {
    const kind = marker.closest("marker").id.replace("arrow-", "");
    marker.setAttribute("fill", resolveColor(ARCH_EDGE_STYLE[kind].stroke));
  }

  const edgePaths = layout.edges.map((e) => {
    const from = positioned.get(e.from), to = positioned.get(e.to);
    const style = ARCH_EDGE_STYLE[e.kind] || { stroke: "var(--ink-soft)", dash: "" };
    const leftToRight = to.x >= from.x;
    const x1 = leftToRight ? from.x + from.w : from.x;
    const x2 = leftToRight ? to.x : to.x + to.w;
    const y1 = from.y + from.h / 2, y2 = to.y + to.h / 2;
    const midX = (x1 + x2) / 2;
    const path = `M${x1},${y1} C${midX},${y1} ${midX},${y2} ${x2},${y2}`;
    const faded = dim(e.from) || dim(e.to);
    return svg("path", {
      d: path, fill: "none", stroke: resolveColor(style.stroke), "stroke-width": faded ? "1" : "1.75",
      "stroke-dasharray": style.dash, opacity: faded ? "0.15" : "0.85", "marker-end": `url(#arrow-${e.kind})`,
    });
  });

  const nodeGroups = [...positioned.values()].map(({ node, x, y, w, h }) => {
    const [fill, stroke] = archStatusColors(node.status);
    const faded = dim(node.id);
    return svg("g", {
      class: "arch-node-group", opacity: faded ? "0.3" : "1", style: "cursor:pointer",
      onclick: () => { graphSelectedId = graphSelectedId === node.id ? null : node.id; renderMain(); },
    }, [
      svg("rect", { x, y, width: w, height: h, rx: "8", fill: resolveColor(fill), stroke: resolveColor(stroke), "stroke-width": graphSelectedId === node.id ? "2.5" : "1.25" }),
      svg("text", { x: x + 10, y: y + 18, "font-size": "9", "font-family": "var(--mono)", fill: resolveColor(stroke), style: "text-transform:uppercase;letter-spacing:.04em" }, node.type),
      svg("text", { x: x + 10, y: y + 34, "font-size": "12.5", "font-weight": "600", fill: resolveColor("var(--ink)") }, truncateLabel(node.label, 20)),
      node.status ? svg("text", { x: x + 10, y: y + 45, "font-size": "9", fill: resolveColor(stroke) }, node.status) : null,
    ]);
  });

  const tierHeaders = tiers.map((t) => {
    const p = [...positioned.values()].find((v) => v.tier === t);
    return svg("text", { x: p.x, y: "14", "font-size": "10.5", "font-weight": "700", fill: resolveColor("var(--ink-soft)"), style: "text-transform:uppercase;letter-spacing:.05em" }, ARCH_TIER_LABELS[t] || `Tier ${t}`);
  });

  const diagram = tiers.length
    ? svg("svg", { viewBox: `0 -22 ${width} ${height + 22}`, width, height: height + 22, style: "min-width:100%;display:block" }, [
        defs, ...tierHeaders, ...edgePaths, ...nodeGroups,
      ])
    : el("p", { class: "muted" }, "No resources yet -- create a network to see the architecture diagram populate live.");

  const resourceNodeCount = nodes.filter((n) => n.type !== "project").length;

  return el("div", {}, [
    el("h1", {}, "Architecture"),
    el("p", { class: "subtitle" }, "Generated automatically from live resources and their real dependency edges -- nothing here is hand-drawn, and it re-fetches live over the same WebSocket as the rest of the console."),
    el("div", { class: "card" }, [
      el("div", { class: "row", style: "justify-content:space-between;align-items:baseline;margin-bottom:10px" }, [
        el("div", { class: "muted", style: "font-size:12px" }, `${resourceNodeCount} resource${resourceNodeCount === 1 ? "" : "s"} · ${layout.edges.length} relationship${layout.edges.length === 1 ? "" : "s"}${graphSelectedId ? " · click the node again to clear the highlight" : " · click a node to trace its dependencies"}`),
      ]),
      el("div", { class: "arch-svg-wrap" }, [diagram]),
      el("div", { class: "arch-legend" }, [
        ...Object.entries(ARCH_EDGE_STYLE).map(([kind, style]) => el("span", { class: "arch-legend-item" }, [
          el("span", { class: "arch-swatch", style: `background:${style.stroke}${style.dash ? ";background-image:repeating-linear-gradient(90deg, currentColor 0 4px, transparent 4px 8px)" : ""}` }),
          kind.replace("_", " "),
        ])),
        el("span", { class: "arch-legend-item" }, [el("span", { class: "arch-swatch", style: "background:var(--green)" }), "healthy"]),
        el("span", { class: "arch-legend-item" }, [el("span", { class: "arch-swatch", style: "background:var(--amber)" }), "in progress"]),
        el("span", { class: "arch-legend-item" }, [el("span", { class: "arch-swatch", style: "background:var(--red)" }), "failed / degraded"]),
      ]),
    ]),
  ]);
}

function truncateLabel(label, max) {
  return label.length > max ? label.slice(0, max - 1) + "…" : label;
}

// Milestone 13: real pagination. "Load more" fetches the next real page
// from Postgres (LIMIT/OFFSET) and appends it -- state.activity/state.audit
// carry {items, page, pageSize, total, hasMore} straight from the API, so
// this never guesses whether more rows exist.
function loadMoreButton(kind) {
  const bucket = state[kind];
  if (!bucket.items.length) return null;
  return el("div", { class: "row", style: "margin-top:12px;align-items:center;gap:10px" }, [
    bucket.hasMore
      ? el("button", { class: "btn small", onclick: () => withErrorHandling(async () => {
          const next = await api(`/projects/${state.projectId}/${kind === "audit" ? "audit" : "activity"}?page=${bucket.page + 1}&pageSize=${bucket.pageSize}`);
          state[kind] = { ...next, items: [...bucket.items, ...next.items] };
          renderMain();
        }) }, "Load more")
      : null,
    el("span", { class: "muted small" }, `Showing ${bucket.items.length} of ${bucket.total}`),
  ]);
}

function renderActivity() {
  return el("div", {}, [
    el("h1", {}, "Activity"),
    el("div", { class: "timeline" }, state.activity.items.length
      ? state.activity.items.map((e) => el("div", { class: "event" }, [
          el("div", {}, [el("strong", {}, e.action), " ", badge(e.status)]),
          el("div", { class: "meta" }, `${fmtTime(e.createdAt)} · ${e.resourceName || e.resourceType || ""} · ${e.durationMs}ms`),
        ]))
      : [el("p", { class: "muted" }, "No activity yet.")]),
    loadMoreButton("activity"),
  ]);
}

function renderAudit() {
  const rows = state.audit.items.map((a) => el("tr", {}, [
    el("td", { class: "muted" }, fmtTime(a.createdAt)),
    el("td", {}, a.action),
    el("td", {}, badge(a.status)),
    el("td", { class: "mono" }, a.httpMethod + " " + a.apiEndpoint),
    el("td", { class: "mono muted" }, a.requestId),
  ]));
  return el("div", {}, [
    el("h1", {}, "Audit Log"),
    el("p", { class: "subtitle" }, "Every API call, logged automatically -- there is no code path that skips this."),
    el("table", {}, [
      el("thead", {}, el("tr", {}, ["Time", "Action", "Status", "Request", "Request ID"].map((h) => el("th", {}, h)))),
      el("tbody", {}, rows.length ? rows : [el("tr", { class: "empty-row" }, [el("td", { colspan: "5" }, "No audit events yet.")])]),
    ]),
    loadMoreButton("audit"),
  ]);
}

function renderIam() {
  const roles = state.iam.roles || [];
  return el("div", {}, [
    el("h1", {}, "IAM"),
    el("div", { class: "grid-2" }, [
      el("div", {}, [
        el("h2", {}, "Built-in roles"),
        el("table", {}, [
          el("thead", {}, el("tr", {}, ["Role", "Allow", "Deny"].map((h) => el("th", {}, h)))),
          el("tbody", {}, roles.map((r) => el("tr", {}, [
            el("td", {}, r.name),
            el("td", { class: "mono", style: "font-size:11px" }, r.allow.join(", ")),
            el("td", { class: "mono", style: "font-size:11px" }, r.deny.join(", ") || "--"),
          ]))),
        ]),
      ]),
      el("div", {}, [
        el("h2", {}, "Project bindings"),
        el("table", {}, [
          el("thead", {}, el("tr", {}, ["User ID", "Role"].map((h) => el("th", {}, h)))),
          el("tbody", {}, (state.iam.bindings || []).map((b) => el("tr", {}, [el("td", { class: "mono" }, b.userId), el("td", {}, b.roleKey)]))),
        ]),
      ]),
    ]),
  ]);
}

// -------------------------------------------------------------- Data loads

async function loadOrgs() {
  state.orgs = await api("/organizations");
  if (state.orgId && !state.orgs.some((o) => o.id === state.orgId)) state.orgId = null;
  if (state.orgId) await loadProjects();
  render();
}

async function loadProjects() {
  state.projects = await api("/projects");
  if (state.projectId && !state.projects.some((p) => p.id === state.projectId)) state.projectId = null;
  if (state.projectId) await selectProject(state.projectId);
  render();
}

async function refreshTabData() {
  const [networks, subnets, firewallRules, dnsRecords, loadBalancers, disks, registries, images, buckets, databases, secrets, k8sClusters, k8sDeployments, pipelines, pipelineRuns, instances, graph, serviceAccounts, instanceTemplates, managedInstanceGroups, natGateways, vpcPeerings, sharedVpcAttachments, bigqueryDatasets, composerEnvironments, cloudRunServices] = await Promise.all([
    api(`/projects/${state.projectId}/networks`),
    api(`/projects/${state.projectId}/subnets`),
    api(`/projects/${state.projectId}/firewall-rules`),
    api(`/projects/${state.projectId}/dns-records`),
    api(`/projects/${state.projectId}/load-balancers`),
    api(`/projects/${state.projectId}/disks`),
    api(`/projects/${state.projectId}/registries`),
    api(`/projects/${state.projectId}/images`),
    api(`/projects/${state.projectId}/buckets`),
    api(`/projects/${state.projectId}/databases`),
    api(`/projects/${state.projectId}/secrets`),
    api(`/projects/${state.projectId}/k8s-clusters`),
    api(`/projects/${state.projectId}/k8s-deployments`),
    api(`/projects/${state.projectId}/pipelines`),
    api(`/projects/${state.projectId}/pipeline-runs`),
    api(`/projects/${state.projectId}/instances`),
    api(`/projects/${state.projectId}/architecture`),
    api(`/projects/${state.projectId}/service-accounts`),
    api(`/projects/${state.projectId}/instance-templates`),
    api(`/projects/${state.projectId}/managed-instance-groups`),
    api(`/projects/${state.projectId}/nat-gateways`),
    api(`/projects/${state.projectId}/vpc-peerings`),
    api(`/projects/${state.projectId}/shared-vpc-attachments`),
    api(`/projects/${state.projectId}/bigquery-datasets`),
    api(`/projects/${state.projectId}/composer-environments`),
    api(`/projects/${state.projectId}/cloud-run-services`),
  ]);
  state.networks = networks;
  state.subnets = subnets;
  state.firewallRules = firewallRules;
  state.dnsRecords = dnsRecords;
  state.loadBalancers = loadBalancers;
  state.disks = disks;
  state.registries = registries;
  state.images = images;
  state.buckets = buckets;
  state.databases = databases;
  state.secrets = secrets;
  state.k8sClusters = k8sClusters;
  state.k8sDeployments = k8sDeployments;
  state.pipelines = pipelines;
  state.pipelineRuns = pipelineRuns;
  state.instances = instances;
  state.graph = graph;
  state.serviceAccounts = serviceAccounts;
  state.instanceTemplates = instanceTemplates;
  state.managedInstanceGroups = managedInstanceGroups;
  state.natGateways = natGateways;
  state.vpcPeerings = vpcPeerings;
  state.sharedVpcAttachments = sharedVpcAttachments;
  state.bigqueryDatasets = bigqueryDatasets;
  state.composerEnvironments = composerEnvironments;
  state.cloudRunServices = cloudRunServices;
  if (state.tab === "activity") state.activity = await api(`/projects/${state.projectId}/activity?page=1&pageSize=${state.activity.pageSize}`);
  if (state.tab === "audit") state.audit = await api(`/projects/${state.projectId}/audit?page=1&pageSize=${state.audit.pageSize}`);
  if (state.tab === "iam") state.iam = await api(`/projects/${state.projectId}/iam`);
  if (state.tab === "observability") state.alerts = await api(`/projects/${state.projectId}/alerts`);
  if (state.tab === "learning") state.scenarios = (await api(`/projects/${state.projectId}/scenarios`)).scenarios;
  render();
}

// -------------------------------------------------------------------- Root

function renderMain() {
  const mainEl = document.getElementById("main-content");
  if (!mainEl) { render(); return; }
  // Bug fix: this used to replace #main-content with *only* currentTabView(),
  // silently dropping the error banner that render() normally places next to
  // it. Since WS events (a resource update, an operation step, a health-check
  // tick) call renderMain() constantly, a validation error from e.g. "Create
  // instance" could vanish from the screen within a second or two of showing
  // up -- the request had failed for a real reason, but the console gave no
  // visible sign of it. Rebuild the same two children render() would.
  const banner = errorBanner();
  mainEl.replaceChildren(...(banner ? [banner] : []), currentTabView());
}

function currentTabView() {
  if (state.tab.startsWith("instance:")) return renderInstanceDetail(state.tab.split(":")[1]);
  switch (state.tab) {
    case "networks": return renderNetworks();
    case "firewall": return renderFirewall();
    case "dns": return renderDns();
    case "loadbalancers": return renderLoadBalancers();
    case "disks": return renderDisks();
    case "registry": return renderRegistry();
    case "storage": return renderStorage();
    case "databases": return renderDatabases();
    case "secrets": return renderSecrets();
    case "kubernetes": return renderKubernetes();
    case "cicd": return renderCicd();
    case "serviceaccounts": return renderServiceAccounts();
    case "instancegroups": return renderInstanceGroups();
    case "natpeering": return renderNatPeering();
    case "bigquery": return renderBigquery();
    case "composer": return renderComposer();
    case "cloudrun": return renderCloudRun();
    case "observability": return renderObservability();
    case "learning": return renderLearning();
    case "instances": return renderInstances();
    case "architecture": return renderArchitecture();
    case "activity": return renderActivity();
    case "audit": return renderAudit();
    case "iam": return renderIam();
    default: return renderDashboard();
  }
}

function render() {
  root.replaceChildren();
  if (!state.token) { root.append(renderAuth()); return; }
  if (!state.orgId) { root.append(renderTopbar(), renderOrgPicker()); return; }
  if (!state.projectId) { root.append(renderTopbar(), renderProjectPicker()); return; }

  const layout = el("div", { class: "layout" }, [
    renderNav(),
    el("div", { class: "main", id: "main-content" }, [
      // Regression fix: withErrorHandling() has always captured failures
      // into state.error, but this banner previously only existed on the
      // pre-login/org-picker/project-picker screens. Every error raised
      // once inside the actual console -- permission denied, a blocked
      // delete, a validation error on exec -- was silently swallowed:
      // state.error was set and render() ran, but nothing in the main
      // layout ever displayed it. The failed request was visible only in
      // the browser's network tab, never to the person using the app.
      errorBanner(),
      currentTabView(),
    ]),
  ]);
  root.append(renderTopbar(), layout);
}

// ------------------------------------------------------------------- Boot

(async function boot() {
  if (state.token) {
    try {
      state.user = await api("/auth/me");
      await loadOrgs();
      return;
    } catch {
      logout();
      return;
    }
  }
  render();
})();

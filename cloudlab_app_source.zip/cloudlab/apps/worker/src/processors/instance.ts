import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { config } from "../../../api/src/config.js";
import { docker, containerNameFor, networkNameFor, diskVolumeNameFor } from "../docker.js";
import { firstFreeIp, ipInCidr } from "../net/ipalloc.js";
import { demuxDockerStream } from "../net/demux.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";
import { machineTypeSpec } from "@cloudlab/shared";

// Docker's --cpus / NanoCpus is an admission-control check, not just a soft
// cgroup weight: `docker run --cpus 4` on a 2-CPU host fails outright with
// "range of CPUs is from 0.01 to 2.00" rather than silently oversubscribing.
// A real cloud never runs into this (its fleets dwarf any one machine type),
// but this simulator's "hosts" are real laptops/VMs -- so a large machine
// type has to be honest about the host's real ceiling rather than fail the
// whole instance create. Cached for the worker's lifetime; Docker's own
// CPU count doesn't change while it's running.
let cachedHostCpus: number | undefined;
async function hostCpuCount(): Promise<number> {
  if (cachedHostCpus) return cachedHostCpus;
  try {
    const info = await docker.info();
    cachedHostCpus = Math.max(1, info.NCPU ?? 1);
  } catch {
    cachedHostCpus = 1;
  }
  return cachedHostCpus;
}

async function waitForHealthy(ip: string, timeoutMs = 8000): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://${ip}:8080/healthz`, { signal: AbortSignal.timeout(1000) });
      if (res.ok) return true;
    } catch {
      // not up yet
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

export async function processInstanceCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { networkId: string; subnetId?: string; zone?: string; machineType?: string; publish?: boolean; diskIds?: string[]; startupScript?: string };
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "NETWORKING", "RUNNING");
    const dockerNetworkName = networkNameFor(network.id);

    // A subnet is a real IPAM assignment, not just a label: when the instance
    // targets one, compute a free address within that subnet's CIDR and pin
    // the container to it via Docker's IPAMConfig, instead of letting
    // Docker's allocator pick anywhere in the parent network's range.
    let staticIp: string | undefined;
    if (spec.subnetId) {
      const [subnet] = await db.select().from(resources).where(eq(resources.id, spec.subnetId)).limit(1);
      const subnetCidr = (subnet.spec as { cidr: string }).cidr;
      // A subnet's address range is carved out of its parent network's own
      // CIDR, so a plain instance created directly on the network (no
      // subnetId at all, Docker's own auto-IPAM picking wherever it likes)
      // can land on an address that also falls inside this subnet's range.
      // Consider every instance on the SAME network "used" here, not only
      // ones explicitly scoped to this subnet -- otherwise firstFreeIp can
      // hand out an address Docker already gave to a sibling container,
      // and the real `docker run` genuinely fails with "address already in
      // use" (this was caught by the QA suite's TC-19 subnet coverage).
      const siblings = await db.select().from(resources).where(eq(resources.type, "instance"));
      const used = siblings
        .filter((r) => (r.spec as { networkId?: string }).networkId === spec.networkId && r.status !== "DELETED")
        .map((r) => (r.metadata as { ip?: string }).ip)
        .filter((ip): ip is string => !!ip && ipInCidr(ip, subnetCidr));
      staticIp = firstFreeIp(subnetCidr, used);
    }
    await pushStep(operationId, projectId, "NETWORKING", "DONE", staticIp ? `assigned static IP ${staticIp} from subnet` : undefined);

    // Real volume mounts, one per attached disk, each landing at a
    // predictable /mnt/disk-N path -- genuine persistent storage backed by
    // Docker's local volume driver, not a label pretending to be one.
    const diskIds = spec.diskIds ?? [];
    const mounts = diskIds.map((diskId, idx) => ({
      Type: "volume" as const,
      Source: diskVolumeNameFor(diskId),
      Target: `/mnt/disk-${idx + 1}`,
    }));

    // The selected machine type is a real resource-shape choice, not a
    // cosmetic label: apply it as genuine Docker CPU/memory limits, so a
    // bigger machine type really does give the container more headroom and
    // `docker inspect` shows the real limit -- scaled down from GCP's real
    // e2 family sizes to stay friendly to a laptop running this whole stack
    // locally (see packages/shared's MACHINE_TYPES for the full table).
    const machine = machineTypeSpec(spec.machineType);
    const hostCpus = await hostCpuCount();
    const appliedCpus = Math.min(machine.vcpus, hostCpus);
    const cpuNote = appliedCpus < machine.vcpus
      ? ` (capped to ${appliedCpus} -- this host only has ${hostCpus} CPU${hostCpus === 1 ? "" : "s"})`
      : "";
    await pushStep(operationId, projectId, "VM_PROVISIONING", "RUNNING", `docker run --network ${dockerNetworkName} --cpus ${appliedCpus}${cpuNote} --memory ${machine.memoryMb}m ${config.guestImage}`);
    const publish = spec.publish !== false;
    const container = await docker.createContainer({
      name: containerNameFor(resourceId),
      Image: config.guestImage,
      Hostname: resource.name.replace(/[^a-zA-Z0-9-]/g, "-").slice(0, 63),
      ExposedPorts: { "8080/tcp": {} },
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId, "cloudlab.machineType": machine.name, "cloudlab.zone": spec.zone ?? "" },
      NetworkingConfig: staticIp
        ? { EndpointsConfig: { [dockerNetworkName]: { IPAMConfig: { IPv4Address: staticIp } } } }
        : undefined,
      HostConfig: {
        NetworkMode: dockerNetworkName,
        PortBindings: publish ? { "8080/tcp": [{ HostPort: "" }] } : undefined,
        RestartPolicy: { Name: "unless-stopped" },
        Mounts: mounts.length ? mounts : undefined,
        NanoCpus: Math.round(appliedCpus * 1e9),
        Memory: machine.memoryMb * 1024 * 1024,
      },
    });
    await container.start();
    await pushStep(operationId, projectId, "VM_PROVISIONING", "DONE");

    const info = await container.inspect();
    const ip = info.NetworkSettings.Networks[dockerNetworkName]?.IPAddress;
    const hostPort = info.NetworkSettings.Ports["8080/tcp"]?.[0]?.HostPort;

    await pushStep(operationId, projectId, "HEALTH_CHECK", "RUNNING");
    const healthy = ip ? await waitForHealthy(ip) : false;
    if (!healthy) throw new Error("guest agent did not become healthy within the timeout");
    await pushStep(operationId, projectId, "HEALTH_CHECK", "DONE");

    await addRelationship(resourceId, network.id, "connects_to");
    if (spec.subnetId) await addRelationship(resourceId, spec.subnetId, "contains");
    for (const diskId of diskIds) await addRelationship(resourceId, diskId, "depends_on");

    // A startup script is a real `docker exec` run once the container is
    // healthy -- genuine command execution via the same mechanism the
    // console's exec panel uses, not a simulated log line.
    let startupOutput: string | undefined;
    let startupExitCode: number | undefined;
    if (spec.startupScript?.trim()) {
      await pushStep(operationId, projectId, "STARTUP_SCRIPT", "RUNNING");
      try {
        const exec = await container.exec({ Cmd: ["/bin/sh", "-c", spec.startupScript], AttachStdout: true, AttachStderr: true });
        const stream = await exec.start({ hijack: true, stdin: false });
        const chunks: Buffer[] = [];
        await new Promise<void>((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error("startup script timed out after 15s")), 15_000);
          stream.on("data", (c: Buffer) => chunks.push(c));
          stream.on("end", () => { clearTimeout(timer); resolve(); });
          stream.on("error", (e: Error) => { clearTimeout(timer); reject(e); });
        });
        const inspect = await exec.inspect();
        startupOutput = demuxDockerStream(Buffer.concat(chunks)).slice(0, 4000);
        startupExitCode = inspect.ExitCode ?? undefined;
        await pushStep(operationId, projectId, "STARTUP_SCRIPT", "DONE", `exit code ${startupExitCode}`);
      } catch (err) {
        startupOutput = (err as Error).message;
        await pushStep(operationId, projectId, "STARTUP_SCRIPT", "FAILED", startupOutput);
      }
    }

    await setResourceStatus(resourceId, "READY", "Container started and health check passed", {
      containerId: info.Id,
      ip,
      hostPort,
      publicUrl: hostPort ? `http://${config.publicHost}:${hostPort}` : null,
      diskMounts: mounts.map((m) => ({ diskId: diskIds[mounts.indexOf(m)], target: m.Target })),
      startupOutput,
      startupExitCode,
      appliedCpus,
      cpuCapped: appliedCpus < machine.vcpus,
    });
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "READY", "DONE");
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processInstanceStart(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "STARTING", "RUNNING");
    const container = docker.getContainer(containerNameFor(resourceId));
    await container.start();
    const info = await container.inspect();
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { networkId: string };
    const dockerNetworkName = networkNameFor(spec.networkId);
    const ip = info.NetworkSettings.Networks[dockerNetworkName]?.IPAddress;
    const healthy = ip ? await waitForHealthy(ip) : false;
    if (!healthy) throw new Error("guest agent did not become healthy after start");
    await pushStep(operationId, projectId, "STARTING", "DONE");

    await setResourceStatus(resourceId, "READY", "Instance started");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processInstanceStop(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "STOPPING", "RUNNING");
    const container = docker.getContainer(containerNameFor(resourceId));
    await container.stop({ t: 5 });
    await pushStep(operationId, projectId, "STOPPING", "DONE");

    await setResourceStatus(resourceId, "STOPPED", "Instance stopped");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processInstanceDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const container = docker.getContainer(containerNameFor(resourceId));
    try {
      await container.remove({ force: true });
    } catch (err) {
      const statusCode = (err as { statusCode?: number }).statusCode;
      if (statusCode !== 404) throw err;
    }
    await setResourceStatus(resourceId, "DELETED", "Container removed");
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

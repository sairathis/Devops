import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { k8sClusterNetworkNameFor } from "../docker.js";
import { docker } from "../docker.js";
import { createPod, listLivePods, podContainerName, defaultPodImage } from "../k8s/pods.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface DeploymentSpec {
  clusterId: string;
  image?: string;
  replicas?: number;
  command?: string[];
}

export async function processK8sDeploymentCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as DeploymentSpec;
    const [cluster] = await db.select().from(resources).where(eq(resources.id, spec.clusterId)).limit(1);
    if (!cluster || cluster.status !== "READY") throw new Error("target k8s_cluster is not READY");

    const replicas = Math.max(1, Math.min(20, spec.replicas ?? 1));
    const image = spec.image || defaultPodImage();
    const networkName = k8sClusterNetworkNameFor(cluster.id);

    await pushStep(operationId, projectId, "SCHEDULING", "RUNNING", `starting ${replicas} pod(s) on cluster ${cluster.name}`);
    const podContainerIds: string[] = [];
    for (let i = 0; i < replicas; i++) {
      const info = await createPod({ deploymentResourceId: resourceId, projectId, index: i, clusterNetworkName: networkName, image, command: spec.command });
      podContainerIds.push(info.Id);
    }
    await pushStep(operationId, projectId, "SCHEDULING", "DONE");

    await addRelationship(resourceId, cluster.id, "depends_on");

    await setResourceStatus(resourceId, "READY", `${replicas} pod(s) running`, {
      clusterId: cluster.id,
      clusterName: cluster.name,
      image,
      replicas,
      podContainerIds,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

// Not a full rolling update -- adding replicas starts new pod containers at
// the next indices; removing replicas stops the highest-indexed ones first.
// Real containers actually start/stop either way, just without the
// surge/drain sequencing a real Kubernetes Deployment controller would do.
export async function processK8sDeploymentScale(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as DeploymentSpec;
    const desired = Math.max(1, Math.min(20, spec.replicas ?? 1));
    const image = spec.image || defaultPodImage();
    const [cluster] = await db.select().from(resources).where(eq(resources.id, spec.clusterId)).limit(1);
    const networkName = k8sClusterNetworkNameFor(cluster.id);

    const live = await listLivePods(resourceId);
    const current = live.length;

    await pushStep(operationId, projectId, "SCALING", "RUNNING", `${current} -> ${desired} replicas`);
    if (desired > current) {
      for (let i = current; i < desired; i++) {
        await createPod({ deploymentResourceId: resourceId, projectId, index: i, clusterNetworkName: networkName, image, command: spec.command });
      }
    } else if (desired < current) {
      for (let i = current - 1; i >= desired; i--) {
        try {
          await docker.getContainer(podContainerName(resourceId, i)).remove({ force: true });
        } catch (err) {
          if ((err as { statusCode?: number }).statusCode !== 404) throw err;
        }
      }
    }
    await pushStep(operationId, projectId, "SCALING", "DONE");

    // setResourceStatus's metadata merge is shallow (see resources/model.ts),
    // so leaving podContainerIds out here would leave it holding the
    // creation-time container list forever -- silently wrong the moment
    // anyone scales, even though the real Docker containers underneath are
    // genuinely correct. Recompute it for real from the live containers
    // this same operation just created/removed, so what's persisted always
    // matches Docker's own accounting.
    const liveAfterScale = await listLivePods(resourceId);
    await setResourceStatus(resourceId, "READY", `Scaled to ${desired} replica(s)`, {
      replicas: desired,
      podContainerIds: liveAfterScale.map((c) => c.Id),
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processK8sDeploymentDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const live = await listLivePods(resourceId);
    for (const c of live) {
      try {
        await docker.getContainer(c.Id).remove({ force: true });
      } catch (err) {
        if ((err as { statusCode?: number }).statusCode !== 404) throw err;
      }
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "All pods removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

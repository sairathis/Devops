"use client";

import * as React from "react";
import { Gauge } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState } from "@/components/resource-explorer/empty-state";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useMonitoringTicker } from "@/store/monitoring-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { cn } from "@/lib/utils";
import { ResourceMetricsPanel } from "@/components/operations-suite/resource-metrics-panel";

// Kept in sync with the identical maps in console-tab.tsx / resource-detail.tsx —
// duplicated rather than imported, matching the existing convention.
const STATUS_BADGE_CLASS: Record<ResourceRuntimeStatus, string> = {
  provisioning: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  starting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  stopping: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  deleting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  running: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  stopped: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  error: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
};

const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "Provisioning",
  starting: "Starting",
  stopping: "Stopping",
  deleting: "Deleting",
  running: "Running",
  stopped: "Stopped",
  error: "Error",
};

export function MetricsTab() {
  useMonitoringTicker();

  const resources = useGcpConsoleStore((s) => s.resources);
  const [selectedId, setSelectedId] = React.useState<string | undefined>(undefined);

  const selected = React.useMemo(
    () => resources.find((r) => r.id === selectedId) ?? null,
    [resources, selectedId],
  );

  // Keep the picker pointed at something sensible: default to the first
  // resource once any exist, and fall back if the selected one is deleted.
  React.useEffect(() => {
    if (resources.length === 0) {
      if (selectedId !== undefined) setSelectedId(undefined);
      return;
    }
    if (!resources.some((r) => r.id === selectedId)) {
      setSelectedId(resources[0].id);
    }
  }, [resources, selectedId]);

  if (resources.length === 0) {
    return (
      <EmptyState
        icon={Gauge}
        message="Nothing to monitor yet — create a VM, load balancer, GKE cluster, or any other resource in the Console to see live metrics here."
      />
    );
  }

  const selectedDef = selected ? getResourceDef(selected.type) : undefined;

  return (
    <div className="space-y-4">
      <div className="max-w-sm">
        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Resource</label>
        <Select value={selectedId} onValueChange={setSelectedId}>
          <SelectTrigger>
            <SelectValue placeholder="Select a resource" />
          </SelectTrigger>
          <SelectContent>
            {resources.map((r) => (
              <SelectItem key={r.id} value={r.id}>
                {r.name} ({r.type.toUpperCase()})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selected && selectedDef ? (
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div className="flex items-center gap-3">
              <ResourceIcon type={selectedDef.type} color={selectedDef.color} size={18} className="h-10 w-10" />
              <div className="min-w-0">
                <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                <CardDescription className="truncate">{selectedDef.label}</CardDescription>
              </div>
            </div>
            <Badge className={cn("shrink-0", STATUS_BADGE_CLASS[selected.status])}>
              {STATUS_LABEL[selected.status]}
            </Badge>
          </CardHeader>
          <CardContent>
            <ResourceMetricsPanel resource={selected} />
          </CardContent>
        </Card>
      ) : (
        <EmptyState icon={Gauge} message="Select a resource above to see its live metrics." />
      )}
    </div>
  );
}

"use client";

import * as React from "react";
import { toast } from "sonner";
import { Plus, Trash2, ShieldAlert, Bell, CheckCircle2, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useMonitoringStore, useMonitoringTicker } from "@/store/monitoring-store";
import { useAlertingStore, type AlertCondition, type AlertMetric, type AlertOperator } from "@/store/alerting-store";
import { getResourceDef } from "@/lib/gcp";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { STATUS_LABEL } from "@/components/gcp-console/console-tab";
import { cn } from "@/lib/utils";

// Cloud-Monitoring-style Alerting: define a policy against a real resource, then
// evaluate it continuously against live status + metrics so incidents open and
// auto-resolve exactly like they would against a real monitored service.

const NO_RESOURCE = "__none__";
const EVALUATE_INTERVAL_MS = 2000;

const STATUS_OPTIONS: ResourceRuntimeStatus[] = [
  "running",
  "stopped",
  "error",
  "provisioning",
  "starting",
  "stopping",
  "deleting",
];

const METRIC_OPTIONS: { value: AlertMetric; label: string }[] = [
  { value: "cpu", label: "CPU utilization (%)" },
  { value: "network", label: "Network throughput (MB/s)" },
  { value: "requests", label: "Request rate (req/s)" },
  { value: "errors", label: "Error rate (err/s)" },
];

function metricLabel(metric: AlertMetric): string {
  return METRIC_OPTIONS.find((m) => m.value === metric)?.label ?? metric;
}

function describeCondition(condition: AlertCondition): string {
  if (condition.kind === "status") return `Status = ${STATUS_LABEL[condition.status]}`;
  return `${metricLabel(condition.metric)} ${condition.operator} ${condition.threshold}`;
}

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

// Literal Tailwind class lookup — never construct classes dynamically.
const INCIDENT_BADGE_CLASS = {
  firing: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
  resolved: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
} as const;

export function AlertingTab() {
  // Live metrics need to be ticking for metric-threshold policies to have anything to
  // evaluate against, and incidents need to open/close continuously while this tab is open.
  useMonitoringTicker();
  React.useEffect(() => {
    const evaluateNow = () => {
      useAlertingStore
        .getState()
        .evaluate(useGcpConsoleStore.getState().resources, useMonitoringStore.getState().series);
    };
    evaluateNow();
    const id = setInterval(evaluateNow, EVALUATE_INTERVAL_MS);
    return () => clearInterval(id);
  }, []);

  const resources = useGcpConsoleStore((s) => s.resources);
  const policies = useAlertingStore((s) => s.policies);
  const incidents = useAlertingStore((s) => s.incidents);
  const addPolicy = useAlertingStore((s) => s.addPolicy);
  const removePolicy = useAlertingStore((s) => s.removePolicy);

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [resourceId, setResourceId] = React.useState<string>(NO_RESOURCE);
  const [kind, setKind] = React.useState<AlertCondition["kind"]>("status");
  const [status, setStatus] = React.useState<ResourceRuntimeStatus>("error");
  const [metric, setMetric] = React.useState<AlertMetric>("cpu");
  const [operator, setOperator] = React.useState<AlertOperator>(">");
  const [threshold, setThreshold] = React.useState("85");
  const [name, setName] = React.useState("");
  const [nameTouched, setNameTouched] = React.useState(false);

  const resource = resources.find((r) => r.id === resourceId);

  const suggestedName = React.useMemo(() => {
    if (!resource) return "";
    const conditionText =
      kind === "status" ? `status = ${STATUS_LABEL[status]}` : `${metric} ${operator} ${threshold || "0"}`;
    return `${resource.name}: ${conditionText}`;
  }, [resource, kind, status, metric, operator, threshold]);

  React.useEffect(() => {
    if (!nameTouched) setName(suggestedName);
  }, [suggestedName, nameTouched]);

  const resetForm = () => {
    setResourceId(NO_RESOURCE);
    setKind("status");
    setStatus("error");
    setMetric("cpu");
    setOperator(">");
    setThreshold("85");
    setName("");
    setNameTouched(false);
  };

  const openQuickAdd = (preset: "status-error" | "cpu-85") => {
    if (resources.length === 0) {
      toast.error("Create a resource in the GCP Console first.");
      return;
    }
    setResourceId((prev) => (prev === NO_RESOURCE ? resources[0].id : prev));
    if (preset === "status-error") {
      setKind("status");
      setStatus("error");
    } else {
      setKind("metric");
      setMetric("cpu");
      setOperator(">");
      setThreshold("85");
    }
    setNameTouched(false);
    setDialogOpen(true);
  };

  const handleCreate = () => {
    if (!resource) {
      toast.error("Pick a resource to monitor.");
      return;
    }
    const condition: AlertCondition =
      kind === "status" ? { kind: "status", status } : { kind: "metric", metric, operator, threshold: Number(threshold) || 0 };

    addPolicy({
      name: name.trim() || suggestedName,
      resourceId: resource.id,
      resourceName: resource.name,
      resourceType: resource.type,
      condition,
    });
    toast.success("Alert policy created");
    setDialogOpen(false);
    resetForm();
  };

  const openIncidentCount = incidents.filter((i) => !i.resolvedAt).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4" /> Alert Policies
            </CardTitle>
            <CardDescription>
              Define a condition on a real resource — an incident opens the moment it&apos;s met, and resolves the
              moment it isn&apos;t.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => openQuickAdd("status-error")}>
              Quick add: status = error
            </Button>
            <Button variant="outline" size="sm" onClick={() => openQuickAdd("cpu-85")}>
              Quick add: CPU &gt; 85
            </Button>
            <Dialog
              open={dialogOpen}
              onOpenChange={(open) => {
                setDialogOpen(open);
                if (!open) resetForm();
              }}
            >
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1.5">
                  <Plus className="h-3.5 w-3.5" /> New policy
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>New alert policy</DialogTitle>
                  <DialogDescription>Choose a resource and the condition that should fire an incident.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label>Resource</Label>
                    <Select value={resourceId} onValueChange={setResourceId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a resource" />
                      </SelectTrigger>
                      <SelectContent>
                        {resources.length === 0 && (
                          <SelectItem value={NO_RESOURCE} disabled>
                            No resources yet
                          </SelectItem>
                        )}
                        {resources.map((r) => (
                          <SelectItem key={r.id} value={r.id}>
                            {r.name} ({getResourceDef(r.type)?.shortLabel ?? r.type})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1.5">
                    <Label>Condition</Label>
                    <Select value={kind} onValueChange={(v) => setKind(v as AlertCondition["kind"])}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="status">Status equals...</SelectItem>
                        <SelectItem value="metric">Metric threshold...</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {kind === "status" ? (
                    <div className="space-y-1.5">
                      <Label>Status</Label>
                      <Select value={status} onValueChange={(v) => setStatus(v as ResourceRuntimeStatus)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STATUS_OPTIONS.map((s) => (
                            <SelectItem key={s} value={s}>
                              {STATUS_LABEL[s]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-3 space-y-1.5 sm:col-span-1">
                        <Label>Metric</Label>
                        <Select value={metric} onValueChange={(v) => setMetric(v as AlertMetric)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {METRIC_OPTIONS.map((m) => (
                              <SelectItem key={m.value} value={m.value}>
                                {m.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label>Operator</Label>
                        <Select value={operator} onValueChange={(v) => setOperator(v as AlertOperator)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value=">">&gt;</SelectItem>
                            <SelectItem value="<">&lt;</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label>Threshold</Label>
                        <Input type="number" value={threshold} onChange={(e) => setThreshold(e.target.value)} />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <Label>Policy name</Label>
                    <Input
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        setNameTouched(true);
                      }}
                      placeholder={suggestedName || "Policy name"}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={!resource}>
                    Create policy
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {policies.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
              No alert policies yet. Create one above to start watching a resource.
            </p>
          ) : (
            <ul className="space-y-2">
              {policies.map((p) => (
                <li
                  key={p.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium">{p.name}</span>
                      <Badge variant="outline">{getResourceDef(p.resourceType)?.shortLabel ?? p.resourceType}</Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {p.resourceName} — {describeCondition(p.condition)}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-danger hover:bg-danger/10"
                    onClick={() => removePolicy(p.id)}
                  >
                    <Trash2 className="h-3.5 w-3.5" /> Delete
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center gap-2 space-y-0">
          <Bell className="h-4 w-4 text-muted-foreground" />
          <div>
            <CardTitle>Incidents</CardTitle>
            <CardDescription>
              {openIncidentCount > 0 ? `${openIncidentCount} firing now` : "Nothing firing right now."}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          {incidents.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
              No incidents recorded yet.
            </p>
          ) : (
            <ul className="space-y-2">
              {incidents.map((incident) => {
                const firing = !incident.resolvedAt;
                return (
                  <li
                    key={incident.id}
                    className={cn(
                      "rounded-lg border p-3",
                      firing ? "border-danger/40 bg-danger/10" : "border-border bg-card/40 opacity-80",
                    )}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {firing ? (
                          <Flame className="h-4 w-4 text-danger" />
                        ) : (
                          <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="text-sm font-medium">{incident.policyName}</span>
                      </div>
                      <Badge className={cn(firing ? INCIDENT_BADGE_CLASS.firing : INCIDENT_BADGE_CLASS.resolved)}>
                        {firing ? "Firing" : "Resolved"}
                      </Badge>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{incident.summary}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground/70">
                      Opened {formatTimestamp(incident.openedAt)}
                      {incident.resolvedAt ? ` · Resolved ${formatTimestamp(incident.resolvedAt)}` : ""}
                    </p>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

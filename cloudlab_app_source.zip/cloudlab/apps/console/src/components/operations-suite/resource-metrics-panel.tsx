"use client";

import * as React from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Cpu, Activity, ArrowLeftRight, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/resource-explorer/empty-state";
import { cn } from "@/lib/utils";
import { useMonitoringStore, MetricPoint } from "@/store/monitoring-store";
import { ConsoleResource } from "@/store/gcp-console-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";

// Kept in sync with the identical maps in console-tab.tsx / resource-detail.tsx —
// duplicated (rather than imported) to avoid pulling those component trees into
// this shared chart module, matching the existing convention in this codebase.
const STATUS_BADGE_CLASS: Record<ResourceRuntimeStatus, string> = {
  provisioning: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  starting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  stopping: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  deleting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  running: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  stopped: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  error: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
};

const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "Provisioning",
  starting: "Starting",
  stopping: "Stopping",
  deleting: "Deleting",
  running: "Running",
  stopped: "Stopped",
  error: "Error",
};

interface ChartTooltipProps {
  active?: boolean;
  label?: React.ReactNode;
  payload?: readonly { dataKey?: unknown; value?: React.ReactNode }[];
  unit: string;
}

function ChartTooltip({ active, payload, label, unit }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md">
      <p className="mb-1 font-medium text-muted-foreground">{label}</p>
      {payload.map((p, i) => (
        <p key={p.dataKey != null ? String(p.dataKey) : i} className="font-semibold">
          {p.value}
          {unit}
        </p>
      ))}
    </div>
  );
}

/** Format an epoch-ms metric timestamp as a short HH:MM:SS tick label. */
export function formatMetricTime(t: number): string {
  return new Date(t).toLocaleTimeString([], { hour12: false, minute: "2-digit", second: "2-digit" });
}

interface ChartDatum {
  time: string;
  cpu: number;
  network: number;
  requests: number;
  errors: number;
}

function toChartData(series: MetricPoint[]): ChartDatum[] {
  return series.map((p) => ({
    time: formatMetricTime(p.t),
    cpu: Math.round(p.cpu * 10) / 10,
    network: Math.round(p.network * 10) / 10,
    requests: Math.round(p.requests),
    errors: Math.round(p.errors * 10) / 10,
  }));
}

type MetricDataKey = "cpu" | "network" | "requests" | "errors";

function MetricChart({
  title,
  description,
  icon: Icon,
  colorVar,
  unit,
  dataKey,
  data,
  kind,
  latestValue,
}: {
  title: string;
  description: string;
  icon: React.ElementType;
  colorVar: string;
  unit: string;
  dataKey: MetricDataKey;
  data: ChartDatum[];
  kind: "line" | "area";
  latestValue: string;
}) {
  const rawId = React.useId();
  const gradientId = `metric-fill-${rawId.replace(/[^a-zA-Z0-9]/g, "")}`;
  const stroke = `hsl(var(${colorVar}))`;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="flex items-center gap-2 text-sm">
            <Icon className="h-4 w-4" style={{ color: stroke }} /> {title}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <span className="shrink-0 text-sm font-semibold tabular-nums">{latestValue}</span>
      </CardHeader>
      <CardContent>
        <div className="h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {kind === "line" ? (
              <LineChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="time"
                  interval={5}
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={false}
                  tickLine={false}
                  width={36}
                />
                <Tooltip content={(p: object) => <ChartTooltip {...(p as ChartTooltipProps)} unit={unit} />} />
                <Line
                  type="monotone"
                  dataKey={dataKey}
                  stroke={stroke}
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                />
              </LineChart>
            ) : (
              <AreaChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={stroke} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={stroke} stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="time"
                  interval={5}
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={false}
                  tickLine={false}
                  width={36}
                />
                <Tooltip content={(p: object) => <ChartTooltip {...(p as ChartTooltipProps)} unit={unit} />} />
                <Area
                  type="monotone"
                  dataKey={dataKey}
                  stroke={stroke}
                  strokeWidth={2}
                  fill={`url(#${gradientId})`}
                  isAnimationActive={false}
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Cloud-Monitoring-style 2x2 chart grid for one resource's live metrics —
 * shared between the Operations Suite's Metrics tab and the Console's
 * per-resource "Monitoring" detail tab so the chart treatment never drifts.
 */
export function ResourceMetricsPanel({ resource }: { resource: ConsoleResource }) {
  const series = useMonitoringStore((s) => s.series[resource.id]);
  const data = React.useMemo(() => toChartData(series ?? []), [series]);

  if (data.length === 0) {
    return (
      <EmptyState
        icon={Activity}
        message="No metrics yet for this resource — give it a couple of seconds after creating it to report its first data point."
      />
    );
  }

  const latest = data[data.length - 1];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
        <span className="text-xs text-muted-foreground">Current status</span>
        <Badge className={cn("shrink-0", STATUS_BADGE_CLASS[resource.status])}>
          {STATUS_LABEL[resource.status]}
        </Badge>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <MetricChart
          title="CPU utilization"
          description="Percent, live"
          icon={Cpu}
          colorVar="--gcp-blue"
          unit="%"
          dataKey="cpu"
          data={data}
          kind="line"
          latestValue={`${latest.cpu}%`}
        />
        <MetricChart
          title="Network throughput"
          description="MB/s, live"
          icon={ArrowLeftRight}
          colorVar="--gcp-green"
          unit=" MB/s"
          dataKey="network"
          data={data}
          kind="area"
          latestValue={`${latest.network} MB/s`}
        />
        <MetricChart
          title="Request rate"
          description="Requests/sec, live"
          icon={Activity}
          colorVar="--gcp-blue"
          unit="/s"
          dataKey="requests"
          data={data}
          kind="line"
          latestValue={`${latest.requests}/s`}
        />
        <MetricChart
          title="Error rate"
          description="Errors/sec, live"
          icon={AlertTriangle}
          colorVar="--gcp-red"
          unit="/s"
          dataKey="errors"
          data={data}
          kind="area"
          latestValue={`${latest.errors}/s`}
        />
      </div>
    </div>
  );
}

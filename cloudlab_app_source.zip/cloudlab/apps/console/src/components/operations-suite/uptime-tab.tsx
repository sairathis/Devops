"use client";

import * as React from "react";
import { toast } from "sonner";
import { Plus, Trash2, PlayCircle, Activity, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useGcpConsoleStore, type ConsoleResource } from "@/store/gcp-console-store";
import { useUptimeStore, uptimePercent, type UptimeCheck, type UptimeResult } from "@/store/uptime-store";
import { runEndpointTest } from "@/lib/console-sim/endpoint-test";
import { getResourceDef } from "@/lib/gcp";
import { cn } from "@/lib/utils";

// Cloud-Monitoring-style Uptime Checks: synthetic probes against real resources,
// using the exact same pass/fail logic as the CI/CD Simulator's "Test endpoint"
// button (runEndpointTest) — never an independently invented random roll.

const NO_RESOURCE = "__none__";
const AUTO_RUN_INTERVAL_MS = 8000;
const HISTORY_WINDOW = 20;

function formatTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleTimeString([], { hour12: false });
}

export function UptimeTab() {
  const resources = useGcpConsoleStore((s) => s.resources);
  const checks = useUptimeStore((s) => s.checks);
  const addCheck = useUptimeStore((s) => s.addCheck);
  const removeCheck = useUptimeStore((s) => s.removeCheck);

  const [resourceId, setResourceId] = React.useState<string>(NO_RESOURCE);

  const handleAdd = () => {
    const resource = resources.find((r) => r.id === resourceId);
    if (!resource) {
      toast.error("Pick a resource to check.");
      return;
    }
    addCheck(resource.id, resource.name);
    toast.success(`Uptime check added for ${resource.name}`);
    setResourceId(NO_RESOURCE);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-4 w-4" /> Uptime Checks
            </CardTitle>
            <CardDescription>
              Synthetic probes against your real resources — the same pass/fail logic as the CI/CD Simulator&apos;s
              endpoint test.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select value={resourceId} onValueChange={setResourceId}>
              <SelectTrigger className="w-[240px]">
                <SelectValue placeholder="Choose a resource" />
              </SelectTrigger>
              <SelectContent>
                {resources.length === 0 && (
                  <SelectItem value={NO_RESOURCE} disabled>
                    No resources yet
                  </SelectItem>
                )}
                {resources.map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    {r.name} ({getResourceDef(r.type)?.shortLabel ?? r.type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" className="gap-1.5" onClick={handleAdd}>
              <Plus className="h-3.5 w-3.5" /> Add check
            </Button>
          </div>
        </CardHeader>
      </Card>

      {checks.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <Activity className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">No uptime checks yet</p>
            <p className="max-w-sm text-xs text-muted-foreground">
              Add a check against any resource above to start probing it — manually or automatically every 8
              seconds.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {checks.map((check) => (
            <UptimeCheckCard
              key={check.id}
              check={check}
              resource={resources.find((r) => r.id === check.resourceId)}
              onRemove={() => removeCheck(check.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function UptimeCheckCard({
  check,
  resource,
  onRemove,
}: {
  check: UptimeCheck;
  resource: ConsoleResource | undefined;
  onRemove: () => void;
}) {
  const recordResult = useUptimeStore((s) => s.recordResult);
  const [autoRun, setAutoRun] = React.useState(false);
  const [running, setRunning] = React.useState(false);

  const runProbe = React.useCallback(() => {
    setRunning(true);
    const currentResource = useGcpConsoleStore.getState().resources.find((r) => r.id === check.resourceId);
    const result = runEndpointTest(currentResource);
    const uptimeResult: UptimeResult = {
      ts: new Date().toISOString(),
      ok: result.ok,
      latencyMs: result.latencyMs,
      reason: result.ok ? undefined : result.reason,
    };
    recordResult(check.id, uptimeResult);
    setRunning(false);
  }, [check.id, check.resourceId, recordResult]);

  // Auto-run while this toggle is on, for as long as this card stays mounted.
  React.useEffect(() => {
    if (!autoRun) return;
    const id = setInterval(runProbe, AUTO_RUN_INTERVAL_MS);
    return () => clearInterval(id);
  }, [autoRun, runProbe]);

  const percent = uptimePercent(check);
  const recentResults = check.results.slice(-HISTORY_WINDOW);
  const latest = check.results[check.results.length - 1];
  const percentClass =
    percent >= 99
      ? "text-emerald-600 dark:text-emerald-400"
      : percent >= 90
        ? "text-amber-600 dark:text-amber-400"
        : "text-red-600 dark:text-red-400";

  return (
    <Card>
      <CardContent className="flex flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{check.resourceName}</p>
            <p className="text-[11px] text-muted-foreground">
              {resource ? getResourceDef(resource.type)?.shortLabel ?? resource.type : "Resource no longer exists"}
            </p>
          </div>
          <span className={cn("text-lg font-semibold tabular-nums", percentClass)}>{percent}%</span>
        </div>

        <div className="flex items-center gap-0.5" aria-label="Recent check history">
          {recentResults.length === 0 ? (
            <p className="text-xs text-muted-foreground">No checks run yet.</p>
          ) : (
            recentResults.map((r, i) => (
              <span
                key={i}
                title={`${formatTime(r.ts)} — ${r.ok ? "OK" : r.reason ?? "Failed"}`}
                className={cn("h-5 w-1.5 rounded-sm", r.ok ? "bg-emerald-500" : "bg-red-500")}
              />
            ))
          )}
        </div>

        {latest && !latest.ok && (
          <div className="flex items-start gap-2 rounded-lg border border-danger/40 bg-danger/10 p-2 text-xs text-danger">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span className="break-words">{latest.reason ?? "Last check failed."}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="gap-1.5" onClick={runProbe} disabled={running}>
              <PlayCircle className="h-3.5 w-3.5" /> Run now
            </Button>
            <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Switch checked={autoRun} onCheckedChange={setAutoRun} />
              Auto-run every 8s
            </label>
          </div>
          <Button size="sm" variant="ghost" className="gap-1.5 text-danger hover:bg-danger/10" onClick={onRemove}>
            <Trash2 className="h-3.5 w-3.5" /> Remove
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

"use client";

import * as React from "react";
import { Search, ScrollText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useActivityLogStore, type ActivityEntry, type ActivityOutcome } from "@/store/activity-log-store";
import { getResourceDef } from "@/lib/gcp";
import { cn } from "@/lib/utils";

// Cloud-Audit-Log-style activity trail — read-only view over the shared
// activity log store, which is already populated by every mutating action
// across the Console, Terraform Lab, and both CI/CD pipelines.

const ALL_SOURCES = "__all__";
const ALL_OUTCOMES = "__all__";

const SOURCE_LABEL: Record<ActivityEntry["source"], string> = {
  console: "GCP Console",
  "terraform-lab": "Terraform Lab",
  "platform-pipeline": "Platform Pipeline",
  "app-pipeline": "App Pipeline",
  "docker-lab": "Docker Lab",
  "kubernetes-lab": "Kubernetes Lab",
};

const SOURCE_OPTIONS = Object.keys(SOURCE_LABEL) as ActivityEntry["source"][];

const OUTCOME_LABEL: Record<ActivityOutcome, string> = {
  success: "Success",
  failure: "Failure",
  info: "Info",
};

const OUTCOME_OPTIONS = Object.keys(OUTCOME_LABEL) as ActivityOutcome[];

// Literal Tailwind class lookup — never construct classes dynamically.
// success=emerald, failure=red, info=amber (transitional / in-progress action).
const OUTCOME_BADGE_CLASS: Record<ActivityOutcome, string> = {
  success: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  failure: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
  info: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
};

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function ActivityLogTab() {
  const entries = useActivityLogStore((s) => s.entries);

  const [search, setSearch] = React.useState("");
  const [source, setSource] = React.useState<string>(ALL_SOURCES);
  const [outcome, setOutcome] = React.useState<string>(ALL_OUTCOMES);

  const filtered = React.useMemo(() => {
    const query = search.trim().toLowerCase();
    return entries.filter((e) => {
      if (source !== ALL_SOURCES && e.source !== source) return false;
      if (outcome !== ALL_OUTCOMES && e.outcome !== outcome) return false;
      if (!query) return true;
      const haystack = [e.actor, e.method, e.resourceName, e.detail].filter(Boolean).join(" ").toLowerCase();
      return haystack.includes(query);
    });
  }, [entries, search, outcome, source]);

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:flex-wrap sm:items-center">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search actor, method, resource, or detail..."
              className="pl-8"
            />
          </div>
          <Select value={source} onValueChange={setSource}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Source" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL_SOURCES}>All sources</SelectItem>
              {SOURCE_OPTIONS.map((s) => (
                <SelectItem key={s} value={s}>
                  {SOURCE_LABEL[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={outcome} onValueChange={setOutcome}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Outcome" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL_OUTCOMES}>All outcomes</SelectItem>
              {OUTCOME_OPTIONS.map((o) => (
                <SelectItem key={o} value={o}>
                  {OUTCOME_LABEL[o]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground sm:ml-auto">
            {filtered.length} of {entries.length} entries
          </p>
        </CardContent>
      </Card>

      {entries.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <ScrollText className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">Nothing recorded yet</p>
            <p className="max-w-sm text-xs text-muted-foreground">
              Create or modify a resource anywhere in the app to see it here.
            </p>
          </CardContent>
        </Card>
      ) : filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <ScrollText className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">No entries match your filters</p>
            <p className="max-w-sm text-xs text-muted-foreground">
              Try clearing the search box or switching the source/outcome filters.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-border">
          <div className="min-w-[720px] divide-y divide-border">
            {filtered.map((entry) => (
              <ActivityRow key={entry.id} entry={entry} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ActivityRow({ entry }: { entry: ActivityEntry }) {
  const resourceDef = entry.resourceType ? getResourceDef(entry.resourceType) : undefined;
  return (
    <div className="flex flex-wrap items-center gap-3 bg-card/40 px-4 py-2.5 text-xs">
      <span className="w-[150px] shrink-0 text-muted-foreground">{formatTimestamp(entry.ts)}</span>
      <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-secondary px-2 py-0.5 font-medium">
        {entry.actor}
      </span>
      <code className="shrink-0 rounded bg-muted px-1.5 py-0.5 font-mono text-[11px]">{entry.method}</code>
      <span className="min-w-0 flex-1 truncate text-muted-foreground">
        {entry.resourceName ? (
          <>
            {resourceDef?.shortLabel ?? entry.resourceType} <span className="text-foreground">{entry.resourceName}</span>
          </>
        ) : (
          "—"
        )}
      </span>
      <Badge className={cn("shrink-0 text-[10px]", OUTCOME_BADGE_CLASS[entry.outcome])}>
        {OUTCOME_LABEL[entry.outcome]}
      </Badge>
      {entry.detail && (
        <span className="basis-full text-[11px] text-muted-foreground/80 sm:basis-auto sm:flex-1 sm:truncate">
          {entry.detail}
        </span>
      )}
      <span className="basis-full text-[10px] text-muted-foreground/60">{SOURCE_LABEL[entry.source]}</span>
    </div>
  );
}

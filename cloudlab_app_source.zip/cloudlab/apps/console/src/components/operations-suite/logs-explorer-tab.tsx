"use client";

import * as React from "react";
import { Search, ScrollText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useGcpConsoleStore, type ConsoleResource } from "@/store/gcp-console-store";
import { SimLogEntry, SimLogLevel } from "@/lib/console-sim/types";
import { getResourceDef } from "@/lib/gcp";
import { cn } from "@/lib/utils";

// Cloud-Logging-style aggregate view over every resource's own log stream.
// Aggregated across the GCP Console's resources so this reads as one real,
// searchable log explorer instead of each resource's private terminal.

const ALL_TYPES = "__all__";
const ALL_RESOURCES = "__all__";

const SEVERITIES: SimLogLevel[] = ["info", "success", "warn", "error", "command"];

const SEVERITY_LABEL: Record<SimLogLevel, string> = {
  info: "Info",
  success: "Success",
  warn: "Warning",
  error: "Error",
  command: "Command",
};

// Literal Tailwind class lookup — never construct classes dynamically. Used for the
// severity filter chips, which sit on the normal (theme-aware) card background.
const SEVERITY_BADGE_CLASS: Record<SimLogLevel, string> = {
  info: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  success: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  warn: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  error: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
  command: "border-transparent bg-sky-500/15 text-sky-600 dark:text-sky-400",
};

// The log list itself renders on a fixed-dark terminal surface (like TerminalOutput),
// so its chip colors are fixed light-on-dark rather than theme-aware.
const SEVERITY_TERMINAL_CLASS: Record<SimLogLevel, string> = {
  info: "bg-slate-500/20 text-slate-300",
  success: "bg-emerald-500/20 text-emerald-300",
  warn: "bg-amber-500/20 text-amber-300",
  error: "bg-red-500/20 text-red-300",
  command: "bg-sky-500/20 text-sky-300",
};

interface LogRow {
  entry: SimLogEntry;
  resource: ConsoleResource;
  sortKey: number;
}

export function LogsExplorerTab() {
  const resources = useGcpConsoleStore((s) => s.resources);

  const [search, setSearch] = React.useState("");
  const [activeSeverities, setActiveSeverities] = React.useState<Set<SimLogLevel>>(new Set(SEVERITIES));
  const [typeFilter, setTypeFilter] = React.useState<string>(ALL_TYPES);
  const [resourceFilter, setResourceFilter] = React.useState<string>(ALL_RESOURCES);

  const totalLogCount = React.useMemo(() => resources.reduce((sum, r) => sum + r.logs.length, 0), [resources]);

  // Interleave every resource's own chronological log array into one stream. Logs never
  // get reordered within a resource, so a resource's createdAt (as a coarse anchor) plus
  // the log's position in that resource's array is a good-enough sort key for a training
  // tool — exact cross-resource ordering by `ts` (a locale time string) isn't reliable
  // anyway, and perfect global ordering isn't worth engineering for this purpose.
  const allRows = React.useMemo<LogRow[]>(() => {
    const rows: LogRow[] = [];
    for (const resource of resources) {
      const base = new Date(resource.createdAt).getTime() || 0;
      resource.logs.forEach((entry, index) => {
        rows.push({ entry, resource, sortKey: base + index * 1000 });
      });
    }
    rows.sort((a, b) => b.sortKey - a.sortKey);
    return rows;
  }, [resources]);

  const typeOptions = React.useMemo(() => {
    const seen = new Map<string, string>();
    for (const r of resources) {
      if (!seen.has(r.type)) seen.set(r.type, getResourceDef(r.type)?.shortLabel ?? r.type);
    }
    return Array.from(seen.entries());
  }, [resources]);

  const filteredRows = React.useMemo(() => {
    const query = search.trim().toLowerCase();
    return allRows.filter(({ entry, resource }) => {
      if (!activeSeverities.has(entry.level)) return false;
      if (typeFilter !== ALL_TYPES && resource.type !== typeFilter) return false;
      if (resourceFilter !== ALL_RESOURCES && resource.id !== resourceFilter) return false;
      if (query && !entry.message.toLowerCase().includes(query)) return false;
      return true;
    });
  }, [allRows, activeSeverities, typeFilter, resourceFilter, search]);

  const toggleSeverity = (level: SimLogLevel) => {
    setActiveSeverities((prev) => {
      const next = new Set(prev);
      if (next.has(level)) next.delete(level);
      else next.add(level);
      return next;
    });
  };

  if (resources.length === 0 || totalLogCount === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
          <ScrollText className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-medium">No logs yet</p>
          <p className="max-w-sm text-xs text-muted-foreground">
            Create or operate a resource in the GCP Console to start generating log entries here.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="flex flex-col gap-3 p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
            <div className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search log messages..."
                className="pl-8"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Resource type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_TYPES}>All types</SelectItem>
                {typeOptions.map(([type, label]) => (
                  <SelectItem key={type} value={type}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={resourceFilter} onValueChange={setResourceFilter}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Resource" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_RESOURCES}>All resources</SelectItem>
                {resources.map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    {r.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground sm:ml-auto">
              {filteredRows.length} of {allRows.length} log lines
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {SEVERITIES.map((level) => {
              const active = activeSeverities.has(level);
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => toggleSeverity(level)}
                  className={cn(
                    "rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors",
                    active
                      ? SEVERITY_BADGE_CLASS[level]
                      : "border-border text-muted-foreground opacity-50 hover:opacity-80",
                  )}
                >
                  {SEVERITY_LABEL[level]}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {filteredRows.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
            <ScrollText className="h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">No results for this filter</p>
            <p className="max-w-sm text-xs text-muted-foreground">
              Try widening your severity selection or clearing the search box.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="max-h-[65vh] overflow-y-auto rounded-lg border border-border bg-[#0b0e14] font-mono text-xs leading-relaxed">
          {filteredRows.map(({ entry, resource }) => (
            <div
              key={entry.id}
              className="flex flex-wrap items-center gap-2 border-b border-white/5 px-3 py-1.5 last:border-b-0"
            >
              <span className="shrink-0 select-none text-slate-500">{entry.ts}</span>
              <span
                className={cn(
                  "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold",
                  SEVERITY_TERMINAL_CLASS[entry.level],
                )}
              >
                {SEVERITY_LABEL[entry.level]}
              </span>
              <span className="shrink-0 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-slate-300">
                {resource.name}
              </span>
              <span className="min-w-0 flex-1 whitespace-pre-wrap break-words text-slate-200">{entry.message}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

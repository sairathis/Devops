"use client";

import * as React from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Boxes, PlayCircle, AlertTriangle, Square, BellRing, Activity, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/resource-explorer/empty-state";
import { cn } from "@/lib/utils";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useMonitoringStore, useMonitoringTicker } from "@/store/monitoring-store";
import { useAlertingStore } from "@/store/alerting-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { formatMetricTime } from "@/components/operations-suite/resource-metrics-panel";

// Kept in sync with the identical maps in console-tab.tsx / resource-detail.tsx —
// duplicated rather than imported, matching the existing convention.
const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "Provisioning",
  starting: "Starting",
  stopping: "Stopping",
  deleting: "Deleting",
  running: "Running",
  stopped: "Stopped",
  error: "Error",
};

// Literal Tailwind class lookup for the status-breakdown dots — never construct
// classes dynamically.
const STATUS_DOT_CLASS: Record<ResourceRuntimeStatus, string> = {
  provisioning: "bg-amber-500",
  starting: "bg-amber-500",
  stopping: "bg-amber-500",
  deleting: "bg-amber-500",
  running: "bg-emerald-500",
  stopped: "bg-slate-500",
  error: "bg-red-500",
};

const STATUS_ORDER: ResourceRuntimeStatus[] = [
  "running",
  "error",
  "provisioning",
  "starting",
  "stopping",
  "stopped",
  "deleting",
];

const STAT_TILE_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "text-gcp-blue bg-gcp-blue/10",
  "gcp-green": "text-gcp-green bg-gcp-green/10",
  "gcp-yellow": "text-gcp-yellow bg-gcp-yellow/10",
  "gcp-red": "text-gcp-red bg-gcp-red/10",
  slate: "text-slate-600 bg-slate-500/10 dark:text-slate-400",
};

function StatTile({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 pt-5">
        <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", STAT_TILE_COLOR_CLASS[color])}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xl font-semibold leading-none">{value}</div>
          <div className="mt-1 text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}

interface ChartTooltipProps {
  active?: boolean;
  label?: React.ReactNode;
  payload?: readonly { dataKey?: unknown; value?: React.ReactNode }[];
  unit: string;
}

function ChartTooltip({ active, payload, label, unit }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md">
      <p className="mb-1 font-medium text-muted-foreground">{label}</p>
      {payload.map((p, i) => (
        <p key={p.dataKey != null ? String(p.dataKey) : i} className="font-semibold">
          {p.value}
          {unit}
        </p>
      ))}
    </div>
  );
}

interface GoldenSignalPoint {
  time: string;
  requests: number;
  errors: number;
}

const HISTORY_WINDOW = 30;

export function DashboardTab() {
  useMonitoringTicker();

  const resources = useGcpConsoleStore((s) => s.resources);
  const series = useMonitoringStore((s) => s.series);
  const incidents = useAlertingStore((s) => s.incidents);

  const [history, setHistory] = React.useState<GoldenSignalPoint[]>([]);

  const counts = React.useMemo(() => {
    const byStatus: Partial<Record<ResourceRuntimeStatus, number>> = {};
    for (const r of resources) {
      byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;
    }
    return byStatus;
  }, [resources]);

  const runningCount = counts.running ?? 0;
  const errorCount = counts.error ?? 0;
  const stoppedCount = counts.stopped ?? 0;
  const activeIncidentCount = React.useMemo(
    () => incidents.filter((i) => !i.resolvedAt).length,
    [incidents],
  );

  // Every tick, sum the latest point of every resource's series into one
  // aggregate "golden signals" reading and roll it into a bounded history —
  // this is derived, client-side state, not persisted anywhere.
  React.useEffect(() => {
    let totalRequests = 0;
    let totalErrors = 0;
    let latestT = Date.now();
    for (const r of resources) {
      const arr = series[r.id];
      const last = arr?.[arr.length - 1];
      if (last) {
        totalRequests += last.requests;
        totalErrors += last.errors;
        latestT = last.t;
      }
    }
    setHistory((prev) =>
      [
        ...prev,
        {
          time: formatMetricTime(latestT),
          requests: Math.round(totalRequests),
          errors: Math.round(totalErrors * 10) / 10,
        },
      ].slice(-HISTORY_WINDOW),
    );
  }, [series, resources]);

  if (resources.length === 0) {
    return (
      <EmptyState
        icon={Boxes}
        message="No resources yet — create a VM, load balancer, GKE cluster, or any other resource in the Console to see fleet health here."
        className="py-16"
      />
    );
  }

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <StatTile icon={Boxes} label="Total resources" value={resources.length} color="gcp-blue" />
        <StatTile icon={PlayCircle} label="Running" value={runningCount} color="gcp-green" />
        <StatTile icon={AlertTriangle} label="In error" value={errorCount} color="gcp-red" />
        <StatTile icon={Square} label="Stopped" value={stoppedCount} color="slate" />
        <StatTile icon={BellRing} label="Active incidents" value={activeIncidentCount} color="gcp-yellow" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <TrendingUp className="h-4 w-4 text-gcp-blue" /> Request rate
                </CardTitle>
                <CardDescription>Summed across all resources, requests/sec</CardDescription>
              </div>
              <Badge variant="info">live</Badge>
            </CardHeader>
            <CardContent>
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis
                      dataKey="time"
                      interval={4}
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      axisLine={{ stroke: "hsl(var(--border))" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      axisLine={false}
                      tickLine={false}
                      width={40}
                    />
                    <Tooltip content={(p: object) => <ChartTooltip {...(p as ChartTooltipProps)} unit="/s" />} />
                    <Line
                      type="monotone"
                      dataKey="requests"
                      stroke="hsl(var(--gcp-blue))"
                      strokeWidth={2}
                      dot={false}
                      activeDot={{ r: 4 }}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Activity className="h-4 w-4 text-gcp-red" /> Error rate
                </CardTitle>
                <CardDescription>Summed across all resources, errors/sec</CardDescription>
              </div>
              <Badge variant="info">live</Badge>
            </CardHeader>
            <CardContent>
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                    <defs>
                      <linearGradient id="dashboardErrorFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--gcp-red))" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="hsl(var(--gcp-red))" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis
                      dataKey="time"
                      interval={4}
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      axisLine={{ stroke: "hsl(var(--border))" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                      axisLine={false}
                      tickLine={false}
                      width={40}
                    />
                    <Tooltip content={(p: object) => <ChartTooltip {...(p as ChartTooltipProps)} unit="/s" />} />
                    <Area
                      type="monotone"
                      dataKey="errors"
                      stroke="hsl(var(--gcp-red))"
                      strokeWidth={2}
                      fill="url(#dashboardErrorFill)"
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Fleet by status</CardTitle>
            <CardDescription>{resources.length} resource{resources.length === 1 ? "" : "s"} total</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2.5">
            {STATUS_ORDER.filter((status) => (counts[status] ?? 0) > 0).map((status) => {
              const count = counts[status] ?? 0;
              const pct = Math.round((count / resources.length) * 100);
              return (
                <div key={status} className="flex items-center gap-2.5">
                  <span className={cn("h-2 w-2 shrink-0 rounded-full", STATUS_DOT_CLASS[status])} />
                  <span className="min-w-0 flex-1 truncate text-sm text-foreground">{STATUS_LABEL[status]}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{pct}%</span>
                  <span className="w-6 shrink-0 text-right text-sm font-semibold tabular-nums">{count}</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

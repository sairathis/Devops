"use client";
import * as React from "react";
import {
  PlayCircle, Loader2, CheckCircle2, XCircle, FlaskConical, History,
  Laptop, Cloud, Terminal, Rocket, HardDrive, Package, Boxes,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/store/auth-store";
import { useTestActivityStore } from "@/store/test-activity-store";
import {
  runResourceTest, loadTestRunHistory, testableKind,
  type TestRunResult, type StoredTestRun, type TestableType,
} from "@/lib/cloudlab/test-actions";
import { cn } from "@/lib/utils";

const KIND_ICON: Record<TestableType, React.ComponentType<{ className?: string }>> = {
  vm: Terminal,
  cloud_run: Rocket,
  gcs: HardDrive,
  registry_image: Package,
  k8s_deployment: Boxes,
};

/**
 * A compact "network flow" strip: Console -> CloudLab API -> the real
 * resource, animated (reusing the same marching-ants edge style the
 * Architecture Diagram uses -- see globals.css's .cloudlab-flow-edge) for
 * exactly as long as the real call above is actually in flight, then
 * settling to a solid green/red line reflecting the genuine outcome. Placed
 * here (not only on the diagram) so every real test -- including the ones
 * run from surfaces that never show the diagram, like Docker Lab and
 * Kubernetes Lab -- gets a live visual of the request actually happening.
 */
function NetworkFlowRow({ kind, running, ok }: { kind: TestableType; running: boolean; ok?: boolean }) {
  const ResourceIcon = KIND_ICON[kind];
  const tone = running ? "running" : ok === true ? "pass" : ok === false ? "fail" : "idle";
  const lineClass = cn(
    "h-0.5 flex-1 rounded-full",
    tone === "running" && "cloudlab-flow-edge-bg bg-sky-500",
    tone === "pass" && "bg-emerald-500",
    tone === "fail" && "bg-red-500",
    tone === "idle" && "bg-border",
  );
  const nodeClass = (active: boolean) =>
    cn(
      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border",
      active && tone === "running" && "border-sky-500 text-sky-500 animate-pulse",
      active && tone === "pass" && "border-emerald-500 text-emerald-500",
      active && tone === "fail" && "border-red-500 text-red-500",
      (!active || tone === "idle") && "border-border text-muted-foreground",
    );

  return (
    <div className="flex items-center gap-1.5 rounded-lg border border-border/70 bg-muted/20 px-3 py-2">
      <div className={nodeClass(false)} title="This console">
        <Laptop className="h-3.5 w-3.5" />
      </div>
      <div className={lineClass} />
      <div className={nodeClass(tone !== "idle")} title="CloudLab API">
        <Cloud className="h-3.5 w-3.5" />
      </div>
      <div className={lineClass} />
      <div className={nodeClass(tone !== "idle")} title="The real backing resource">
        <ResourceIcon className="h-3.5 w-3.5" />
      </div>
      <span className="ml-2 truncate text-[11px] text-muted-foreground">
        {tone === "running" && "Request in flight…"}
        {tone === "pass" && "Reached the real resource and back — healthy."}
        {tone === "fail" && "Request failed — see the real error below."}
        {tone === "idle" && "Idle."}
      </span>
    </div>
  );
}

/**
 * A real (not simulated) "run a test against this resource" panel. Shown
 * wherever a resource can be inspected -- the GCP Services Console's detail
 * sheet, Architecture Builder's inspector, Terraform Lab's resource rows --
 * so "I can't test the services I created" has one honest, working answer
 * everywhere a resource shows up, instead of three different half-answers.
 */
export function RealTestPanel({
  resourceType,
  cloudlabResourceId,
  cloudlabReady,
}: {
  resourceType: string;
  cloudlabResourceId?: string;
  cloudlabReady: boolean;
}) {
  const projectId = useAuthStore((s) => s.projectId);
  const kind = testableKind(resourceType);
  const [running, setRunning] = React.useState(false);
  const [result, setResult] = React.useState<TestRunResult | null>(null);
  const [history, setHistory] = React.useState<StoredTestRun[] | null>(null);

  // Load prior real test runs (persisted server-side -- see
  // routes/testRuns.ts) whenever this panel opens for a live resource, so
  // "I ran this an hour ago" doesn't just vanish the moment the sheet closes.
  React.useEffect(() => {
    let cancelled = false;
    setHistory(null);
    if (!kind || !cloudlabReady || !cloudlabResourceId || !projectId) return;
    loadTestRunHistory(projectId, cloudlabResourceId)
      .then((rows) => { if (!cancelled) setHistory(rows); })
      .catch(() => { if (!cancelled) setHistory([]); });
    return () => { cancelled = true; };
  }, [kind, cloudlabReady, cloudlabResourceId, projectId]);

  if (!kind) {
    return (
      <div className="rounded-lg border border-dashed border-border p-4 text-center">
        <FlaskConical className="mx-auto mb-2 h-5 w-5 text-muted-foreground" />
        <p className="text-sm font-medium">No real test endpoint yet</p>
        <p className="mt-1 text-xs text-muted-foreground">
          CloudLab doesn&apos;t have a real test-capable endpoint wired up for this resource type yet. Compute
          instances, Cloud Run services, and Cloud Storage buckets can be tested for real today.
        </p>
      </div>
    );
  }

  if (!cloudlabReady || !cloudlabResourceId || !projectId) {
    return (
      <div className="rounded-lg border border-dashed border-border p-4 text-center">
        <FlaskConical className="mx-auto mb-2 h-5 w-5 text-muted-foreground" />
        <p className="text-sm font-medium">Not live on CloudLab yet</p>
        <p className="mt-1 text-xs text-muted-foreground">
          This resource needs to finish provisioning for real (see the &quot;Live on CloudLab&quot; status) before it
          can be tested for real.
        </p>
      </div>
    );
  }

  const run = async () => {
    setRunning(true);
    setResult(null);
    // Signals the real Architecture Diagram (see test-activity-store.ts) so
    // it can show network flow for exactly as long as this real call is
    // actually in flight -- begin/finish bracket the genuine
    // runResourceTest below, not a decorative timer.
    useTestActivityStore.getState().begin(cloudlabResourceId);
    try {
      const outcome = await runResourceTest(projectId, resourceType, cloudlabResourceId);
      setResult(outcome);
      useTestActivityStore.getState().finish(cloudlabResourceId, outcome.ok);
      // The run just got persisted server-side; refresh history rather than
      // re-fetch (the outcome we already have is more current than any
      // network round-trip could return).
      setHistory((prev) => [
        { id: `local-${Date.now()}`, kind, ranAt: new Date().toISOString(), ...outcome },
        ...(prev ?? []),
      ].slice(0, 10));
    } catch (err) {
      useTestActivityStore.getState().finish(cloudlabResourceId, false);
      throw err;
    } finally {
      setRunning(false);
    }
  };

  const priorRuns = result ? (history ?? []).slice(1) : (history ?? []);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
        <div>
          <p className="text-sm font-medium">Real test</p>
          <p className="text-xs text-muted-foreground">
            {kind === "vm" && "Fetches real logs and live stats, then runs a real command inside the instance."}
            {kind === "cloud_run" && "Sends a real invoke request — cold-starts the container if it's idle."}
            {kind === "gcs" && "Uploads, downloads, and deletes a real test object against the bucket's live store."}
          </p>
        </div>
        <Button size="sm" onClick={run} disabled={running} className="shrink-0 gap-1.5">
          {running ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
          {running ? "Testing…" : "Run test"}
        </Button>
      </div>

      {(running || result) && <NetworkFlowRow kind={kind} running={running} ok={result?.ok} />}

      {(result ?? (history && history[0])) && (
        <div className="space-y-1.5">
          {!result && history?.[0] && (
            <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <History className="h-3 w-3" /> Last run {new Date(history[0].ranAt).toLocaleString()}
            </p>
          )}
          {(result ?? history![0]).steps.map((step, i) => (
            <div
              key={i}
              className={cn(
                "flex items-start gap-2 rounded-lg border px-3 py-2 text-xs",
                step.ok ? "border-success/30 bg-success/5" : "border-danger/30 bg-danger/5",
              )}
            >
              {step.ok ? (
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-success" />
              ) : (
                <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-danger" />
              )}
              <div className="min-w-0">
                <p className="font-medium">{step.label}</p>
                <p className="mt-0.5 break-words font-mono text-[11px] text-muted-foreground">{step.detail}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {priorRuns.length > 0 && (
        <details className="rounded-lg border border-border/70 px-3 py-2">
          <summary className="cursor-pointer select-none text-xs font-medium text-muted-foreground">
            {priorRuns.length} earlier {priorRuns.length === 1 ? "run" : "runs"}
          </summary>
          <ul className="mt-2 space-y-1">
            {priorRuns.map((run) => (
              <li key={run.id} className="flex items-center gap-2 text-[11px] text-muted-foreground">
                {run.ok ? (
                  <CheckCircle2 className="h-3 w-3 shrink-0 text-success" />
                ) : (
                  <XCircle className="h-3 w-3 shrink-0 text-danger" />
                )}
                <span className="font-mono">{new Date(run.ranAt).toLocaleString()}</span>
                <span>· {run.steps.length} steps · {run.ok ? "passed" : "failed"}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
}

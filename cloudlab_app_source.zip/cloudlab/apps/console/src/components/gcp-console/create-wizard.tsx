"use client";

import * as React from "react";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, DollarSign, Rocket } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ConfigForm } from "@/components/architecture/config-form";
import { CodeBlock } from "@/components/code-block";
import { getResourceDef } from "@/lib/gcp";
import { ResourceConfig } from "@/types/gcp";
import { scenariosForResourceType } from "@/lib/console-sim/scenarios-gcp";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useIamStore } from "@/store/iam-store";
import { useProgressStore } from "@/store/progress-store";
import { isProvisionable } from "@/lib/cloudlab/console-provision";
import { cn, formatCurrency, slugify } from "@/lib/utils";

const NO_SCENARIO = "none";
const NO_SERVICE_ACCOUNT = "none";

function formatConfigValue(
  field: { key: string; type: string },
  v: ResourceConfig[string],
  resourceById: Map<string, { name: string }>,
): string {
  if (field.type === "resource-ref") {
    if (typeof v !== "string" || !v) return "Not bound";
    return resourceById.get(v)?.name ?? "Not bound";
  }
  if (field.type === "resource-ref-multi") {
    const ids = Array.isArray(v) ? (v as string[]) : [];
    if (ids.length === 0) return "Not bound";
    return ids.map((id) => resourceById.get(id)?.name ?? "(deleted)").join(", ");
  }
  if (Array.isArray(v)) return v.length ? v.join(", ") : "—";
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (v === "" || v === undefined || v === null) return "—";
  return String(v);
}

export function CreateWizard({
  type,
  open,
  onOpenChange,
}: {
  type: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const def = getResourceDef(type);
  const createResource = useGcpConsoleStore((s) => s.createResource);
  const consoleResources = useGcpConsoleStore((s) => s.resources);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const addXp = useProgressStore((s) => s.addXp);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const [step, setStep] = React.useState<"configure" | "review">("configure");
  const [config, setConfig] = React.useState<ResourceConfig>(def?.defaultConfig ?? {});
  const [scenarioId, setScenarioId] = React.useState<string>(NO_SCENARIO);
  const [serviceAccountId, setServiceAccountId] = React.useState<string>(NO_SERVICE_ACCOUNT);

  React.useEffect(() => {
    if (open && def) {
      // Start from the type's defaults, then auto-bind any reference field that has
      // exactly one eligible candidate — the common case (one VPC, one subnet) —
      // so a resource isn't accidentally left as an unconnected orphan in the
      // Architecture Diagram just because the field was never touched. Any field
      // with zero or multiple candidates is left for the user to decide explicitly.
      const initial: ResourceConfig = { ...def.defaultConfig };
      for (const field of def.configFields) {
        if (field.type === "resource-ref" && !initial[field.key]) {
          const candidates = consoleResources.filter((r) => field.refTypes?.includes(r.type));
          if (candidates.length === 1) initial[field.key] = candidates[0].id;
        }
        if (field.type === "resource-ref-multi") {
          const current = Array.isArray(initial[field.key]) ? (initial[field.key] as string[]) : [];
          if (current.length === 0) {
            const candidates = consoleResources.filter((r) => field.refTypes?.includes(r.type));
            if (candidates.length === 1) initial[field.key] = [candidates[0].id];
          }
        }
      }
      setConfig(initial);
      setScenarioId(NO_SCENARIO);
      setServiceAccountId(NO_SERVICE_ACCOUNT);
      setStep("configure");
    }
    // Reset only when the dialog opens (or the target resource type changes while open).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, type]);

  const resourceById = React.useMemo(
    () => new Map(consoleResources.map((r) => [r.id, { name: r.name }])),
    [consoleResources],
  );

  if (!def) return null;

  const scenarios = scenariosForResourceType(type);
  const chosenScenario = scenarioId !== NO_SCENARIO ? scenarios.find((s) => s.id === scenarioId) : undefined;
  const monthlyCost = def.estimateMonthlyCost(config);
  const name = String(config.name ?? def.label);

  const terraform = def.generateTerraform({
    config,
    nodeId: "preview",
    label: name,
    slug: slugify(name || def.type),
    allNodes: [],
    connections: [],
  });

  const canProceed = Boolean(String(config.name ?? "").trim());
  const chosenServiceAccount =
    serviceAccountId !== NO_SERVICE_ACCOUNT ? serviceAccounts.find((sa) => sa.id === serviceAccountId) : undefined;

  function handleCreate() {
    if (!def) return;
    const finalConfig = chosenServiceAccount ? ({ ...config, serviceAccountId: chosenServiceAccount.id } as ResourceConfig) : config;
    createResource(type, finalConfig, chosenScenario);
    onOpenChange(false);

    if (chosenScenario) {
      toast.success(`Creating ${def.label.toLowerCase()} "${name}"...`, {
        description: "This one is set up to fail on purpose — head to its Troubleshooting tab once it errors out.",
      });
    } else {
      toast.success(`Creating ${def.label.toLowerCase()} "${name}"...`, {
        description: "Watch its progress from the resource list — it'll be running shortly.",
      });
      const isFirstEver = useGcpConsoleStore.getState().claimFirstSuccess();
      if (isFirstEver) {
        addXp(15);
        setModuleProgress("gcp-services", 60);
      }
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create {def.label}</DialogTitle>
          <DialogDescription>
            {step === "configure"
              ? isProvisionable(type)
                ? "Configure the resource. This type is one of the seven CloudLab can actually provision — if the VPC/Subnet it needs is already real, this will create real state on CloudLab too, alongside the simulation below."
                : "Configure the resource. This type is simulated — no real GCP calls, no billing, no credentials."
              : "Review the configuration, estimated cost, and generated Terraform before creating it."}
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <StepDot active={step === "configure"} done={step === "review"} label="1. Configure" />
          <div className="h-px flex-1 bg-border" />
          <StepDot active={step === "review"} done={false} label="2. Review & Create" />
        </div>

        {step === "configure" && (
          <div className="flex flex-col gap-4">
            <ConfigForm
              fields={def.configFields}
              config={config}
              onChange={(patch) => setConfig((c) => ({ ...c, ...patch } as ResourceConfig))}
              resources={consoleResources.map((r) => ({ id: r.id, type: r.type, name: r.name }))}
            />

            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Identity &amp; access — service account (optional)</Label>
              <Select value={serviceAccountId} onValueChange={setServiceAccountId}>
                <SelectTrigger>
                  <SelectValue placeholder="Default service account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NO_SERVICE_ACCOUNT}>No explicit identity (default service account)</SelectItem>
                  {serviceAccounts.map((sa) => (
                    <SelectItem key={sa.id} value={sa.id}>
                      {sa.displayName} — {sa.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">
                In real GCP, every resource runs as some identity — never as &ldquo;nobody&rdquo;. Pick a service
                account from IAM &amp; Admin, or leave this as the project default.
              </p>
            </div>

            {scenarios.length > 0 && (
              <Accordion type="single" collapsible>
                <AccordionItem value="scenario">
                  <AccordionTrigger className="text-sm">Practice a failure (advanced)</AccordionTrigger>
                  <AccordionContent className="space-y-2">
                    <p className="text-xs text-muted-foreground">
                      Optionally make this creation fail with a realistic incident, so you can practice diagnosing and
                      fixing it from the resource&apos;s Troubleshooting tab.
                    </p>
                    <Label className="text-xs text-muted-foreground">Fail with scenario</Label>
                    <Select value={scenarioId} onValueChange={setScenarioId}>
                      <SelectTrigger>
                        <SelectValue placeholder="None (succeed normally)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={NO_SCENARIO}>None (succeed normally)</SelectItem>
                        {scenarios.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            )}
          </div>
        )}

        {step === "review" && (
          <div className="flex flex-col gap-4">
            <div className="rounded-lg border border-border p-3">
              <p className="mb-2 text-xs font-medium text-muted-foreground">Summary</p>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-sm">
                {def.configFields.map((field) => (
                  <React.Fragment key={field.key}>
                    <dt className="truncate text-muted-foreground">{field.label}</dt>
                    <dd className="truncate text-right font-medium">{formatConfigValue(field, config[field.key], resourceById)}</dd>
                  </React.Fragment>
                ))}
                <dt className="truncate text-muted-foreground">Service account</dt>
                <dd className="truncate text-right font-medium">
                  {chosenServiceAccount ? chosenServiceAccount.email : "Default service account"}
                </dd>
              </dl>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <DollarSign className="h-3.5 w-3.5" /> Est. monthly cost
              </span>
              <span className="text-sm font-semibold">{formatCurrency(monthlyCost)}</span>
            </div>

            {chosenScenario && (
              <div className="rounded-lg border border-danger/30 bg-danger/5 p-3 text-xs">
                <span className="font-medium text-danger">This creation will fail: </span>
                {chosenScenario.title}
              </div>
            )}

            <CodeBlock code={terraform} language="hcl" filename={`${def.terraformResourceType}.tf`} />
          </div>
        )}

        <DialogFooter>
          {step === "configure" ? (
            <Button onClick={() => setStep("review")} disabled={!canProceed} className="gap-1.5">
              Next: Review <ChevronRight className="h-4 w-4" />
            </Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => setStep("configure")} className="gap-1.5">
                <ChevronLeft className="h-4 w-4" /> Back
              </Button>
              <Button onClick={handleCreate} className="gap-1.5">
                <Rocket className="h-4 w-4" /> Create
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StepDot({ active, done, label }: { active: boolean; done: boolean; label: string }) {
  return (
    <span
      className={cn(
        "shrink-0 rounded-full px-2 py-0.5",
        active
          ? "bg-primary/10 font-medium text-primary"
          : done
            ? "text-foreground"
            : "text-muted-foreground",
      )}
    >
      {label}
    </span>
  );
}

"use client";

import * as React from "react";
import { Plus, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { GCP_RESOURCES } from "@/lib/gcp";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";

// Same category ordering used by the Catalog tab and Console nav, for visual consistency.
const CATEGORY_ORDER: ResourceCategory[] = [
  "networking",
  "compute",
  "storage",
  "database",
  "containers",
  "cicd",
  "security",
  "messaging",
];

/** The full GCP resource catalog, grouped by category — pick a type to stage
 *  it as a new planned block (configured via a dialog, never free-text HCL). */
export function ResourcePicker({ onPick }: { onPick: (type: string) => void }) {
  const [query, setQuery] = React.useState("");

  const grouped = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = GCP_RESOURCES.filter(
      (r) => !q || r.label.toLowerCase().includes(q) || r.shortLabel.toLowerCase().includes(q),
    );
    const map = new Map<ResourceCategory, typeof GCP_RESOURCES>();
    for (const cat of CATEGORY_ORDER) {
      const items = filtered.filter((r) => r.category === cat);
      if (items.length > 0) map.set(cat, items);
    }
    return map;
  }, [query]);

  return (
    <div className="flex flex-col gap-3">
      <div className="relative">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search resource types..."
          className="h-8 pl-8 text-xs"
        />
      </div>

      {grouped.size === 0 && <p className="text-xs text-muted-foreground">No resource types match.</p>}

      {Array.from(grouped.entries()).map(([cat, items]) => (
        <div key={cat}>
          <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            {CATEGORY_META[cat].label}
            <Badge variant="outline" className="text-[10px]">
              {items.length}
            </Badge>
          </div>
          <div className="flex flex-col gap-1">
            {items.map((def) => (
              <button
                key={def.type}
                type="button"
                onClick={() => onPick(def.type)}
                className="flex items-center gap-2 rounded-lg border border-border px-2 py-1.5 text-left text-sm transition-colors hover:bg-accent"
              >
                <ResourceIcon type={def.type} color={def.color} size={14} className="h-7 w-7 shrink-0" />
                <span className="min-w-0 flex-1 truncate">{def.label}</span>
                <Plus className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

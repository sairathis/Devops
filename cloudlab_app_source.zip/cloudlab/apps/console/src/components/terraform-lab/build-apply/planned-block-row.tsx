"use client";

import * as React from "react";
import { Pencil, Trash2, Eye, Flame, Rocket, FlaskConical } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { PlannedBlock } from "@/store/terraform-lab-store";
import { blockDisplayName } from "@/lib/terraform-lab/build-apply";
import { cn } from "@/lib/utils";

// Literal Tailwind class lookup — never construct classes dynamically.
const APPLIED_BADGE_CLASS = "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
const PLANNED_BADGE_CLASS = "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400";
const CLOUDLAB_BADGE_CLASS = "border-transparent bg-primary/15 text-primary";

export function PlannedBlockRow({
  block,
  busy,
  cloudlabStatus,
  testable = false,
  onEdit,
  onRemove,
  onViewDetail,
  onTest,
  onDestroy,
  onApply,
}: {
  block: PlannedBlock;
  busy: boolean;
  /** The applied resource's real-provisioning status, when this block maps to one of CloudLab's real-backed types. */
  cloudlabStatus?: "creating" | "ready" | "failed";
  /** True when this resource type has a real test action (VM exec, Cloud Run invoke, bucket round-trip) — see lib/cloudlab/test-actions.ts. */
  testable?: boolean;
  onEdit: () => void;
  onRemove: () => void;
  onViewDetail: () => void;
  onTest?: () => void;
  onDestroy: () => void;
  onApply: () => void;
}) {
  const def = getResourceDef(block.type);
  if (!def) return null;
  const applied = Boolean(block.appliedResourceId);
  const name = blockDisplayName(block);

  return (
    <div className="flex items-center gap-2.5 rounded-xl border border-border bg-card/60 px-3 py-2.5">
      <ResourceIcon type={def.type} color={def.color} size={16} className="h-9 w-9 shrink-0" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{name}</p>
        <div className="flex min-w-0 items-center gap-1">
          <p className="truncate text-[11px] text-muted-foreground">{def.shortLabel}</p>
          {cloudlabStatus === "ready" && (
            <Badge className={cn("shrink-0 px-1.5 py-0 text-[9px] leading-4", CLOUDLAB_BADGE_CLASS)}>
              Live on CloudLab
            </Badge>
          )}
        </div>
      </div>
      <Badge className={cn("shrink-0 text-[10px]", applied ? APPLIED_BADGE_CLASS : PLANNED_BADGE_CLASS)}>
        {applied ? "Applied" : "Planned"}
      </Badge>
      <div className="flex shrink-0 items-center gap-1">
        {applied ? (
          <>
            <Button
              size="iconSm"
              variant="ghost"
              onClick={onViewDetail}
              title="Open resource detail (overview, Terraform, logs, Fix)"
            >
              <Eye className="h-3.5 w-3.5" />
            </Button>
            {testable && cloudlabStatus === "ready" && onTest && (
              <Button
                size="iconSm"
                variant="ghost"
                onClick={onTest}
                title="Run a real test against this resource (command exec, invoke, or object round-trip)"
              >
                <FlaskConical className="h-3.5 w-3.5" />
              </Button>
            )}
            <Button
              size="iconSm"
              variant="ghost"
              className="text-danger hover:bg-danger/10"
              onClick={onDestroy}
              disabled={busy}
              title="Destroy this resource"
            >
              <Flame className="h-3.5 w-3.5" />
            </Button>
          </>
        ) : (
          <>
            <Button size="iconSm" variant="ghost" onClick={onEdit} disabled={busy} title="Edit configuration">
              <Pencil className="h-3.5 w-3.5" />
            </Button>
            <Button
              size="iconSm"
              variant="ghost"
              onClick={onApply}
              disabled={busy}
              title="Apply this block (and any dependency it needs first)"
            >
              <Rocket className="h-3.5 w-3.5" />
            </Button>
            <Button
              size="iconSm"
              variant="ghost"
              className="text-danger hover:bg-danger/10"
              onClick={onRemove}
              disabled={busy}
              title="Remove from plan"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

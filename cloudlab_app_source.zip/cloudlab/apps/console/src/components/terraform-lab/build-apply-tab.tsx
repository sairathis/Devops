"use client";

import * as React from "react";
import { toast } from "sonner";
import { Boxes, Rocket, Flame, ListChecks, Waypoints, Info } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { CodeBlock } from "@/components/code-block";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ArchitectureDiagram } from "@/components/gcp-console/architecture-diagram";
import { ResourceDetail } from "@/components/gcp-console/resource-detail";
import { ResourcePicker } from "@/components/terraform-lab/build-apply/resource-picker";
import { BlockFormDialog } from "@/components/terraform-lab/build-apply/block-form-dialog";
import { PlannedBlockRow } from "@/components/terraform-lab/build-apply/planned-block-row";
import { useTerraformLabStore, PlannedBlock } from "@/store/terraform-lab-store";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useIamStore } from "@/store/iam-store";
import { useActivityLogStore } from "@/store/activity-log-store";
import { useProgressStore } from "@/store/progress-store";
import { getResourceDef } from "@/lib/gcp";
import { isProvisionable } from "@/lib/cloudlab/engine";
import { testableKind } from "@/lib/cloudlab/test-actions";
import { ResourceConfig } from "@/types/gcp";
import { SimLogEntry, makeLog } from "@/lib/console-sim/types";
import {
  blockDisplayName,
  buildRefCandidates,
  computePlanSummary,
  generatePlanHcl,
  remapConfigForApply,
  resolveApplyOrder,
} from "@/lib/terraform-lab/build-apply";
import { cn } from "@/lib/utils";

// Literal Tailwind class lookup — never construct classes dynamically.
const BUSY_BADGE_CLASS = "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400";

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// How long to wait for CloudLab's own async real-provisioning attempt
// (fired inside useGcpConsoleStore.createResource, see console-provision.ts)
// to settle before giving up and telling the user to check back later —
// applying a real chain end to end (VPC -> Subnet -> VM, say) is well within
// this per-block budget.
const CLOUDLAB_CONFIRM_TIMEOUT_MS = 20_000;

/**
 * Polls the shared Console store directly (via getState(), not a React
 * closure) for a just-created resource's real CloudLab status to settle, so
 * Apply can report genuine confirmation rather than assuming success the
 * instant the simulated resource exists.
 */
async function waitForCloudlabConfirmation(
  resourceId: string,
): Promise<{ status: "ready" | "failed" | "timeout"; error?: string }> {
  const deadline = Date.now() + CLOUDLAB_CONFIRM_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const res = useGcpConsoleStore.getState().resources.find((r) => r.id === resourceId);
    if (res?.cloudlabStatus === "ready") return { status: "ready" };
    if (res?.cloudlabStatus === "failed") return { status: "failed", error: res.cloudlabError };
    await sleep(400);
  }
  return { status: "timeout" };
}

/**
 * "Build & Apply" — the live counterpart to the Terraform Lab's HCL sandbox.
 * Plans are built from a structured resource picker (never free-text HCL), so
 * Apply always succeeds: every planned block is a real, valid config for a
 * real resource type. Applying creates that resource for real in
 * useGcpConsoleStore — the same shared store the GCP Services Console,
 * Demo Architectures, and Troubleshooting Center all read from — so it's
 * fully troubleshootable and destroyable from there too.
 */
export function BuildApplyTab() {
  const blocks = useTerraformLabStore((s) => s.blocks);
  const addBlock = useTerraformLabStore((s) => s.addBlock);
  const updateBlockConfig = useTerraformLabStore((s) => s.updateBlockConfig);
  const removeBlock = useTerraformLabStore((s) => s.removeBlock);
  const markApplied = useTerraformLabStore((s) => s.markApplied);
  const markDestroyed = useTerraformLabStore((s) => s.markDestroyed);

  const consoleResources = useGcpConsoleStore((s) => s.resources);
  const createResource = useGcpConsoleStore((s) => s.createResource);
  const deleteResource = useGcpConsoleStore((s) => s.deleteResource);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const logActivity = useActivityLogStore((s) => s.logActivity);
  const addXp = useProgressStore((s) => s.addXp);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const [addingType, setAddingType] = React.useState<string | null>(null);
  const [editingBlock, setEditingBlock] = React.useState<PlannedBlock | null>(null);
  const [detailResourceId, setDetailResourceId] = React.useState<string | null>(null);
  const [detailTab, setDetailTab] = React.useState<"overview" | "test">("overview");
  const [diagramOpen, setDiagramOpen] = React.useState(false);
  const [busy, setBusy] = React.useState<"apply" | "destroy" | null>(null);
  const [progress, setProgress] = React.useState<{ index: number; total: number; label: string } | null>(null);
  const [logs, setLogs] = React.useState<SimLogEntry[]>([]);
  const xpAwardedRef = React.useRef(false);

  const refCandidates = React.useMemo(() => buildRefCandidates(blocks, consoleResources), [blocks, consoleResources]);
  const plan = React.useMemo(() => computePlanSummary(blocks), [blocks]);
  const hcl = React.useMemo(() => generatePlanHcl(blocks), [blocks]);

  const appliedResources = React.useMemo(() => {
    const ids = new Set(blocks.map((b) => b.appliedResourceId).filter((v): v is string => Boolean(v)));
    return consoleResources.filter((r) => ids.has(r.id));
  }, [blocks, consoleResources]);

  const detailResource = React.useMemo(
    () => (detailResourceId ? (consoleResources.find((r) => r.id === detailResourceId) ?? null) : null),
    [detailResourceId, consoleResources],
  );

  const appendLog = React.useCallback((level: SimLogEntry["level"], message: string) => {
    setLogs((prev) => [...prev, makeLog(level, message)]);
  }, []);

  const runApply = React.useCallback(
    async (targetId?: string) => {
      if (busy) return;
      const pendingAll = resolveApplyOrder(blocks).filter((b) => !b.appliedResourceId);
      let list = pendingAll;
      if (targetId) {
        const idx = pendingAll.findIndex((b) => b.id === targetId);
        if (idx < 0) return;
        list = pendingAll.slice(0, idx + 1);
      }
      if (list.length === 0) {
        toast.info("Nothing to apply — every planned block is already applied.");
        return;
      }

      setBusy("apply");
      setDiagramOpen(true);
      appendLog("command", "terraform apply");
      appendLog("info", "Do you want to perform these actions?");
      appendLog("command", "  Enter a value: yes");

      // Seed with everything already applied, so a block referencing a
      // previously-applied dependency resolves immediately.
      const resolvedIds = new Map<string, string>();
      blocks.forEach((b) => {
        if (b.appliedResourceId) resolvedIds.set(b.id, b.appliedResourceId);
      });

      let realConfirmed = 0;
      let realFailed = 0;

      for (let i = 0; i < list.length; i++) {
        const block = list[i];
        const def = getResourceDef(block.type);
        if (!def) continue;
        const name = blockDisplayName(block);
        setProgress({ index: i + 1, total: list.length, label: def.label });
        appendLog("info", `${def.terraformResourceType}."${name}": Creating...`);

        const finalConfig = remapConfigForApply(block, resolvedIds);
        const resourceId = createResource(block.type, finalConfig);
        resolvedIds.set(block.id, resourceId);
        markApplied(block.id, resourceId);

        appendLog("success", `${def.terraformResourceType}."${name}": Creation complete [id=${resourceId}]`);

        // The Console fired off a best-effort real CloudLab provisioning
        // attempt inside createResource above (see console-provision.ts) —
        // for the 14 real-backed types, wait for it to genuinely settle
        // instead of moving on as if "Applied" already meant "confirmed
        // real". This is what makes the Architecture Diagram opened above,
        // and each row's "Live on CloudLab" badge, trustworthy live signals
        // rather than an optimistic guess.
        if (isProvisionable(block.type)) {
          appendLog("info", `${def.terraformResourceType}."${name}": waiting for real confirmation from CloudLab...`);
          const confirm = await waitForCloudlabConfirmation(resourceId);
          if (confirm.status === "ready") {
            realConfirmed += 1;
            appendLog("success", `${def.terraformResourceType}."${name}": confirmed live on CloudLab — real and testable.`);
          } else if (confirm.status === "failed") {
            realFailed += 1;
            appendLog(
              "warn",
              `${def.terraformResourceType}."${name}": CloudLab real provisioning failed (${confirm.error ?? "unknown error"}) — it stays applied here as a simulated resource only.`,
            );
          } else {
            appendLog(
              "warn",
              `${def.terraformResourceType}."${name}": still provisioning on CloudLab after ${CLOUDLAB_CONFIRM_TIMEOUT_MS / 1000}s — check its Test tab shortly.`,
            );
          }
        }

        if (i < list.length - 1) await sleep(450);
      }

      appendLog(
        "success",
        `Apply complete! Resources: ${list.length} added, 0 changed, 0 destroyed.${
          realConfirmed > 0 ? ` ${realConfirmed} confirmed live on CloudLab.` : ""
        }${realFailed > 0 ? ` ${realFailed} failed real provisioning (see warnings above).` : ""}`,
      );
      setProgress(null);
      setBusy(null);
      toast.success(
        `${list.length} resource${list.length === 1 ? "" : "s"} created — real, troubleshootable, and on the Architecture Diagram.`,
      );
      logActivity({
        actor: "Terraform Lab (Build & Apply)",
        method: "terraform.apply",
        outcome: "success",
        detail: `Apply complete — ${list.length} resource${list.length === 1 ? "" : "s"} added.`,
        source: "terraform-lab",
      });
      if (!xpAwardedRef.current) {
        xpAwardedRef.current = true;
        addXp(20);
        setModuleProgress("terraform-lab", 60);
      }
    },
    [addXp, appendLog, blocks, busy, createResource, logActivity, markApplied, setModuleProgress],
  );

  const runDestroy = React.useCallback(
    async (targetId?: string) => {
      if (busy) return;
      const appliedOrdered = resolveApplyOrder(blocks)
        .filter((b) => b.appliedResourceId)
        .reverse();
      const list = targetId ? appliedOrdered.filter((b) => b.id === targetId) : appliedOrdered;
      if (list.length === 0) {
        toast.info("Nothing applied to destroy.");
        return;
      }

      setBusy("destroy");
      setDiagramOpen(true);
      appendLog("command", "terraform destroy");
      appendLog("info", "Do you really want to destroy all resources?");
      appendLog("command", "  Enter a value: yes");

      for (let i = 0; i < list.length; i++) {
        const block = list[i];
        const def = getResourceDef(block.type);
        const name = blockDisplayName(block);
        const wasReal = isProvisionable(block.type);
        setProgress({ index: i + 1, total: list.length, label: def?.label ?? block.type });
        appendLog(
          "info",
          `${def?.terraformResourceType ?? block.type}."${name}": Destroying...${wasReal ? " (waiting for CloudLab to confirm the real delete too)" : ""}`,
        );

        // deleteResource now resolves only once both the simulated removal
        // AND the best-effort real CloudLab delete have settled (see
        // gcp-console-store.ts) — so markDestroyed here means genuinely
        // gone, not just "we asked it to go".
        await deleteResource(block.appliedResourceId!);
        markDestroyed(block.id);

        appendLog(
          "success",
          `${def?.terraformResourceType ?? block.type}."${name}": Destruction complete${wasReal ? " — confirmed removed from CloudLab too." : "."}`,
        );
        if (i < list.length - 1) await sleep(350);
      }

      appendLog("success", `Destroy complete! Resources: ${list.length} destroyed.`);
      setProgress(null);
      setBusy(null);
      toast.info(`${list.length} resource${list.length === 1 ? "" : "s"} removed from the Console.`);
      logActivity({
        actor: "Terraform Lab (Build & Apply)",
        method: "terraform.destroy",
        outcome: "success",
        detail: `Destroy complete — ${list.length} resource${list.length === 1 ? "" : "s"} removed.`,
        source: "terraform-lab",
      });
    },
    [appendLog, blocks, busy, deleteResource, logActivity, markDestroyed],
  );

  function handleAddSubmit(config: ResourceConfig) {
    if (!addingType) return;
    addBlock(addingType, config);
    toast.success("Added to plan — run Apply to create it for real.");
  }

  function handleEditSubmit(config: ResourceConfig) {
    if (!editingBlock) return;
    updateBlockConfig(editingBlock.id, config);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-2 rounded-xl border border-info/30 bg-info/5 p-3 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-info" />
        <p>
          Pick resource types from the actual GCP catalog, configure them with the same forms the Console&apos;s
          Create wizard uses, then Apply creates them in the shared GCP Services Console — troubleshoot, inspect
          logs, and watch them appear live on the Architecture Diagram (opened automatically below) exactly like
          anything else you create there. 14 types — VPC, Subnet, VM, GKE, Cloud Storage, Cloud SQL, Artifact
          Registry, Cloud NAT, Cloud DNS, Load Balancer, Instance Template, Managed Instance Group, Cloud Run, and
          Composer — also provision for real on CloudLab&apos;s API when applied; Apply waits for that real
          confirmation before moving on, so the &quot;Live on CloudLab&quot; badge is trustworthy the moment it
          appears. Use a row&apos;s flask icon to run a genuine test against it (a real command, invoke, or object
          round trip). Destroy waits for CloudLab to confirm the real delete too before removing a block here.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="outline" className="gap-1">
          <ListChecks className="h-3 w-3" /> {plan.toAdd} to add, {plan.applied} already applied
        </Badge>
        <Button size="sm" onClick={() => runApply()} disabled={busy !== null || plan.toAdd === 0} className="gap-1.5">
          <Rocket className="h-3.5 w-3.5" /> Apply plan
        </Button>
        <Button
          size="sm"
          variant="destructive"
          onClick={() => runDestroy()}
          disabled={busy !== null || plan.applied === 0}
          className="gap-1.5"
        >
          <Flame className="h-3.5 w-3.5" /> Destroy all
        </Button>
        {plan.applied > 0 && (
          <Button size="sm" variant="outline" onClick={() => setDiagramOpen(true)} className="gap-1.5">
            <Waypoints className="h-3.5 w-3.5" /> View diagram
          </Button>
        )}
        {busy && progress && (
          <Badge className={cn("gap-1", BUSY_BADGE_CLASS)}>
            {busy === "apply" ? "Applying" : "Destroying"} {progress.index}/{progress.total} — {progress.label}
          </Badge>
        )}
      </div>
      {busy && progress && <Progress value={(progress.index / progress.total) * 100} />}

      <div className="grid gap-5 lg:grid-cols-[260px_1fr_1fr]">
        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Resource catalog</CardTitle>
            <CardDescription className="text-xs">Pick a real GCP resource type to stage.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto pt-0">
            <ResourcePicker onPick={(type) => setAddingType(type)} />
          </CardContent>
        </Card>

        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-1.5 text-sm">
              <Boxes className="h-4 w-4" /> Planned blocks ({blocks.length})
            </CardTitle>
            <CardDescription className="text-xs">
              Bind a block to another via its config form&apos;s reference fields — same as the Console&apos;s wizard.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-1 flex-col gap-2 overflow-y-auto pt-0">
            {blocks.length === 0 ? (
              <p className="flex flex-1 items-center justify-center text-center text-sm text-muted-foreground">
                Nothing staged yet — add a resource from the catalog to start building a plan.
              </p>
            ) : (
              blocks.map((block) => (
                <PlannedBlockRow
                  key={block.id}
                  block={block}
                  busy={busy !== null}
                  cloudlabStatus={
                    block.appliedResourceId
                      ? consoleResources.find((r) => r.id === block.appliedResourceId)?.cloudlabStatus
                      : undefined
                  }
                  testable={testableKind(block.type) !== null}
                  onEdit={() => setEditingBlock(block)}
                  onRemove={() => removeBlock(block.id)}
                  onViewDetail={() => {
                    if (!block.appliedResourceId) return;
                    setDetailTab("overview");
                    setDetailResourceId(block.appliedResourceId);
                  }}
                  onTest={() => {
                    if (!block.appliedResourceId) return;
                    setDetailTab("test");
                    setDetailResourceId(block.appliedResourceId);
                  }}
                  onDestroy={() => runDestroy(block.id)}
                  onApply={() => runApply(block.id)}
                />
              ))
            )}
          </CardContent>
        </Card>

        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Generated Terraform</CardTitle>
            <CardDescription className="text-xs">
              {hcl.resourceCount} resource block{hcl.resourceCount === 1 ? "" : "s"} — real generateTerraform() output,
              concatenated.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden pt-0">
            <CodeBlock code={hcl.full} language="hcl" filename="build-and-apply.tf" maxHeight="480px" />
          </CardContent>
        </Card>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold">Apply / destroy log</p>
        <TerminalOutput
          lines={logs}
          heightClassName="h-56"
          emptyLabel='Nothing has run yet. Add resources from the catalog, then click "Apply plan".'
        />
      </div>

      <Dialog open={diagramOpen} onOpenChange={setDiagramOpen}>
        <DialogContent className="max-h-[85vh] max-w-5xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Terraform Lab — Architecture Diagram</DialogTitle>
            <DialogDescription>
              Only the resources this lab has actually applied, wired by the real bindings you chose.
            </DialogDescription>
          </DialogHeader>
          <ArchitectureDiagram
            resources={appliedResources}
            serviceAccounts={serviceAccounts.map((sa) => ({ id: sa.id, name: sa.name, email: sa.email }))}
            onFixBinding={(id) => {
              setDiagramOpen(false);
              setDetailResourceId(id);
            }}
          />
        </DialogContent>
      </Dialog>

      <BlockFormDialog
        type={addingType}
        open={addingType !== null}
        onOpenChange={(open) => !open && setAddingType(null)}
        resources={refCandidates}
        onSubmit={handleAddSubmit}
      />

      <BlockFormDialog
        type={editingBlock?.type ?? null}
        open={editingBlock !== null}
        onOpenChange={(open) => !open && setEditingBlock(null)}
        initialConfig={editingBlock?.config}
        resources={refCandidates.filter((r) => r.id !== editingBlock?.id)}
        onSubmit={handleEditSubmit}
      />

      <ResourceDetail
        resource={detailResource}
        open={detailResource !== null}
        onOpenChange={(open) => !open && setDetailResourceId(null)}
        defaultTab={detailTab}
      />
    </div>
  );
}

"use client";
import * as React from "react";
import { CloudCog, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type RealLabStatus = "idle" | "provisioning" | "ready" | "failed";

const STATUS_BADGE: Record<RealLabStatus, { label: string; className: string; icon: React.ReactNode }> = {
  idle: { label: "Not deployed for real yet", className: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400", icon: null },
  provisioning: {
    label: "Pending — waiting for CloudLab",
    className: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
  },
  ready: {
    label: "Live on CloudLab",
    className: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
    icon: <CheckCircle2 className="h-3 w-3" />,
  },
  failed: { label: "Real provisioning failed", className: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400", icon: <XCircle className="h-3 w-3" /> },
};

/**
 * Shared "this lab also did something real" status card for Docker Lab and
 * Kubernetes Lab -- the same Pending -> Live on CloudLab language used
 * everywhere else real provisioning happens (Terraform Lab, Architecture
 * Builder), but standalone rather than built on ResourceDetail/ConsoleResource
 * (container_image and k8s_deployment aren't GCP-catalog resource types --
 * getResourceDef/ConfigForm/the Architecture Diagram's lanes don't know them
 * — so this renders its own compact facts list instead of assuming that
 * shape).
 */
export function RealLabPanel({
  title,
  description,
  status,
  error,
  facts,
  children,
}: {
  title: string;
  description: string;
  status: RealLabStatus;
  error?: string;
  facts?: { label: string; value: React.ReactNode }[];
  children?: React.ReactNode;
}) {
  const badge = STATUS_BADGE[status];
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-sm">
            <CloudCog className="h-4 w-4 text-muted-foreground" />
            {title}
          </CardTitle>
          <Badge className={cn("gap-1 text-[11px]", badge.className)}>
            {badge.icon}
            {badge.label}
          </Badge>
        </div>
        <CardDescription className="text-xs">{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {status === "failed" && error && (
          <p className="rounded-md border border-danger/30 bg-danger/5 px-3 py-2 text-xs text-danger">{error}</p>
        )}
        {facts && facts.length > 0 && (
          <dl className="grid gap-x-4 gap-y-1.5 text-xs sm:grid-cols-2">
            {facts.map((f) => (
              <div key={f.label} className="flex flex-col gap-0.5">
                <dt className="text-muted-foreground">{f.label}</dt>
                <dd className="break-words font-mono text-[11px]">{f.value}</dd>
              </div>
            ))}
          </dl>
        )}
        {children}
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { usePathname, useRouter } from "next/navigation";
import { Search, Bell, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { MobileNav } from "@/components/layout/mobile-nav";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useUiStore } from "@/store/ui-store";
import { useProgressStore } from "@/store/progress-store";
import { useAuthStore } from "@/store/auth-store";
import { MODULES } from "@/lib/modules";
import { Badge } from "@/components/ui/badge";

function initialsOf(name: string | undefined) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")).toUpperCase() || "?";
}

export function Topbar() {
  const pathname = usePathname();
  const router = useRouter();
  const setCommandPaletteOpen = useUiStore((s) => s.setCommandPaletteOpen);
  const totalXp = useProgressStore((s) => s.totalXp);
  const streakDays = useProgressStore((s) => s.streakDays);
  const user = useAuthStore((s) => s.user);
  const projectName = useAuthStore((s) => s.projectName);
  const logout = useAuthStore((s) => s.logout);
  const current = MODULES.find((m) => m.href === pathname);

  function handleSignOut() {
    logout();
    router.replace("/login");
  }

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border bg-background/70 px-4 backdrop-blur-md md:px-6">
      <MobileNav />
      <div className="hidden flex-col md:flex">
        <h1 className="text-sm font-semibold leading-tight">{current?.label ?? "CloudVerse DevOps Academy"}</h1>
        <p className="text-xs text-muted-foreground leading-tight">{current?.description ?? "Learn cloud by building it"}</p>
      </div>

      <button
        onClick={() => setCommandPaletteOpen(true)}
        className="ml-2 flex flex-1 items-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted md:ml-6 md:max-w-md"
      >
        <Search className="h-4 w-4" />
        <span className="hidden sm:inline">Search everywhere...</span>
        <span className="hidden sm:inline">&nbsp;</span>
        <kbd className="ml-auto hidden rounded border border-border bg-background px-1.5 py-0.5 text-[10px] font-medium sm:inline">
          ⌘K
        </kbd>
      </button>

      <div className="ml-auto flex items-center gap-1.5">
        <Badge variant="warning" className="hidden items-center gap-1 sm:flex">
          <Flame className="h-3 w-3" /> {streakDays}d streak
        </Badge>
        <Badge variant="info" className="hidden sm:flex">{totalXp} XP</Badge>
        <Button variant="ghost" size="icon" aria-label="Notifications">
          <Bell className="h-4 w-4" />
        </Button>
        <ThemeToggle />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="ml-1">
              <Avatar className="h-8 w-8 border border-border">
                <AvatarFallback>{initialsOf(user?.name)}</AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel className="flex flex-col">
              <span>{user?.name ?? "Not signed in"}</span>
              <span className="text-xs font-normal text-muted-foreground">{user?.email}</span>
              {projectName && (
                <span className="mt-1 text-[10px] font-normal uppercase tracking-wide text-muted-foreground">
                  Project: {projectName}
                </span>
              )}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile settings</DropdownMenuItem>
            <DropdownMenuItem>Keyboard shortcuts</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={handleSignOut}>Sign out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

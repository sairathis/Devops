"use client";
import * as React from "react";
import { usePathname, useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { CommandPalette } from "@/components/layout/command-palette";
import { OnboardingTour } from "@/components/layout/onboarding-tour";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useAuthStore } from "@/store/auth-store";
import { useProgressStore } from "@/store/progress-store";
import { useArchitectureStore } from "@/store/architecture-store";

const PUBLIC_ROUTES = new Set(["/login"]);

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const token = useAuthStore((s) => s.token);
  const projectId = useAuthStore((s) => s.projectId);
  const ensureProject = useAuthStore((s) => s.ensureProject);
  const [hydrated, setHydrated] = React.useState(false);

  // zustand's persist middleware hydrates from localStorage asynchronously
  // (after first render), so wait one tick before deciding whether to redirect.
  React.useEffect(() => {
    setHydrated(true);
  }, []);

  const isPublicRoute = PUBLIC_ROUTES.has(pathname);

  React.useEffect(() => {
    if (!hydrated) return;
    if (!token && !isPublicRoute) {
      router.replace("/login");
    }
  }, [hydrated, token, isPublicRoute, router]);

  // Once signed in, make sure there's a real CloudLab project to provision into
  // (creates one automatically on a user's very first sign-in).
  React.useEffect(() => {
    if (token && !projectId) {
      ensureProject().catch(() => {
        // Surfaced to the user the next time a module tries to call the API
        // and gets a 401/"no project" error; avoid a toast storm on mount.
      });
    }
  }, [token, projectId, ensureProject]);

  // Reconcile this browser's Quiz Engine / Certification Paths / Progress &
  // Badges state against the real per-user rows CloudLab's academy API keeps
  // (Postgres, not just localStorage) — independent of ensureProject's
  // project bootstrap above, since academy progress is scoped to the account
  // rather than a project.
  React.useEffect(() => {
    if (token) {
      useProgressStore.getState().hydrateFromServer();
    }
  }, [token]);

  // Architecture Builder's saved diagrams are scoped to a real CloudLab
  // project, so this one waits for ensureProject's bootstrap above.
  React.useEffect(() => {
    if (token && projectId) {
      useArchitectureStore.getState().hydrateProjectsFromServer();
    }
  }, [token, projectId]);

  // Heal any resource left mid-transition (provisioning/starting/stopping, or a
  // simulated-failure that was mid-recovery) by a hard page reload — run this
  // once, app-wide, rather than only when the user happens to land on the GCP
  // Console tab, so a refresh from any page (Operations Suite included) never
  // leaves a resource stuck in a state that can no longer change on its own.
  React.useEffect(() => {
    useGcpConsoleStore.getState().resumeStuckStates();
  }, []);

  if (isPublicRoute) {
    return (
      <TooltipProvider delayDuration={200}>
        {children}
        <Toaster position="bottom-right" />
      </TooltipProvider>
    );
  }

  if (!hydrated || (!token && !isPublicRoute)) {
    return (
      <div className="flex h-svh w-full items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex h-svh w-full overflow-hidden bg-background">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar />
          <main className="flex-1 overflow-y-auto">{children}</main>
        </div>
        <CommandPalette />
        <OnboardingTour />
        <Toaster position="bottom-right" />
      </div>
    </TooltipProvider>
  );
}

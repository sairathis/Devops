"use client";

import * as React from "react";
import { toast } from "sonner";
import { Play, RotateCcw, AlertTriangle, History, ScrollText, Trash2, Boxes } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { PipelineStepper } from "@/components/cicd-simulator/pipeline-stepper";
import { LogPanel, type LogEntry } from "@/components/cicd-simulator/log-panel";
import { StageLogViewer } from "@/components/cicd-simulator/stage-log-viewer";
import { APPLY_STAGES, DESTROY_STAGES } from "@/components/cicd-simulator/platform-pipeline-config";
import type { StageStatus } from "@/components/cicd-simulator/pipeline-config";
import { useTerraformLabStore, type PlannedBlock } from "@/store/terraform-lab-store";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { usePlatformPipelineStore, type PlatformRunEntry, type PlatformRunType } from "@/store/platform-pipeline-store";
import { useActivityLogStore } from "@/store/activity-log-store";
import type { StageLogGroup } from "@/store/cicd-simulator-store";
import { getResourceDef } from "@/lib/gcp";
import { cn, slugify } from "@/lib/utils";
import { CodeBlock } from "@/components/code-block";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function randomBetween(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

let logIdCounter = 0;
function nextLogId() {
  logIdCounter += 1;
  return `platform-log-${logIdCounter}`;
}

const RUN_TYPE_BADGE_VARIANT: Record<PlatformRunType, "info" | "warning"> = {
  apply: "info",
  destroy: "warning",
};

const RUN_TYPE_LABEL: Record<PlatformRunType, string> = {
  apply: "Apply",
  destroy: "Destroy",
};

const RUN_STATUS_BADGE_VARIANT: Record<PlatformRunEntry["status"], "success" | "danger"> = {
  success: "success",
  failed: "danger",
};

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

function blockLabel(block: PlannedBlock): string {
  const def = getResourceDef(block.type);
  const name = String(block.config.name ?? block.type);
  return `${def?.shortLabel ?? def?.label ?? block.type}: ${name}`;
}

export function PlatformPipelinePanel() {
  const blocks = useTerraformLabStore((s) => s.blocks);
  const markApplied = useTerraformLabStore((s) => s.markApplied);
  const markDestroyed = useTerraformLabStore((s) => s.markDestroyed);
  const createResource = useGcpConsoleStore((s) => s.createResource);
  const deleteResource = useGcpConsoleStore((s) => s.deleteResource);

  const runs = usePlatformPipelineStore((s) => s.runs);
  const recordRun = usePlatformPipelineStore((s) => s.recordRun);
  const logActivity = useActivityLogStore((s) => s.logActivity);

  const notApplied = blocks.filter((b) => !b.appliedResourceId);
  const applied = blocks.filter((b) => b.appliedResourceId);

  const [runMode, setRunMode] = React.useState<PlatformRunType>("apply");
  const [statuses, setStatuses] = React.useState<StageStatus[]>(() => APPLY_STAGES.map(() => "pending"));
  const [logs, setLogs] = React.useState<LogEntry[]>([]);
  const [running, setRunning] = React.useState(false);
  const [failedIndex, setFailedIndex] = React.useState<number | null>(null);
  const [failureMessage, setFailureMessage] = React.useState<string | null>(null);
  const [logsFor, setLogsFor] = React.useState<PlatformRunEntry | null>(null);

  const runTokenRef = React.useRef(0);
  const stageGroupsRef = React.useRef<StageLogGroup[]>([]);
  const targetBlockIdsRef = React.useRef<string[]>([]);

  const appendLog = React.useCallback((text: string, tone: LogEntry["tone"]) => {
    setLogs((prev) => [...prev, { id: nextLogId(), text, tone }]);
  }, []);

  const runPipeline = React.useCallback(
    async (mode: PlatformRunType, startIndex: number) => {
      const stageList = mode === "apply" ? APPLY_STAGES : DESTROY_STAGES;
      const myToken = ++runTokenRef.current;
      setRunMode(mode);
      setRunning(true);
      setFailureMessage(null);
      setFailedIndex(null);

      const freshGroups = (): StageLogGroup[] =>
        stageList.map((s) => ({ stageId: s.id, label: s.label, status: "skipped" as const, lines: [] }));

      if (startIndex === 0) {
        setStatuses(stageList.map(() => "pending"));
        setLogs([]);
        stageGroupsRef.current = freshGroups();
        targetBlockIdsRef.current =
          mode === "apply"
            ? useTerraformLabStore.getState().blocks.filter((b) => !b.appliedResourceId).map((b) => b.id)
            : useTerraformLabStore.getState().blocks.filter((b) => b.appliedResourceId).map((b) => b.id);
        appendLog(mode === "apply" ? "Starting `terraform apply`..." : "Starting `terraform destroy`...", "muted");
      } else {
        setStatuses((prev) => prev.map((s, i) => (i < startIndex ? s : "pending")));
        const base = stageGroupsRef.current.length === stageList.length ? stageGroupsRef.current : freshGroups();
        stageGroupsRef.current = base.map((g, i) => (i < startIndex ? g : freshGroups()[i]));
        appendLog(`Retrying from stage "${stageList[startIndex].label}"...`, "muted");
      }

      const streamLines = async (
        lines: string[],
        totalMs: number,
        logLine: (text: string, tone: LogEntry["tone"]) => void,
      ): Promise<boolean> => {
        const perLineMs = Math.max(150, Math.floor(totalMs / (lines.length + 1)));
        for (const line of lines) {
          await sleep(perLineMs);
          if (runTokenRef.current !== myToken) return false;
          logLine(line, "info");
        }
        await sleep(Math.max(0, totalMs - perLineMs * lines.length));
        return runTokenRef.current === myToken;
      };

      for (let i = startIndex; i < stageList.length; i++) {
        if (runTokenRef.current !== myToken) return;
        const stage = stageList[i];

        const group: StageLogGroup = { stageId: stage.id, label: stage.label, status: "skipped", lines: [] };
        stageGroupsRef.current[i] = group;

        const logLine = (text: string, tone: LogEntry["tone"]) => {
          appendLog(text, tone);
          group.lines.push({ id: `${stage.id}-${group.lines.length}`, text, tone });
        };

        const failStage = (message: string) => {
          logLine(message, "error");
          group.status = "failed";
          setStatuses((prev) => prev.map((s, idx) => (idx === i ? "failed" : s)));
          setFailedIndex(i);
          setFailureMessage(message);
          setRunning(false);
          logActivity({
            actor: "Platform (Terraform) pipeline",
            method: `terraform.${mode}`,
            outcome: "failure",
            detail: `${stage.label} stage failed: ${message}`,
            source: "platform-pipeline",
          });
        };

        const succeedStage = (message: string) => {
          logLine(message, "success");
          group.status = "success";
          setStatuses((prev) => prev.map((s, idx) => (idx === i ? "success" : s)));
        };

        setStatuses((prev) => prev.map((s, idx) => (idx === i ? "running" : s)));
        logLine(`Stage started: ${stage.label}`, "muted");
        const totalMs = randomBetween(stage.minMs, stage.maxMs);
        const pickFailure = () =>
          stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ?? `FAIL: ${stage.label} failed unexpectedly`;

        // --- Plan: dynamic "N to add" / "N to destroy" summary. ---
        if (stage.id === "plan") {
          const ok = await streamLines(stage.runningLog, totalMs, logLine);
          if (!ok) return;
          if (Math.random() < stage.failChance) {
            failStage(pickFailure());
            return;
          }
          const count = targetBlockIdsRef.current.length;
          if (mode === "apply") {
            succeedStage(count > 0 ? `Plan: ${count} to add, 0 to change, 0 to destroy.` : "Plan: no changes — infrastructure is up-to-date.");
          } else {
            succeedStage(count > 0 ? `Plan: 0 to add, 0 to change, ${count} to destroy.` : "Plan: nothing to destroy.");
          }
          continue;
        }

        // --- Apply: sequentially create each not-yet-applied block as a real resource. ---
        if (stage.id === "apply") {
          const ok = await streamLines(stage.runningLog, totalMs, logLine);
          if (!ok) return;
          if (Math.random() < stage.failChance) {
            failStage(pickFailure());
            return;
          }
          const ids = targetBlockIdsRef.current;
          for (const blockId of ids) {
            const block = useTerraformLabStore.getState().blocks.find((b) => b.id === blockId);
            if (!block || block.appliedResourceId) continue;
            await sleep(400);
            if (runTokenRef.current !== myToken) return;
            const def = getResourceDef(block.type);
            const name = String(block.config.name ?? block.type);
            const resourceId = createResource(block.type, block.config);
            markApplied(block.id, resourceId);
            logLine(
              `${def?.terraformResourceType ?? block.type}.${name}: Creation complete after ${(1 + Math.random() * 3).toFixed(1)}s [id=${resourceId}]`,
              "success",
            );
          }
          succeedStage(`Apply complete! ${ids.length} resource${ids.length === 1 ? "" : "s"} added.`);
          continue;
        }

        // --- Destroy: sequentially delete each applied block's real resource. ---
        if (stage.id === "destroy") {
          const ok = await streamLines(stage.runningLog, totalMs, logLine);
          if (!ok) return;
          if (Math.random() < stage.failChance) {
            failStage(pickFailure());
            return;
          }
          const ids = targetBlockIdsRef.current;
          for (const blockId of ids) {
            const block = useTerraformLabStore.getState().blocks.find((b) => b.id === blockId);
            if (!block || !block.appliedResourceId) continue;
            await sleep(400);
            if (runTokenRef.current !== myToken) return;
            const def = getResourceDef(block.type);
            const name = String(block.config.name ?? block.type);
            deleteResource(block.appliedResourceId);
            markDestroyed(block.id);
            logLine(`${def?.terraformResourceType ?? block.type}.${name}: Destruction complete after ${(0.5 + Math.random() * 2).toFixed(1)}s`, "success");
          }
          succeedStage(`Destroy complete! ${ids.length} resource${ids.length === 1 ? "" : "s"} destroyed.`);
          continue;
        }

        // --- Verify: poll real resource status/existence until it settles, then confirm. ---
        if (stage.id === "verify") {
          logLine("Waiting for resources to settle...", "muted");
          const ids = targetBlockIdsRef.current;
          const deadline = Date.now() + 6000;

          if (mode === "apply") {
            while (true) {
              if (runTokenRef.current !== myToken) return;
              const blocksNow = useTerraformLabStore.getState().blocks;
              const resourcesNow = useGcpConsoleStore.getState().resources;
              const relevant = blocksNow.filter((b) => ids.includes(b.id) && b.appliedResourceId);
              const settled = relevant.every((b) => {
                const r = resourcesNow.find((res) => res.id === b.appliedResourceId);
                return !r || r.status !== "provisioning";
              });
              if (settled || Date.now() >= deadline) break;
              await sleep(300);
            }
            if (runTokenRef.current !== myToken) return;

            const blocksNow = useTerraformLabStore.getState().blocks;
            const resourcesNow = useGcpConsoleStore.getState().resources;
            const relevant = blocksNow.filter((b) => ids.includes(b.id) && b.appliedResourceId);
            const healthy = relevant.filter((b) => {
              const r = resourcesNow.find((res) => res.id === b.appliedResourceId);
              return r?.status === "running";
            }).length;
            const total = relevant.length;

            if (total > 0 && healthy < total) {
              failStage(`FAIL: Verify — only ${healthy}/${total} resources reached a healthy status`);
              return;
            }
            if (Math.random() < stage.failChance) {
              failStage(pickFailure());
              return;
            }
            succeedStage(total > 0 ? `Verify: ${healthy}/${total} resources report a healthy status.` : "Verify: nothing to check.");
          } else {
            while (true) {
              if (runTokenRef.current !== myToken) return;
              const blocksNow = useTerraformLabStore.getState().blocks;
              const resourcesNow = useGcpConsoleStore.getState().resources;
              const stillThere = ids.some((id) => {
                const b = blocksNow.find((bl) => bl.id === id);
                return b?.appliedResourceId && resourcesNow.some((r) => r.id === b.appliedResourceId);
              });
              if (!stillThere || Date.now() >= deadline) break;
              await sleep(300);
            }
            if (runTokenRef.current !== myToken) return;

            if (Math.random() < stage.failChance) {
              failStage(pickFailure());
              return;
            }
            succeedStage(`Verify: ${ids.length} resource${ids.length === 1 ? "" : "s"} confirmed removed.`);
          }
          continue;
        }

        // --- Everything else (Init, Validate): canned running log + dice roll. ---
        const ok = await streamLines(stage.runningLog, totalMs, logLine);
        if (!ok) return;
        if (Math.random() < stage.failChance) {
          failStage(pickFailure());
          return;
        }
        succeedStage(stage.successLog);
      }

      appendLog(mode === "apply" ? "terraform apply finished — all stages succeeded." : "terraform destroy finished — all stages succeeded.", "success");
      setRunning(false);
      setFailedIndex(null);

      recordRun({
        runType: mode,
        status: "success",
        summary:
          mode === "apply"
            ? `${targetBlockIdsRef.current.length} resource${targetBlockIdsRef.current.length === 1 ? "" : "s"} applied`
            : `${targetBlockIdsRef.current.length} resource${targetBlockIdsRef.current.length === 1 ? "" : "s"} destroyed`,
        stageLogs: stageGroupsRef.current,
      });
      toast.success(mode === "apply" ? "Apply complete" : "Destroy complete", {
        description:
          mode === "apply" ? "Resources are now live in the GCP Console." : "Resources have been removed from the GCP Console.",
      });
      logActivity({
        actor: "Platform (Terraform) pipeline",
        method: `terraform.${mode}`,
        outcome: "success",
        detail:
          mode === "apply"
            ? `${targetBlockIdsRef.current.length} resource${targetBlockIdsRef.current.length === 1 ? "" : "s"} applied via pipeline.`
            : `${targetBlockIdsRef.current.length} resource${targetBlockIdsRef.current.length === 1 ? "" : "s"} destroyed via pipeline.`,
        source: "platform-pipeline",
      });
    },
    [appendLog, createResource, deleteResource, logActivity, markApplied, markDestroyed, recordRun],
  );

  const handleRunApply = () => void runPipeline("apply", 0);
  const handleRunDestroy = () => void runPipeline("destroy", 0);
  const handleRetry = () => {
    if (failedIndex === null) return;
    void runPipeline(runMode, failedIndex);
  };

  const activeStages = runMode === "apply" ? APPLY_STAGES : DESTROY_STAGES;

  const stagedTerraform = React.useMemo(() => {
    if (blocks.length === 0) return "# Nothing staged in Terraform Lab yet.";
    return blocks
      .map((block) => {
        const def = getResourceDef(block.type);
        if (!def) return `# Unknown resource type: ${block.type}`;
        const name = String(block.config.name ?? block.type);
        return def.generateTerraform({
          config: block.config,
          nodeId: block.id,
          label: name,
          slug: slugify(name),
          allNodes: [],
          connections: [],
        });
      })
      .join("\n\n");
  }, [blocks]);

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Boxes className="h-4 w-4 text-muted-foreground" /> Platform Pipeline
            </CardTitle>
            <CardDescription>
              Runs the same terraform apply / destroy against the blocks staged in the Terraform Lab —
              {" "}
              {notApplied.length} planned, {applied.length} applied.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {failedIndex !== null && !running && (
              <Button variant="outline" onClick={handleRetry}>
                <RotateCcw className="h-4 w-4" /> Retry from failed stage
              </Button>
            )}
            <Button
              variant="outline"
              onClick={handleRunDestroy}
              disabled={running || applied.length === 0}
              title={applied.length === 0 ? "Nothing is applied yet — there's nothing to destroy." : undefined}
            >
              <Trash2 className="h-4 w-4" /> {running && runMode === "destroy" ? "Running..." : "Run Destroy"}
            </Button>
            <Button
              onClick={handleRunApply}
              disabled={running || notApplied.length === 0}
              title={notApplied.length === 0 ? "Everything staged in Terraform Lab is already applied — stage a new resource block first." : undefined}
            >
              <Play className="h-4 w-4" /> {running && runMode === "apply" ? "Running..." : "Run Pipeline"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <PipelineStepper statuses={statuses} stages={activeStages} />

          {!running && notApplied.length === 0 && applied.length === 0 && (
            <div className="rounded-lg border border-dashed border-border bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
              Both buttons are disabled because there&apos;s nothing staged yet. Go to Terraform Lab → Build &amp;
              Apply and stage a resource block, then come back here to run the pipeline against it.
            </div>
          )}
          {!running && notApplied.length === 0 && applied.length > 0 && (
            <div className="rounded-lg border border-dashed border-border bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
              &quot;Run Pipeline&quot; is disabled because every staged block is already applied — there&apos;s
              nothing new for it to do. Stage another block in Terraform Lab to run Apply again, or use &quot;Run
              Destroy&quot; to tear down what&apos;s applied.
            </div>
          )}

          {failureMessage && (
            <div className="flex items-start gap-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <div className="min-w-0">
                <p className="font-medium">Pipeline failed</p>
                <p className="mt-0.5 break-words font-mono text-xs text-danger/90">{failureMessage}</p>
              </div>
            </div>
          )}

          {blocks.length === 0 ? (
            <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
              No resource blocks staged yet. Stage some in the Terraform Lab&apos;s Build &amp; Apply mode, then run
              this pipeline to apply them.
            </p>
          ) : (
            <ul className="space-y-1.5">
              {blocks.map((block) => (
                <li
                  key={block.id}
                  className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2 text-sm"
                >
                  <span className="truncate font-mono text-xs">{blockLabel(block)}</span>
                  <Badge variant={block.appliedResourceId ? "success" : "secondary"}>
                    {block.appliedResourceId ? "Applied" : "Planned"}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="pipeline">
        <TabsList>
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="code">Pipeline as Code</TabsTrigger>
          <TabsTrigger value="history">
            Run History
            {runs.length > 0 && (
              <Badge variant="secondary" className="ml-1.5">
                {runs.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pipeline">
          <div>
            <h2 className="mb-2 text-sm font-medium text-muted-foreground">Live pipeline log</h2>
            <LogPanel entries={logs} />
          </div>
        </TabsContent>

        <TabsContent value="code">
          <p className="mb-2 text-xs text-muted-foreground">
            The real Terraform HCL for every block currently staged in Terraform Lab — exactly what &quot;Run
            Pipeline&quot; applies. Stage or remove blocks in Terraform Lab and this regenerates.
          </p>
          <CodeBlock code={stagedTerraform} language="hcl" filename="main.tf" maxHeight="28rem" />
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader className="flex-row items-center gap-2 space-y-0">
              <History className="h-4 w-4 text-muted-foreground" />
              <div>
                <CardTitle>Run History</CardTitle>
                <CardDescription>Every successful apply or destroy run, with full stage logs.</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              {runs.length === 0 ? (
                <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                  No runs yet. Run the pipeline to provision or tear down staged resources.
                </p>
              ) : (
                <ul className="space-y-2">
                  {runs.map((run) => (
                    <li
                      key={run.id}
                      className={cn("flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3")}
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-sm font-medium">run #{run.version}</span>
                          <Badge variant={RUN_TYPE_BADGE_VARIANT[run.runType]}>{RUN_TYPE_LABEL[run.runType]}</Badge>
                          <Badge variant={RUN_STATUS_BADGE_VARIANT[run.status]}>{run.status === "success" ? "Success" : "Failed"}</Badge>
                        </div>
                        <p className="mt-1 truncate text-xs text-muted-foreground">{run.summary}</p>
                        <p className="mt-0.5 text-[11px] text-muted-foreground/70">{formatTimestamp(run.timestamp)}</p>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => setLogsFor(run)}>
                        <ScrollText className="h-3.5 w-3.5" /> View logs
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={logsFor !== null} onOpenChange={(open) => !open && setLogsFor(null)}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{logsFor ? `Run #${logsFor.version} — stage logs` : "Stage logs"}</DialogTitle>
            <DialogDescription>
              {logsFor ? `${RUN_TYPE_LABEL[logsFor.runType]} · ${formatTimestamp(logsFor.timestamp)}` : null}
            </DialogDescription>
          </DialogHeader>
          {logsFor && <StageLogViewer stageLogs={logsFor.stageLogs} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

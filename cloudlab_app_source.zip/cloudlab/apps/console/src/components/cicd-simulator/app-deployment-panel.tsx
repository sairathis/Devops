"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Play,
  RotateCcw,
  AlertTriangle,
  History,
  RefreshCcw,
  Undo2,
  ScrollText,
  Activity,
  CheckCircle2,
  XCircle,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { CodeBlock } from "@/components/code-block";
import { PipelineStepper } from "@/components/cicd-simulator/pipeline-stepper";
import { LogPanel, type LogEntry, type LogTone } from "@/components/cicd-simulator/log-panel";
import { AppCodeEditor } from "@/components/cicd-simulator/app-code-editor";
import { StageLogViewer } from "@/components/cicd-simulator/stage-log-viewer";
import { generatePipelineCode, PROVIDER_OPTIONS, type CicdProvider } from "@/lib/cicd/pipeline-codegen";
import {
  PIPELINE_STAGES,
  DEPLOY_TARGET_FLAVORS,
  DEPLOY_TARGET_OPTIONS,
  type StageStatus,
  type DeployTarget,
} from "@/components/cicd-simulator/pipeline-config";
import { runTests, FUNCTION_NAME } from "@/components/cicd-simulator/sample-app";
import { useProgressStore } from "@/store/progress-store";
import {
  useCicdSimulatorStore,
  type DeploymentEntry,
  type DeploymentStatus,
  type StageLogGroup,
} from "@/store/cicd-simulator-store";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import type { SimLogLevel } from "@/lib/console-sim/types";
import { runEndpointTest } from "@/lib/console-sim/endpoint-test";
import { testableKind } from "@/lib/cloudlab/test-actions";
import { RealTestPanel } from "@/components/gcp-console/real-test-panel";
import { useActivityLogStore } from "@/store/activity-log-store";
import { cn } from "@/lib/utils";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function randomBetween(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

let logIdCounter = 0;
function nextLogId() {
  logIdCounter += 1;
  return `log-${logIdCounter}`;
}

const DEPLOY_STATUS_BADGE_VARIANT: Record<DeploymentStatus, "success" | "danger" | "warning"> = {
  success: "success",
  failed: "danger",
  "rolled-back": "warning",
};

const DEPLOY_STATUS_LABEL: Record<DeploymentStatus, string> = {
  success: "Success",
  failed: "Failed",
  "rolled-back": "Rolled back",
};

const DEPLOY_TARGET_BADGE_VARIANT: Record<DeployTarget, "info" | "secondary" | "warning"> = {
  "cloud-run": "info",
  gke: "secondary",
  "compute-engine": "warning",
};

// Radix <Select.Item> rejects an empty-string value, so "no resource picked" needs a sentinel.
const NO_TARGET = "__none__";
const TARGET_RESOURCE_TYPES = ["vm", "mig", "gke"];

function simLevelToTone(level: SimLogLevel): LogTone {
  switch (level) {
    case "error":
      return "error";
    case "success":
      return "success";
    case "command":
      return "muted";
    default:
      return "info";
  }
}

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AppDeploymentPanel() {
  const addXp = useProgressStore((s) => s.addXp);

  const code = useCicdSimulatorStore((s) => s.code);
  const setCode = useCicdSimulatorStore((s) => s.setCode);
  const deployments = useCicdSimulatorStore((s) => s.deployments);
  const recordDeployment = useCicdSimulatorStore((s) => s.recordDeployment);
  const rollbackTo = useCicdSimulatorStore((s) => s.rollbackTo);
  const resetToDefault = useCicdSimulatorStore((s) => s.resetToDefault);
  const deploySource = useCicdSimulatorStore((s) => s.deploySource);
  const clearDeploySource = useCicdSimulatorStore((s) => s.clearDeploySource);

  const resources = useGcpConsoleStore((s) => s.resources);

  const [target, setTarget] = React.useState<DeployTarget>("cloud-run");
  const [provider, setProvider] = React.useState<CicdProvider>("cloudbuild");
  const [targetResourceId, setTargetResourceId] = React.useState<string>(NO_TARGET);
  const [statuses, setStatuses] = React.useState<StageStatus[]>(() => PIPELINE_STAGES.map(() => "pending"));
  const [logs, setLogs] = React.useState<LogEntry[]>([]);
  const [running, setRunning] = React.useState(false);
  const [failedIndex, setFailedIndex] = React.useState<number | null>(null);
  const [failureMessage, setFailureMessage] = React.useState<string | null>(null);
  // Guards against duplicate/overlapping runs from double-clicks.
  const runTokenRef = React.useRef(0);
  // Guards against awarding XP more than once per successful run. Previously
  // this was a discarded useState value whose setter's functional-updater
  // callback smuggled in a call to addXp() (a different Zustand store's
  // setter) as a side effect -- React runs that updater during this
  // component's own render/reconciliation pass, and since Topbar also
  // subscribes to the progress store, that produced a real
  // "Cannot update a component (Topbar) while rendering a different
  // component (AppDeploymentPanel)" warning. A plain ref needs no store
  // interaction at all and the addXp() call below runs as an ordinary
  // statement instead of hidden inside a state updater.
  const hasEarnedXpRef = React.useRef(false);
  // Per-stage log groups for the run in progress — persists across a retry-from-failed-stage
  // so a run that succeeds after a retry still records every earlier stage's logs.
  const stageGroupsRef = React.useRef<StageLogGroup[]>([]);
  const [logsFor, setLogsFor] = React.useState<DeploymentEntry | null>(null);
  const [testingFor, setTestingFor] = React.useState<DeploymentEntry | null>(null);

  const targetResourceOptions = React.useMemo(
    () => resources.filter((r) => TARGET_RESOURCE_TYPES.includes(r.type)),
    [resources],
  );

  const appendLog = React.useCallback((text: string, tone: LogEntry["tone"]) => {
    setLogs((prev) => [...prev, { id: nextLogId(), text, tone }]);
  }, []);

  const runPipeline = React.useCallback(
    async (startIndex: number) => {
      const myToken = ++runTokenRef.current;
      setRunning(true);
      setFailureMessage(null);
      setFailedIndex(null);
      setStatuses((prev) => prev.map((s, i) => (i < startIndex ? s : "pending")));

      const freshGroups = (): StageLogGroup[] =>
        PIPELINE_STAGES.map((s) => ({ stageId: s.id, label: s.label, status: "skipped" as const, lines: [] }));

      if (startIndex === 0) {
        setLogs([]);
        stageGroupsRef.current = freshGroups();
        appendLog("Starting pipeline run for commit 4f2a9c1 on branch main...", "muted");
      } else {
        // Keep the already-recorded groups for stages before the retry point; reset the rest.
        const base = stageGroupsRef.current.length === PIPELINE_STAGES.length ? stageGroupsRef.current : freshGroups();
        stageGroupsRef.current = base.map((g, i) => (i < startIndex ? g : freshGroups()[i]));
        appendLog(`Retrying from stage "${PIPELINE_STAGES[startIndex].label}"...`, "muted");
      }

      const streamLines = async (
        lines: string[],
        totalMs: number,
        logLine: (text: string, tone: LogEntry["tone"]) => void,
      ): Promise<boolean> => {
        const perLineMs = Math.max(150, Math.floor(totalMs / (lines.length + 1)));
        for (const line of lines) {
          await sleep(perLineMs);
          if (runTokenRef.current !== myToken) return false;
          logLine(line, "info");
        }
        await sleep(Math.max(0, totalMs - perLineMs * lines.length));
        return runTokenRef.current === myToken;
      };

      for (let i = startIndex; i < PIPELINE_STAGES.length; i++) {
        if (runTokenRef.current !== myToken) return; // a newer run superseded this one
        const stage = PIPELINE_STAGES[i];

        const group: StageLogGroup = { stageId: stage.id, label: stage.label, status: "skipped", lines: [] };
        stageGroupsRef.current[i] = group;

        const logLine = (text: string, tone: LogEntry["tone"]) => {
          appendLog(text, tone);
          group.lines.push({ id: `${stage.id}-${group.lines.length}`, text, tone });
        };

        const failStage = (message: string) => {
          logLine(message, "error");
          group.status = "failed";
          setStatuses((prev) => prev.map((s, idx) => (idx === i ? "failed" : s)));
          setFailedIndex(i);
          setFailureMessage(message);
          setRunning(false);
          useActivityLogStore.getState().logActivity({
            actor: "App Deployment pipeline",
            method: "app.pipeline.run",
            resourceType: targetResourceId !== NO_TARGET ? resources.find((r) => r.id === targetResourceId)?.type : undefined,
            resourceName: targetResourceId !== NO_TARGET ? resources.find((r) => r.id === targetResourceId)?.name : DEPLOY_TARGET_FLAVORS[target].label,
            outcome: "failure",
            detail: `${stage.label} stage failed: ${message}`,
            source: "app-pipeline",
          });
        };

        const succeedStage = (message: string) => {
          logLine(message, "success");
          group.status = "success";
          setStatuses((prev) => prev.map((s, idx) => (idx === i ? "success" : s)));
        };

        setStatuses((prev) => prev.map((s, idx) => (idx === i ? "running" : s)));
        logLine(`Stage started: ${stage.label}`, "muted");

        const totalMs = randomBetween(stage.minMs, stage.maxMs);

        // --- Build: parse the user's edited source for real before ever rolling dice. ---
        if (stage.id === "build") {
          const ok = await streamLines(stage.runningLog, totalMs, logLine);
          if (!ok) return;

          try {
            new Function(code);
          } catch (err) {
            const detail = err instanceof Error ? err.message : String(err);
            failStage(`FAIL: Build failed — the app source does not parse (${detail})`);
            return;
          }

          const failed = Math.random() < stage.failChance;
          if (failed) {
            const message =
              stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ??
              `FAIL: ${stage.label} failed unexpectedly`;
            failStage(message);
            return;
          }
          succeedStage(stage.successLog);
          continue;
        }

        // --- Unit Tests: actually execute the user's edited code against real test cases. ---
        if (stage.id === "unit-tests") {
          const ok = await streamLines(stage.runningLog, totalMs, logLine);
          if (!ok) return;

          const results = runTests(code);
          for (const result of results) {
            if (runTokenRef.current !== myToken) return;
            const line = result.passed
              ? `PASS: ${result.description}`
              : `FAIL: ${result.description}${result.error ? ` — ${result.error}` : ""}`;
            logLine(line, result.passed ? "success" : "error");
            await sleep(160);
          }

          const failing = results.find((r) => !r.passed);
          if (failing) {
            failStage(
              `FAIL: unit tests failed — ${failing.description}${failing.error ? ` (${failing.error})` : ""}`,
            );
            return;
          }
          succeedStage(`Tests complete — ${results.length} passed, 0 failed.`);
          continue;
        }

        // --- Deploy: flavor the log lines by the chosen target, keep the random outcome. ---
        if (stage.id === "deploy") {
          const flavor = DEPLOY_TARGET_FLAVORS[target];
          const ok = await streamLines(flavor.runningLog, totalMs, logLine);
          if (!ok) return;

          const failed = Math.random() < stage.failChance;
          if (failed) {
            const message =
              flavor.failureLogPool[Math.floor(Math.random() * flavor.failureLogPool.length)] ??
              `FAIL: Deploy to ${flavor.label} failed unexpectedly`;
            failStage(message);
            return;
          }
          succeedStage(flavor.successLog);
          continue;
        }

        // --- Everything else (Commit, Push, Smoke Test): unchanged lightweight randomness. ---
        const ok = await streamLines(stage.runningLog, totalMs, logLine);
        if (!ok) return;

        const failed = Math.random() < stage.failChance;
        if (failed) {
          const message =
            stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ??
            `FAIL: ${stage.label} failed unexpectedly`;
          failStage(message);
          return;
        }
        succeedStage(stage.successLog);
      }

      appendLog("Pipeline finished — all stages succeeded.", "success");
      setRunning(false);
      setFailedIndex(null);

      recordDeployment({
        target,
        status: "success",
        commitMessage: `Update ${FUNCTION_NAME} logic`,
        codeSnapshot: code,
        stageLogs: stageGroupsRef.current,
        targetResourceId: targetResourceId === NO_TARGET ? undefined : targetResourceId,
      });
      useActivityLogStore.getState().logActivity({
        actor: "App Deployment pipeline",
        method: "app.pipeline.run",
        resourceType: targetResourceId !== NO_TARGET ? resources.find((r) => r.id === targetResourceId)?.type : undefined,
        resourceName: targetResourceId !== NO_TARGET ? resources.find((r) => r.id === targetResourceId)?.name : DEPLOY_TARGET_FLAVORS[target].label,
        outcome: "success",
        detail: "Pipeline finished — all stages succeeded.",
        source: "app-pipeline",
      });
      toast.success("Deployment recorded", {
        description: `${DEPLOY_TARGET_FLAVORS[target].label} is now serving the new revision.`,
      });
      // A pipeline actually ran — the Docker/Kubernetes handoff banner (if any) has done its job.
      clearDeploySource();

      if (!hasEarnedXpRef.current) {
        hasEarnedXpRef.current = true;
        addXp(15);
      }
    },
    [appendLog, addXp, code, target, targetResourceId, resources, recordDeployment, clearDeploySource],
  );

  const handleRun = () => {
    void runPipeline(0);
  };

  const handleRetry = () => {
    if (failedIndex === null) return;
    void runPipeline(failedIndex);
  };

  const handleRollback = (deployment: DeploymentEntry) => {
    rollbackTo(deployment.id);
    toast.success(`Rolled back to v${deployment.version}`, {
      description: "The editor now shows the code from that deployment.",
    });
  };

  const handleResetApp = () => {
    resetToDefault();
    toast.success("Reset to default app + history cleared");
  };

  const latestDeploymentId = deployments[0]?.id;
  const pipelineCode = React.useMemo(() => generatePipelineCode(provider, target), [provider, target]);

  const testResource = testingFor?.targetResourceId
    ? resources.find((r) => r.id === testingFor.targetResourceId)
    : undefined;
  const testResult = testingFor ? runEndpointTest(testResource) : null;

  return (
    <div className="space-y-5">
      {deploySource && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start justify-between gap-3 rounded-lg border border-info/40 bg-info/10 p-3 text-sm text-info"
        >
          <div className="min-w-0">
            <p className="font-medium">
              Deploying: {deploySource.summary} — from {deploySource.kind === "docker" ? "Docker Lab" : "Kubernetes Lab"}
            </p>
            <p className="mt-0.5 text-xs text-info/80">
              Run the pipeline below to ship it, or dismiss this if you&apos;re deploying something else.
            </p>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={clearDeploySource}>
            <X className="h-3.5 w-3.5" />
          </Button>
        </motion.div>
      )}

      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp}>
        <Card>
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
            <div>
              <CardTitle>Pipeline</CardTitle>
              <CardDescription>Commit → Build → Unit Tests → Push → Deploy → Smoke Test</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select value={provider} onValueChange={(v) => setProvider(v as CicdProvider)} disabled={running}>
                <SelectTrigger className="w-[210px]">
                  <SelectValue placeholder="CI provider" />
                </SelectTrigger>
                <SelectContent>
                  {PROVIDER_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={target} onValueChange={(v) => setTarget(v as DeployTarget)} disabled={running}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="Deploy target" />
                </SelectTrigger>
                <SelectContent>
                  {DEPLOY_TARGET_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      Deploy target: {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {failedIndex !== null && !running && (
                <Button variant="outline" onClick={handleRetry}>
                  <RotateCcw className="h-4 w-4" /> Retry from failed stage
                </Button>
              )}
              <Button onClick={handleRun} disabled={running}>
                <Play className="h-4 w-4" /> {running ? "Running..." : "Run Pipeline"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <PipelineStepper statuses={statuses} />

            {failureMessage && (
              <div className="flex items-start gap-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <div className="min-w-0">
                  <p className="font-medium">Pipeline failed</p>
                  <p className="mt-0.5 break-words font-mono text-xs text-danger/90">{failureMessage}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp}>
        <Tabs defaultValue="pipeline">
          <TabsList>
            <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
            <TabsTrigger value="history">
              Deployment History
              {deployments.length > 0 && (
                <Badge variant="secondary" className="ml-1.5">
                  {deployments.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pipeline" className="space-y-5">
            <div className="grid gap-5 lg:grid-cols-2">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-medium text-muted-foreground">
                    App source — <code className="font-mono">{FUNCTION_NAME}()</code>
                  </h2>
                  <Button variant="ghost" size="sm" onClick={handleResetApp} disabled={running}>
                    <RefreshCcw className="h-3.5 w-3.5" /> Reset app
                  </Button>
                </div>
                <AppCodeEditor value={code} onChange={setCode} filename="shipping-calculator.js" minHeight="18rem" />

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
                    Deploy onto (optional) — bind this deployment to a real resource
                  </label>
                  <Select value={targetResourceId} onValueChange={setTargetResourceId} disabled={running}>
                    <SelectTrigger>
                      <SelectValue placeholder="No target resource" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NO_TARGET}>No target resource</SelectItem>
                      {targetResourceOptions.map((r) => (
                        <SelectItem key={r.id} value={r.id}>
                          {r.name} ({r.type.toUpperCase()})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="mt-1.5 text-[11px] text-muted-foreground">
                    Pick a VM, MIG, or GKE cluster you created in the GCP Console to test this deployment&apos;s
                    health against real platform state afterward.
                  </p>
                </div>
              </div>
              <div>
                <h2 className="mb-2 text-sm font-medium text-muted-foreground">
                  Pipeline as code — {PROVIDER_OPTIONS.find((p) => p.value === provider)?.label}
                </h2>
                <p className="mb-2 text-[11px] text-muted-foreground">
                  Every stage&apos;s real shell commands, generated for the selected provider and deploy target. Switch
                  either dropdown above and this regenerates — a GKE target adds the Docker build + Artifact Registry
                  push stages and a kubectl rollout; Cloud Run and Compute Engine each get their own required deploy
                  stage instead.
                </p>
                <CodeBlock code={pipelineCode.code} language={pipelineCode.language} filename={pipelineCode.filename} maxHeight="18rem" />
              </div>
            </div>

            <div>
              <h2 className="mb-2 text-sm font-medium text-muted-foreground">Live build log</h2>
              <LogPanel entries={logs} />
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader className="flex-row items-center gap-2 space-y-0">
                <History className="h-4 w-4 text-muted-foreground" />
                <div>
                  <CardTitle>Deployment History</CardTitle>
                  <CardDescription>Every successful pipeline run ships a new version — roll back any time.</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                {deployments.length === 0 ? (
                  <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                    No deployments yet. Run the pipeline to completion to ship the first version.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {deployments.map((d) => {
                      const isCurrent = d.id === latestDeploymentId;
                      return (
                        <li
                          key={d.id}
                          className={cn(
                            "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3",
                            isCurrent && "border-primary/40 bg-primary/5",
                          )}
                        >
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-mono text-sm font-medium">v{d.version}</span>
                              <Badge variant={DEPLOY_STATUS_BADGE_VARIANT[d.status]}>
                                {DEPLOY_STATUS_LABEL[d.status]}
                              </Badge>
                              <Badge variant={DEPLOY_TARGET_BADGE_VARIANT[d.target]}>
                                {DEPLOY_TARGET_FLAVORS[d.target].label}
                              </Badge>
                              {isCurrent && <Badge variant="outline">Current</Badge>}
                            </div>
                            <p className="mt-1 truncate text-xs text-muted-foreground">{d.commitMessage}</p>
                            <p className="mt-0.5 text-[11px] text-muted-foreground/70">{formatTimestamp(d.timestamp)}</p>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <Button variant="ghost" size="sm" onClick={() => setLogsFor(d)}>
                              <ScrollText className="h-3.5 w-3.5" /> View logs
                            </Button>
                            {d.targetResourceId && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  const target = resources.find((r) => r.id === d.targetResourceId);
                                  const result = runEndpointTest(target);
                                  useActivityLogStore.getState().logActivity({
                                    actor: "App Deployment pipeline",
                                    method: "app.testEndpoint",
                                    resourceType: target?.type,
                                    resourceName: target?.name,
                                    outcome: result.ok ? "success" : "failure",
                                    detail: result.ok
                                      ? `HTTP ${result.statusCode} OK (${result.latencyMs}ms)`
                                      : (result.reason ?? "Endpoint test failed."),
                                    source: "app-pipeline",
                                  });
                                  setTestingFor(d);
                                }}
                              >
                                <Activity className="h-3.5 w-3.5" /> Test endpoint
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={isCurrent}
                              onClick={() => handleRollback(d)}
                            >
                              <Undo2 className="h-3.5 w-3.5" /> Rollback to this version
                            </Button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>

      <Dialog open={logsFor !== null} onOpenChange={(open) => !open && setLogsFor(null)}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{logsFor ? `Deployment v${logsFor.version} — stage logs` : "Stage logs"}</DialogTitle>
            <DialogDescription>
              {logsFor
                ? `${DEPLOY_TARGET_FLAVORS[logsFor.target].label} · ${formatTimestamp(logsFor.timestamp)}`
                : null}
            </DialogDescription>
          </DialogHeader>
          {logsFor && <StageLogViewer stageLogs={logsFor.stageLogs} />}
        </DialogContent>
      </Dialog>

      <Dialog open={testingFor !== null} onOpenChange={(open) => !open && setTestingFor(null)}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {testingFor ? `Test endpoint — v${testingFor.version}` : "Test endpoint"}
            </DialogTitle>
            <DialogDescription>
              {testResource ? `Target: ${testResource.name} (${testResource.type.toUpperCase()})` : "Target resource not found."}
            </DialogDescription>
          </DialogHeader>
          {testResult && (
            <div className="space-y-4">
              {testResult.ok ? (
                <div className="flex items-start gap-3 rounded-lg border border-success/40 bg-success/10 p-3 text-sm text-success">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  <div className="min-w-0">
                    <p className="font-medium">HTTP 200 OK — {testResult.latencyMs}ms</p>
                    <p className="mt-0.5 text-xs text-success/90">
                      {testResource?.name} is running and served the request successfully.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <div className="min-w-0">
                    <p className="font-medium">
                      {testResult.statusCode > 0 ? `HTTP ${testResult.statusCode}` : "Request timed out"} —{" "}
                      {testResult.latencyMs}ms
                    </p>
                    <p className="mt-0.5 break-words font-mono text-xs text-danger/90">{testResult.reason}</p>
                    {testResult.hint && <p className="mt-1.5 text-xs text-danger/80">{testResult.hint}</p>}
                  </div>
                </div>
              )}

              <div>
                <h3 className="mb-2 text-xs font-medium text-muted-foreground">
                  Recent log lines from {testResource?.name ?? "the target resource"}
                </h3>
                <LogPanel
                  entries={testResult.tail.map((entry) => ({
                    id: entry.id,
                    text: entry.message,
                    tone: simLevelToTone(entry.level),
                  }))}
                />
              </div>

              {testResource && testableKind(testResource.type) && (
                <div className="border-t border-border pt-4">
                  <h3 className="mb-2 text-xs font-medium text-muted-foreground">
                    Post-deploy real test — {testResource.name} is one of the types CloudLab can genuinely
                    provision, so run an actual command / invoke / object round-trip against it, not just the
                    simulated result above.
                  </h3>
                  <RealTestPanel
                    resourceType={testResource.type}
                    cloudlabResourceId={testResource.cloudlabResourceId}
                    cloudlabReady={testResource.cloudlabStatus === "ready"}
                  />
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

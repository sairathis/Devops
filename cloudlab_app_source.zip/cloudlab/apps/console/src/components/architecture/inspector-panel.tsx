"use client";
import * as React from "react";
import { ExternalLink, DollarSign, Lightbulb, Workflow } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { ConfigForm } from "@/components/architecture/config-form";
import { NodeQuiz } from "@/components/architecture/node-quiz";
import { CodeBlock } from "@/components/code-block";
import { useArchitectureStore } from "@/store/architecture-store";
import { getResourceDef } from "@/lib/gcp";
import { generateTerraform } from "@/lib/terraform/generate";
import { formatCurrency } from "@/lib/utils";
import { RealTestPanel } from "@/components/gcp-console/real-test-panel";

export function InspectorPanel() {
  const nodes = useArchitectureStore((s) => s.nodes);
  const edges = useArchitectureStore((s) => s.edges);
  const selectedNodeId = useArchitectureStore((s) => s.selectedNodeId);
  const updateNodeConfig = useArchitectureStore((s) => s.updateNodeConfig);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId);
  const def = selectedNode ? getResourceDef(selectedNode.data.resourceType) : undefined;

  const tf = React.useMemo(() => generateTerraform(nodes, edges), [nodes, edges]);

  if (!selectedNode || !def) {
    return (
      <div className="flex h-full w-96 shrink-0 flex-col border-l border-border bg-card/40">
        <div className="border-b border-border p-4">
          <h3 className="text-sm font-semibold">Project Terraform</h3>
          <p className="text-xs text-muted-foreground">
            {nodes.length} resource{nodes.length === 1 ? "" : "s"} · select one to configure it
          </p>
        </div>
        <ScrollArea className="flex-1 p-4">
          <CodeBlock code={tf.full} language="hcl" filename="main.tf" maxHeight="calc(100svh - 220px)" />
        </ScrollArea>
      </div>
    );
  }

  const nodeCost = def.estimateMonthlyCost(selectedNode.data.config);

  return (
    <div className="flex h-full w-96 shrink-0 flex-col border-l border-border bg-card/40">
      <div className="flex items-center gap-3 border-b border-border p-4">
        <ResourceIcon type={def.type} color={def.color} size={18} className="h-9 w-9" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{selectedNode.data.label}</p>
          <p className="truncate text-xs text-muted-foreground">{def.description}</p>
        </div>
      </div>

      <Tabs defaultValue="config" className="flex flex-1 flex-col overflow-hidden">
        <TabsList className="mx-4 mt-3 grid grid-cols-5">
          <TabsTrigger value="config">Config</TabsTrigger>
          <TabsTrigger value="terraform">Terraform</TabsTrigger>
          <TabsTrigger value="test">Test</TabsTrigger>
          <TabsTrigger value="learn">Learn</TabsTrigger>
          <TabsTrigger value="fix">Fix</TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1">
          <TabsContent value="config" className="m-0 p-4">
            <div className="mb-4 flex items-center justify-between rounded-lg border border-border px-3 py-2">
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <DollarSign className="h-3.5 w-3.5" /> Est. monthly cost
              </span>
              <span className="text-sm font-semibold">{formatCurrency(nodeCost)}</span>
            </div>
            <ConfigForm
              fields={def.configFields}
              config={selectedNode.data.config}
              onChange={(patch) => updateNodeConfig(selectedNode.id, patch)}
              resources={nodes
                .filter((n) => n.id !== selectedNode.id)
                .map((n) => ({ id: n.id, type: n.data.resourceType, name: n.data.label }))}
            />
          </TabsContent>

          <TabsContent value="terraform" className="m-0 p-4">
            <div className="mb-3 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Workflow className="h-3.5 w-3.5" /> Resource type: {def.terraformResourceType}
            </div>
            <CodeBlock
              code={tf.perNode[selectedNode.id] ?? ""}
              language="hcl"
              filename={`${def.terraformResourceType}.tf`}
            />
          </TabsContent>

          <TabsContent value="test" className="m-0 p-4">
            <RealTestPanel
              resourceType={selectedNode.data.resourceType}
              cloudlabResourceId={selectedNode.data.cloudlabResourceId}
              cloudlabReady={selectedNode.data.provisionStatus === "ready"}
            />
          </TabsContent>

          <TabsContent value="learn" className="m-0 space-y-4 p-4">
            <div className="rounded-lg border border-border p-3">
              <p className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Lightbulb className="h-3.5 w-3.5 text-gcp-yellow" /> What&apos;s happening here
              </p>
              <p className="text-sm leading-relaxed">{def.learningNotes}</p>
            </div>
            <a
              href={def.docsUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-xs text-primary hover:underline"
            >
              Read the official GCP docs <ExternalLink className="h-3 w-3" />
            </a>
            <NodeQuiz def={def} />
          </TabsContent>

          <TabsContent value="fix" className="m-0 p-4">
            <p className="mb-3 text-xs text-muted-foreground">Common issues with {def.label} and how to resolve them.</p>
            <Accordion type="single" collapsible>
              {def.troubleshooting.map((t, i) => (
                <AccordionItem key={i} value={String(i)}>
                  <AccordionTrigger className="text-sm">{t.issue}</AccordionTrigger>
                  <AccordionContent className="space-y-2">
                    <div className="text-sm">
                      <Badge variant="danger" className="mr-1.5">Cause</Badge>
                      {t.cause}
                    </div>
                    <div className="text-sm">
                      <Badge variant="success" className="mr-1.5">Fix</Badge>
                      {t.fix}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}

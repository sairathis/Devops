"use client";
import * as React from "react";
import { toast } from "sonner";
import {
  LayoutGrid, Play, Pause, Download, Trash2, Save, FolderOpen, ChevronDown, ImageDown, FileImage, FileText,
  Rocket, Loader2, CheckCircle2, XCircle, AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useArchitectureStore } from "@/store/architecture-store";
import { useReactFlow } from "reactflow";
import { autoArrange } from "@/lib/architecture/layout";
import { exportCanvasAsPdf, exportCanvasAsPng, exportCanvasAsSvg } from "@/lib/architecture/export";
import { canvasWrapperId } from "@/components/architecture/canvas";
import { EXAMPLE_TEMPLATES } from "@/lib/architecture/examples";
import { useProgressStore } from "@/store/progress-store";
import { useAuthStore } from "@/store/auth-store";
import { isProvisionable, provisionDiagram, type ProvisionOutcome } from "@/lib/cloudlab/provision";

export function ArchitectureToolbar() {
  const nodes = useArchitectureStore((s) => s.nodes);
  const edges = useArchitectureStore((s) => s.edges);
  const setNodes = useArchitectureStore((s) => s.setNodes);
  const clearCanvas = useArchitectureStore((s) => s.clearCanvas);
  const loadExample = useArchitectureStore((s) => s.loadExample);
  const simulationRunning = useArchitectureStore((s) => s.simulationRunning);
  const setSimulationRunning = useArchitectureStore((s) => s.setSimulationRunning);
  const saveProject = useArchitectureStore((s) => s.saveProject);
  const projects = useArchitectureStore((s) => s.projects);
  const loadProject = useArchitectureStore((s) => s.loadProject);
  const updateNodeProvisionState = useArchitectureStore((s) => s.updateNodeProvisionState);
  const addXp = useProgressStore((s) => s.addXp);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const projectId = useAuthStore((s) => s.projectId);

  const { fitView } = useReactFlow();
  const [saveOpen, setSaveOpen] = React.useState(false);
  const [projectName, setProjectName] = React.useState("My Architecture");
  const [exporting, setExporting] = React.useState(false);
  const [provisioning, setProvisioning] = React.useState(false);
  const [provisionResults, setProvisionResults] = React.useState<ProvisionOutcome[] | null>(null);

  const provisionableCount = nodes.filter((n) => isProvisionable(n.data.resourceType)).length;

  const handleProvision = async () => {
    if (!projectId) {
      toast.error("No CloudLab project yet — sign out and back in, or reload the page.");
      return;
    }
    if (provisionableCount === 0) {
      toast.info("Nothing provisionable yet. Add a VPC, Subnet, VM, GKE cluster, Bucket, Cloud SQL, or Artifact Registry node.");
      return;
    }
    setProvisioning(true);
    setProvisionResults(null);
    try {
      const results = await provisionDiagram(projectId, nodes, updateNodeProvisionState);
      setProvisionResults(results);
      const readyCount = results.filter((r) => r.status === "ready").length;
      if (readyCount > 0) {
        addXp(20);
        setModuleProgress("architecture-builder", 70);
      }
      if (readyCount === results.length) {
        toast.success(`Provisioned ${readyCount} resource${readyCount === 1 ? "" : "s"} on CloudLab`);
      } else {
        toast.warning(`${readyCount}/${results.length} provisioned — see details`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Provisioning failed");
    } finally {
      setProvisioning(false);
    }
  };

  const handleAutoArrange = () => {
    if (nodes.length === 0) return;
    setNodes(autoArrange(nodes, edges));
    setTimeout(() => fitView({ padding: 0.3, duration: 400 }), 50);
  };

  const handleExport = async (kind: "png" | "svg" | "pdf") => {
    const el = document.getElementById(canvasWrapperId);
    if (!el || nodes.length === 0) {
      toast.error("Nothing to export yet — add a resource first.");
      return;
    }
    setExporting(true);
    try {
      if (kind === "png") await exportCanvasAsPng(el);
      if (kind === "svg") await exportCanvasAsSvg(el);
      if (kind === "pdf") await exportCanvasAsPdf(el);
      toast.success(`Exported as ${kind.toUpperCase()}`);
    } catch {
      toast.error("Export failed. Try a smaller diagram or a different format.");
    } finally {
      setExporting(false);
    }
  };

  const handleClear = () => {
    if (nodes.length === 0) return;
    if (window.confirm("Clear the entire canvas? This can't be undone.")) {
      clearCanvas();
    }
  };

  const handleSave = () => {
    saveProject(projectName || "Untitled Architecture");
    setSaveOpen(false);
    addXp(15);
    setModuleProgress("architecture-builder", 40);
    toast.success("Architecture saved", { description: `Saved as "${projectName}"` });
  };

  const handleToggleSimulation = () => {
    if (nodes.length < 2) {
      toast.info("Add at least two connected resources to simulate traffic.");
      return;
    }
    setSimulationRunning(!simulationRunning);
  };

  return (
    <div className="flex h-14 items-center gap-2 border-b border-border bg-card/60 px-4">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <FolderOpen className="h-3.5 w-3.5" /> Examples <ChevronDown className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-72">
          <DropdownMenuLabel>Starter architectures</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {EXAMPLE_TEMPLATES.map((t) => (
            <DropdownMenuItem
              key={t.id}
              className="flex-col items-start gap-0.5"
              onSelect={() => {
                loadExample(t.nodes, t.edges);
                setTimeout(() => fitView({ padding: 0.3, duration: 400 }), 50);
                toast.success(`Loaded "${t.label}"`);
              }}
            >
              <span className="text-sm font-medium">{t.label}</span>
              <span className="text-xs text-muted-foreground">{t.description}</span>
            </DropdownMenuItem>
          ))}
          {projects.length > 0 && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Your saved projects</DropdownMenuLabel>
              {projects.map((p) => (
                <DropdownMenuItem key={p.id} onSelect={() => loadProject(p.id)}>
                  {p.name}
                </DropdownMenuItem>
              ))}
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <Button variant="outline" size="sm" onClick={handleAutoArrange}>
        <LayoutGrid className="h-3.5 w-3.5" /> Auto-arrange
      </Button>

      <Button
        variant={simulationRunning ? "default" : "outline"}
        size="sm"
        onClick={handleToggleSimulation}
      >
        {simulationRunning ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
        {simulationRunning ? "Stop simulation" : "Simulate traffic"}
      </Button>

      <div className="mx-1 h-6 w-px bg-border" />

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" disabled={exporting}>
            <Download className="h-3.5 w-3.5" /> Export <ChevronDown className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start">
          <DropdownMenuItem onSelect={() => handleExport("png")}>
            <ImageDown className="h-4 w-4" /> Export as PNG
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => handleExport("svg")}>
            <FileImage className="h-4 w-4" /> Export as SVG
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => handleExport("pdf")}>
            <FileText className="h-4 w-4" /> Export as PDF
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Button variant="outline" size="sm" onClick={() => setSaveOpen(true)}>
        <Save className="h-3.5 w-3.5" /> Save
      </Button>

      <Button variant="ghost" size="sm" onClick={handleClear} className="text-danger hover:text-danger">
        <Trash2 className="h-3.5 w-3.5" /> Clear
      </Button>

      <div className="mx-1 h-6 w-px bg-border" />

      <Button
        size="sm"
        onClick={handleProvision}
        disabled={provisioning}
        className="gap-1.5 bg-success text-white hover:bg-success/90"
      >
        {provisioning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
        Provision to CloudLab
      </Button>

      <div className="ml-auto flex items-center gap-2">
        <Badge variant="secondary">{nodes.length} resources</Badge>
        <Badge variant="secondary">{edges.length} connections</Badge>
        {provisionableCount > 0 && (
          <Badge variant="info">{provisionableCount} provisionable</Badge>
        )}
      </div>

      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save architecture</DialogTitle>
            <DialogDescription>Save this diagram locally so you can reload it later.</DialogDescription>
          </DialogHeader>
          <Input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Project name" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={provisionResults !== null} onOpenChange={(open) => !open && setProvisionResults(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Provisioning results</DialogTitle>
            <DialogDescription>
              These calls went to CloudLab&apos;s real API — each resource below is a real Postgres row and, for
              compute/network types, real Docker state.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-80 space-y-2 overflow-y-auto">
            {provisionResults?.map((r) => (
              <div key={r.nodeId} className="flex items-start gap-2 rounded-lg border border-border p-2.5">
                {r.status === "ready" && <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />}
                {r.status === "failed" && <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-danger" />}
                {r.status === "skipped" && <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />}
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">{r.label}</p>
                  {r.status === "ready" && (
                    <p className="truncate text-xs text-muted-foreground">CloudLab resource id: {r.resourceId}</p>
                  )}
                  {r.error && <p className="text-xs text-muted-foreground">{r.error}</p>}
                </div>
              </div>
            ))}
            {provisionResults?.length === 0 && (
              <p className="text-sm text-muted-foreground">No provisionable resources on this canvas yet.</p>
            )}
          </div>
          <DialogFooter>
            <Button onClick={() => setProvisionResults(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

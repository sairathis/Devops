"use client";
import * as React from "react";
import { ConfigField, ResourceConfig } from "@/types/gcp";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

// Radix <Select.Item> rejects an empty-string value, so "no resource picked" is
// represented with this sentinel in the UI and translated to "" in config.
const NO_REF = "__none__";

export interface RefCandidate {
  id: string;
  type: string;
  name: string;
}

export function ConfigForm({
  fields,
  config,
  onChange,
  resources = [],
}: {
  fields: ConfigField[];
  config: ResourceConfig;
  onChange: (patch: Partial<ResourceConfig>) => void;
  /** Existing resources eligible to be picked by "resource-ref" / "resource-ref-multi" fields. */
  resources?: RefCandidate[];
}) {
  return (
    <div className="flex flex-col gap-4">
      {fields.map((field) => (
        <div key={field.key} className="flex flex-col gap-1.5">
          {field.type !== "boolean" && (
            <Label htmlFor={field.key} className="text-xs text-muted-foreground">
              {field.label}
            </Label>
          )}

          {field.type === "text" && (
            <Input
              id={field.key}
              value={(config[field.key] as string) ?? ""}
              placeholder={field.placeholder}
              onChange={(e) => onChange({ [field.key]: e.target.value })}
            />
          )}

          {field.type === "textarea" && (
            <Textarea
              id={field.key}
              value={(config[field.key] as string) ?? ""}
              placeholder={field.placeholder}
              onChange={(e) => onChange({ [field.key]: e.target.value })}
            />
          )}

          {field.type === "number" && (
            <Input
              id={field.key}
              type="number"
              min={field.min}
              max={field.max}
              value={(config[field.key] as number) ?? 0}
              onChange={(e) => onChange({ [field.key]: Number(e.target.value) })}
            />
          )}

          {field.type === "select" && (
            <Select
              value={(config[field.key] as string) ?? ""}
              onValueChange={(v) => onChange({ [field.key]: v })}
            >
              <SelectTrigger id={field.key}>
                <SelectValue placeholder="Select..." />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          {field.type === "boolean" && (
            <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
              <Label htmlFor={field.key} className="text-xs">
                {field.label}
              </Label>
              <Switch
                id={field.key}
                checked={Boolean(config[field.key])}
                onCheckedChange={(v) => onChange({ [field.key]: v })}
              />
            </div>
          )}

          {field.type === "slider" && (
            <div className="flex items-center gap-3">
              <Slider
                id={field.key}
                min={field.min}
                max={field.max}
                step={field.step ?? 1}
                value={[(config[field.key] as number) ?? field.min ?? 0]}
                onValueChange={([v]) => onChange({ [field.key]: v })}
              />
              <span className="w-10 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                {config[field.key] as number}
              </span>
            </div>
          )}

          {field.type === "tags" && (
            <Input
              id={field.key}
              value={((config[field.key] as string[]) ?? []).join(", ")}
              placeholder={field.placeholder}
              onChange={(e) =>
                onChange({
                  [field.key]: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                })
              }
            />
          )}

          {field.type === "resource-ref" && (() => {
            const candidates = resources.filter((r) => field.refTypes?.includes(r.type));
            const value = (config[field.key] as string) || undefined;
            if (candidates.length === 0) {
              return (
                <p className="rounded-lg border border-dashed border-border px-3 py-2 text-xs text-muted-foreground">
                  No {field.label.toLowerCase()} candidates exist yet — create one first, then come back and create
                  this resource to bind it.
                </p>
              );
            }
            return (
              <>
                <Select
                  value={value ?? NO_REF}
                  onValueChange={(v) => onChange({ [field.key]: v === NO_REF ? "" : v })}
                >
                  <SelectTrigger id={field.key}>
                    <SelectValue placeholder="Not bound" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NO_REF}>Not bound</SelectItem>
                    {candidates.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!value && (
                  <p className="text-[11px] text-amber-600 dark:text-amber-400">
                    Left unbound, this resource won&apos;t be a connected edge in the Architecture Diagram or its
                    Connectivity Test.
                  </p>
                )}
              </>
            );
          })()}

          {field.type === "resource-ref-multi" && (() => {
            const candidates = resources.filter((r) => field.refTypes?.includes(r.type));
            const selected = (config[field.key] as string[]) ?? [];
            if (candidates.length === 0) {
              return (
                <p className="rounded-lg border border-dashed border-border px-3 py-2 text-xs text-muted-foreground">
                  No {field.label.toLowerCase()} candidates exist yet — create one first, then come back and create
                  this resource to bind it.
                </p>
              );
            }
            return (
              <>
                <div className="flex flex-col gap-1.5 rounded-lg border border-border p-2">
                  {candidates.map((c) => (
                    <label key={c.id} className="flex cursor-pointer items-center gap-2 rounded-md px-1.5 py-1 text-sm hover:bg-muted/50">
                      <Checkbox
                        checked={selected.includes(c.id)}
                        onCheckedChange={(checked) =>
                          onChange({
                            [field.key]: checked ? [...selected, c.id] : selected.filter((id) => id !== c.id),
                          })
                        }
                      />
                      {c.name}
                    </label>
                  ))}
                </div>
                {selected.length === 0 && (
                  <p className="text-[11px] text-amber-600 dark:text-amber-400">
                    Left unbound, this resource won&apos;t be a connected edge in the Architecture Diagram or its
                    Connectivity Test.
                  </p>
                )}
              </>
            );
          })()}

          {field.helpText && <p className="text-[11px] text-muted-foreground">{field.helpText}</p>}
        </div>
      ))}
    </div>
  );
}

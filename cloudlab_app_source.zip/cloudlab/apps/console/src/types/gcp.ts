export type ResourceCategory =
  | "networking"
  | "compute"
  | "storage"
  | "database"
  | "containers"
  | "cicd"
  | "security"
  | "messaging";

export type ConfigFieldType =
  | "text"
  | "select"
  | "number"
  | "boolean"
  | "textarea"
  | "tags"
  | "slider"
  | "resource-ref"
  | "resource-ref-multi";

export interface ConfigFieldOption {
  label: string;
  value: string;
}

export interface ConfigField {
  key: string;
  label: string;
  type: ConfigFieldType;
  options?: ConfigFieldOption[];
  min?: number;
  max?: number;
  step?: number;
  placeholder?: string;
  helpText?: string;
  required?: boolean;
  /** For "resource-ref" / "resource-ref-multi": which resource `type`s are valid picks. */
  refTypes?: string[];
}

export type ResourceConfig = Record<string, string | number | boolean | string[]>;

/** Real provisioning state against CloudLab's API -- undefined/"idle" means "not sent yet". */
export type ProvisionStatus = "idle" | "pending" | "creating" | "ready" | "failed" | "skipped";

export interface CanvasNodeData {
  resourceType: string;
  label: string;
  config: ResourceConfig;
  /** Set by the "Provision to CloudLab" flow -- see lib/cloudlab/provision.ts. */
  provisionStatus?: ProvisionStatus;
  /** The real CloudLab resource id once provisioning succeeds. */
  cloudlabResourceId?: string;
  /** Composer only: the real backing `pipeline` resource id auto-created alongside it, needed to clean it up on delete. */
  cloudlabPipelineId?: string;
  /** The real API's error message when provisioning this node failed or was skipped. */
  provisionError?: string;
  [key: string]: unknown;
}

export interface TerraformContext {
  config: ResourceConfig;
  nodeId: string;
  label: string;
  slug: string;
  allNodes: { id: string; type: string; label: string; config: ResourceConfig }[];
  connections: { source: string; target: string }[];
}

export interface GcpResourceDef {
  type: string;
  label: string;
  shortLabel: string;
  category: ResourceCategory;
  color: string;
  description: string;
  learningNotes: string;
  tooltip: string;
  docsUrl: string;
  terraformResourceType: string;
  configFields: ConfigField[];
  defaultConfig: ResourceConfig;
  generateTerraform: (ctx: TerraformContext) => string;
  estimateMonthlyCost: (config: ResourceConfig) => number;
  troubleshooting: { issue: string; cause: string; fix: string }[];
  quiz: { question: string; options: string[]; answerIndex: number; explanation: string; difficulty?: "beginner" | "intermediate" | "advanced" }[];
  validConnectionTargets?: string[];
}

export const CATEGORY_META: Record<ResourceCategory, { label: string; color: string }> = {
  networking: { label: "Networking", color: "gcp-blue" },
  compute: { label: "Compute", color: "gcp-green" },
  storage: { label: "Storage", color: "gcp-yellow" },
  database: { label: "Databases", color: "gcp-red" },
  containers: { label: "Containers", color: "gcp-green" },
  cicd: { label: "CI/CD", color: "gcp-blue" },
  security: { label: "Security", color: "gcp-red" },
  messaging: { label: "Messaging", color: "gcp-yellow" },
};

"use client";

import * as React from "react";
import { Gauge, LayoutDashboard, LineChart, ScrollText, BellRing, Radar, History } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DashboardTab } from "@/components/operations-suite/dashboard-tab";
import { MetricsTab } from "@/components/operations-suite/metrics-tab";
import { LogsExplorerTab } from "@/components/operations-suite/logs-explorer-tab";
import { AlertingTab } from "@/components/operations-suite/alerting-tab";
import { UptimeTab } from "@/components/operations-suite/uptime-tab";
import { ActivityLogTab } from "@/components/operations-suite/activity-log-tab";
import { useProgressStore } from "@/store/progress-store";

export default function OperationsSuitePage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  React.useEffect(() => {
    setModuleProgress("operations-suite", 20);
  }, [setModuleProgress]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
          <Gauge className="h-6 w-6 text-primary" /> Operations Suite
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          A unified observability layer for everything you&apos;ve built — Cloud Monitoring-style dashboards and
          metrics, a cross-resource Logs Explorer, Alerting policies with live-firing incidents, Uptime Checks, and
          an audit-log-style Activity trail. Every number here is derived from your resources&apos; own state in
          this console, not a disconnected random generator — though the metrics themselves (CPU, network, request
          rate) are simulated, not telemetry pulled from real infrastructure, even for the resource types CloudLab
          provisions for real.
        </p>
      </div>

      <Tabs defaultValue="dashboard">
        <TabsList className="mb-5 flex-wrap">
          <TabsTrigger value="dashboard" className="gap-1.5">
            <LayoutDashboard className="h-3.5 w-3.5" /> Dashboard
          </TabsTrigger>
          <TabsTrigger value="metrics" className="gap-1.5">
            <LineChart className="h-3.5 w-3.5" /> Metrics
          </TabsTrigger>
          <TabsTrigger value="logs" className="gap-1.5">
            <ScrollText className="h-3.5 w-3.5" /> Logs Explorer
          </TabsTrigger>
          <TabsTrigger value="alerting" className="gap-1.5">
            <BellRing className="h-3.5 w-3.5" /> Alerting
          </TabsTrigger>
          <TabsTrigger value="uptime" className="gap-1.5">
            <Radar className="h-3.5 w-3.5" /> Uptime Checks
          </TabsTrigger>
          <TabsTrigger value="activity" className="gap-1.5">
            <History className="h-3.5 w-3.5" /> Activity Log
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <DashboardTab />
        </TabsContent>
        <TabsContent value="metrics">
          <MetricsTab />
        </TabsContent>
        <TabsContent value="logs">
          <LogsExplorerTab />
        </TabsContent>
        <TabsContent value="alerting">
          <AlertingTab />
        </TabsContent>
        <TabsContent value="uptime">
          <UptimeTab />
        </TabsContent>
        <TabsContent value="activity">
          <ActivityLogTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

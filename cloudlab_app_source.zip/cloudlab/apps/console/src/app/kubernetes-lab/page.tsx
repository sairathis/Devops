"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { Ship, Rocket, FlaskConical, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DeploymentForm } from "@/components/kubernetes-lab/deployment-form";
import { NetworkForm } from "@/components/kubernetes-lab/network-form";
import { ManifestViewer } from "@/components/kubernetes-lab/manifest-viewer";
import { Topology } from "@/components/kubernetes-lab/topology";
import { ApplySimulator } from "@/components/kubernetes-lab/apply-simulator";
import { PodList } from "@/components/kubernetes-lab/pod-list";
import { Cheatsheet } from "@/components/kubernetes-lab/cheatsheet";
import { Concepts } from "@/components/kubernetes-lab/concepts";
import { generateDeploymentYaml, generateServiceYaml, generateIngressYaml } from "@/components/kubernetes-lab/yaml";
import { DEFAULT_DEPLOYMENT, DEFAULT_SERVICE, DEFAULT_INGRESS } from "@/components/kubernetes-lab/types";
import type { DeploymentConfig, ServiceConfig, IngressConfig } from "@/components/kubernetes-lab/types";
import { useProgressStore } from "@/store/progress-store";
import { useKubernetesLabStore } from "@/store/kubernetes-lab-store";
import { useCicdSimulatorStore } from "@/store/cicd-simulator-store";
import { useAuthStore } from "@/store/auth-store";
import { RealLabPanel, type RealLabStatus } from "@/components/cloudlab/real-lab-panel";
import { RealTestPanel } from "@/components/gcp-console/real-test-panel";
import { ensureK8sLabCluster, deployK8sReal, scaleK8sReal, deleteK8sDeploymentReal, type RealDeploymentResult } from "@/lib/cloudlab/lab-provision";

export default function KubernetesLabPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);
  const setDeploySource = useCicdSimulatorStore((s) => s.setDeploySource);
  const projectId = useAuthStore((s) => s.projectId);
  const router = useRouter();

  const [deployment, setDeployment] = React.useState<DeploymentConfig>(DEFAULT_DEPLOYMENT);
  const [service, setService] = React.useState<ServiceConfig>(DEFAULT_SERVICE);
  const [ingress, setIngress] = React.useState<IngressConfig>(DEFAULT_INGRESS);
  const hasAwardedReplicaXp = React.useRef(false);

  const [realStatus, setRealStatus] = React.useState<RealLabStatus>("idle");
  const [realResult, setRealResult] = React.useState<RealDeploymentResult | null>(null);
  const [realBusy, setRealBusy] = React.useState(false);

  React.useEffect(() => {
    setModuleProgress("kubernetes-lab", 20);
  }, [setModuleProgress]);

  React.useEffect(() => {
    useKubernetesLabStore.getState().resumeStuckStates();
  }, []);

  const handleReplicasChange = React.useCallback(
    (replicas: number) => {
      setDeployment((prev) => (prev.replicas === replicas ? prev : { ...prev, replicas }));
      if (!hasAwardedReplicaXp.current) {
        hasAwardedReplicaXp.current = true;
        addXp(10);
      }
    },
    [addXp],
  );

  const deploymentYaml = React.useMemo(() => generateDeploymentYaml(deployment), [deployment]);
  const serviceYaml = React.useMemo(
    () => generateServiceYaml(deployment.name, service),
    [deployment.name, service],
  );
  const ingressYaml = React.useMemo(
    () => (ingress.enabled ? generateIngressYaml(deployment.name, service, ingress) : null),
    [deployment.name, service, ingress],
  );

  const handleDeployViaCicd = React.useCallback(() => {
    setDeploySource({
      kind: "kubernetes",
      summary: `Deployment ${deployment.name} (${deployment.replicas} replica${deployment.replicas === 1 ? "" : "s"})`,
    });
    router.push("/cicd-simulator");
  }, [deployment.name, deployment.replicas, setDeploySource, router]);

  const handleDeployReal = React.useCallback(async () => {
    if (!projectId) return;
    setRealBusy(true);
    setRealStatus("provisioning");
    setRealResult(null);
    try {
      const cluster = await ensureK8sLabCluster();
      if (!cluster.cloudlabResourceId) {
        setRealStatus("failed");
        setRealResult({ status: "failed", error: cluster.error ?? "Could not provision a real cluster." });
        return;
      }
      const outcome = await deployK8sReal(projectId, cluster.cloudlabResourceId, `${deployment.name}-${Date.now()}`, deployment.replicas);
      setRealResult(outcome.status === "ready" ? { ...outcome, clusterName: outcome.clusterName ?? cluster.clusterName } : outcome);
      setRealStatus(outcome.status === "ready" ? "ready" : "failed");
    } finally {
      setRealBusy(false);
    }
  }, [projectId, deployment.name, deployment.replicas]);

  const handleSyncReplicasReal = React.useCallback(async () => {
    if (!projectId || !realResult?.resourceId) return;
    setRealBusy(true);
    try {
      const outcome = await scaleK8sReal(projectId, realResult.resourceId, deployment.replicas);
      setRealResult(outcome);
      setRealStatus(outcome.status === "ready" ? "ready" : "failed");
    } finally {
      setRealBusy(false);
    }
  }, [projectId, realResult, deployment.replicas]);

  const handleDestroyReal = React.useCallback(async () => {
    if (!projectId || !realResult?.resourceId) return;
    setRealBusy(true);
    try {
      await deleteK8sDeploymentReal(projectId, realResult.resourceId);
      setRealStatus("idle");
      setRealResult(null);
    } finally {
      setRealBusy(false);
    }
  }, [projectId, realResult]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-6 flex flex-wrap items-start justify-between gap-3"
      >
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <Ship className="h-6 w-6 text-gcp-blue" />
            Kubernetes Lab
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Configure Kubernetes workloads and see the manifests and topology come to life.
          </p>
        </div>
        <Button variant="outline" onClick={handleDeployViaCicd} className="shrink-0">
          <Rocket className="h-4 w-4" /> Deploy via CI/CD Pipeline
        </Button>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-5">
          <DeploymentForm value={deployment} onChange={setDeployment} onReplicasChange={handleReplicasChange} />
          <NetworkForm service={service} onServiceChange={setService} ingress={ingress} onIngressChange={setIngress} />
        </div>
        <div className="space-y-5">
          <Topology name={deployment.name} replicas={deployment.replicas} service={service} ingress={ingress} />
          <ManifestViewer deploymentYaml={deploymentYaml} serviceYaml={serviceYaml} ingressYaml={ingressYaml} />
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1fr]">
        <ApplySimulator
          deploymentName={deployment.name}
          replicas={deployment.replicas}
          ingressEnabled={ingress.enabled}
        />
        <PodList deploymentName={deployment.name} />
      </div>

      <div className="mt-8">
        <div className="mb-3">
          <h2 className="text-lg font-semibold tracking-tight">Deploy for real</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            The simulation above is instant and side-effect-free so the manifest/topology lesson stays clear. This
            creates a genuine k8s cluster and deployment on CloudLab (Milestone 6) — real per-pod Docker containers,
            a real replica count, real scaling.
          </p>
        </div>
        <RealLabPanel
          title="Real cluster + deployment"
          description="Backed by CloudLab's k8s_cluster / k8s_deployment resources — real Docker containers per pod."
          status={realStatus}
          error={realResult?.status === "failed" ? realResult.error : undefined}
          facts={
            realResult?.status === "ready"
              ? [
                  { label: "Cluster", value: realResult.clusterName ?? "—" },
                  { label: "Replicas requested", value: String(realResult.replicas ?? deployment.replicas) },
                  { label: "Real pod containers running", value: String(realResult.podContainerIds?.length ?? 0) },
                ]
              : undefined
          }
        >
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={handleDeployReal} disabled={realBusy || realStatus === "provisioning"} className="gap-1.5">
              {realBusy ? "Working…" : realStatus === "ready" ? "Redeploy for real" : "Deploy for real"}
            </Button>
            {realStatus === "ready" && realResult?.resourceId && (
              <>
                <Button size="sm" variant="outline" onClick={handleSyncReplicasReal} disabled={realBusy} className="gap-1.5">
                  Sync to {deployment.replicas} replica{deployment.replicas === 1 ? "" : "s"} for real
                </Button>
                <Button size="sm" variant="outline" onClick={handleDestroyReal} disabled={realBusy} className="gap-1.5">
                  <Trash2 className="h-3.5 w-3.5" /> Delete real deployment
                </Button>
              </>
            )}
          </div>
          {realStatus === "ready" && realResult?.resourceId && projectId && (
            <div className="mt-3 border-t border-border pt-3">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <FlaskConical className="h-3.5 w-3.5" /> Run a real test against this deployment
              </p>
              <RealTestPanel resourceType="k8s_deployment" cloudlabResourceId={realResult.resourceId} cloudlabReady />
            </div>
          )}
        </RealLabPanel>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Cheatsheet />
        <Concepts />
      </div>
    </div>
  );
}

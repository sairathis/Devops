"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Rocket, FlaskConical, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";
import { DockerfileForm } from "@/components/docker-lab/dockerfile-form";
import { BuildSimulator } from "@/components/docker-lab/build-simulator";
import { ImageLayers } from "@/components/docker-lab/image-layers";
import { DockerCheatsheet } from "@/components/docker-lab/cheatsheet";
import { RunSimulator } from "@/components/docker-lab/run-simulator";
import { ContainerList } from "@/components/docker-lab/container-list";
import { useDockerfileBuilder } from "@/components/docker-lab/use-dockerfile-builder";
import { buildDockerfileLines, generateDockerfile } from "@/components/docker-lab/dockerfile-config";
import { useProgressStore } from "@/store/progress-store";
import { useDockerLabStore } from "@/store/docker-lab-store";
import { useCicdSimulatorStore } from "@/store/cicd-simulator-store";
import { useAuthStore } from "@/store/auth-store";
import { RealLabPanel, type RealLabStatus } from "@/components/cloudlab/real-lab-panel";
import { RealTestPanel } from "@/components/gcp-console/real-test-panel";
import { ensureDockerLabRegistry, buildImageReal, deleteImageReal, type RealImageResult } from "@/lib/cloudlab/lab-provision";

export default function DockerLabPage() {
  const builder = useDockerfileBuilder();
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);
  const setDeploySource = useCicdSimulatorStore((s) => s.setDeploySource);
  const projectId = useAuthStore((s) => s.projectId);
  const router = useRouter();
  const [builtOnce, setBuiltOnce] = React.useState(false);

  const [realStatus, setRealStatus] = React.useState<RealLabStatus>("idle");
  const [realResult, setRealResult] = React.useState<RealImageResult | null>(null);
  const [realBusy, setRealBusy] = React.useState(false);

  React.useEffect(() => {
    setModuleProgress("docker-lab", 20);
  }, [setModuleProgress]);

  React.useEffect(() => {
    useDockerLabStore.getState().resumeStuckStates();
  }, []);

  const lines = React.useMemo(() => buildDockerfileLines(builder.config), [builder.config]);
  const dockerfile = React.useMemo(() => generateDockerfile(builder.config), [builder.config]);

  const handleFirstBuild = React.useCallback(() => {
    addXp(10);
  }, [addXp]);

  const handleBuildComplete = React.useCallback(() => {
    setBuiltOnce(true);
  }, []);

  const handleDeployViaCicd = React.useCallback(() => {
    const image = builder.config.baseImage.trim() || "node:20-slim";
    const port = builder.config.exposePort.trim();
    setDeploySource({
      kind: "docker",
      summary: `Docker image built from ${image}${port ? ` (exposes port ${port})` : ""}`,
    });
    router.push("/cicd-simulator");
  }, [builder.config.baseImage, builder.config.exposePort, setDeploySource, router]);

  const handleBuildReal = React.useCallback(async () => {
    if (!projectId) return;
    setRealBusy(true);
    setRealStatus("provisioning");
    setRealResult(null);
    try {
      const registry = await ensureDockerLabRegistry();
      if (!registry.cloudlabResourceId) {
        setRealStatus("failed");
        setRealResult({ status: "failed", error: registry.error ?? "Could not provision a real registry." });
        return;
      }
      const outcome = await buildImageReal(
        projectId,
        registry.cloudlabResourceId,
        `docker-lab-image-${Date.now()}`,
        "latest",
        dockerfile,
        builder.config.copyRows,
      );
      setRealResult(outcome);
      setRealStatus(outcome.status === "ready" ? "ready" : "failed");
    } finally {
      setRealBusy(false);
    }
  }, [projectId, dockerfile, builder.config.copyRows]);

  const handleDestroyReal = React.useCallback(async () => {
    if (!projectId || !realResult?.resourceId) return;
    setRealBusy(true);
    try {
      await deleteImageReal(projectId, realResult.resourceId);
      setRealStatus("idle");
      setRealResult(null);
    } finally {
      setRealBusy(false);
    }
  }, [projectId, realResult]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Docker Lab</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Build and understand Dockerfiles and image layers hands-on &mdash; configure instructions, watch a
          simulated build, and see how layer caching actually works.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
        <DockerfileForm builder={builder} />

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle>Generated Dockerfile</CardTitle>
              <CardDescription>Regenerates live as you edit the configuration on the left.</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock language="dockerfile" filename="Dockerfile" code={dockerfile} />
            </CardContent>
          </Card>

          <BuildSimulator lines={lines} onFirstBuild={handleFirstBuild} onBuildComplete={handleBuildComplete} />
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <ImageLayers lines={lines} config={builder.config} />
        <DockerCheatsheet />
      </div>

      <div className="mt-8">
        <div className="mb-3">
          <h2 className="text-lg font-semibold tracking-tight">Build &amp; push for real</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            The simulation above is instant and always succeeds so the layer-caching lesson stays clear. This runs
            a genuine <code className="rounded bg-muted px-1 py-0.5 text-xs">docker build</code> + push of the
            Dockerfile above against a real CloudLab-managed registry — real Docker Engine, real digest, real
            failures if something&apos;s actually wrong (e.g. a base image this environment can&apos;t reach).
          </p>
        </div>
        <RealLabPanel
          title="Real registry build"
          description="Builds and pushes for real via CloudLab's Docker Distribution v2 registry (Milestone 4)."
          status={realStatus}
          error={realResult?.status === "failed" ? realResult.error : undefined}
          facts={
            realResult?.status === "ready"
              ? [
                  { label: "Full tag", value: realResult.fullTag ?? "—" },
                  { label: "Digest", value: realResult.digest ?? "—" },
                  { label: "Pull command", value: realResult.pullCommand ?? "—" },
                ]
              : undefined
          }
        >
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={handleBuildReal} disabled={realBusy || realStatus === "provisioning"} className="gap-1.5">
              {realBusy ? "Working…" : realStatus === "ready" ? "Rebuild for real" : "Build & push for real"}
            </Button>
            {realStatus === "ready" && realResult?.resourceId && (
              <Button size="sm" variant="outline" onClick={handleDestroyReal} disabled={realBusy} className="gap-1.5">
                <Trash2 className="h-3.5 w-3.5" /> Delete real image
              </Button>
            )}
          </div>
          {realResult?.buildLogTail && (
            <div className="mt-3">
              <p className="mb-1 text-xs font-medium text-muted-foreground">Real build log (last lines)</p>
              <CodeBlock language="bash" code={realResult.buildLogTail} maxHeight="180px" />
            </div>
          )}
          {realStatus === "ready" && realResult?.resourceId && projectId && (
            <div className="mt-3 border-t border-border pt-3">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <FlaskConical className="h-3.5 w-3.5" /> Run a real test against this image
              </p>
              <RealTestPanel resourceType="container_image" cloudlabResourceId={realResult.resourceId} cloudlabReady />
            </div>
          )}
        </RealLabPanel>
      </div>

      <div className="mt-8 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Run &amp; manage containers</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Once you&apos;ve simulated a build, run the resulting image as a container &mdash; watch it pull, boot, and
            show up below, then stop it, restart it, or trigger a realistic failure to practice troubleshooting.
          </p>
        </div>
        {builtOnce && (
          <Button variant="outline" onClick={handleDeployViaCicd} className="shrink-0">
            <Rocket className="h-4 w-4" /> Deploy via CI/CD Pipeline
          </Button>
        )}
      </div>

      <div className="mt-4 grid gap-5 lg:grid-cols-2">
        <RunSimulator enabled={builtOnce} exposePort={builder.config.exposePort} />
        <ContainerList />
      </div>
    </div>
  );
}

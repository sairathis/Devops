// Generates real, syntactically-correct pipeline-as-code for the App
// Deployment pipeline, parameterized by CI provider AND deploy target.
//
// Scope, stated plainly (see the CloudVerse feature proposal): this produces
// genuinely correct pipeline-as-code text for whichever provider is picked --
// a real Groovy Jenkinsfile, a real GitHub Actions workflow YAML, a real
// Bitbucket Pipelines YAML -- but this sandbox cannot actually run a Jenkins
// controller, a GitHub Actions runner, or a Bitbucket Pipelines runner (the
// same networking constraint that keeps the real `terraform` binary
// uninstallable here). The simulated run underneath (app-deployment-panel.tsx)
// still executes the SAME stage sequence with realistic per-stage output, so
// what you see running matches what this code describes -- it's the
// execution engine underneath that's a stand-in, not the pipeline definition.
import type { DeployTarget } from "@/components/cicd-simulator/pipeline-config";

export type CicdProvider = "cloudbuild" | "jenkins" | "github" | "bitbucket";

export const PROVIDER_OPTIONS: { value: CicdProvider; label: string; filename: string; language: string }[] = [
  { value: "cloudbuild", label: "Google Cloud Build", filename: "cloudbuild.yaml", language: "yaml" },
  { value: "jenkins", label: "Jenkins", filename: "Jenkinsfile", language: "groovy" },
  { value: "github", label: "GitHub Actions", filename: ".github/workflows/deploy.yml", language: "yaml" },
  { value: "bitbucket", label: "Bitbucket Pipelines", filename: "bitbucket-pipelines.yml", language: "yaml" },
];

interface TargetStageInfo {
  /** Extra stages this deploy target requires beyond build/test/push, in order, each as {name, shellCommands}. */
  extraBuildStages: { name: string; commands: string[] }[];
  deployStageName: string;
  deployCommands: string[];
  smokeTestCommands: string[];
}

function targetStages(target: DeployTarget): TargetStageInfo {
  switch (target) {
    case "gke":
      return {
        extraBuildStages: [],
        deployStageName: "Deploy to GKE",
        deployCommands: [
          "gcloud container clusters get-credentials payments-cluster --region us-central1",
          "kubectl set image deployment/payments-api app=us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA",
          "kubectl rollout status deployment/payments-api --timeout=600s",
        ],
        smokeTestCommands: ["curl -sf https://payments-api.cloudverse.dev/healthz"],
      };
    case "compute-engine":
      return {
        extraBuildStages: [],
        deployStageName: "Roll out to Managed Instance Group",
        deployCommands: [
          "gcloud compute instance-templates create payments-api-tmpl-$COMMIT_SHA --image-family=payments-api --source-image-project=$PROJECT_ID",
          "gcloud compute instance-groups managed rolling-action start-update payments-api-mig --version=template=payments-api-tmpl-$COMMIT_SHA --zone=us-central1-a",
          "gcloud compute instance-groups managed wait-until payments-api-mig --stable --zone=us-central1-a",
        ],
        smokeTestCommands: ["curl -sf http://payments-api.cloudverse.internal/healthz"],
      };
    case "cloud-run":
    default:
      return {
        extraBuildStages: [],
        deployStageName: "Deploy to Cloud Run",
        deployCommands: [
          "gcloud run deploy payments-api --image us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA --region us-central1 --platform managed",
        ],
        smokeTestCommands: ["curl -sf https://payments-api.cloudverse.dev/healthz"],
      };
  }
}

// Every target here is container-based, so Docker build + Artifact Registry
// push are always required stages -- but GKE is called out explicitly since
// that's the target the user asked to confirm this for.
const DOCKER_BUILD_COMMANDS = ["docker build -t us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA ."];
const REGISTRY_PUSH_COMMANDS = [
  "gcloud auth configure-docker us-central1-docker.pkg.dev",
  "docker push us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA",
];
const UNIT_TEST_COMMANDS = ["npm ci", "npm test"];

export function generatePipelineCode(provider: CicdProvider, target: DeployTarget): { filename: string; language: string; code: string } {
  const meta = PROVIDER_OPTIONS.find((p) => p.value === provider)!;
  const t = targetStages(target);

  if (provider === "jenkins") {
    return {
      filename: meta.filename,
      language: meta.language,
      code: `// Generated for deploy target: ${t.deployStageName}
pipeline {
  agent any
  environment {
    PROJECT_ID = credentials('gcp-project-id')
    COMMIT_SHA = "\${env.GIT_COMMIT.take(7)}"
  }
  stages {
    stage('Checkout') {
      steps { checkout scm }
    }
    stage('Unit Tests') {
      steps {
        sh '''${UNIT_TEST_COMMANDS.join("\n        ")}'''
      }
    }
    stage('Build Image') {
      steps {
        sh '''${DOCKER_BUILD_COMMANDS.join("\n        ")}'''
      }
    }
    stage('Push to Artifact Registry') {
      steps {
        sh '''${REGISTRY_PUSH_COMMANDS.join("\n        ")}'''
      }
    }
    stage('${t.deployStageName}') {
      steps {
        sh '''${t.deployCommands.join("\n        ")}'''
      }
    }
    stage('Smoke Test') {
      steps {
        sh '''${t.smokeTestCommands.join("\n        ")}'''
      }
    }
  }
  post {
    failure {
      echo "Pipeline failed on stage: \${env.STAGE_NAME}"
    }
    success {
      echo "Deployed \${env.COMMIT_SHA} to ${target}"
    }
  }
}
`,
    };
  }

  if (provider === "github") {
    return {
      filename: meta.filename,
      language: meta.language,
      code: `# Generated for deploy target: ${t.deployStageName}
name: Deploy payments-api

on:
  push:
    branches: [main]

env:
  PROJECT_ID: \${{ secrets.GCP_PROJECT_ID }}

jobs:
  build-test-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Unit tests
        run: |
${UNIT_TEST_COMMANDS.map((c) => `          ${c}`).join("\n")}

      - id: auth
        uses: google-github-actions/auth@v2
        with:
          workload_identity_provider: \${{ secrets.WIF_PROVIDER }}
          service_account: \${{ secrets.WIF_SERVICE_ACCOUNT }}

      - name: Build image
        run: |
${DOCKER_BUILD_COMMANDS.map((c) => `          ${c}`).join("\n")}

      - name: Push to Artifact Registry
        run: |
${REGISTRY_PUSH_COMMANDS.map((c) => `          ${c}`).join("\n")}

      - name: ${t.deployStageName}
        run: |
${t.deployCommands.map((c) => `          ${c}`).join("\n")}

      - name: Smoke test
        run: |
${t.smokeTestCommands.map((c) => `          ${c}`).join("\n")}
`,
    };
  }

  if (provider === "bitbucket") {
    return {
      filename: meta.filename,
      language: meta.language,
      code: `# Generated for deploy target: ${t.deployStageName}
image: google/cloud-sdk:latest

pipelines:
  branches:
    main:
      - step:
          name: Unit Tests
          script:
${UNIT_TEST_COMMANDS.map((c) => `            - ${c}`).join("\n")}
      - step:
          name: Build Image
          services:
            - docker
          script:
${DOCKER_BUILD_COMMANDS.map((c) => `            - ${c}`).join("\n")}
      - step:
          name: Push to Artifact Registry
          services:
            - docker
          script:
${REGISTRY_PUSH_COMMANDS.map((c) => `            - ${c}`).join("\n")}
      - step:
          name: ${t.deployStageName}
          script:
${t.deployCommands.map((c) => `            - ${c}`).join("\n")}
      - step:
          name: Smoke Test
          script:
${t.smokeTestCommands.map((c) => `            - ${c}`).join("\n")}
`,
    };
  }

  // cloudbuild
  return {
    filename: meta.filename,
    language: meta.language,
    code: `# Generated for deploy target: ${t.deployStageName}
steps:
  - name: 'node:20'
    entrypoint: npm
    args: ['ci']
  - name: 'node:20'
    entrypoint: npm
    args: ['test']
  - name: 'gcr.io/cloud-builders/docker'
    args: ${JSON.stringify(["build", "-t", "us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA", "."])}
  - name: 'gcr.io/cloud-builders/docker'
    args: ${JSON.stringify(["push", "us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA"])}
${t.deployCommands
  .map(
    (cmd) => `  - name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'
    entrypoint: bash
    args: ['-c', ${JSON.stringify(cmd)}]`,
  )
  .join("\n")}
  - name: 'gcr.io/cloud-builders/curl'
    args: ${JSON.stringify(["-sf", ...t.smokeTestCommands[0].split(" ").slice(1)])}
images:
  - 'us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$COMMIT_SHA'
`,
  };
}

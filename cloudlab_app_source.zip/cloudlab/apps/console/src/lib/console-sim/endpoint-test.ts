// Shared "is this resource actually reachable right now" check, used by the
// CI/CD Simulator's App Deployment "Test endpoint" button AND the Operations
// Suite's Uptime Checks — both must derive pass/fail from the exact same real
// resource status and logs, never an independent random roll, so a viewer
// sees one consistent story everywhere they test the same resource.
import { ConsoleResource } from "@/store/gcp-console-store";
import { SimLogEntry } from "@/lib/console-sim/types";

export interface EndpointTestResult {
  ok: boolean;
  statusCode: number;
  latencyMs: number;
  reason?: string;
  hint?: string;
  tail: SimLogEntry[];
}

function randomBetween(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

const STATUS_PHRASE: Record<string, string> = {
  provisioning: "is still provisioning",
  starting: "is still starting up",
  stopping: "is shutting down",
  stopped: "is stopped",
  deleting: "is being deleted",
};

export function runEndpointTest(resource: ConsoleResource | undefined): EndpointTestResult {
  if (!resource) {
    return {
      ok: false,
      statusCode: 502,
      latencyMs: 0,
      reason: "The target resource no longer exists in the GCP Console.",
      hint: "Pick a different target and redeploy.",
      tail: [],
    };
  }

  const tail = resource.logs.slice(-6);

  if (resource.status === "running") {
    return {
      ok: true,
      statusCode: 200,
      latencyMs: randomBetween(38, 210),
      tail,
    };
  }

  if (resource.status === "error") {
    const lastError = [...resource.logs].reverse().find((l) => l.level === "error");
    return {
      ok: false,
      statusCode: 502,
      latencyMs: randomBetween(1200, 4000),
      reason: lastError?.message ?? `${resource.name} reported an error.`,
      hint: "Open the Troubleshooting Center or the resource's detail view in the GCP Console, fix the underlying issue, then re-test.",
      tail,
    };
  }

  return {
    ok: false,
    statusCode: 0,
    latencyMs: randomBetween(3000, 5000),
    reason: `${resource.name} ${STATUS_PHRASE[resource.status] ?? "is not currently running"} — there is nothing listening to serve the request.`,
    hint:
      resource.status === "stopped"
        ? "Start the resource from the GCP Console, then re-test."
        : "Wait for the resource to finish, or check the GCP Console for details, then re-test.",
    tail,
  };
}

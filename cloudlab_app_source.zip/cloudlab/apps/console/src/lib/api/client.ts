// Thin fetch wrapper around CloudLab's real Fastify API (apps/api).
//
// The console talks to the API directly over HTTP -- CloudLab's API already
// sends permissive CORS headers (see apps/api/src/server.ts), so no Next.js
// rewrite/proxy is needed. Every authenticated call attaches the JWT issued
// by POST /auth/login|register (see apps/api/src/routes/auth.ts).

export const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:4000/api/v1"
).replace(/\/+$/, "");

export interface ApiErrorBody {
  code?: string;
  message: string;
  what?: string;
  why?: string;
  diagnose?: string;
  fix?: string;
  details?: unknown;
}

/** Mirrors apps/api/src/errors.ts's HttpError body shape. */
export class ApiError extends Error {
  status: number;
  body: ApiErrorBody;
  constructor(status: number, body: ApiErrorBody) {
    super(body?.message || `Request failed with status ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

type TokenGetter = () => string | null;
type UnauthorizedHandler = () => void;

// Set from auth-store.ts once at module init to avoid a circular import at
// the top level (this module is imported by auth-store.ts too).
let getToken: TokenGetter = () => null;
let onUnauthorized: UnauthorizedHandler = () => {};

export function configureApiAuth(getter: TokenGetter, unauthorized: UnauthorizedHandler) {
  getToken = getter;
  onUnauthorized = unauthorized;
}

interface RequestOpts {
  method?: "GET" | "POST" | "PATCH" | "PUT" | "DELETE";
  body?: unknown;
  auth?: boolean; // default true -- attach Authorization header when a token exists
}

async function request<T>(path: string, opts: RequestOpts = {}): Promise<T> {
  const { method = "GET", body, auth = true } = opts;
  const token = auth ? getToken() : null;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const text = await res.text();
  const data = text ? safeJson(text) : null;

  if (!res.ok) {
    const errBody: ApiErrorBody = (data as ApiErrorBody) ?? { message: res.statusText || "Request failed" };
    if (res.status === 401 && auth) onUnauthorized();
    throw new ApiError(res.status, errBody);
  }

  return data as T;
}

function safeJson(text: string) {
  try {
    return JSON.parse(text);
  } catch {
    return { message: text };
  }
}

export const api = {
  get: <T>(path: string, opts: Omit<RequestOpts, "method" | "body"> = {}) =>
    request<T>(path, { ...opts, method: "GET" }),
  post: <T>(path: string, body?: unknown, opts: Omit<RequestOpts, "method" | "body"> = {}) =>
    request<T>(path, { ...opts, method: "POST", body }),
  patch: <T>(path: string, body?: unknown, opts: Omit<RequestOpts, "method" | "body"> = {}) =>
    request<T>(path, { ...opts, method: "PATCH", body }),
  put: <T>(path: string, body?: unknown, opts: Omit<RequestOpts, "method" | "body"> = {}) =>
    request<T>(path, { ...opts, method: "PUT", body }),
  delete: <T>(path: string, opts: Omit<RequestOpts, "method" | "body"> = {}) =>
    request<T>(path, { ...opts, method: "DELETE" }),
};

/** Every real resource route is scoped under a project, e.g. /projects/:id/instances. */
export function projectPath(projectId: string, subPath: string) {
  return `/projects/${projectId}${subPath.startsWith("/") ? subPath : `/${subPath}`}`;
}

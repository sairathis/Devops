import { GcpResourceDef } from "@/types/gcp";

export const networkingResources: GcpResourceDef[] = [
  {
    type: "vpc",
    label: "VPC Network",
    shortLabel: "VPC",
    category: "networking",
    color: "gcp-blue",
    description: "A global, software-defined network that provides connectivity for your Compute Engine, GKE, and other resources.",
    learningNotes:
      "A VPC in GCP is global — it can span all regions without needing peering. Subnets, however, are regional. Always design VPCs around the principle of least privilege: separate public and private subnets, and use firewall rules to control east-west and north-south traffic. Custom-mode VPCs (recommended for production) let you control subnet CIDR ranges explicitly, unlike auto-mode VPCs which create a subnet per region automatically.",
    tooltip: "The foundational network container for all your GCP resources.",
    docsUrl: "https://cloud.google.com/vpc/docs/vpc",
    terraformResourceType: "google_compute_network",
    configFields: [
      { key: "name", label: "Network Name", type: "text", required: true, placeholder: "prod-vpc" },
      {
        key: "subnetMode",
        label: "Subnet Creation Mode",
        type: "select",
        options: [
          { label: "Custom (recommended)", value: "CUSTOM" },
          { label: "Auto", value: "AUTO" },
        ],
      },
      { key: "routingMode", label: "Routing Mode", type: "select", options: [{ label: "Regional", value: "REGIONAL" }, { label: "Global", value: "GLOBAL" }] },
      { key: "mtu", label: "MTU", type: "number", min: 1300, max: 8896 },
      { key: "description", label: "Description", type: "textarea" },
    ],
    defaultConfig: { name: "prod-vpc", subnetMode: "CUSTOM", routingMode: "REGIONAL", mtu: 1460, description: "Primary application VPC" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_network" "${slug}" {
  name                    = "${config.name}"
  auto_create_subnetworks = ${config.subnetMode === "AUTO"}
  routing_mode            = "${config.routingMode}"
  mtu                     = ${config.mtu}
  description             = "${config.description ?? ""}"
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "Instances in different subnets can't reach each other", cause: "Missing firewall rule allowing internal ingress", fix: "Add an allow rule for the internal CIDR ranges on the required ports/protocols." },
      { issue: "VPC peering shows INACTIVE", cause: "The peering was only configured on one side", fix: "Create the peering connection symmetrically from both VPCs." },
    ],
    quiz: [
      {
        question: "Are GCP VPC networks regional or global resources?",
        options: ["Regional", "Global", "Zonal", "Multi-regional only in us-central1"],
        answerIndex: 1,
        explanation: "VPC networks are global resources; subnets within them are regional.",
        difficulty: "beginner",
      },
      {
        question: "What's the difference between Auto and Custom subnet creation mode when creating a VPC?",
        options: [
          "Auto mode automatically creates one subnet per region with predetermined ranges; Custom mode requires you to explicitly define each subnet's CIDR range and region",
          "Custom mode is a legacy option that Google recommends against",
          "Auto mode is recommended for production workloads",
          "They differ only in billing, not behavior",
        ],
        answerIndex: 0,
        explanation: "Auto mode trades control for convenience, provisioning a /20 subnet in every region automatically. Custom mode is recommended for production precisely because it lets you deliberately size and place subnets, avoiding accidental IP overlap.",
        difficulty: "beginner",
      },
      {
        question: "A VPC peering connection between two VPCs shows status INACTIVE. What is the most likely cause?",
        options: [
          "The peered VPCs are in different regions",
          "The peering connection was only configured from one side",
          "One VPC uses Custom mode and the other uses Auto mode",
          "Firewall rules are blocking the peering handshake",
        ],
        answerIndex: 1,
        explanation: "VPC peering must be established symmetrically — each VPC creates its own peering resource pointing at the other. If only one side has done so, the connection remains INACTIVE until the second side configures its half.",
        difficulty: "intermediate",
      },
      {
        question: "How does 'Global' routing mode differ from 'Regional' routing mode on a VPC network?",
        options: [
          "Global routing mode makes a Cloud Router's dynamic and static routes visible to instances in every region of the VPC, not just the region the routes were learned in",
          "Global mode disables firewall rules across regions",
          "Regional mode is required for GKE clusters to function",
          "Global mode removes the need to create subnets",
        ],
        answerIndex: 0,
        explanation: "In Regional mode, routes learned or created in one region only apply within that region; Global mode propagates them VPC-wide, which matters for hybrid connectivity where routes learned via one region's Cloud Router should reach workloads everywhere.",
        difficulty: "intermediate",
      },
      {
        question: "Why is a Custom-mode VPC generally recommended over Auto-mode for production, even though Auto-mode is faster to stand up?",
        options: [
          "Auto-mode VPCs cost significantly more per month",
          "Custom-mode gives explicit control over CIDR allocation per subnet, avoiding IP overlap and supporting deliberate network segmentation",
          "Auto-mode doesn't support firewall rules at all",
          "Custom-mode is required for any resource with a public IP",
        ],
        answerIndex: 1,
        explanation: "Auto-mode's automatically-assigned ranges are convenient for demos but make it easy to end up with IP ranges that later conflict with on-prem networks or other VPCs during peering/hybrid connectivity — a problem Custom mode avoids by design.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["subnet", "nat", "dns", "lb", "cloud_run"],
  },
  {
    type: "subnet",
    label: "Subnet",
    shortLabel: "Subnet",
    category: "networking",
    color: "gcp-blue",
    description: "A regional IP address range within a VPC where resources like VMs get their internal IPs.",
    learningNotes:
      "Subnets are regional — resources in the same subnet can span multiple zones within that region but not other regions. Use separate subnets for public (has a route to an internet gateway) and private (egress only via Cloud NAT) workloads. Enable 'Private Google Access' on private subnets so instances without external IPs can still reach Google APIs.",
    tooltip: "A regional slice of your VPC's IP space.",
    docsUrl: "https://cloud.google.com/vpc/docs/subnets",
    terraformResourceType: "google_compute_subnetwork",
    configFields: [
      { key: "name", label: "Subnet Name", type: "text", required: true, placeholder: "public-subnet-1" },
      {
        key: "vpcId", label: "VPC Network", type: "resource-ref", refTypes: ["vpc"],
        helpText: "Which VPC this subnet belongs to. In real GCP a subnet always lives inside exactly one VPC — bind one here so the architecture diagram can draw the real connection.",
      },
      { key: "region", label: "Region", type: "select", options: [
        { label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" },
        { label: "europe-west1", value: "europe-west1" }, { label: "asia-south1", value: "asia-south1" },
      ] },
      { key: "ipCidrRange", label: "IP CIDR Range", type: "text", placeholder: "10.0.1.0/24" },
      { key: "access", label: "Access Type", type: "select", options: [{ label: "Public", value: "public" }, { label: "Private", value: "private" }] },
      { key: "privateGoogleAccess", label: "Private Google Access", type: "boolean" },
      { key: "flowLogs", label: "Enable VPC Flow Logs", type: "boolean" },
    ],
    defaultConfig: { name: "public-subnet-1", vpcId: "", region: "us-central1", ipCidrRange: "10.0.1.0/24", access: "public", privateGoogleAccess: true, flowLogs: false },
    generateTerraform: ({ slug, config }) => `resource "google_compute_subnetwork" "${slug}" {
  name                     = "${config.name}"
  ip_cidr_range            = "${config.ipCidrRange}"
  region                   = "${config.region}"
  network                  = google_compute_network.prod_vpc.id
  private_ip_google_access = ${config.privateGoogleAccess}
  dynamic "log_config" {
    for_each = ${config.flowLogs} ? [1] : []
    content {
      aggregation_interval = "INTERVAL_5_SEC"
      flow_sampling        = 0.5
      metadata             = "INCLUDE_ALL_METADATA"
    }
  }
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "VM has no internet access", cause: "Private subnet with no Cloud NAT attached", fix: "Attach a Cloud NAT gateway to the subnet's region via a Cloud Router." },
      { issue: "Overlapping CIDR error on creation", cause: "IP range collides with another subnet in the VPC", fix: "Pick a non-overlapping CIDR block, e.g. split a /16 into /24s per subnet." },
    ],
    quiz: [
      {
        question: "What lets a VM with no external IP reach Google APIs like Cloud Storage?",
        options: ["Cloud NAT", "Private Google Access", "Cloud Armor", "Cloud Interconnect"],
        answerIndex: 1,
        explanation: "Private Google Access lets internal-only instances reach Google APIs/services without a public IP.",
        difficulty: "beginner",
      },
      {
        question: "What is the defining characteristic of a private subnet, as opposed to a public one?",
        options: [
          "Private subnets have no route to an internet gateway, so instances there need something like Cloud NAT for outbound internet access",
          "Private subnets cannot host Compute Engine VMs",
          "Public subnets are regional while private subnets are zonal",
          "Private subnets don't support IAM permissions",
        ],
        answerIndex: 0,
        explanation: "The public/private distinction is about routing, not capability — a private subnet's instances simply have no default route out to the internet, which is exactly why they rely on Cloud NAT for any outbound traffic.",
        difficulty: "beginner",
      },
      {
        question: "A subnet creation request fails with an overlapping CIDR error. What is the cause?",
        options: [
          "The subnet's region doesn't support that CIDR size",
          "The requested IP range collides with another subnet already in the same VPC",
          "Private Google Access is enabled",
          "VPC Flow Logs are enabled",
        ],
        answerIndex: 1,
        explanation: "All subnet IP ranges in a VPC must be unique, even across different regions, since routing within the VPC is global. Splitting a larger block (e.g. a /16) into non-overlapping /24s per subnet avoids this.",
        difficulty: "intermediate",
      },
      {
        question: "A VM in a private subnet needs to download OS packages from the internet but has no external IP. What must be attached to make this work?",
        options: [
          "A public DNS zone",
          "A Cloud NAT gateway (via a Cloud Router) covering that subnet",
          "A Cloud Armor policy",
          "An HTTP(S) load balancer",
        ],
        answerIndex: 1,
        explanation: "Without a public IP and without NAT, a private-subnet VM has no path to the internet at all. Cloud NAT provides that outbound-only path; a load balancer or Cloud Armor are for inbound traffic, which is the opposite direction.",
        difficulty: "intermediate",
      },
      {
        question: "Can two subnets in the same VPC, located in different regions, be assigned overlapping IP CIDR ranges?",
        options: [
          "Yes, since each region's traffic is isolated from the others",
          "No — subnet IP ranges must be unique across the entire VPC regardless of region, since VPC routing operates network-wide",
          "Only if routing mode is set to Regional",
          "Only for subnets marked private",
        ],
        answerIndex: 1,
        explanation: "Even though subnets are regional resources, the VPC's routing table is not scoped per region — every subnet's range must be distinct VPC-wide, or routing between them becomes ambiguous.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["vm", "mig", "gke", "cloudsql", "redis"],
  },
  {
    type: "lb",
    label: "Load Balancer",
    shortLabel: "LB",
    category: "networking",
    color: "gcp-blue",
    description: "Distributes incoming traffic across multiple backend instances for scale, availability, and health-checked routing.",
    learningNotes:
      "GCP offers several load balancer types: Global external HTTP(S) for internet-facing web apps (Layer 7, uses Anycast IP), Network/TCP for non-HTTP traffic, and Internal LBs for private, VPC-only traffic between tiers. HTTP(S) LBs integrate natively with Cloud Armor and Cloud CDN. Health checks determine which backends receive traffic — an unhealthy backend is automatically drained.",
    tooltip: "Distributes traffic across backends with health checking.",
    docsUrl: "https://cloud.google.com/load-balancing/docs",
    terraformResourceType: "google_compute_forwarding_rule",
    configFields: [
      { key: "name", label: "Load Balancer Name", type: "text", required: true, placeholder: "web-lb" },
      {
        key: "vpcId", label: "VPC Network", type: "resource-ref", refTypes: ["vpc"],
        helpText: "Which VPC this load balancer's forwarding rule belongs to. Bind one (or drag a connection from a VPC node) so it provisions for real on CloudLab.",
      },
      { key: "lbType", label: "Type", type: "select", options: [
        { label: "HTTP(S) — External", value: "HTTPS" }, { label: "TCP — External", value: "TCP" },
        { label: "Internal HTTP(S)", value: "INTERNAL_HTTPS" }, { label: "Internal TCP/UDP", value: "INTERNAL" },
      ] },
      {
        key: "backendTargetIds", label: "Backend Targets", type: "resource-ref-multi", refTypes: ["vm", "mig", "gke"],
        helpText: "Which running VMs, Managed Instance Groups, or GKE clusters this load balancer distributes traffic to. A real, provisioned Managed Instance Group is routed to for real (its live member set); real VMs are routed to as a fixed backend list. Pick at least one so the diagram shows real traffic-flow lines.",
      },
      { key: "protocol", label: "Protocol", type: "select", options: [{ label: "HTTP", value: "HTTP" }, { label: "HTTPS", value: "HTTPS" }, { label: "TCP", value: "TCP" }] },
      { key: "port", label: "Port", type: "number", min: 1, max: 65535 },
      { key: "healthCheckPath", label: "Health Check Path", type: "text", placeholder: "/healthz" },
      { key: "sessionAffinity", label: "Session Affinity", type: "select", options: [{ label: "None", value: "NONE" }, { label: "Client IP", value: "CLIENT_IP" }, { label: "Cookie", value: "GENERATED_COOKIE" }] },
      { key: "cloudArmor", label: "Attach Cloud Armor Policy", type: "boolean" },
    ],
    defaultConfig: { name: "web-lb", vpcId: "", lbType: "HTTPS", backendTargetIds: [], protocol: "HTTPS", port: 443, healthCheckPath: "/healthz", sessionAffinity: "NONE", cloudArmor: true },
    generateTerraform: ({ slug, config }) => `resource "google_compute_health_check" "${slug}_hc" {
  name               = "${config.name}-hc"
  check_interval_sec = 5
  timeout_sec        = 5
  http_health_check {
    port         = ${config.port}
    request_path = "${config.healthCheckPath}"
  }
}

resource "google_compute_backend_service" "${slug}_backend" {
  name                  = "${config.name}-backend"
  protocol              = "${config.protocol}"
  port_name             = "http"
  load_balancing_scheme = "${String(config.lbType).startsWith("INTERNAL") ? "INTERNAL_MANAGED" : "EXTERNAL_MANAGED"}"
  session_affinity      = "${config.sessionAffinity}"
  health_checks         = [google_compute_health_check.${slug}_hc.id]
  ${config.cloudArmor ? "security_policy       = google_compute_security_policy.cloud_armor_policy.id" : ""}
}

resource "google_compute_global_forwarding_rule" "${slug}" {
  name       = "${config.name}"
  port_range = "${config.port}"
  target     = google_compute_target_http_proxy.${slug}_proxy.id
}`,
    estimateMonthlyCost: () => 18,
    troubleshooting: [
      { issue: "Backend shows UNHEALTHY", cause: "Health check path returns non-200 or firewall blocks the health-check IP ranges", fix: "Allow ingress from 130.211.0.0/22 and 35.191.0.0/16, and verify the app responds 200 on the health check path." },
      { issue: "502 Server Error from the LB", cause: "All backends are unhealthy or backend timeout exceeded", fix: "Check instance health, increase backend timeout, verify the app is listening on the configured port." },
    ],
    quiz: [
      {
        question: "Which GCP firewall source ranges must be allowed for HTTP(S) load balancer health checks?",
        options: ["10.0.0.0/8", "130.211.0.0/22 and 35.191.0.0/16", "0.0.0.0/0", "192.168.0.0/16"],
        answerIndex: 1,
        explanation: "Google's health check probes originate from these two documented ranges.",
        difficulty: "beginner",
      },
      {
        question: "Which GCP load balancer type operates at Layer 7 and fronts internet-facing HTTP(S) traffic through a single global anycast IP?",
        options: ["Internal TCP/UDP Load Balancer", "Global external HTTP(S) Load Balancer", "Internal HTTP(S) Load Balancer", "Cloud NAT"],
        answerIndex: 1,
        explanation: "The global external HTTP(S) load balancer is Layer 7 (understands HTTP paths/hosts) and uses one anycast IP that routes users to the nearest healthy backend worldwide. Internal load balancer variants serve only private, VPC-internal traffic.",
        difficulty: "beginner",
      },
      {
        question: "Clients start seeing intermittent 502 Server Errors from a load balancer that was working fine. What's the most likely cause?",
        options: [
          "The load balancer's SSL certificate expired",
          "All (or most) backends are failing health checks, or requests are exceeding the backend timeout",
          "Cloud Armor is enabled",
          "Session affinity is set to NONE",
        ],
        answerIndex: 1,
        explanation: "A 502 means the load balancer couldn't get a valid response from any backend — usually because backends are unhealthy or too slow to respond within the configured timeout. A certificate issue would typically surface as a TLS/handshake error, not a 502.",
        difficulty: "intermediate",
      },
      {
        question: "An application keeps session state in local server memory (not an external cache) and needs a client's repeat requests to consistently land on the same backend. Which setting addresses this, and what's the tradeoff?",
        options: [
          "Session affinity NONE — it spreads load evenly with no downside",
          "CLIENT_IP or GENERATED_COOKIE session affinity — it provides stickiness, but can lead to uneven load distribution across backends",
          "Attaching a Cloud Armor policy",
          "Switching the load balancer type to TCP",
        ],
        answerIndex: 1,
        explanation: "Sticky sessions solve the local-state problem but work against the load balancer's ability to spread traffic evenly, since some backends may end up handling disproportionately more 'sticky' clients than others. The better long-term fix is externalizing session state (e.g. to Memorystore), but affinity is the direct config-level answer here.",
        difficulty: "intermediate",
      },
      {
        question: "A backend service must only be reachable from other services inside the VPC — never the internet — but still needs HTTP(S)-level routing like path-based rules. Which load balancer type fits?",
        options: [
          "External HTTP(S) Load Balancer with a Cloud Armor policy",
          "Internal HTTP(S) Load Balancer",
          "External TCP Load Balancer",
          "Cloud NAT",
        ],
        answerIndex: 1,
        explanation: "The Internal HTTP(S) Load Balancer provides Layer 7 routing entirely within the VPC, with no external-facing IP at all. An external LB with Cloud Armor still exposes a public endpoint, just a filtered one — that's a different security posture than never being internet-reachable.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["vm", "mig", "gke"],
  },
  {
    type: "router",
    label: "Cloud Router",
    shortLabel: "Router",
    category: "networking",
    color: "gcp-blue",
    description: "A regional, fully-distributed BGP router used for dynamic route exchange with on-prem networks and to power Cloud NAT.",
    learningNotes:
      "Cloud Router is a prerequisite for both Cloud NAT and dynamic routing over VPN/Interconnect. It speaks BGP to exchange routes dynamically rather than requiring static routes to be maintained by hand. One Cloud Router exists per region per VPC.",
    tooltip: "Regional BGP router; required for Cloud NAT and dynamic VPN/Interconnect routing.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/router",
    terraformResourceType: "google_compute_router",
    configFields: [
      { key: "name", label: "Router Name", type: "text", required: true, placeholder: "prod-router" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "asn", label: "BGP ASN", type: "number", min: 64512, max: 65534 },
    ],
    defaultConfig: { name: "prod-router", region: "us-central1", asn: 64514 },
    generateTerraform: ({ slug, config }) => `resource "google_compute_router" "${slug}" {
  name    = "${config.name}"
  region  = "${config.region}"
  network = google_compute_network.prod_vpc.id
  bgp {
    asn = ${config.asn}
  }
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "BGP session not established", cause: "ASN mismatch or interface/peer misconfiguration", fix: "Verify ASN pairing and BGP peer IP addresses on both sides of the session." },
    ],
    quiz: [
      { question: "What protocol does Cloud Router use to exchange routes?", options: ["OSPF", "BGP", "RIP", "EIGRP"], answerIndex: 1, explanation: "Cloud Router is a fully managed BGP speaker.", difficulty: "beginner" },
      {
        question: "Why does creating a Cloud NAT gateway require a Cloud Router, even though NAT itself doesn't exchange any BGP routes?",
        options: [
          "Cloud NAT is implemented as a configuration attached to a Cloud Router in the same region/VPC, which manages it, even though NAT's SNAT function has nothing to do with BGP",
          "Cloud Router encrypts the NAT'd traffic",
          "Cloud Router is the source of the external IP addresses NAT uses",
          "It's only a historical requirement with no technical basis",
        ],
        answerIndex: 0,
        explanation: "Google chose to host Cloud NAT's configuration on top of the Cloud Router resource rather than as a fully standalone object, so a router must exist first — but NAT itself only performs address translation and never participates in route exchange.",
        difficulty: "intermediate",
      },
      {
        question: "A BGP session between a Cloud Router and an on-prem peer never establishes. What's a likely cause?",
        options: [
          "The VPC is in Auto subnet mode",
          "A mismatched ASN or misconfigured peer/interface IP address on one side of the session",
          "Cloud NAT isn't attached",
          "Private Google Access isn't enabled",
        ],
        answerIndex: 1,
        explanation: "BGP peering requires both sides to agree on ASNs and have correctly configured interface/peer IP addresses; a mismatch on either prevents the session from ever coming up, regardless of subnet mode or NAT configuration.",
        difficulty: "intermediate",
      },
      {
        question: "What is the typical monthly cost of a Cloud Router resource itself?",
        options: ["A flat $50/month", "It's free — you only pay for the NAT gateway, VPN, or Interconnect resources that use it", "$0.01 per BGP session established", "The same as a load balancer forwarding rule"],
        answerIndex: 1,
        explanation: "Cloud Router itself carries no direct charge; costs come from the dependent resources (Cloud NAT gateways, VPN tunnels, Interconnect attachments) it enables, not from the router configuration.",
        difficulty: "intermediate",
      },
      {
        question: "A hybrid network uses Cloud VPN configured with static routes only, no Cloud Router. What capability is being given up?",
        options: [
          "IPsec encryption of the tunnel",
          "Automatic propagation of route changes via BGP — if on-prem routes change, they must be manually re-added on both sides",
          "The ability to use HA VPN at all",
          "DNS resolution across the tunnel",
        ],
        answerIndex: 1,
        explanation: "Without a Cloud Router providing dynamic BGP routing, any change to on-prem network topology requires manually updating static routes on both ends — brittle compared to BGP, which detects and propagates such changes automatically.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["nat", "vpn", "interconnect"],
  },
  {
    type: "nat",
    label: "Cloud NAT",
    shortLabel: "NAT",
    category: "networking",
    color: "gcp-blue",
    description: "Provides outbound-only internet access for instances without external IPs, without exposing them to inbound connections.",
    learningNotes:
      "Cloud NAT is regional and requires a Cloud Router in the same region/VPC. It performs source NAT (SNAT) only — there's no way to initiate inbound connections through it, which is exactly why it's the recommended pattern for private-subnet workloads that need outbound package downloads or API calls.",
    tooltip: "Outbound-only internet access for private instances.",
    docsUrl: "https://cloud.google.com/nat/docs/overview",
    terraformResourceType: "google_compute_router_nat",
    configFields: [
      { key: "name", label: "NAT Gateway Name", type: "text", required: true, placeholder: "prod-nat" },
      {
        key: "vpcId", label: "VPC Network", type: "resource-ref", refTypes: ["vpc"],
        helpText: "Which VPC this Cloud NAT covers. Bind one (or drag a connection from a VPC node) so it provisions for real on CloudLab.",
      },
      { key: "natIpAllocation", label: "IP Allocation", type: "select", options: [{ label: "Auto-allocate", value: "AUTO_ONLY" }, { label: "Manual (reserved IPs)", value: "MANUAL_ONLY" }] },
      { key: "minPortsPerVm", label: "Min Ports Per VM", type: "number", min: 32, max: 65536 },
      { key: "loggingFilter", label: "Logging", type: "select", options: [{ label: "Off", value: "OFF" }, { label: "Errors Only", value: "ERRORS_ONLY" }, { label: "All", value: "ALL" }] },
    ],
    defaultConfig: { name: "prod-nat", vpcId: "", natIpAllocation: "AUTO_ONLY", minPortsPerVm: 64, loggingFilter: "ERRORS_ONLY" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_router_nat" "${slug}" {
  name                               = "${config.name}"
  router                             = google_compute_router.prod_router.name
  region                             = google_compute_router.prod_router.region
  nat_ip_allocate_option             = "${config.natIpAllocation}"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  min_ports_per_vm                   = ${config.minPortsPerVm}
  log_config {
    enable = ${config.loggingFilter !== "OFF"}
    filter = "${config.loggingFilter}"
  }
}`,
    estimateMonthlyCost: (c) => 32 + Number(c.minPortsPerVm ?? 64) * 0.01,
    troubleshooting: [
      { issue: "Outbound connections fail intermittently", cause: "NAT port exhaustion under high connection concurrency", fix: "Increase minPortsPerVm or switch to dynamic port allocation." },
      { issue: "New VM in subnet still has no internet", cause: "NAT source range doesn't include that subnet", fix: "Set NAT to cover ALL_SUBNETWORKS_ALL_IP_RANGES or explicitly add the subnet." },
    ],
    quiz: [
      { question: "Can Cloud NAT be used to allow inbound connections to a private instance?", options: ["Yes, symmetric NAT", "No, it is outbound-only", "Only for TCP", "Only with a static IP"], answerIndex: 1, explanation: "Cloud NAT only performs source NAT for outbound traffic.", difficulty: "beginner" },
      {
        question: "What must already exist in the same region and VPC before you can create a Cloud NAT gateway?",
        options: ["A Cloud Router", "A Cloud VPN tunnel", "A Cloud Armor security policy", "A Cloud DNS managed zone"],
        answerIndex: 0,
        explanation: "Cloud NAT is configured as an add-on to a Cloud Router in the same region and network — there is no way to create a standalone NAT gateway without one.",
        difficulty: "beginner",
      },
      {
        question: "Outbound connections from VMs behind a Cloud NAT gateway start failing intermittently under heavy concurrent connection load. What's the most likely cause?",
        options: [
          "The Cloud Router's ASN is misconfigured",
          "NAT port exhaustion — too few ports allocated per VM for the number of simultaneous outbound connections",
          "The VPC is in Auto subnet mode",
          "DNSSEC is disabled",
        ],
        answerIndex: 1,
        explanation: "Each VM behind Cloud NAT is allocated a limited number of ports for SNAT; under high connection concurrency, exhausting that allocation causes new connection attempts to fail. Raising minPortsPerVm (or enabling dynamic port allocation) gives each VM more headroom.",
        difficulty: "intermediate",
      },
      {
        question: "A newly-created VM in a subnet still has no outbound internet access despite Cloud NAT being configured in the VPC. What's the likely cause?",
        options: [
          "The VM doesn't have a public IP",
          "The NAT gateway's source range configuration doesn't include that subnet",
          "The VM's machine type doesn't support NAT",
          "Cloud NAT requires a restart after any new VM is added",
        ],
        answerIndex: 1,
        explanation: "If NAT is scoped to specific subnets rather than ALL_SUBNETWORKS_ALL_IP_RANGES, a new subnet won't automatically get outbound access through it — the NAT configuration must explicitly cover it. A VM behind NAT deliberately has no public IP by design, so that isn't the problem.",
        difficulty: "intermediate",
      },
      {
        question: "Raising minPortsPerVm on a Cloud NAT gateway helps avoid port exhaustion for individual VMs with many concurrent connections. What's the tradeoff of setting it very high across an entire fleet?",
        options: [
          "There is no downside — always set it as high as possible",
          "It reduces how many VMs a single NAT IP address can serve, since each IP's usable port range gets divided among fewer VMs",
          "It disables NAT logging",
          "It increases per-connection latency",
        ],
        answerIndex: 1,
        explanation: "Each NAT IP has a fixed pool of usable ports; allocating more ports per VM means fewer VMs can be served per IP before you need to provision additional NAT IP addresses. It's a direct tradeoff between per-VM headroom and how many VMs one IP can support.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: [],
  },
  {
    type: "dns",
    label: "Cloud DNS",
    shortLabel: "DNS",
    category: "networking",
    color: "gcp-blue",
    description: "A scalable, reliable, managed authoritative DNS service running on Google's infrastructure.",
    learningNotes:
      "Cloud DNS supports public managed zones (resolvable from the internet) and private managed zones (resolvable only from specified VPCs). 100% uptime SLA is backed by Google's global anycast network. DNSSEC can be enabled per zone to prevent spoofing/cache poisoning.",
    tooltip: "Managed, authoritative DNS for public or private zones.",
    docsUrl: "https://cloud.google.com/dns/docs/overview",
    terraformResourceType: "google_dns_managed_zone",
    configFields: [
      { key: "name", label: "Zone Name", type: "text", required: true, placeholder: "prod-zone" },
      {
        key: "vpcId", label: "VPC Network", type: "resource-ref", refTypes: ["vpc"],
        helpText: "Which VPC this zone's record resolves within. Bind one (or drag a connection from a VPC node) so the mapping provisions for real on CloudLab.",
      },
      { key: "dnsName", label: "DNS Name (FQDN)", type: "text", placeholder: "example.com." },
      { key: "targetIp", label: "Record Target IP", type: "text", placeholder: "10.0.0.10", helpText: "The IP address this DNS name maps to (an A record)." },
      { key: "visibility", label: "Visibility", type: "select", options: [{ label: "Public", value: "public" }, { label: "Private", value: "private" }] },
      { key: "dnssec", label: "Enable DNSSEC", type: "boolean" },
    ],
    defaultConfig: { name: "prod-zone", vpcId: "", dnsName: "example.com.", targetIp: "10.0.0.10", visibility: "public", dnssec: true },
    generateTerraform: ({ slug, config }) => `resource "google_dns_managed_zone" "${slug}" {
  name       = "${config.name}"
  dns_name   = "${config.dnsName}"
  visibility = "${config.visibility}"
  dnssec_config {
    state = "${config.dnssec ? "on" : "off"}"
  }
}`,
    estimateMonthlyCost: () => 0.4,
    troubleshooting: [
      { issue: "Domain doesn't resolve", cause: "Registrar's nameservers not updated to Cloud DNS NS records", fix: "Copy the zone's NS records into your domain registrar's nameserver settings." },
    ],
    quiz: [
      { question: "What determines whether a Cloud DNS zone is resolvable only within your VPCs?", options: ["Zone TTL", "Visibility setting (private vs public)", "DNSSEC", "Record type"], answerIndex: 1, explanation: "Private zones resolve only within specified VPC networks.", difficulty: "beginner" },
      {
        question: "What does enabling DNSSEC on a Cloud DNS zone protect against?",
        options: [
          "DDoS volumetric attacks against the DNS servers",
          "DNS spoofing and cache poisoning, by cryptographically signing DNS responses so resolvers can verify authenticity",
          "Slow DNS resolution times",
          "Domain registration expiring unexpectedly",
        ],
        answerIndex: 1,
        explanation: "DNSSEC adds cryptographic signatures to DNS records so a validating resolver can detect a forged or tampered response. It has no effect on DDoS resilience, latency, or domain registration.",
        difficulty: "beginner",
      },
      {
        question: "A newly created public Cloud DNS zone has correct records, but the domain still doesn't resolve from the public internet. What's the likely cause?",
        options: [
          "DNSSEC wasn't enabled",
          "The domain registrar's nameserver records haven't been updated to point to the Cloud DNS zone's NS records",
          "The zone's TTL is set too high",
          "The zone is missing an SOA record",
        ],
        answerIndex: 1,
        explanation: "Cloud DNS only becomes authoritative for a domain once the registrar is told (via NS records) to delegate to it; until that delegation happens, the internet keeps asking whatever nameservers were previously configured.",
        difficulty: "intermediate",
      },
      {
        question: "A private Cloud DNS zone is created for internal.example.com. Which clients can resolve records in it?",
        options: [
          "Anyone on the public internet",
          "Only resources within the VPC networks explicitly authorized on that zone",
          "Only Compute Engine VMs, never GKE pods",
          "Only clients connecting over Cloud VPN",
        ],
        answerIndex: 1,
        explanation: "A private zone's visibility is scoped to a specific list of VPC networks — resources in those networks can resolve it, but it's invisible from the public internet or from VPCs not on the authorized list.",
        difficulty: "intermediate",
      },
      {
        question: "Why might a platform team choose a private Cloud DNS zone over relying on static /etc/hosts entries or a self-managed DNS server for internal service discovery?",
        options: [
          "Private zones offer no meaningful advantage over static host files",
          "A managed, VPC-scoped, IAM-controlled DNS service avoids per-host config drift and removes a self-managed single point of failure",
          "Self-managed DNS servers are always faster",
          "/etc/hosts entries update automatically as infrastructure changes",
        ],
        answerIndex: 1,
        explanation: "Centralizing internal name resolution in a managed zone means one source of truth, updated via IAM-controlled API calls, instead of manually syncing host files across every machine or operating and patching a DNS server yourself.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["lb"],
  },
  {
    type: "vpn",
    label: "Cloud VPN",
    shortLabel: "VPN",
    category: "networking",
    color: "gcp-blue",
    description: "Securely connects your on-premises network to your VPC through an IPsec VPN tunnel over the public internet.",
    learningNotes:
      "HA VPN provides a 99.99% SLA when configured with two interfaces/tunnels to a peer. Classic VPN (single tunnel, single external IP) only offers 99.9%. Cloud VPN encrypts traffic but rides over the public internet, unlike Interconnect which uses private connectivity.",
    tooltip: "Encrypted IPsec tunnel to on-prem or another cloud.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/vpn",
    terraformResourceType: "google_compute_vpn_gateway",
    configFields: [
      { key: "name", label: "Gateway Name", type: "text", required: true, placeholder: "prod-vpn" },
      { key: "vpnType", label: "Type", type: "select", options: [{ label: "HA VPN (99.99% SLA)", value: "HA" }, { label: "Classic VPN (99.9% SLA)", value: "CLASSIC" }] },
      { key: "peerIp", label: "Peer Gateway IP", type: "text", placeholder: "203.0.113.1" },
      { key: "sharedSecret", label: "Shared Secret", type: "text", placeholder: "••••••••" },
    ],
    defaultConfig: { name: "prod-vpn", vpnType: "HA", peerIp: "203.0.113.1", sharedSecret: "" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_ha_vpn_gateway" "${slug}" {
  name    = "${config.name}"
  network = google_compute_network.prod_vpc.id
}

resource "google_compute_external_vpn_gateway" "${slug}_peer" {
  name            = "${config.name}-peer"
  redundancy_type = "SINGLE_IP_INTERNALLY_REDUNDANT"
  interface {
    id         = 0
    ip_address = "${config.peerIp}"
  }
}`,
    estimateMonthlyCost: () => 36,
    troubleshooting: [
      { issue: "Tunnel status stuck at 'FIRST_HANDSHAKE'", cause: "Shared secret or peer IP mismatch", fix: "Verify identical pre-shared keys and correct peer gateway IP on both ends." },
    ],
    quiz: [
      { question: "Which Cloud VPN mode offers a 99.99% availability SLA?", options: ["Classic VPN", "HA VPN with two tunnels", "Any VPN with a static route", "Cloud NAT"], answerIndex: 1, explanation: "HA VPN with redundant tunnels/interfaces provides the 99.99% SLA.", difficulty: "beginner" },
      {
        question: "What protocol does Cloud VPN use to secure the tunnel between networks?",
        options: ["TLS", "IPsec", "SSH", "MACsec"],
        answerIndex: 1,
        explanation: "Cloud VPN establishes IPsec tunnels to encrypt traffic between your VPC and a peer network. TLS secures application-layer connections, not network-layer VPN tunnels.",
        difficulty: "beginner",
      },
      {
        question: "A VPN tunnel's status is stuck at 'FIRST_HANDSHAKE' and never progresses to Established. What's the most likely cause?",
        options: [
          "The Cloud Router's ASN is too high",
          "A shared secret (pre-shared key) or peer gateway IP mismatch between the two ends",
          "The subnet is in Auto mode",
          "DNSSEC is misconfigured on the peer",
        ],
        answerIndex: 1,
        explanation: "IPsec tunnel negotiation can't complete if both ends don't agree on the pre-shared key and are pointed at the correct peer IP — that's exactly the kind of mismatch that stalls the handshake before it establishes.",
        difficulty: "intermediate",
      },
      {
        question: "When would you choose Cloud VPN over Dedicated Interconnect for hybrid connectivity?",
        options: [
          "When you need the lowest possible latency and highest, most predictable throughput",
          "When you need to get connected quickly and cost-effectively over the public internet, and can tolerate internet-variable performance",
          "When you require a 100 Gbps dedicated physical circuit",
          "When your on-prem network has no internet connectivity at all",
        ],
        answerIndex: 1,
        explanation: "Cloud VPN can be provisioned in minutes over the existing internet connection with no physical circuit to arrange, making it ideal when speed of setup and lower cost matter more than guaranteed bandwidth and latency. Interconnect needs physical provisioning and internet reachability isn't a substitute for it — it's the opposite requirement.",
        difficulty: "intermediate",
      },
      {
        question: "To achieve HA VPN's 99.99% SLA, what topology is required?",
        options: [
          "A single tunnel to a single peer gateway IP",
          "Two tunnels connected to two different interfaces on a redundant HA VPN gateway",
          "A Classic VPN gateway using a static external IP",
          "Any VPN gateway, regardless of tunnel count",
        ],
        answerIndex: 1,
        explanation: "HA VPN's SLA depends on redundancy — two tunnels across two gateway interfaces so a single tunnel or interface failure doesn't take down connectivity. A single-tunnel setup, HA or Classic, only qualifies for the lower 99.9% SLA.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["router"],
  },
  {
    type: "interconnect",
    label: "Dedicated Interconnect",
    shortLabel: "Interconnect",
    category: "networking",
    color: "gcp-blue",
    description: "A private, physical connection between your on-premises network and Google's network — bypassing the public internet entirely.",
    learningNotes:
      "Interconnect offers higher throughput (10/100 Gbps circuits) and lower, more predictable latency than VPN since it never traverses the public internet. Partner Interconnect is available when a direct physical presence in a colocation facility isn't feasible. Combine with Cloud Router for dynamic BGP routing across the link.",
    tooltip: "Private physical link to Google's network, bypassing the internet.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/interconnect",
    terraformResourceType: "google_compute_interconnect_attachment",
    configFields: [
      { key: "name", label: "Attachment Name", type: "text", required: true, placeholder: "prod-interconnect" },
      { key: "type", label: "Type", type: "select", options: [{ label: "Dedicated", value: "DEDICATED" }, { label: "Partner", value: "PARTNER" }] },
      { key: "bandwidth", label: "Bandwidth", type: "select", options: [{ label: "10 Gbps", value: "BPS_10G" }, { label: "50 Gbps", value: "BPS_50G" }, { label: "100 Gbps", value: "BPS_100G" }] },
    ],
    defaultConfig: { name: "prod-interconnect", type: "DEDICATED", bandwidth: "BPS_10G" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_interconnect_attachment" "${slug}" {
  name                     = "${config.name}"
  type                     = "${config.type}"
  router                   = google_compute_router.prod_router.id
  bandwidth                = "${config.bandwidth}"
}`,
    estimateMonthlyCost: () => 1700,
    troubleshooting: [
      { issue: "Attachment stuck PENDING_CUSTOMER", cause: "LOA-CFA not completed with the colocation provider", fix: "Complete the Letter of Authorization / Connecting Facility Assignment with your provider." },
    ],
    quiz: [
      { question: "What is the main advantage of Dedicated Interconnect over Cloud VPN?", options: ["Cheaper for low bandwidth", "Bypasses the public internet with dedicated bandwidth", "No need for a Cloud Router", "Works over Wi-Fi"], answerIndex: 1, explanation: "Interconnect is a private physical link, avoiding public internet transit.", difficulty: "beginner" },
      {
        question: "What's the difference between Dedicated Interconnect and Partner Interconnect?",
        options: [
          "Dedicated requires a direct physical presence in a Google colocation facility; Partner Interconnect works through a supported service provider when that isn't feasible",
          "Partner Interconnect is always faster than Dedicated",
          "Dedicated Interconnect still routes over the public internet",
          "They are simply two pricing tiers of the same physical connection",
        ],
        answerIndex: 0,
        explanation: "Dedicated Interconnect needs your own equipment physically cross-connected in a Google colocation facility, while Partner Interconnect lets you reach Google's network through a supported partner when you don't have that physical presence.",
        difficulty: "beginner",
      },
      {
        question: "An Interconnect attachment is stuck in status PENDING_CUSTOMER. What is the required next step?",
        options: [
          "Wait for Google to automatically activate it",
          "Complete the Letter of Authorization / Connecting Facility Assignment (LOA-CFA) process with the colocation provider",
          "Attach a Cloud Router to the interconnect",
          "Increase the requested bandwidth",
        ],
        answerIndex: 1,
        explanation: "PENDING_CUSTOMER means Google is waiting on the customer to complete the physical cross-connect paperwork/process (LOA-CFA) with the colocation facility before the circuit can go live.",
        difficulty: "intermediate",
      },
      {
        question: "At roughly $1,700+/month for a 10 Gbps circuit, Dedicated Interconnect represents a significant fixed cost. For which kind of workload does this investment typically make sense compared to Cloud VPN?",
        options: [
          "A small startup doing occasional, low-bandwidth batch syncs",
          "Sustained, high-volume, latency-sensitive hybrid workloads — e.g. large-scale data migration or real-time replication — where consistent throughput justifies the fixed cost",
          "A single developer's personal test environment",
          "A workload that only needs outbound internet access",
        ],
        answerIndex: 1,
        explanation: "Interconnect's value is consistent, high-bandwidth, low-latency capacity — it pays off when data volume and performance requirements are sustained and large enough that internet-based VPN's variability and per-egress-GB costs would be worse in practice.",
        difficulty: "intermediate",
      },
      {
        question: "Why is Cloud Router typically paired with Dedicated Interconnect?",
        options: [
          "It adds encryption to the physical link",
          "It enables dynamic BGP route exchange across the interconnect attachment, keeping on-prem and GCP routes in sync without manual updates",
          "It's a prerequisite for completing the LOA-CFA process",
          "It replaces the need for an interconnect attachment entirely",
        ],
        answerIndex: 1,
        explanation: "Interconnect provides the physical/logical link, but Cloud Router supplies the BGP control plane so that route changes on either side propagate automatically — without it you'd be maintaining static routes by hand across a link meant for scale.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["router"],
  },
];

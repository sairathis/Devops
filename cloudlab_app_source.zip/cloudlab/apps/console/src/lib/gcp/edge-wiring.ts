// Makes a drawn Architecture Builder connection line functionally wire the
// two resources together, not just draw a cosmetic edge. Previously, the
// "this depends on that" link CloudLab's real provisioning needs came only
// from a dropdown inside the Config tab -- so dragging a line from a VPC to
// a Subnet *looked* like it connected them but didn't actually set the
// Subnet's "VPC Network" field, which is the actual source of truth every
// real create body (see lib/cloudlab/engine.ts) reads from. This closes that
// gap: connecting two nodes on the canvas now sets the appropriate
// resource-ref config field on the downstream node automatically.
import { ResourceConfig } from "@/types/gcp";
import { getResourceDef } from "@/lib/gcp";

export interface EdgeWiringResult {
  /** Config patch to apply to the target node, or null if no ref field on the target accepts this source's type. */
  patch: Partial<ResourceConfig> | null;
  /** Human label of the field that was set, for a toast/explanation. */
  fieldLabel?: string;
}

export function resolveEdgeWiring(
  sourceType: string,
  targetType: string,
  sourceNodeId: string,
  targetConfig: ResourceConfig,
): EdgeWiringResult {
  const targetDef = getResourceDef(targetType);
  if (!targetDef) return { patch: null };

  for (const field of targetDef.configFields) {
    if (!field.refTypes?.includes(sourceType)) continue;

    if (field.type === "resource-ref") {
      return { patch: { [field.key]: sourceNodeId }, fieldLabel: field.label };
    }
    if (field.type === "resource-ref-multi") {
      const existing = (targetConfig[field.key] as string[]) ?? [];
      if (existing.includes(sourceNodeId)) return { patch: null };
      return { patch: { [field.key]: [...existing, sourceNodeId] }, fieldLabel: field.label };
    }
  }
  return { patch: null };
}

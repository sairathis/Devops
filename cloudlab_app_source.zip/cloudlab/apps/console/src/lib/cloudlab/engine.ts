// Shared real-provisioning primitives used by both Architecture Builder
// (lib/cloudlab/provision.ts) and the GCP Services Console / Terraform Lab's
// Build & Apply tab (lib/cloudlab/console-provision.ts). Kept in one place so
// the CloudVerse-type -> CloudLab-type mapping, the CIDR workarounds, and the
// operation-polling logic have exactly one definition.
import { api, projectPath, ApiError } from "@/lib/api/client";

/** CloudVerse resourceType -> CloudLab resource `type` + its REST collection path. */
export const PROVISIONABLE: Record<string, { cloudlabType: string; path: string }> = {
  vpc: { cloudlabType: "network", path: "networks" },
  subnet: { cloudlabType: "subnet", path: "subnets" },
  vm: { cloudlabType: "instance", path: "instances" },
  gke: { cloudlabType: "k8s_cluster", path: "k8s-clusters" },
  gcs: { cloudlabType: "bucket", path: "buckets" },
  cloudsql: { cloudlabType: "database", path: "databases" },
  artifact_registry: { cloudlabType: "registry", path: "registries" },
  // Wired in as part of the Architecture Builder "full provisioning chain"
  // request -- these 5 types were already real on CloudLab's backend
  // (Milestones 1-16), they just weren't reachable from the canvas yet.
  nat: { cloudlabType: "nat_gateway", path: "nat-gateways" },
  dns: { cloudlabType: "dns_record", path: "dns-records" },
  lb: { cloudlabType: "load_balancer", path: "load-balancers" },
  instance_template: { cloudlabType: "instance_template", path: "instance-templates" },
  mig: { cloudlabType: "managed_instance_group", path: "managed-instance-groups" },
  // New canvas node types (previously missing from the palette entirely)
  // routed to the target the LB/MIG chain hands off to.
  cloud_run: { cloudlabType: "cloud_run_service", path: "cloud-run-services" },
  // composer's real create is a 2-step flow (pipeline, then environment) --
  // see createReal's special case below. `path` here is unused for it.
  composer: { cloudlabType: "composer_environment", path: "composer-environments" },
};

export function isProvisionable(resourceType: string): boolean {
  return resourceType in PROVISIONABLE;
}

interface OperationResult {
  status: string;
  error?: { message?: string };
}

export async function waitForOperation(projectId: string, operationId: string, timeoutMs = 90_000): Promise<OperationResult> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const op = await api.get<OperationResult>(projectPath(projectId, `/operations/${operationId}`));
    if (op.status === "SUCCEEDED" || op.status === "FAILED") return op;
    await new Promise((r) => setTimeout(r, 600));
  }
  throw new Error("Timed out waiting for CloudLab to finish provisioning this resource.");
}

export function randomVpcCidr(): string {
  // 10.<10-209>.0.0/16 -- CloudLab's own CIDR-collision check is host-wide
  // (Docker's IPAM pool is host-wide, not scoped per project -- see
  // apps/api/src/routes/networks.ts), and every network created without an
  // explicit cidr shares the same "172.30.0.0/24" default, so a second VPC
  // on this host would immediately collide. CloudVerse's own `vpc` node has
  // no CIDR field (real GCP auto-mode VPCs don't have one either -- CIDRs
  // live on the subnet), so pick a random /16 here instead.
  const octet = Math.floor(Math.random() * 200) + 10;
  return `10.${octet}.0.0/16`;
}

/**
 * CloudLab validates that a subnet's CIDR falls inside its parent network's
 * CIDR (real GCP does too). Since the VPC's own CIDR is a randomly generated
 * /16 (randomVpcCidr), CloudVerse's static per-resource default
 * ("10.0.1.0/24") won't generally fall inside it -- so keep whatever
 * third/fourth octets + mask were configured (or the CloudVerse default),
 * but graft them onto the VPC's actual first two octets.
 */
export function deriveContainedSubnetCidr(vpcCidr: string, requestedCidr: string): string {
  const vpcMatch = /^(\d+)\.(\d+)\./.exec(vpcCidr);
  const subMatch = /^\d+\.\d+\.(\d+\.\d+\/\d+)$/.exec(requestedCidr);
  if (!vpcMatch || !subMatch) return requestedCidr; // malformed -- let the real API reject it with a clear error
  return `${vpcMatch[1]}.${vpcMatch[2]}.${subMatch[1]}`;
}

export function zoneOf(region: unknown, zoneSuffix: unknown): string | undefined {
  if (!region) return undefined;
  return `${region}${zoneSuffix ?? "-a"}`;
}

/**
 * Every other provisionable node this one's config explicitly depends on (by
 * node id), in the order they must resolve first. Most types depend on at
 * most one thing (a subnet's VPC); the fuller chain (VPC -> Subnet -> LB ->
 * Instance Template -> MIG -> Cloud Run/Composer/GKE, +NAT +DNS) needs more
 * than one for a few types, so this always returns an array.
 */
export function dependencyKeys(resourceType: string, config: Record<string, unknown>): string[] {
  const deps: (string | undefined | false)[] = [];
  if (resourceType === "subnet") deps.push(config.vpcId as string);
  if (resourceType === "vm") deps.push(config.subnetId as string);
  if (resourceType === "nat") deps.push(config.vpcId as string);
  if (resourceType === "dns") deps.push(config.vpcId as string);
  if (resourceType === "cloud_run") deps.push(config.vpcId as string);
  if (resourceType === "lb") {
    deps.push(config.vpcId as string);
    // A MIG among the chosen backend targets must be real before the LB can
    // reference its real managedInstanceGroupId.
    const backendIds = (config.backendTargetIds as string[]) ?? [];
    deps.push(...backendIds);
  }
  if (resourceType === "mig") {
    deps.push(config.subnetId as string);
    deps.push(config.instanceTemplateId as string);
  }
  return deps.filter((d): d is string => Boolean(d));
}

/** @deprecated kept for any straggling single-dependency callers; prefer dependencyKeys. */
export function dependencyKey(resourceType: string, config: Record<string, unknown>): string | undefined {
  return dependencyKeys(resourceType, config)[0];
}

export interface ResolvedRefs {
  resourceId: (key: string) => string | undefined;
  networkIdOfSubnet: (key: string) => string | undefined;
  cidrOfVpc: (key: string) => string | undefined;
  /** Node-type lookup for a node id, needed to tell a MIG backend target apart from a plain VM one. */
  nodeType?: (key: string) => string | undefined;
}

/** Builds the exact POST body each CloudLab route expects, or null when a required link isn't resolved yet. */
export function buildProvisionBody(
  resourceType: string,
  config: Record<string, unknown>,
  label: string,
  refs: ResolvedRefs,
): Record<string, unknown> | null {
  const cfg = config ?? {};
  const name = (cfg.name as string) || label;

  switch (resourceType) {
    case "vpc":
      return { name, cidr: randomVpcCidr() };

    case "subnet": {
      const vpcKey = cfg.vpcId as string | undefined;
      if (!vpcKey) return null;
      const networkId = refs.resourceId(vpcKey);
      const vpcCidr = refs.cidrOfVpc(vpcKey);
      if (!networkId || !vpcCidr) return null;
      const requestedCidr = (cfg.ipCidrRange as string) || "10.0.1.0/24";
      return {
        name,
        networkId,
        cidr: deriveContainedSubnetCidr(vpcCidr, requestedCidr),
        region: (cfg.region as string) || undefined,
      };
    }

    case "vm": {
      const subnetKey = cfg.subnetId as string | undefined;
      if (!subnetKey) return null;
      const subnetId = refs.resourceId(subnetKey);
      const networkId = refs.networkIdOfSubnet(subnetKey);
      if (!subnetId || !networkId) return null;
      return {
        name,
        networkId,
        subnetId,
        zone: zoneOf(cfg.region, cfg.zone),
        machineType: (cfg.machineType as string) || undefined,
      };
    }

    case "gke":
      return { name, nodeCount: typeof cfg.nodeCount === "number" ? cfg.nodeCount : undefined };

    case "gcs":
    case "cloudsql":
    case "artifact_registry":
      return { name };

    case "instance_template":
      return { name, image: (cfg.image as string) || undefined, publish: cfg.publish === true };

    case "nat": {
      const vpcKey = cfg.vpcId as string | undefined;
      if (!vpcKey) return null;
      const networkResourceId = refs.resourceId(vpcKey);
      if (!networkResourceId) return null;
      return { name, networkResourceId };
    }

    case "dns": {
      const vpcKey = cfg.vpcId as string | undefined;
      if (!vpcKey) return null;
      const networkId = refs.resourceId(vpcKey);
      if (!networkId) return null;
      const hostname = (cfg.hostname as string) || (cfg.dnsName as string) || `${name}.internal`;
      const ip = (cfg.targetIp as string) || "10.0.0.10";
      return { name, networkId, hostname, ip };
    }

    case "cloud_run": {
      const vpcKey = cfg.vpcId as string | undefined;
      if (!vpcKey) return null;
      const networkId = refs.resourceId(vpcKey);
      if (!networkId) return null;
      return {
        name,
        networkId,
        image: (cfg.image as string) || undefined,
        idleTimeoutSeconds: typeof cfg.idleTimeoutSeconds === "number" ? cfg.idleTimeoutSeconds : undefined,
      };
    }

    case "mig": {
      const subnetKey = cfg.subnetId as string | undefined;
      const templateKey = cfg.instanceTemplateId as string | undefined;
      if (!subnetKey || !templateKey) return null;
      const networkId = refs.networkIdOfSubnet(subnetKey);
      const instanceTemplateId = refs.resourceId(templateKey);
      if (!networkId || !instanceTemplateId) return null;
      const targetSize = Math.max(1, Math.min(10, Number(cfg.minReplicas) || 1));
      return { name, instanceTemplateId, networkId, targetSize };
    }

    case "lb": {
      const vpcKey = cfg.vpcId as string | undefined;
      if (!vpcKey) return null;
      const networkId = refs.resourceId(vpcKey);
      if (!networkId) return null;
      const backendIds = (cfg.backendTargetIds as string[]) ?? [];
      // A real load balancer can target either a single Managed Instance
      // Group (its live member set) or a fixed list of instance ids -- not
      // both. Prefer the first backend target that's a real, resolved MIG;
      // otherwise fall back to whichever backend targets are real VMs.
      const migKey = backendIds.find((k) => refs.nodeType?.(k) === "mig" && refs.resourceId(k));
      const managedInstanceGroupId = migKey ? refs.resourceId(migKey) : undefined;
      const backendInstanceIds = managedInstanceGroupId
        ? []
        : backendIds.map((k) => refs.resourceId(k)).filter((id): id is string => Boolean(id));
      return { name, networkId, backendInstanceIds, managedInstanceGroupId, publish: true };
    }

    case "composer":
      // Handled entirely by createReal's 2-step special case (a real backing
      // `pipeline` resource is created first) -- this body only carries the
      // fields createReal needs to do that.
      return { name, schedule: (cfg.schedule as string) || "0 * * * *" };

    default:
      return null;
  }
}

/** Best-effort real delete, mirroring a simulated resource's deletion so a real Docker container / Postgres row doesn't leak. */
export async function deleteReal(projectId: string, resourceType: string, resourceId: string, extra?: { pipelineId?: string }): Promise<void> {
  const entry = PROVISIONABLE[resourceType];
  if (!entry) return;
  try {
    const res = await api.delete<{ operationId: string }>(projectPath(projectId, `/${entry.path}/${resourceId}`));
    if (res?.operationId) await waitForOperation(projectId, res.operationId).catch(() => {});
  } catch {
    // Best-effort: the resource may already be gone, or this call may race the
    // console's own optimistic UI. Nothing to surface -- the simulated
    // deletion (which the user sees) always proceeds regardless.
  }
  // Composer's real backing `pipeline` resource has no independent life on
  // the canvas -- clean it up alongside the environment it belongs to.
  if (resourceType === "composer" && extra?.pipelineId) {
    try {
      const res = await api.delete<{ operationId: string }>(projectPath(projectId, `/pipelines/${extra.pipelineId}`));
      if (res?.operationId) await waitForOperation(projectId, res.operationId).catch(() => {});
    } catch {
      // best-effort, same as above
    }
  }
}

export interface CreateOutcome {
  status: "ready" | "failed";
  resourceId?: string;
  networkId?: string; // set when resourceType === "subnet"
  cidr?: string; // set when resourceType === "vpc"
  /** set when resourceType === "composer" -- the auto-created backing `pipeline` resource, needed to clean it up on delete. */
  pipelineId?: string;
  error?: string;
}

/** Fires one real create + waits for its operation. Callers own dependency ordering. */
export async function createReal(
  projectId: string,
  resourceType: string,
  body: Record<string, unknown>,
): Promise<CreateOutcome> {
  if (resourceType === "composer") return createComposerReal(projectId, body);
  const { path } = PROVISIONABLE[resourceType];
  try {
    const res = await api.post<{ resource: { id: string }; operationId: string }>(projectPath(projectId, `/${path}`), body);
    const op = await waitForOperation(projectId, res.operationId);
    if (op.status !== "SUCCEEDED") throw new Error(op.error?.message || "CloudLab reported the operation failed.");
    return {
      status: "ready",
      resourceId: res.resource.id,
      networkId: resourceType === "subnet" ? (body.networkId as string) : undefined,
      cidr: resourceType === "vpc" ? (body.cidr as string) : undefined,
    };
  } catch (err) {
    const message = err instanceof ApiError ? err.body.message : err instanceof Error ? err.message : "Provisioning failed.";
    return { status: "failed", error: message };
  }
}

/**
 * Cloud Composer's real backend (composer-environments) requires an
 * existing `pipeline` resource id -- there's no canvas node for "the
 * pipeline a Composer environment runs", so a minimal one is created
 * automatically first, then the environment is created pointing at it.
 * Both steps are genuinely real (real Postgres rows, a real 5-field UTC
 * cron schedule evaluated by apps/worker/src/composer/scheduler.ts).
 */
async function createComposerReal(projectId: string, body: Record<string, unknown>): Promise<CreateOutcome> {
  const name = body.name as string;
  const schedule = (body.schedule as string) || "0 * * * *";
  try {
    const pipelineRes = await api.post<{ resource: { id: string }; operationId: string }>(
      projectPath(projectId, "/pipelines"),
      { name: `${name}-pipeline`, stages: [{ name: "run", command: "echo 'Composer-triggered DAG run'" }] },
    );
    const pipelineOp = await waitForOperation(projectId, pipelineRes.operationId);
    if (pipelineOp.status !== "SUCCEEDED") throw new Error(pipelineOp.error?.message || "Could not create the pipeline this Composer environment runs.");

    const envRes = await api.post<{ resource: { id: string }; operationId: string }>(
      projectPath(projectId, "/composer-environments"),
      { name, pipelineId: pipelineRes.resource.id, schedule },
    );
    const envOp = await waitForOperation(projectId, envRes.operationId);
    if (envOp.status !== "SUCCEEDED") throw new Error(envOp.error?.message || "CloudLab reported the operation failed.");

    return { status: "ready", resourceId: envRes.resource.id, pipelineId: pipelineRes.resource.id };
  } catch (err) {
    const message = err instanceof ApiError ? err.body.message : err instanceof Error ? err.message : "Provisioning failed.";
    return { status: "failed", error: message };
  }
}

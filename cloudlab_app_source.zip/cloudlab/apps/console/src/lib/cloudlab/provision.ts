// Sends an Architecture Builder diagram to CloudLab's real API and drives
// each supported node through the same create -> operation -> READY/FAILED
// lifecycle every other CloudLab client goes through. The actual REST calls,
// type mapping and CIDR handling live in lib/cloudlab/engine.ts, shared with
// the GCP Services Console / Terraform Lab wiring (lib/cloudlab/console-provision.ts).
//
// Only resource types where CloudVerse's own config fields already carry an
// explicit link to their dependency are wired for real (a subnet's chosen
// VPC, a VM's chosen subnet). Cloud Armor, Cloud Router, VPN, Interconnect,
// Memorystore, Pub/Sub and Cloud Build have no CloudLab equivalent; NAT
// Gateway, Load Balancer, Managed Instance Group and Cloud DNS do have one,
// but CloudVerse's canvas doesn't yet capture the specific link CloudLab's
// API requires for them (a NAT gateway's network, a load balancer's real
// backend instance ids, a MIG's instance template, an A-record's zone) --
// those stay simulated rather than being wired with a guessed mapping.
import type { ArchNode } from "@/store/architecture-store";
import type { ProvisionStatus } from "@/types/gcp";
import { buildProvisionBody, createReal, dependencyKeys, isProvisionable, type ResolvedRefs } from "@/lib/cloudlab/engine";

export { isProvisionable };

export interface ProvisionOutcome {
  nodeId: string;
  label: string;
  status: ProvisionStatus;
  resourceId?: string;
  error?: string;
}

export async function provisionDiagram(
  projectId: string,
  allNodes: ArchNode[],
  onUpdate: (nodeId: string, patch: { provisionStatus: ProvisionStatus; cloudlabResourceId?: string; cloudlabPipelineId?: string; provisionError?: string }) => void,
): Promise<ProvisionOutcome[]> {
  const targets = allNodes.filter((n) => isProvisionable(n.data.resourceType));
  targets.forEach((n) => onUpdate(n.id, { provisionStatus: "pending" }));

  const nodeIdToResourceId = new Map<string, string>();
  const subnetNodeIdToNetworkId = new Map<string, string>();
  const vpcNodeIdToCidr = new Map<string, string>();
  const nodeIdToType = new Map(allNodes.map((n) => [n.id, n.data.resourceType]));
  const nodeIdToPipelineId = new Map<string, string>();
  const outcomes: ProvisionOutcome[] = [];

  const refs: ResolvedRefs = {
    resourceId: (nodeId) => nodeIdToResourceId.get(nodeId),
    networkIdOfSubnet: (nodeId) => subnetNodeIdToNetworkId.get(nodeId),
    cidrOfVpc: (nodeId) => vpcNodeIdToCidr.get(nodeId),
    nodeType: (nodeId) => nodeIdToType.get(nodeId),
  };

  let remaining = [...targets];
  let progressed = true;

  while (remaining.length > 0 && progressed) {
    progressed = false;
    for (let i = remaining.length - 1; i >= 0; i--) {
      const node = remaining[i];
      const depIds = dependencyKeys(node.data.resourceType, node.data.config ?? {});
      // Wait for every in-scope dependency to resolve before attempting this node.
      const blockedOn = depIds.filter((depId) => targets.some((t) => t.id === depId) && !nodeIdToResourceId.has(depId));
      if (blockedOn.length > 0) continue;

      const body = buildProvisionBody(node.data.resourceType, node.data.config ?? {}, node.data.label, refs);

      if (!body) {
        const error = "Missing a required link on the canvas (choose a VPC / Subnet / Instance Template in the Config tab, or draw a connection from one) before provisioning.";
        onUpdate(node.id, { provisionStatus: "skipped", provisionError: error });
        outcomes.push({ nodeId: node.id, label: node.data.label, status: "skipped", error });
        remaining.splice(i, 1);
        progressed = true;
        continue;
      }

      onUpdate(node.id, { provisionStatus: "creating" });
      const result = await createReal(projectId, node.data.resourceType, body);
      if (result.status === "ready" && result.resourceId) {
        nodeIdToResourceId.set(node.id, result.resourceId);
        if (result.networkId) subnetNodeIdToNetworkId.set(node.id, result.networkId);
        if (result.cidr) vpcNodeIdToCidr.set(node.id, result.cidr);
        if (result.pipelineId) nodeIdToPipelineId.set(node.id, result.pipelineId);
        onUpdate(node.id, { provisionStatus: "ready", cloudlabResourceId: result.resourceId, cloudlabPipelineId: result.pipelineId });
        outcomes.push({ nodeId: node.id, label: node.data.label, status: "ready", resourceId: result.resourceId });
      } else {
        onUpdate(node.id, { provisionStatus: "failed", provisionError: result.error });
        outcomes.push({ nodeId: node.id, label: node.data.label, status: "failed", error: result.error });
      }
      remaining.splice(i, 1);
      progressed = true;
    }
  }

  // Left over only because a dependency in front of it failed/was skipped.
  for (const node of remaining) {
    const error = "A resource this depends on did not provision successfully.";
    onUpdate(node.id, { provisionStatus: "skipped", provisionError: error });
    outcomes.push({ nodeId: node.id, label: node.data.label, status: "skipped", error });
  }

  return outcomes;
}

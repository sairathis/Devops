// Shared "run a real test against this resource" actions, used by the GCP
// Services Console's resource detail panel, Architecture Builder's
// inspector, and Terraform Lab's resource rows -- one definition so the set
// of resource types that can genuinely be tested (vs. simulated only) never
// drifts between the three surfaces.
import { api, projectPath, ApiError } from "@/lib/api/client";

export type TestableType = "vm" | "cloud_run" | "gcs" | "registry_image" | "k8s_deployment";

const TESTABLE: Record<string, TestableType> = {
  vm: "vm",
  instance: "vm", // console-store / Terraform Lab spell it "vm" too, kept for safety
  cloud_run: "cloud_run",
  cloud_run_service: "cloud_run",
  gcs: "gcs",
  bucket: "gcs",
  container_image: "registry_image", // Docker Lab's real build+push (see lab-provision.ts)
  k8s_deployment: "k8s_deployment", // Kubernetes Lab's real per-pod deployment (see lab-provision.ts)
};

export function testableKind(resourceType: string): TestableType | null {
  return TESTABLE[resourceType] ?? null;
}

export interface TestStepResult {
  label: string;
  ok: boolean;
  detail: string;
}

export interface TestRunResult {
  ok: boolean;
  steps: TestStepResult[];
}

/** A previously-run test, as persisted by the API (routes/testRuns.ts) and read back by RealTestPanel. */
export interface StoredTestRun extends TestRunResult {
  id: string;
  kind: TestableType;
  ranAt: string;
}

function errMessage(err: unknown): string {
  if (err instanceof ApiError) return err.body.message;
  if (err instanceof Error) return err.message;
  return "Request failed.";
}

/** VM: fetch real logs + real live stats, then run a real command over the real Docker exec API. */
async function testVm(projectId: string, resourceId: string): Promise<TestRunResult> {
  const steps: TestStepResult[] = [];

  try {
    const { logs } = await api.get<{ logs: string }>(projectPath(projectId, `/instances/${resourceId}/logs`));
    steps.push({ label: "Fetch real container logs", ok: true, detail: logs ? `${logs.split("\n").length} lines returned` : "No logs yet" });
  } catch (err) {
    steps.push({ label: "Fetch real container logs", ok: false, detail: errMessage(err) });
  }

  try {
    const stats = await api.get<{ cpuPercent: number; memUsageMb: number; memLimitMb: number }>(
      projectPath(projectId, `/instances/${resourceId}/stats`),
    );
    steps.push({
      label: "Fetch real live CPU/memory stats",
      ok: true,
      detail: `CPU ${stats.cpuPercent?.toFixed?.(1) ?? stats.cpuPercent}% · Mem ${stats.memUsageMb}/${stats.memLimitMb} MB`,
    });
  } catch (err) {
    steps.push({ label: "Fetch real live CPU/memory stats", ok: false, detail: errMessage(err) });
  }

  try {
    const result = await api.post<{ exitCode: number; output: string }>(
      projectPath(projectId, `/instances/${resourceId}/exec`),
      { command: "echo cloudverse-test-ok && uptime" },
    );
    steps.push({
      label: "Run a real command inside the instance (docker exec)",
      ok: result.exitCode === 0,
      detail: result.output?.trim() || `exit code ${result.exitCode}`,
    });
  } catch (err) {
    steps.push({ label: "Run a real command inside the instance (docker exec)", ok: false, detail: errMessage(err) });
  }

  return { ok: steps.every((s) => s.ok), steps };
}

/** Cloud Run: real invoke, which cold-starts the container if needed and makes a real HTTP request to it. */
async function testCloudRun(projectId: string, resourceId: string): Promise<TestRunResult> {
  const steps: TestStepResult[] = [];
  try {
    const result = await api.post<{ coldStart: boolean; invokeStatus: string; publicUrl: string | null }>(
      projectPath(projectId, `/cloud-run-services/${resourceId}/invoke`),
    );
    steps.push({
      label: result.coldStart ? "Cold-start the container and invoke it" : "Invoke the warm container",
      ok: result.invokeStatus === "ok",
      detail: `${result.invokeStatus}${result.publicUrl ? ` · reachable at ${result.publicUrl}` : ""}`,
    });
  } catch (err) {
    steps.push({ label: "Invoke the service", ok: false, detail: errMessage(err) });
  }
  return { ok: steps.every((s) => s.ok), steps };
}

/** Cloud Storage bucket: a real end-to-end PUT -> GET -> DELETE round trip against the bucket's real object-store container. */
async function testBucket(projectId: string, resourceId: string): Promise<TestRunResult> {
  const steps: TestStepResult[] = [];
  const key = `cloudverse-test-${Date.now()}.txt`;
  const content = `CloudVerse real object test written at ${new Date().toISOString()}`;

  try {
    await api.put(projectPath(projectId, `/buckets/${resourceId}/objects/${encodeURIComponent(key)}`), { content });
    steps.push({ label: `Upload a real test object (${key})`, ok: true, detail: `${content.length} bytes written to disk` });
  } catch (err) {
    steps.push({ label: "Upload a real test object", ok: false, detail: errMessage(err) });
    return { ok: false, steps };
  }

  try {
    const got = await api.get<{ content: string }>(projectPath(projectId, `/buckets/${resourceId}/objects/${encodeURIComponent(key)}`));
    steps.push({ label: "Download it back", ok: got.content === content, detail: got.content === content ? "Round-trip matched byte-for-byte" : "Content mismatch" });
  } catch (err) {
    steps.push({ label: "Download it back", ok: false, detail: errMessage(err) });
  }

  try {
    await api.delete(projectPath(projectId, `/buckets/${resourceId}/objects/${encodeURIComponent(key)}`));
    steps.push({ label: "Delete the test object", ok: true, detail: "Removed from disk" });
  } catch (err) {
    steps.push({ label: "Delete the test object", ok: false, detail: errMessage(err) });
  }

  return { ok: steps.every((s) => s.ok), steps };
}

/** Docker Lab image: a real GET of the build/push result -- genuine digest and pull command from the real registry push, not a guess. */
async function testRegistryImage(projectId: string, resourceId: string): Promise<TestRunResult> {
  const steps: TestStepResult[] = [];
  try {
    const resource = await api.get<{ status: string; metadata?: { fullTag?: string; digest?: string; pullCommand?: string } }>(
      projectPath(projectId, `/images/${resourceId}`),
    );
    const meta = resource.metadata ?? {};
    steps.push({
      label: "Fetch the real build + push result",
      ok: resource.status === "READY",
      detail: resource.status === "READY"
        ? `${meta.fullTag ?? "(no tag recorded)"} — digest ${meta.digest ?? "(none)"}`
        : `Image status: ${resource.status}`,
    });
    if (resource.status === "READY" && meta.pullCommand) {
      steps.push({ label: "Real pull command (verify by running it against a Docker Hub-reachable host)", ok: true, detail: meta.pullCommand });
    }
  } catch (err) {
    steps.push({ label: "Fetch the real build + push result", ok: false, detail: errMessage(err) });
  }
  return { ok: steps.every((s) => s.ok), steps };
}

/** Kubernetes Lab deployment: a real GET verifying the desired replica count actually has that many real Docker containers running as pods. */
async function testK8sDeployment(projectId: string, resourceId: string): Promise<TestRunResult> {
  const steps: TestStepResult[] = [];
  try {
    const resource = await api.get<{ status: string; metadata?: { replicas?: number; podContainerIds?: string[]; clusterName?: string; image?: string } }>(
      projectPath(projectId, `/k8s-deployments/${resourceId}`),
    );
    const meta = resource.metadata ?? {};
    const desired = meta.replicas ?? 0;
    const actual = meta.podContainerIds?.length ?? 0;
    steps.push({
      label: "Fetch real deployment status from CloudLab",
      ok: resource.status === "READY",
      detail: `${resource.status} on cluster ${meta.clusterName ?? "(unknown)"} — image ${meta.image ?? "(unknown)"}`,
    });
    steps.push({
      label: "Verify real pod containers match the desired replica count",
      ok: actual === desired && desired > 0,
      detail: `${actual} real Docker container(s) running / ${desired} desired`,
    });
  } catch (err) {
    steps.push({ label: "Fetch real deployment status from CloudLab", ok: false, detail: errMessage(err) });
  }
  return { ok: steps.every((s) => s.ok), steps };
}

/**
 * Runs the real test for this resource type, then persists the outcome via
 * POST .../test-runs (routes/testRuns.ts) so a reopened RealTestPanel can
 * show it as history instead of it vanishing when the panel closes.
 * Persistence failures are swallowed (best-effort logging, same spirit as
 * the metrics collector) -- the caller always gets the real test outcome
 * regardless of whether saving it succeeded.
 */
export async function runResourceTest(projectId: string, resourceType: string, resourceId: string): Promise<TestRunResult> {
  const kind = testableKind(resourceType);
  let result: TestRunResult;
  if (kind === "vm") result = await testVm(projectId, resourceId);
  else if (kind === "cloud_run") result = await testCloudRun(projectId, resourceId);
  else if (kind === "gcs") result = await testBucket(projectId, resourceId);
  else if (kind === "registry_image") result = await testRegistryImage(projectId, resourceId);
  else if (kind === "k8s_deployment") result = await testK8sDeployment(projectId, resourceId);
  else return { ok: false, steps: [{ label: "No real test available", ok: false, detail: "This resource type has no real test endpoint on CloudLab yet." }] };

  try {
    await api.post(projectPath(projectId, `/resources/${resourceId}/test-runs`), { kind, ok: result.ok, steps: result.steps });
  } catch {
    // Non-fatal: the test itself already ran for real against the live
    // resource above -- losing the history record shouldn't hide that.
  }
  return result;
}

/** Loads the persisted history of real test runs for this resource, most recent first. */
export async function loadTestRunHistory(projectId: string, resourceId: string, limit = 10): Promise<StoredTestRun[]> {
  return api.get<StoredTestRun[]>(projectPath(projectId, `/resources/${resourceId}/test-runs?limit=${limit}`));
}

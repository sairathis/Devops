// Additive real-provisioning hook for the GCP Services Console and Terraform
// Lab's Build & Apply tab (both create resources through
// useGcpConsoleStore.createResource -- see store/gcp-console-store.ts).
//
// This deliberately does NOT change createResource's existing simulated
// timeline, logs, or return value in any way, because that store is also
// shared by Demo Architectures, the CI/CD Simulator, and Operations Suite --
// modules the approved plan keeps simulated this milestone. Instead, this
// module is called *alongside* the simulation, fire-and-forget, and only
// ever does something when:
//   1. the resource's type is one of the 7 CloudVerse types CloudLab can
//      actually provision (see lib/cloudlab/engine.ts's PROVISIONABLE), AND
//   2. every resource-ref its config points at (a chosen VPC, a chosen
//      Subnet) is ITSELF already real (has a cloudlabResourceId).
// Anything else -- Cloud Armor, a Demo Architecture's one-click deploy, a
// CI/CD panel's deployment target, a VM with no subnet chosen yet -- resolves
// to "skipped" here with no API call and no user-visible change: it keeps
// behaving exactly as it did before this feature existed.
import { useAuthStore } from "@/store/auth-store";
import { buildProvisionBody, createReal, isProvisionable, type ResolvedRefs } from "@/lib/cloudlab/engine";
import type { ConsoleResource } from "@/store/gcp-console-store";

export { isProvisionable };

export interface CloudlabAttempt {
  status: "ready" | "failed" | "skipped";
  resourceId?: string;
  networkId?: string;
  cidr?: string;
  error?: string;
  /** Composer only: the real backing `pipeline` resource id, needed later to clean it up on delete. */
  pipelineId?: string;
}

/**
 * Best-effort: try to create the real CloudLab counterpart of a
 * just-created (simulated) ConsoleResource. `allResources` is the full
 * console resource list *including* the new one, used to resolve its
 * resource-ref config fields (vpcId/subnetId) to their real CloudLab ids.
 */
export async function attemptRealProvision(
  resource: ConsoleResource,
  allResources: ConsoleResource[],
): Promise<CloudlabAttempt> {
  if (!isProvisionable(resource.type)) return { status: "skipped" };

  const projectId = useAuthStore.getState().projectId;
  if (!projectId) return { status: "skipped" };

  const byId = new Map(allResources.map((r) => [r.id, r]));
  const refs: ResolvedRefs = {
    resourceId: (id) => byId.get(id)?.cloudlabResourceId,
    networkIdOfSubnet: (id) => byId.get(id)?.cloudlabNetworkId,
    cidrOfVpc: (id) => byId.get(id)?.cloudlabCidr,
  };

  const body = buildProvisionBody(resource.type, resource.config, resource.name, refs);
  if (!body) return { status: "skipped" };

  const result = await createReal(projectId, resource.type, body);
  if (result.status === "ready") {
    return {
      status: "ready",
      resourceId: result.resourceId,
      networkId: result.networkId,
      cidr: result.cidr,
      pipelineId: result.pipelineId,
    };
  }
  return { status: "failed", error: result.error };
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { api } from "@/lib/api/client";
import { useCertificationStore } from "@/store/certification-store";

export interface ModuleProgress {
  moduleId: string;
  percent: number;
  xp: number;
  lastVisited: string;
}

export interface Badge {
  id: string;
  label: string;
  description: string;
  icon: string;
  earnedAt: string;
}

interface AcademySnapshot {
  totalXp: number;
  level: number;
  streakDays: number;
  lastActiveDate: string | null;
  modules: Record<string, { moduleId: string; percent: number; xp: number; lastVisited: string | null }>;
  quizScores: Record<string, { correct: number; total: number }>;
  badges: { id: string; label: string; description: string; icon: string; earnedAt: string }[];
  completedTopics: Record<string, boolean>;
}

interface ProgressState {
  modules: Record<string, ModuleProgress>;
  totalXp: number;
  level: number;
  badges: Badge[];
  streakDays: number;
  lastActiveDate: string | null;
  quizScores: Record<string, { correct: number; total: number }>;
  /** Set once this session's localStorage state has been reconciled against CloudLab's real academy API. */
  serverHydrated: boolean;
  setModuleProgress: (moduleId: string, percent: number) => void;
  addXp: (amount: number) => void;
  awardBadge: (badge: Omit<Badge, "earnedAt">) => void;
  recordQuizResult: (topic: string, correct: number, total: number) => void;
  touchStreak: () => void;
  resetProgress: () => void;
  /** Reconciles localStorage state against the real per-user rows CloudLab's API now keeps (see apps/api/src/routes/academy.ts), pushing up anything local-only. Call once per sign-in. Best-effort: never throws. */
  hydrateFromServer: () => Promise<void>;
}

const LEVEL_XP = 500;

// Fire-and-forget helpers: this module is the single place that talks to the
// real academy API, so every call site above (create-wizard, quiz-card,
// architecture toolbar, etc.) keeps working unchanged against local state,
// while this store additionally makes it durable server-side, per-account,
// in Postgres -- instead of only ever living in this one browser's
// localStorage. Failures (offline, not-yet-authenticated, etc.) are swallowed
// -- the local, always-available state is still the source of truth for the
// UI on this device.
function syncModuleProgress(moduleId: string, percent: number) {
  api.post(`/academy/modules/${encodeURIComponent(moduleId)}/progress`, { percent }).catch(() => {});
}
function syncXp(amount: number): Promise<{ totalXp: number; level: number; streakDays: number; lastActiveDate: string } | null> {
  return api
    .post<{ totalXp: number; level: number; streakDays: number; lastActiveDate: string }>("/academy/xp", { amount })
    .catch(() => null);
}
function syncQuiz(subjectKey: string, correct: boolean) {
  api.post("/academy/quiz", { subjectKey, correct }).catch(() => {});
}
function syncBadge(badge: Omit<Badge, "earnedAt">) {
  api.post("/academy/badges", { badgeKey: badge.id, label: badge.label, description: badge.description, icon: badge.icon }).catch(() => {});
}

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      modules: {},
      totalXp: 0,
      level: 1,
      badges: [],
      streakDays: 1,
      lastActiveDate: null,
      quizScores: {},
      serverHydrated: false,

      setModuleProgress: (moduleId, percent) => {
        const nextPercent = Math.max(percent, get().modules[moduleId]?.percent ?? 0);
        set({
          modules: {
            ...get().modules,
            [moduleId]: {
              moduleId,
              percent: nextPercent,
              xp: get().modules[moduleId]?.xp ?? 0,
              lastVisited: new Date().toISOString(),
            },
          },
        });
        syncModuleProgress(moduleId, nextPercent);
      },

      addXp: (amount) => {
        const newXp = get().totalXp + amount;
        set({ totalXp: newXp, level: Math.max(1, Math.floor(newXp / LEVEL_XP) + 1) });
        // The server derives real streak-day continuity from wall-clock
        // dates (see academy.ts's daysBetween) -- reconcile it back in once
        // it responds, so the streak shown in the topbar is real rather than
        // permanently stuck at its initial value.
        void syncXp(amount).then((res) => {
          if (!res) return;
          set({ totalXp: res.totalXp, level: res.level, streakDays: res.streakDays, lastActiveDate: res.lastActiveDate });
        });
      },

      awardBadge: (badge) => {
        if (get().badges.some((b) => b.id === badge.id)) return;
        set({ badges: [...get().badges, { ...badge, earnedAt: new Date().toISOString() }] });
        syncBadge(badge);
      },

      recordQuizResult: (topic, correct, total) => {
        const prev = get().quizScores[topic] ?? { correct: 0, total: 0 };
        set({
          quizScores: {
            ...get().quizScores,
            [topic]: { correct: prev.correct + correct, total: prev.total + total },
          },
        });
        // Every call site answers exactly one question at a time (total===1);
        // that's the shape /academy/quiz records. A future caller batching
        // multiple questions in one call would just skip the real sync here,
        // never lose the local tally.
        if (total === 1) syncQuiz(topic, correct > 0);
      },

      touchStreak: () => {
        const today = new Date().toDateString();
        const last = get().lastActiveDate;
        if (last === today) return;
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        set({
          streakDays: last === yesterday ? get().streakDays + 1 : 1,
          lastActiveDate: today,
        });
      },

      resetProgress: () =>
        set({ modules: {}, totalXp: 0, level: 1, badges: [], streakDays: 1, lastActiveDate: null, quizScores: {} }),

      hydrateFromServer: async () => {
        if (get().serverHydrated) return;
        try {
          const snapshot = await api.get<AcademySnapshot>("/academy/progress");
          const local = get();

          // Reconcile module-by-module: whichever side is further along wins
          // locally, and if the local browser was ahead (e.g. progress made
          // before this account had real academy rows), push it up so it
          // becomes durable instead of getting silently dropped.
          const mergedModules: Record<string, ModuleProgress> = { ...snapshot.modules } as unknown as Record<string, ModuleProgress>;
          for (const [moduleId, localMod] of Object.entries(local.modules)) {
            const serverMod = snapshot.modules[moduleId];
            const percent = Math.max(localMod.percent, serverMod?.percent ?? 0);
            const xp = Math.max(localMod.xp, serverMod?.xp ?? 0);
            mergedModules[moduleId] = { moduleId, percent, xp, lastVisited: localMod.lastVisited };
            if (percent > (serverMod?.percent ?? 0)) syncModuleProgress(moduleId, percent);
          }

          const mergedBadges: Badge[] = [...snapshot.badges];
          for (const localBadge of local.badges) {
            if (!mergedBadges.some((b) => b.id === localBadge.id)) {
              mergedBadges.push(localBadge);
              syncBadge(localBadge);
            }
          }

          const mergedQuizScores: Record<string, { correct: number; total: number }> = { ...snapshot.quizScores };
          for (const [topic, localScore] of Object.entries(local.quizScores)) {
            const serverScore = snapshot.quizScores[topic];
            mergedQuizScores[topic] = {
              correct: Math.max(localScore.correct, serverScore?.correct ?? 0),
              total: Math.max(localScore.total, serverScore?.total ?? 0),
            };
          }

          const totalXp = Math.max(local.totalXp, snapshot.totalXp);
          if (local.totalXp > snapshot.totalXp) void syncXp(local.totalXp - snapshot.totalXp);

          set({
            modules: mergedModules,
            badges: mergedBadges,
            quizScores: mergedQuizScores,
            totalXp,
            level: Math.max(1, Math.floor(totalXp / LEVEL_XP) + 1),
            streakDays: snapshot.streakDays || local.streakDays,
            lastActiveDate: snapshot.lastActiveDate ?? local.lastActiveDate,
            serverHydrated: true,
          });

          // The same snapshot carries certification-path completions -- feed
          // them to that store too so one sign-in reconciles everything in
          // a single round trip.
          useCertificationStore.getState().hydrateFromServer(snapshot.completedTopics);
        } catch {
          // Offline, or the API is briefly unreachable -- keep going on
          // local state only; serverHydrated flips back to false on logout
          // (see auth-store.ts's logout), so the next sign-in retries.
        }
      },
    }),
    {
      name: "cloudverse-progress-store",
      partialize: (s) => ({
        modules: s.modules,
        totalXp: s.totalXp,
        level: s.level,
        badges: s.badges,
        streakDays: s.streakDays,
        lastActiveDate: s.lastActiveDate,
        quizScores: s.quizScores,
        // serverHydrated deliberately excluded -- it must re-run per sign-in.
      }),
    },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";

// Cloud-Monitoring-style Uptime Checks: a named synthetic probe against one
// resource, with a rolling history of pass/fail results. The actual pass/fail
// determination is computed by the UI via the shared runEndpointTest() (same
// logic as the CI/CD Simulator's "Test endpoint") — this store only holds the
// check definitions and their result history, capped so it can't grow forever
// across a long training session.

export interface UptimeResult {
  ts: string; // ISO
  ok: boolean;
  latencyMs?: number;
  reason?: string;
}

export interface UptimeCheck {
  id: string;
  resourceId: string;
  resourceName: string;
  createdAt: string;
  results: UptimeResult[];
}

const MAX_RESULTS = 40;

interface UptimeState {
  checks: UptimeCheck[];
  addCheck: (resourceId: string, resourceName: string) => string;
  removeCheck: (id: string) => void;
  recordResult: (id: string, result: UptimeResult) => void;
}

export const useUptimeStore = create<UptimeState>()(
  persist(
    (set, get) => ({
      checks: [],

      addCheck: (resourceId, resourceName) => {
        const id = randomId("uptime");
        const check: UptimeCheck = { id, resourceId, resourceName, createdAt: new Date().toISOString(), results: [] };
        set({ checks: [...get().checks, check] });
        return id;
      },

      removeCheck: (id) => {
        set({ checks: get().checks.filter((c) => c.id !== id) });
      },

      recordResult: (id, result) => {
        set({
          checks: get().checks.map((c) =>
            c.id === id ? { ...c, results: [...c.results, result].slice(-MAX_RESULTS) } : c,
          ),
        });
      },
    }),
    { name: "cloudverse-uptime-store" },
  ),
);

export function uptimePercent(check: UptimeCheck): number {
  if (check.results.length === 0) return 100;
  const okCount = check.results.filter((r) => r.ok).length;
  return Math.round((okCount / check.results.length) * 1000) / 10;
}

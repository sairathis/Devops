import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Edge, Node } from "reactflow";
import { CanvasNodeData, ProvisionStatus, ResourceConfig } from "@/types/gcp";
import { getResourceDef } from "@/lib/gcp";
import { randomId, slugify } from "@/lib/utils";
import { api, projectPath } from "@/lib/api/client";
import { useAuthStore } from "@/store/auth-store";
import { deleteReal } from "@/lib/cloudlab/engine";

export type ArchNode = Node<CanvasNodeData>;

interface Project {
  id: string;
  name: string;
  updatedAt: string;
  nodes: ArchNode[];
  edges: Edge[];
  /** Real CloudLab diagram id (apps/api's `architecture_diagrams` table), once this save has round-tripped to the server. Absent while offline or still saving. */
  remoteId?: string;
}

interface DiagramRow {
  id: string;
  name: string;
  nodes: ArchNode[];
  edges: Edge[];
  updatedAt: string;
}

interface ArchitectureState {
  projects: Project[];
  activeProjectId: string;
  nodes: ArchNode[];
  edges: Edge[];
  selectedNodeId: string | null;
  simulationRunning: boolean;
  addNode: (resourceType: string, position: { x: number; y: number }) => string;
  updateNodeConfig: (nodeId: string, config: Partial<ResourceConfig>) => void;
  updateNodeProvisionState: (
    nodeId: string,
    patch: { provisionStatus: ProvisionStatus; cloudlabResourceId?: string; cloudlabPipelineId?: string; provisionError?: string },
  ) => void;
  removeNode: (nodeId: string) => void;
  setNodes: (nodes: ArchNode[]) => void;
  setEdges: (edges: Edge[]) => void;
  addEdge: (edge: Edge) => void;
  selectNode: (nodeId: string | null) => void;
  clearCanvas: () => void;
  loadExample: (nodes: ArchNode[], edges: Edge[]) => void;
  setSimulationRunning: (running: boolean) => void;
  saveProject: (name: string) => void;
  loadProject: (id: string) => void;
  deleteProject: (id: string) => void;
  /** Set once this session's locally-saved diagrams have been reconciled against CloudLab's real /diagrams API. */
  serverHydrated: boolean;
  /** Pulls in any diagram saved from another browser/session for the current CloudLab project, and pushes up any local-only saves. Best-effort: never throws. */
  hydrateProjectsFromServer: () => Promise<void>;
}

export const useArchitectureStore = create<ArchitectureState>()(
  persist(
    (set, get) => ({
      projects: [],
      serverHydrated: false,
      activeProjectId: "draft",
      nodes: [],
      edges: [],
      selectedNodeId: null,
      simulationRunning: false,

      addNode: (resourceType, position) => {
        const def = getResourceDef(resourceType);
        if (!def) return "";
        const existingCount = get().nodes.filter((n) => n.data.resourceType === resourceType).length;
        const id = randomId(slugify(resourceType));
        const label = existingCount > 0 ? `${def.label} ${existingCount + 1}` : def.label;
        const node: ArchNode = {
          id,
          type: "gcpNode",
          position,
          data: { resourceType, label, config: { ...def.defaultConfig, name: slugify(label) } },
        };
        set({ nodes: [...get().nodes, node], selectedNodeId: id });
        return id;
      },

      updateNodeConfig: (nodeId, config) => {
        set({
          nodes: get().nodes.map((n) =>
            n.id === nodeId
            ? { ...n, data: { ...n.data, config: { ...n.data.config, ...config } as ResourceConfig } }
            : n,
          ),
        });
      },

      updateNodeProvisionState: (nodeId, patch) => {
        set({
          nodes: get().nodes.map((n) =>
            n.id === nodeId
              ? {
                  ...n,
                  data: {
                    ...n.data,
                    provisionStatus: patch.provisionStatus,
                    cloudlabResourceId: patch.cloudlabResourceId ?? n.data.cloudlabResourceId,
                    cloudlabPipelineId: patch.cloudlabPipelineId ?? n.data.cloudlabPipelineId,
                    provisionError: patch.provisionStatus === "failed" || patch.provisionStatus === "skipped" ? patch.provisionError : undefined,
                  },
                }
              : n,
          ),
        });
      },

      removeNode: (nodeId) => {
        const node = get().nodes.find((n) => n.id === nodeId);
        set({
          nodes: get().nodes.filter((n) => n.id !== nodeId),
          edges: get().edges.filter((e) => e.source !== nodeId && e.target !== nodeId),
          selectedNodeId: get().selectedNodeId === nodeId ? null : get().selectedNodeId,
        });

        // If this node was actually provisioned for real on CloudLab, delete
        // its real counterpart too -- otherwise removing it from the canvas
        // would leave an orphaned real Docker container / Postgres row
        // behind, contradicting "delete really deletes" elsewhere in this
        // app. Fire-and-forget: the canvas removal above always proceeds.
        if (node?.data.provisionStatus === "ready" && node.data.cloudlabResourceId) {
          const cloudlabProjectId = useAuthStore.getState().projectId;
          if (cloudlabProjectId) {
            void deleteReal(cloudlabProjectId, node.data.resourceType, node.data.cloudlabResourceId, {
              pipelineId: node.data.cloudlabPipelineId,
            });
          }
        }
      },

      setNodes: (nodes) => set({ nodes }),
      setEdges: (edges) => set({ edges }),
      addEdge: (edge) => set({ edges: [...get().edges, edge] }),
      selectNode: (nodeId) => set({ selectedNodeId: nodeId }),
      clearCanvas: () => set({ nodes: [], edges: [], selectedNodeId: null }),
      loadExample: (nodes, edges) => set({ nodes, edges, selectedNodeId: null }),
      setSimulationRunning: (running) => set({ simulationRunning: running }),

      saveProject: (name) => {
        const { nodes, edges, projects } = get();
        const id = randomId("project");
        const project: Project = { id, name, updatedAt: new Date().toISOString(), nodes, edges };
        set({ projects: [...projects, project], activeProjectId: id });

        // Make the save durable server-side too (real Postgres row scoped to
        // this CloudLab project), so it survives a browser reset and shows
        // up for anyone else on the project -- without changing the
        // synchronous, locally-instant save UX above.
        const cloudlabProjectId = useAuthStore.getState().projectId;
        if (!cloudlabProjectId) return;
        api
          .post<DiagramRow>(projectPath(cloudlabProjectId, "/diagrams"), { name, nodes, edges })
          .then((row) => {
            set({
              projects: get().projects.map((p) => (p.id === id ? { ...p, remoteId: row.id } : p)),
            });
          })
          .catch(() => {
            // Offline or the API is briefly unreachable -- the diagram stays
            // saved locally; it's simply not backed up until the next save.
          });
      },

      loadProject: (id) => {
        const project = get().projects.find((p) => p.id === id);
        if (project) set({ nodes: project.nodes, edges: project.edges, activeProjectId: id });
      },

      deleteProject: (id) => {
        const project = get().projects.find((p) => p.id === id);
        set({ projects: get().projects.filter((p) => p.id !== id) });

        const cloudlabProjectId = useAuthStore.getState().projectId;
        if (!cloudlabProjectId || !project?.remoteId) return;
        api.delete(projectPath(cloudlabProjectId, `/diagrams/${project.remoteId}`)).catch(() => {});
      },

      hydrateProjectsFromServer: async () => {
        if (get().serverHydrated) return;
        const cloudlabProjectId = useAuthStore.getState().projectId;
        if (!cloudlabProjectId) return;
        try {
          const rows = await api.get<DiagramRow[]>(projectPath(cloudlabProjectId, "/diagrams"));
          const local = get().projects;
          const alreadySynced = new Set(local.map((p) => p.remoteId).filter(Boolean));
          const fromServer: Project[] = rows
            .filter((row) => !alreadySynced.has(row.id))
            .map((row) => ({ id: row.id, remoteId: row.id, name: row.name, nodes: row.nodes, edges: row.edges, updatedAt: row.updatedAt }));

          set({ projects: [...local, ...fromServer], serverHydrated: true });

          // Anything saved locally before this project ever had real
          // diagram rows (or saved while offline) gets pushed up now, same
          // as a fresh saveProject would.
          for (const p of local) {
            if (p.remoteId) continue;
            api
              .post<DiagramRow>(projectPath(cloudlabProjectId, "/diagrams"), { name: p.name, nodes: p.nodes, edges: p.edges })
              .then((row) => set({ projects: get().projects.map((q) => (q.id === p.id ? { ...q, remoteId: row.id } : q)) }))
              .catch(() => {});
          }
        } catch {
          // Offline, or the API is briefly unreachable -- keep going on
          // local state only; serverHydrated flips back to false on logout
          // (see auth-store.ts's logout), so the next sign-in retries.
        }
      },
    }),
    {
      name: "cloudverse-architecture-store",
      partialize: (s) => ({
        projects: s.projects,
        activeProjectId: s.activeProjectId,
        nodes: s.nodes,
        edges: s.edges,
        // serverHydrated deliberately excluded -- it must re-run per sign-in.
      }),
    },
  ),
);

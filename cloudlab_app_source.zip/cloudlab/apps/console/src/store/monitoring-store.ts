import * as React from "react";
import { create } from "zustand";
import { useGcpConsoleStore, ConsoleResource } from "@/store/gcp-console-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";

// Cloud-Monitoring-style time-series metrics, simulated from each resource's
// REAL runtime status — never an independent random walk. A running resource
// looks nominal-but-noisy, an errored one shows the CPU/error spike you'd
// expect from a real incident, and a stopped/stopping/deleting resource goes
// flat to zero. This is intentionally NOT persisted (zustand persist) — it's
// live telemetry, not durable state, and would only bloat localStorage.

export interface MetricPoint {
  t: number; // epoch ms
  cpu: number; // percent, 0-100
  network: number; // simulated MB/s
  requests: number; // simulated requests/sec
  errors: number; // simulated errors/sec
}

const WINDOW = 30;

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

function nextPoint(status: ResourceRuntimeStatus, prev: MetricPoint | undefined): MetricPoint {
  const t = Date.now();

  if (status === "running") {
    const cpu = clamp((prev?.cpu ?? 22) + (Math.random() * 14 - 7), 4, 88);
    const requests = clamp((prev?.requests ?? 40) + (Math.random() * 16 - 8), 2, 400);
    const network = clamp((prev?.network ?? 12) + (Math.random() * 6 - 3), 1, 250);
    // A running resource occasionally has a brief, small error blip — realistic background noise.
    const errors = Math.random() < 0.06 ? Math.round(requests * (0.01 + Math.random() * 0.02)) : 0;
    return { t, cpu, requests, network, errors };
  }

  if (status === "error") {
    const cpu = clamp((prev?.cpu ?? 55) + (Math.random() * 20 - 4), 35, 100);
    const requests = clamp((prev?.requests ?? 40) * (0.4 + Math.random() * 0.3), 0, 400);
    const errors = clamp(requests * (0.35 + Math.random() * 0.5), requests > 0 ? 1 : 0, requests || 1);
    const network = clamp((prev?.network ?? 10) * 0.5, 0, 250);
    return { t, cpu, requests, network, errors };
  }

  if (status === "provisioning" || status === "starting") {
    const cpu = clamp((prev?.cpu ?? 5) + Math.random() * 10, 0, 55);
    const network = clamp((prev?.network ?? 2) + Math.random() * 3, 0, 40);
    return { t, cpu, requests: 0, network, errors: 0 };
  }

  // stopped, stopping, deleting — nothing is serving traffic.
  return { t, cpu: 0, requests: 0, network: 0, errors: 0 };
}

interface MonitoringState {
  series: Record<string, MetricPoint[]>;
  tick: (resources: ConsoleResource[]) => void;
  reset: () => void;
}

export const useMonitoringStore = create<MonitoringState>()((set, get) => ({
  series: {},

  tick: (resources) => {
    const current = get().series;
    const next: Record<string, MetricPoint[]> = { ...current };
    const liveIds = new Set(resources.map((r) => r.id));

    for (const r of resources) {
      const prevArr = current[r.id] ?? [];
      const prevPoint = prevArr[prevArr.length - 1];
      const point = nextPoint(r.status, prevPoint);
      next[r.id] = [...prevArr, point].slice(-WINDOW);
    }
    // Drop series for resources that no longer exist (deleted).
    for (const id of Object.keys(next)) {
      if (!liveIds.has(id)) delete next[id];
    }

    set({ series: next });
  },

  reset: () => set({ series: {} }),
}));

/**
 * Mount once per screen that needs live metrics (the Operations Suite page,
 * and the resource detail panel's Monitoring tab). Safe to mount in more than
 * one place at once — every mount just calls the same idempotent tick().
 */
export function useMonitoringTicker(intervalMs = 2000) {
  const tick = useMonitoringStore((s) => s.tick);
  React.useEffect(() => {
    const id = setInterval(() => {
      tick(useGcpConsoleStore.getState().resources);
    }, intervalMs);
    // Fire once immediately so a freshly opened panel isn't empty for a full interval.
    tick(useGcpConsoleStore.getState().resources);
    return () => clearInterval(id);
  }, [tick, intervalMs]);
}

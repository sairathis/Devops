import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import { ConsoleResource } from "@/store/gcp-console-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { MetricPoint } from "@/store/monitoring-store";

// Cloud-Monitoring-style Alerting: define a policy against a real resource
// (either "alert when status equals X" or "alert when a metric crosses a
// threshold"), then evaluate() it against live status + metrics on every
// monitoring tick. Incidents open and auto-resolve exactly like a real
// alerting policy would, driven by the same real resource state everything
// else in the Operations Suite reads.

export type AlertMetric = "cpu" | "network" | "requests" | "errors";
export type AlertOperator = ">" | "<";

export type AlertCondition =
  | { kind: "status"; status: ResourceRuntimeStatus }
  | { kind: "metric"; metric: AlertMetric; operator: AlertOperator; threshold: number };

export interface AlertPolicy {
  id: string;
  name: string;
  resourceId: string;
  resourceName: string;
  resourceType: string;
  condition: AlertCondition;
  createdAt: string;
}

export interface Incident {
  id: string;
  policyId: string;
  policyName: string;
  resourceId: string;
  resourceName: string;
  openedAt: string;
  resolvedAt?: string;
  summary: string;
}

function describeCondition(condition: AlertCondition): string {
  if (condition.kind === "status") return `status becomes "${condition.status}"`;
  const metricLabel: Record<AlertMetric, string> = {
    cpu: "CPU utilization",
    network: "network throughput",
    requests: "request rate",
    errors: "error rate",
  };
  return `${metricLabel[condition.metric]} ${condition.operator} ${condition.threshold}`;
}

interface AlertingState {
  policies: AlertPolicy[];
  incidents: Incident[];
  addPolicy: (p: Omit<AlertPolicy, "id" | "createdAt">) => string;
  removePolicy: (id: string) => void;
  evaluate: (resources: ConsoleResource[], seriesByResource: Record<string, MetricPoint[]>) => void;
  clearIncidents: () => void;
}

export const useAlertingStore = create<AlertingState>()(
  persist(
    (set, get) => ({
      policies: [],
      incidents: [],

      addPolicy: (p) => {
        const id = randomId("policy");
        const policy: AlertPolicy = { ...p, id, createdAt: new Date().toISOString() };
        set({ policies: [...get().policies, policy] });
        return id;
      },

      removePolicy: (id) => {
        set({
          policies: get().policies.filter((p) => p.id !== id),
          // Resolve any still-open incident for a deleted policy so it doesn't linger forever.
          incidents: get().incidents.map((inc) =>
            inc.policyId === id && !inc.resolvedAt ? { ...inc, resolvedAt: new Date().toISOString() } : inc,
          ),
        });
      },

      evaluate: (resources, seriesByResource) => {
        const byId = new Map(resources.map((r) => [r.id, r]));
        const { policies, incidents } = get();
        let nextIncidents = incidents;
        let changed = false;

        for (const policy of policies) {
          const resource = byId.get(policy.resourceId);
          const openIncident = nextIncidents.find((i) => i.policyId === policy.id && !i.resolvedAt);

          let conditionMet = false;
          if (resource) {
            if (policy.condition.kind === "status") {
              conditionMet = resource.status === policy.condition.status;
            } else {
              const series = seriesByResource[policy.resourceId] ?? [];
              const latest = series[series.length - 1];
              if (latest) {
                const value = latest[policy.condition.metric];
                conditionMet = policy.condition.operator === ">" ? value > policy.condition.threshold : value < policy.condition.threshold;
              }
            }
          }

          if (conditionMet && !openIncident) {
            const incident: Incident = {
              id: randomId("incident"),
              policyId: policy.id,
              policyName: policy.name,
              resourceId: policy.resourceId,
              resourceName: policy.resourceName,
              openedAt: new Date().toISOString(),
              summary: `${policy.resourceName}: ${describeCondition(policy.condition)}`,
            };
            nextIncidents = [incident, ...nextIncidents];
            changed = true;
          } else if (!conditionMet && openIncident) {
            nextIncidents = nextIncidents.map((i) =>
              i.id === openIncident.id ? { ...i, resolvedAt: new Date().toISOString() } : i,
            );
            changed = true;
          }
        }

        if (changed) set({ incidents: nextIncidents.slice(0, 200) });
      },

      clearIncidents: () => set({ incidents: [] }),
    }),
    { name: "cloudverse-alerting-store" },
  ),
);

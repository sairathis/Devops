import { create } from "zustand";

/**
 * Tiny cross-surface signal so the real Architecture Diagram can show
 * network flow while a REAL test (RealTestPanel -> runResourceTest) is
 * actually in flight against a specific CloudLab resource -- not a
 * decorative animation, a reflection of an actual HTTP call/exec/invoke
 * happening right now. Keyed by cloudlabResourceId (the real backing
 * resource's id), the same id ArchitectureDiagram's nodes already carry as
 * ConsoleResource.cloudlabResourceId, so no new id scheme is introduced.
 *
 * Deliberately NOT persisted and NOT resource-specific state on
 * ConsoleResource itself -- this is transient "what's happening right now
 * across the whole app" activity, cleared the moment the real call finishes
 * (see RealTestPanel), so a diagram open in one tab reflects a test kicked
 * off from a completely different panel (Terraform Lab row, resource
 * detail sheet, CI/CD deploy dialog) without those surfaces needing to know
 * about each other.
 */
interface TestActivityState {
  /** The cloudlabResourceId of whatever real test is currently in flight, if any. */
  activeResourceId: string | null;
  /** The most recently *completed* real test's outcome, kept until the next one starts. */
  lastResult: { resourceId: string; ok: boolean; at: number } | null;
  begin: (cloudlabResourceId: string) => void;
  finish: (cloudlabResourceId: string, ok: boolean) => void;
}

export const useTestActivityStore = create<TestActivityState>((set) => ({
  activeResourceId: null,
  lastResult: null,
  begin: (cloudlabResourceId) => set({ activeResourceId: cloudlabResourceId }),
  finish: (cloudlabResourceId, ok) =>
    set({ activeResourceId: null, lastResult: { resourceId: cloudlabResourceId, ok, at: Date.now() } }),
}));

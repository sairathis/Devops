import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";

// A single Cloud-Audit-Log-style entry: who did what, to which resource, and
// whether it succeeded — recorded from every mutating action across the whole
// platform (the Console, Terraform Lab Build & Apply, and both CI/CD
// pipelines), so the Operations Suite's Activity Log tab can show one real,
// chronological trail instead of each module keeping its own private history.
export type ActivityOutcome = "success" | "failure" | "info";

export interface ActivityEntry {
  id: string;
  ts: string; // ISO timestamp
  actor: string; // identity that performed the action — a service account email, or the project default
  method: string; // gcloud/Terraform/pipeline-flavored method name, e.g. "compute.instances.insert"
  resourceType?: string;
  resourceName?: string;
  outcome: ActivityOutcome;
  detail?: string;
  source: "console" | "terraform-lab" | "platform-pipeline" | "app-pipeline" | "docker-lab" | "kubernetes-lab";
}

const MAX_ENTRIES = 500;

interface ActivityLogState {
  entries: ActivityEntry[];
  logActivity: (entry: Omit<ActivityEntry, "id" | "ts">) => void;
  clear: () => void;
}

export const useActivityLogStore = create<ActivityLogState>()(
  persist(
    (set, get) => ({
      entries: [],

      logActivity: (entry) => {
        const full: ActivityEntry = {
          ...entry,
          id: randomId("audit"),
          ts: new Date().toISOString(),
        };
        // Newest first, capped so localStorage never grows unbounded across a long session.
        set({ entries: [full, ...get().entries].slice(0, MAX_ENTRIES) });
      },

      clear: () => set({ entries: [] }),
    }),
    { name: "cloudverse-activity-log-store" },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ResourceConfig } from "@/types/gcp";
import { ErrorScenario, ResourceRuntimeStatus, SimLogEntry, SimLogLevel, makeLog } from "@/lib/console-sim/types";
import { randomId } from "@/lib/utils";
import { useActivityLogStore } from "@/store/activity-log-store";
import { useIamStore } from "@/store/iam-store";
import { attemptRealProvision } from "@/lib/cloudlab/console-provision";
import { deleteReal } from "@/lib/cloudlab/engine";
import { useAuthStore } from "@/store/auth-store";

// Resolves the same "Runs as" identity shown in the resource detail panel, so
// the Activity Log's actor column always matches what's shown elsewhere.
function actorFor(config: ResourceConfig): string {
  const saId = config.serviceAccountId;
  if (typeof saId === "string" && saId) {
    const sa = useIamStore.getState().serviceAccounts.find((s) => s.id === saId);
    if (sa) return sa.email;
  }
  return "Default service account";
}

export interface ConsoleResource {
  id: string;
  type: string;
  name: string;
  config: ResourceConfig;
  status: ResourceRuntimeStatus;
  createdAt: string;
  logs: SimLogEntry[];
  /**
   * Epoch ms at which a simulated-scenario failure (see simulateScenario) will
   * self-heal back to "running". Only ever set for that specific auto-recovering
   * error path — never for a creation-time injected failure, which is meant to
   * stay broken until the learner works through the Fix tab. The in-memory
   * setTimeout that actually performs the recovery is lost on a hard page
   * reload (a real browser navigation, not SPA routing); this timestamp is what
   * lets resumeStuckStates() heal or reschedule it after a reload instead of
   * leaving the resource stuck in "error" forever.
   */
  recoverAt?: number;

  /**
   * Real CloudLab provisioning, attempted best-effort alongside the
   * simulation above -- see lib/cloudlab/console-provision.ts for exactly
   * when this fires. Undefined/"idle" means either this type isn't one of
   * the 7 CloudLab can provision, or its dependency chain (VPC/Subnet) isn't
   * fully real yet; this resource still behaves as a normal simulated
   * resource in every other respect either way.
   */
  cloudlabStatus?: "creating" | "ready" | "failed";
  cloudlabResourceId?: string;
  cloudlabError?: string;
  /** Set only for type "subnet" once real, so a real VM created on top of it can resolve its parent network. */
  cloudlabNetworkId?: string;
  /** Set only for type "vpc" once real, so a real Subnet created on top of it can pick a CIDR that fits inside it. */
  cloudlabCidr?: string;
  /** Composer only: the real backing `pipeline` resource id auto-created alongside it, needed to clean it up on delete. */
  cloudlabPipelineId?: string;
}

interface ProvisionStep {
  level: SimLogLevel;
  message: string;
}

// gcloud/gsutil-flavored command line shown as the first log line for each type.
function commandFor(type: string, config: ResourceConfig, name: string): string {
  switch (type) {
    case "vm":
      return `$ gcloud compute instances create ${name} --zone=${config.region}${config.zone} --machine-type=${config.machineType}`;
    case "gcs":
      return `$ gsutil mb -l ${config.location} -c ${String(config.storageClass ?? "standard").toLowerCase()} gs://${name}`;
    case "cloudsql":
      return `$ gcloud sql instances create ${name} --database-version=${config.engine} --tier=${config.tier} --region=${config.region}`;
    case "gke":
      return config.mode === "autopilot"
        ? `$ gcloud container clusters create-auto ${name} --region=${config.region}`
        : `$ gcloud container clusters create ${name} --region=${config.region} --num-nodes=${config.nodeCount}`;
    case "lb":
      return `$ gcloud compute forwarding-rules create ${name} --global --target-http-proxy=${name}-proxy --ports=${config.port}`;
    default:
      return `$ gcloud services create ${name}`;
  }
}

// The middle "what's actually happening" steps, flavored per resource type.
function provisioningSteps(type: string, config: ResourceConfig): ProvisionStep[] {
  switch (type) {
    case "vm":
      return [
        { level: "info", message: `Reserving network interface${config.publicIp ? " and external IP" : ""} in ${config.region}${config.zone}...` },
        { level: "info", message: `Attaching ${config.diskSizeGb}GB ${config.diskType} boot disk (${config.osImage})...` },
        { level: "info", message: "Booting instance and running startup scripts..." },
      ];
    case "gcs":
      return [
        { level: "info", message: "Checking global namespace for bucket name availability..." },
        { level: "info", message: `Provisioning ${config.storageClass} storage backend in ${config.location}...` },
        {
          level: "info",
          message: config.uniformAccess
            ? "Applying uniform bucket-level access policy..."
            : "Applying default object ACLs (uniform bucket-level access disabled)...",
        },
      ];
    case "cloudsql": {
      const steps: ProvisionStep[] = [
        { level: "info", message: `Allocating Cloud SQL instance (tier ${config.tier})...` },
        { level: "info", message: `Provisioning ${config.storageGb}GB storage and configuring networking...` },
      ];
      if (config.highAvailability) {
        steps.push({ level: "info", message: "Provisioning synchronous standby in a secondary zone for high availability..." });
      }
      return steps;
    }
    case "gke": {
      const steps: ProvisionStep[] = [
        { level: "info", message: `Reserving control plane in ${config.region}...` },
        {
          level: "info",
          message:
            config.mode === "autopilot"
              ? "Configuring Autopilot compute classes..."
              : `Provisioning node pool (${config.nodeCount} nodes/zone)...`,
        },
      ];
      if (config.workloadIdentity) {
        steps.push({ level: "info", message: "Binding Workload Identity pool (svc.id.goog)..." });
      }
      return steps;
    }
    case "lb":
      return [
        { level: "info", message: `Creating health check on port ${config.port} (${config.healthCheckPath})...` },
        { level: "info", message: `Registering backend service (${config.protocol}, session affinity ${config.sessionAffinity})...` },
        { level: "info", message: "Allocating global anycast IP address..." },
      ];
    default:
      return [{ level: "info", message: "Provisioning resource..." }];
  }
}

function successMessage(type: string, name: string): string {
  switch (type) {
    case "vm":
      return `Instance ${name} is RUNNING.`;
    case "gcs":
      return `Bucket gs://${name} created and ready.`;
    case "cloudsql":
      return `Instance ${name} state: RUNNABLE.`;
    case "gke":
      return `Cluster ${name} is RUNNING.`;
    case "lb":
      return `Load balancer ${name} is ACTIVE and serving traffic.`;
    default:
      return `${name} is ready.`;
  }
}

function logLevelForCliLine(line: string): SimLogLevel {
  return line.trim().startsWith("$") ? "command" : "error";
}

interface GcpConsoleState {
  resources: ConsoleResource[];
  firstSuccessAwarded: boolean;
  createResource: (type: string, config: ResourceConfig, injectScenario?: ErrorScenario) => string;
  updateResourceConfig: (id: string, patch: Partial<ResourceConfig>) => void;
  appendLog: (id: string, entry: SimLogEntry) => void;
  setStatus: (id: string, status: ResourceRuntimeStatus) => void;
  startResource: (id: string) => void;
  stopResource: (id: string) => void;
  /** Returns once the simulated removal AND (best-effort) the real CloudLab delete have both settled, so a caller that needs real confirmation (Terraform Lab's runDestroy) can await it; fire-and-forget callers can simply ignore the promise. */
  deleteResource: (id: string) => Promise<void>;
  simulateScenario: (id: string, scenario: ErrorScenario) => void;
  /** Internal: performs the actual auto-heal for a simulateScenario-induced error. */
  recoverFromSimulatedFailure: (id: string) => void;
  resumeStuckStates: () => void;
  /** Returns true only the first time it is ever called (and records that it happened). */
  claimFirstSuccess: () => boolean;
  setCloudlabState: (
    id: string,
    patch: {
      cloudlabStatus: ConsoleResource["cloudlabStatus"];
      cloudlabResourceId?: string;
      cloudlabNetworkId?: string;
      cloudlabCidr?: string;
      cloudlabError?: string;
      cloudlabPipelineId?: string;
    },
  ) => void;
}

export const useGcpConsoleStore = create<GcpConsoleState>()(
  persist(
    (set, get) => ({
      resources: [],
      firstSuccessAwarded: false,

      createResource: (type, config, injectScenario) => {
        const id = randomId(type);
        const name = String(config.name ?? type);
        const resource: ConsoleResource = {
          id,
          type,
          name,
          config,
          status: "provisioning",
          createdAt: new Date().toISOString(),
          logs: [makeLog("command", commandFor(type, config, name))],
        };
        set({ resources: [...get().resources, resource] });

        // Best-effort real provisioning, entirely independent of the
        // simulated timeline below -- see lib/cloudlab/console-provision.ts
        // for exactly when this does anything at all. cloudlabStatus is left
        // untouched (undefined) for the common "skipped" case -- this type
        // isn't one CloudLab can provision, or its VPC/Subnet ref isn't
        // itself real yet -- so the resource-detail UI shows no CloudLab
        // section at all rather than a spinner that would never resolve.
        attemptRealProvision(resource, [...get().resources]).then((result) => {
          if (result.status === "ready") {
            get().setCloudlabState(id, {
              cloudlabStatus: "ready",
              cloudlabResourceId: result.resourceId,
              cloudlabNetworkId: result.networkId,
              cloudlabCidr: result.cidr,
              cloudlabPipelineId: result.pipelineId,
            });
          } else if (result.status === "failed") {
            get().setCloudlabState(id, { cloudlabStatus: "failed", cloudlabError: result.error });
          }
        });

        const actor = actorFor(config);
        useActivityLogStore.getState().logActivity({
          actor,
          method: `${type}.create`,
          resourceType: type,
          resourceName: name,
          outcome: "info",
          detail: `Creation requested${injectScenario ? " (set up to fail on purpose)" : ""}.`,
          source: "console",
        });

        const steps = provisioningSteps(type, config);
        const delays = [500, 1100, 1800, 2400].slice(0, steps.length);

        steps.forEach((step, i) => {
          setTimeout(() => {
            if (!get().resources.some((r) => r.id === id)) return;
            get().appendLog(id, makeLog(step.level, step.message));
          }, delays[i]);
        });

        const finalDelay = (delays[delays.length - 1] ?? 500) + 800;
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          if (injectScenario) {
            injectScenario.cliOutput.forEach((line) => {
              get().appendLog(id, makeLog(logLevelForCliLine(line), line));
            });
            get().setStatus(id, "error");
            useActivityLogStore.getState().logActivity({
              actor,
              method: `${type}.create`,
              resourceType: type,
              resourceName: name,
              outcome: "failure",
              detail: injectScenario.title,
              source: "console",
            });
          } else {
            get().appendLog(id, makeLog("success", successMessage(type, name)));
            get().setStatus(id, "running");
            useActivityLogStore.getState().logActivity({
              actor,
              method: `${type}.create`,
              resourceType: type,
              resourceName: name,
              outcome: "success",
              detail: successMessage(type, name),
              source: "console",
            });
          }
        }, finalDelay);

        return id;
      },

      updateResourceConfig: (id, patch) => {
        set({
          resources: get().resources.map((r) =>
            r.id === id ? { ...r, config: { ...r.config, ...patch } as ResourceConfig } : r,
          ),
        });
      },

      appendLog: (id, entry) => {
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, logs: [...r.logs, entry] } : r)),
        });
      },

      setStatus: (id, status) => {
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, status } : r)),
        });
      },

      startResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res || res.status !== "stopped") return;
        get().setStatus(id, "starting");
        get().appendLog(id, makeLog("command", `$ gcloud ... start ${res.name}`));
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          get().appendLog(id, makeLog("success", `${res.name} is running again.`));
          get().setStatus(id, "running");
          useActivityLogStore.getState().logActivity({
            actor: actorFor(res.config),
            method: `${res.type}.start`,
            resourceType: res.type,
            resourceName: res.name,
            outcome: "success",
            detail: `${res.name} is running again.`,
            source: "console",
          });
        }, 1200);
      },

      stopResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res || res.status !== "running") return;
        get().setStatus(id, "stopping");
        get().appendLog(id, makeLog("command", `$ gcloud ... stop ${res.name}`));
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          get().appendLog(id, makeLog("info", `${res.name} has stopped.`));
          get().setStatus(id, "stopped");
          useActivityLogStore.getState().logActivity({
            actor: actorFor(res.config),
            method: `${res.type}.stop`,
            resourceType: res.type,
            resourceName: res.name,
            outcome: "success",
            detail: `${res.name} has stopped.`,
            source: "console",
          });
        }, 1000);
      },

      deleteResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res) return Promise.resolve();
        get().setStatus(id, "deleting");
        get().appendLog(id, makeLog("command", `$ gcloud ... delete ${res.name} --quiet`));

        // Best-effort: if this resource has a real CloudLab counterpart,
        // delete that too, so a "deleted" simulated resource doesn't leave a
        // real Docker container / Postgres row running forever. Independent
        // of the simulated deletion timeline below either way. Kept as a
        // promise (rather than instantly firing-and-forgetting it) so a
        // caller that cares about real confirmation -- Terraform Lab's
        // runDestroy -- can await the returned promise; deleteReal never
        // throws (it's already try/catch'd internally), so this never
        // rejects and every existing fire-and-forget caller keeps working
        // unchanged.
        const projectId = useAuthStore.getState().projectId;
        const realDeletion =
          res.cloudlabStatus === "ready" && res.cloudlabResourceId && projectId
            ? deleteReal(projectId, res.type, res.cloudlabResourceId, { pipelineId: res.cloudlabPipelineId })
            : Promise.resolve();

        useActivityLogStore.getState().logActivity({
          actor: actorFor(res.config),
          method: `${res.type}.delete`,
          resourceType: res.type,
          resourceName: res.name,
          outcome: "info",
          detail: "Deletion requested.",
          source: "console",
        });
        return new Promise<void>((resolve) => {
          setTimeout(() => {
            set({ resources: get().resources.filter((r) => r.id !== id) });
            useActivityLogStore.getState().logActivity({
              actor: actorFor(res.config),
              method: `${res.type}.delete`,
              resourceType: res.type,
              resourceName: res.name,
              outcome: "success",
              detail: `${res.name} deleted.`,
              source: "console",
            });
            void realDeletion.finally(resolve);
          }, 1200);
        });
      },

      simulateScenario: (id, scenario) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res) return;
        scenario.cliOutput.forEach((line) => {
          get().appendLog(id, makeLog(logLevelForCliLine(line), line));
        });
        get().setStatus(id, "error");
        const recoverAt = Date.now() + 3000;
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, recoverAt } : r)),
        });
        useActivityLogStore.getState().logActivity({
          actor: actorFor(res.config),
          method: `${res.type}.simulateFailure`,
          resourceType: res.type,
          resourceName: res.name,
          outcome: "failure",
          detail: scenario.title,
          source: "console",
        });
        setTimeout(() => get().recoverFromSimulatedFailure(id), 3000);
      },

      recoverFromSimulatedFailure: (id) => {
        const res = get().resources.find((r) => r.id === id);
        // Only recover a resource that's still in the exact error state this
        // scenario put it in — a since-deleted, restarted, or freshly re-broken
        // resource should not be silently flipped back to running.
        if (!res || res.status !== "error" || res.recoverAt === undefined) return;
        get().appendLog(id, makeLog("info", "Applying fix and re-checking resource health..."));
        get().appendLog(id, makeLog("success", `${res.name} recovered and is running normally.`));
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, status: "running", recoverAt: undefined } : r)),
        });
        useActivityLogStore.getState().logActivity({
          actor: actorFor(res.config),
          method: `${res.type}.recover`,
          resourceType: res.type,
          resourceName: res.name,
          outcome: "success",
          detail: `${res.name} recovered and is running normally.`,
          source: "console",
        });
      },

      resumeStuckStates: () => {
        const now = Date.now();
        set({
          resources: get()
            .resources.filter((r) => r.status !== "deleting")
            .map((r) => {
              if (r.status === "provisioning" || r.status === "starting") {
                return {
                  ...r,
                  status: "running" as ResourceRuntimeStatus,
                  logs: [...r.logs, makeLog("info", "Resumed after reload — the operation had completed in the background.")],
                };
              }
              if (r.status === "stopping") {
                return {
                  ...r,
                  status: "stopped" as ResourceRuntimeStatus,
                  logs: [...r.logs, makeLog("info", "Resumed after reload — the instance had finished stopping.")],
                };
              }
              // A simulated-scenario failure auto-heals on a 3s in-memory timer, which a
              // hard page reload discards. If enough real time already passed, heal it now
              // instead of leaving it stuck in "error" forever; otherwise reschedule the
              // remaining time so it still self-heals on its original clock.
              if (r.status === "error" && r.recoverAt !== undefined) {
                if (now >= r.recoverAt) {
                  useActivityLogStore.getState().logActivity({
                    actor: actorFor(r.config),
                    method: `${r.type}.recover`,
                    resourceType: r.type,
                    resourceName: r.name,
                    outcome: "success",
                    detail: `${r.name} recovered and is running normally.`,
                    source: "console",
                  });
                  return {
                    ...r,
                    status: "running" as ResourceRuntimeStatus,
                    recoverAt: undefined,
                    logs: [
                      ...r.logs,
                      makeLog("info", "Applying fix and re-checking resource health..."),
                      makeLog("success", `${r.name} recovered and is running normally.`),
                    ],
                  };
                }
                setTimeout(() => get().recoverFromSimulatedFailure(r.id), r.recoverAt - now);
              }
              return r;
            }),
        });
      },

      claimFirstSuccess: () => {
        if (get().firstSuccessAwarded) return false;
        set({ firstSuccessAwarded: true });
        return true;
      },

      setCloudlabState: (id, patch) => {
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, ...patch } : r)),
        });
      },
    }),
    { name: "cloudverse-gcp-console-store" },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { api, configureApiAuth } from "@/lib/api/client";
import { useProgressStore } from "@/store/progress-store";
import { useCertificationStore } from "@/store/certification-store";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface Org {
  id: string;
  name: string;
}

interface Project {
  id: string;
  orgId: string;
  name: string;
}

interface AuthState {
  token: string | null;
  user: AuthUser | null;
  orgId: string | null;
  projectId: string | null;
  projectName: string | null;
  bootstrapping: boolean;
  authError: string | null;

  register: (name: string, email: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  /** Idempotent: makes sure the signed-in user has an org + project to work in, creating one on first login. */
  ensureProject: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      orgId: null,
      projectId: null,
      projectName: null,
      bootstrapping: false,
      authError: null,

      register: async (name, email, password) => {
        set({ authError: null });
        try {
          const res = await api.post<{ token: string; user: AuthUser }>("/auth/register", {
            name,
            email,
            password,
          });
          set({ token: res.token, user: res.user });
          await get().ensureProject();
        } catch (err: unknown) {
          set({ authError: messageOf(err) });
          throw err;
        }
      },

      login: async (email, password) => {
        set({ authError: null });
        try {
          const res = await api.post<{ token: string; user: AuthUser }>("/auth/login", { email, password });
          set({ token: res.token, user: res.user });
          await get().ensureProject();
        } catch (err: unknown) {
          set({ authError: messageOf(err) });
          throw err;
        }
      },

      logout: () => {
        set({ token: null, user: null, orgId: null, projectId: null, projectName: null, authError: null });
        // Force the next sign-in (possibly a different account, same browser)
        // to re-reconcile against its own real academy rows rather than
        // skipping hydration because a previous account already ran it.
        useProgressStore.setState({ serverHydrated: false });
        useCertificationStore.setState({ serverHydrated: false });
      },

      ensureProject: async () => {
        if (get().bootstrapping) return;
        set({ bootstrapping: true });
        try {
          const orgs = await api.get<Org[]>("/organizations");
          let orgId = orgs.find((o) => o.id === get().orgId)?.id ?? orgs[0]?.id ?? null;
          if (!orgId) {
            const created = await api.post<Org>("/organizations", {
              name: `${get().user?.name ?? "My"}'s Organization`,
            });
            orgId = created.id;
          }

          const projects = await api.get<Project[]>(`/projects?orgId=${orgId}`);
          let project = projects.find((p) => p.id === get().projectId) ?? projects[0] ?? null;
          if (!project) {
            project = await api.post<Project>("/projects", { orgId, name: "CloudVerse Lab" });
          }

          set({ orgId, projectId: project.id, projectName: project.name });
        } finally {
          set({ bootstrapping: false });
        }
      },
    }),
    {
      name: "cloudlab-console-auth",
      partialize: (s) => ({
        token: s.token,
        user: s.user,
        orgId: s.orgId,
        projectId: s.projectId,
        projectName: s.projectName,
      }),
    },
  ),
);

function messageOf(err: unknown): string {
  if (err && typeof err === "object" && "message" in err) return String((err as { message: unknown }).message);
  return "Something went wrong. Please try again.";
}

// Wire the plain API client to this store without a top-level circular import.
configureApiAuth(
  () => useAuthStore.getState().token,
  () => useAuthStore.getState().logout(),
);

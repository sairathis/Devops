import { create } from "zustand";
import { persist } from "zustand/middleware";
import { api } from "@/lib/api/client";

function topicKey(pathId: string, topicId: string): string {
  return `${pathId}:${topicId}`;
}

function syncTopic(pathId: string, topicId: string, completed: boolean) {
  const path = `/academy/certifications/${encodeURIComponent(pathId)}/topics/${encodeURIComponent(topicId)}`;
  (completed ? api.post(path) : api.delete(path)).catch(() => {});
}

interface CertificationState {
  completedTopics: Record<string, boolean>;
  serverHydrated: boolean;
  toggleTopic: (pathId: string, topicId: string) => void;
  isTopicCompleted: (pathId: string, topicId: string) => boolean;
  resetPath: (pathId: string) => void;
  /** Merges in the real per-user completions CloudLab's API keeps (apps/api/src/routes/academy.ts), pushing up anything local-only. Call once per sign-in. Best-effort: never throws. */
  hydrateFromServer: (serverCompletedTopics: Record<string, boolean>) => void;
}

export const useCertificationStore = create<CertificationState>()(
  persist(
    (set, get) => ({
      completedTopics: {},
      serverHydrated: false,

      toggleTopic: (pathId, topicId) => {
        const key = topicKey(pathId, topicId);
        const current = get().completedTopics;
        const next = !current[key];
        set({ completedTopics: { ...current, [key]: next } });
        syncTopic(pathId, topicId, next);
      },

      isTopicCompleted: (pathId, topicId) => {
        return Boolean(get().completedTopics[topicKey(pathId, topicId)]);
      },

      resetPath: (pathId) => {
        const prefix = `${pathId}:`;
        const next: Record<string, boolean> = {};
        for (const [key, value] of Object.entries(get().completedTopics)) {
          if (!key.startsWith(prefix)) next[key] = value;
        }
        set({ completedTopics: next });
      },

      hydrateFromServer: (serverCompletedTopics) => {
        if (get().serverHydrated) return;
        const local = get().completedTopics;
        const merged: Record<string, boolean> = { ...serverCompletedTopics };
        for (const [key, done] of Object.entries(local)) {
          if (done && !merged[key]) {
            merged[key] = true;
            const [pathId, topicId] = key.split(":");
            if (pathId && topicId) syncTopic(pathId, topicId, true);
          }
        }
        set({ completedTopics: merged, serverHydrated: true });
      },
    }),
    {
      name: "cloudverse-certification-store",
      partialize: (s) => ({ completedTopics: s.completedTopics }),
    },
  ),
);

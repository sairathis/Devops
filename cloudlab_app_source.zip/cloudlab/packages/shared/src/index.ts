// Shared types and constants used by apps/api, apps/worker and (conceptually) any
// CLI/Terraform client that talks to the CloudLab API. Keeping this as the single
// source of truth is what the master spec calls "never duplicate business logic
// between UI/CLI/API" -- everything downstream imports from here.

// Extended milestone by milestone (see ROADMAP.md) on top of the original
// network/instance pair. New types are additive to the generic resource
// model -- no schema change needed, just a new `type` value plus a route +
// worker processor + UI panel.
export type ResourceType =
  | "network" | "instance" // Milestone 1
  | "subnet" | "firewall_rule" | "dns_record" | "load_balancer" // Milestone 2
  | "disk" // Milestone 3
  | "registry" | "container_image" // Milestone 4
  | "database" | "bucket" | "secret" // Milestone 5
  | "k8s_cluster" | "k8s_deployment" // Milestone 6
  | "pipeline" | "pipeline_run" // Milestone 8
  // Milestone 15: GCP Platform/DevOps architect pass -- NAT Gateway, Shared
  // VPC, VPC Peering, Service Accounts, Instance Templates, Managed Instance
  // Groups, and honest substitutes for BigQuery, Composer and Cloud Run. See
  // ROADMAP.md "Milestone 15" for the full GCP-service mapping table.
  | "service_account" | "instance_template" | "managed_instance_group"
  | "nat_gateway" | "vpc_peering" | "shared_vpc_attachment"
  | "bigquery_dataset" | "composer_environment" | "cloud_run_service"
  ;

export const RESOURCE_TYPES: ResourceType[] = [
  "network", "instance", "subnet", "firewall_rule", "dns_record", "load_balancer",
  "disk", "registry", "container_image", "database", "bucket", "secret",
  "k8s_cluster", "k8s_deployment", "pipeline", "pipeline_run",
  "service_account", "instance_template", "managed_instance_group",
  "nat_gateway", "vpc_peering", "shared_vpc_attachment",
  "bigquery_dataset", "composer_environment", "cloud_run_service",
];

// Lifecycle states every resource moves through. Section 6 of the spec is explicit:
// never report a state before the underlying infrastructure actually confirms it.
export type ResourceStatus =
  | "CREATING"
  | "PROVISIONING"
  | "READY"
  | "UPDATING"
  | "DEGRADED"
  | "FAILED"
  | "STOPPING"
  | "STOPPED"
  | "DELETING"
  | "DELETED";

export type OperationStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED";

export type ErrorCode =
  | "PERMISSION_DENIED"
  | "RESOURCE_NOT_FOUND"
  | "INVALID_CONFIGURATION"
  | "QUOTA_EXCEEDED"
  | "RESOURCE_CONFLICT"
  | "DEPENDENCY_EXISTS"
  | "NETWORK_UNREACHABLE"
  | "DEPLOYMENT_FAILED"
  | "HEALTH_CHECK_FAILED"
  | "TIMEOUT"
  | "AUTHENTICATION_FAILED"
  | "ACCOUNT_LOCKED"
  | "RATE_LIMITED"
  | "VALIDATION_ERROR"
  | "INTERNAL_ERROR";

export interface ApiError {
  code: ErrorCode;
  message: string;
  what?: string;
  why?: string;
  diagnose?: string;
  fix?: string;
  details?: Record<string, unknown>;
}

export interface ResourceDTO {
  id: string;
  projectId: string;
  name: string;
  type: ResourceType;
  region: string;
  status: ResourceStatus;
  spec: Record<string, unknown>;
  metadata: Record<string, unknown>;
  labels: Record<string, string>;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  version: number;
}

export interface OperationDTO {
  id: string;
  projectId: string;
  resourceId: string | null;
  type: string;
  status: OperationStatus;
  steps: { name: string; status: string; at: string; message?: string }[];
  error: ApiError | null;
  createdAt: string;
  updatedAt: string;
}

export interface GraphNode {
  id: string;
  type: ResourceType | "project";
  label: string;
  status?: ResourceStatus;
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  kind: "contains" | "connects_to" | "routes_to" | "depends_on" | "exposes";
}

// IAM: permission strings look like "compute.instances.create". Roles carry
// allow/deny lists; deny always wins. "*" segments are wildcards.
export interface Role {
  key: string;
  name: string;
  allow: string[];
  deny: string[];
}

export const BUILTIN_ROLES: Role[] = [
  { key: "owner", name: "Owner", allow: ["*"], deny: [] },
  {
    key: "admin",
    name: "Admin",
    allow: ["projects.*", "compute.*", "network.*", "registry.*", "storage.*", "database.*", "secrets.*", "k8s.*", "cicd.*", "iam.roles.read", "iam.bindings.*", "iam.serviceAccounts.*", "bigquery.*", "composer.*", "run.*"],
    deny: ["organizations.delete"],
  },
  {
    key: "developer",
    name: "Developer",
    allow: [
      "projects.get",
      "projects.list",
      "compute.instances.create",
      "compute.instances.get",
      "compute.instances.list",
      "compute.instances.start",
      "compute.instances.stop",
      "compute.instances.exec",
      "network.networks.create",
      "network.networks.get",
      "network.networks.list",
      "network.subnets.create",
      "network.subnets.get",
      "network.subnets.list",
      "network.firewall.create",
      "network.firewall.get",
      "network.firewall.list",
      "network.dns.create",
      "network.dns.get",
      "network.dns.list",
      "network.loadbalancers.create",
      "network.loadbalancers.get",
      "network.loadbalancers.list",
      "network.loadbalancers.update",
      "compute.disks.create",
      "compute.disks.get",
      "compute.disks.list",
      "registry.registries.create",
      "registry.registries.get",
      "registry.registries.list",
      "registry.images.create",
      "registry.images.get",
      "registry.images.list",
      "storage.buckets.create",
      "storage.buckets.get",
      "storage.buckets.list",
      "database.databases.create",
      "database.databases.get",
      "database.databases.list",
      "secrets.secrets.create",
      "secrets.secrets.get",
      "secrets.secrets.list",
      "k8s.clusters.create",
      "k8s.clusters.get",
      "k8s.clusters.list",
      "k8s.deployments.create",
      "k8s.deployments.get",
      "k8s.deployments.list",
      "k8s.deployments.scale",
      "cicd.pipelines.create",
      "cicd.pipelines.get",
      "cicd.pipelines.list",
      "cicd.pipelineRuns.create",
      "cicd.pipelineRuns.get",
      "cicd.pipelineRuns.list",
      "iam.serviceAccounts.create",
      "iam.serviceAccounts.get",
      "iam.serviceAccounts.list",
      "compute.instanceTemplates.create",
      "compute.instanceTemplates.get",
      "compute.instanceTemplates.list",
      "compute.instanceGroups.create",
      "compute.instanceGroups.get",
      "compute.instanceGroups.list",
      "compute.instanceGroups.resize",
      "network.natGateways.create",
      "network.natGateways.get",
      "network.natGateways.list",
      "network.peerings.create",
      "network.peerings.get",
      "network.peerings.list",
      "network.sharedVpc.create",
      "network.sharedVpc.get",
      "network.sharedVpc.list",
      "bigquery.datasets.create",
      "bigquery.datasets.get",
      "bigquery.datasets.list",
      "bigquery.datasets.query",
      "composer.environments.create",
      "composer.environments.get",
      "composer.environments.list",
      "run.services.create",
      "run.services.get",
      "run.services.list",
      "run.services.invoke",
    ],
    deny: [
      "compute.instances.delete",
      "network.networks.delete",
      "network.subnets.delete",
      "network.firewall.delete",
      "network.dns.delete",
      "network.loadbalancers.delete",
      "compute.disks.delete",
      "registry.registries.delete",
      "registry.images.delete",
      "storage.buckets.delete",
      "database.databases.delete",
      "secrets.secrets.delete",
      "secrets.secrets.reveal",
      "k8s.clusters.delete",
      "k8s.deployments.delete",
      "cicd.pipelines.delete",
      "cicd.pipelineRuns.delete",
      "compute.instanceTemplates.delete",
      "compute.instanceGroups.delete",
      "network.natGateways.delete",
      "network.peerings.delete",
      "network.sharedVpc.delete",
      "bigquery.datasets.delete",
      "composer.environments.delete",
      "run.services.delete",
      "iam.serviceAccounts.delete",
      // Narrower than the old blanket "iam.*" -- that would also have shadowed
      // the iam.serviceAccounts.* entries just above in `allow` (deny always
      // wins), silently taking back the service-account access this role is
      // meant to have. Role/binding management specifically stays denied.
      "iam.roles.*",
      "iam.bindings.*",
    ],
  },
  {
    key: "viewer",
    name: "Viewer",
    allow: ["*.get", "*.list"],
    deny: ["*.create", "*.delete", "*.update", "*.exec", "*.start", "*.stop"],
  },
];

export function matchesPattern(pattern: string, action: string): boolean {
  if (pattern === "*") return true;
  // "*" is a genuine glob wildcard here -- it can span multiple dot-separated
  // segments (so "compute.*" matches "compute.instances.create", and "*.get"
  // matches both "projects.get" and "compute.instances.get"), not just one
  // segment. This matters because action strings in this system are not all
  // the same arity ("projects.get" is 2 segments, "compute.instances.get" is 3).
  const escaped = pattern
    .split("*")
    .map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join(".*");
  return new RegExp(`^${escaped}$`).test(action);
}

export function isAllowed(role: Role, action: string): boolean {
  const denied = role.deny.some((p) => matchesPattern(p, action));
  if (denied) return false;
  return role.allow.some((p) => matchesPattern(p, action));
}

// --- Milestone 5: secret encryption -------------------------------------
// Real envelope encryption (AES-256-GCM via Node's stdlib crypto), not a
// database column masked by the UI. The master key comes from
// SECRETS_MASTER_KEY (base64, 32 bytes); both apps/api and apps/worker read
// it via secretsMasterKeyFromEnv() so a value encrypted by one process can be
// decrypted by the other. A ciphertext payload is safe to store in a
// resource's `spec` and return from the API -- only the reveal endpoint,
// gated by its own IAM permission, ever produces plaintext again.
import { randomBytes, createCipheriv, createDecipheriv } from "node:crypto";

export interface EncryptedSecretPayload {
  algorithm: "aes-256-gcm";
  iv: string; // base64
  authTag: string; // base64
  ciphertext: string; // base64
}

export function secretsMasterKeyFromEnv(): Buffer {
  const raw = process.env.SECRETS_MASTER_KEY;
  if (raw) {
    const key = Buffer.from(raw, "base64");
    if (key.length === 32) return key;
  }
  // No key configured -- generate one for this process's lifetime. Real
  // encryption either way, but documented in ROADMAP.md: without a fixed
  // SECRETS_MASTER_KEY, secrets encrypted before a restart become
  // undecryptable after one, since api and worker would each mint their own
  // key. Set SECRETS_MASTER_KEY in .env for persistence across restarts.
  return randomBytes(32);
}

export function encryptSecretValue(plaintext: string, key: Buffer): EncryptedSecretPayload {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return {
    algorithm: "aes-256-gcm",
    iv: iv.toString("base64"),
    authTag: authTag.toString("base64"),
    ciphertext: ciphertext.toString("base64"),
  };
}

export function decryptSecretValue(payload: EncryptedSecretPayload, key: Buffer): string {
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(payload.iv, "base64"));
  decipher.setAuthTag(Buffer.from(payload.authTag, "base64"));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(payload.ciphertext, "base64")), decipher.final()]);
  return plaintext.toString("utf8");
}

// --- Milestone 12: learning system -----------------------------------------
// Scenario *content* (titles, instructions, step keys) lives here as plain
// data so both the API (which evaluates it) and any future client can share
// it. The actual pass/fail predicate for each step is deliberately NOT here
// -- it needs real database access, which apps/api/src/scenarios/checks.ts
// provides -- but every predicate is keyed by the `key` a step declares
// below, so the two stay linked without duplicating the step list.

export interface ScenarioStep {
  key: string;
  title: string;
  instructions: string;
}

export interface ScenarioDefinition {
  key: string;
  title: string;
  description: string;
  steps: ScenarioStep[];
}

export const SCENARIOS: ScenarioDefinition[] = [
  {
    key: "networking-fundamentals",
    title: "Networking Fundamentals",
    description: "Build a real VPC from the ground up: a network, a subnet inside it, an instance with a real static IP, and a firewall rule guarding it.",
    steps: [
      { key: "create-network", title: "Create a VPC network", instructions: "Go to Networking and create a network. Wait for it to reach READY -- that's a real Docker network, not a label." },
      { key: "create-subnet", title: "Create a subnet", instructions: "Under Networking, create a subnet inside that network and get it to READY." },
      { key: "create-instance-in-subnet", title: "Launch an instance inside the subnet", instructions: "Go to Compute and create an instance, choosing that subnet -- it should get a real static IP allocated from the subnet's CIDR." },
      { key: "add-firewall-rule", title: "Add a firewall rule", instructions: "Go to Firewall and add a rule for the network. It becomes a real iptables rule on the network's bridge once READY." },
    ],
  },
  {
    key: "compute-lifecycle",
    title: "Compute Lifecycle & Recovery",
    description: "Take an instance through a full real lifecycle: stop and restart it deliberately, then crash and recover it via fault injection.",
    steps: [
      { key: "create-instance", title: "Create an instance", instructions: "Go to Compute and create an instance. Wait for it to reach READY." },
      { key: "stop-and-start", title: "Stop it, then start it again", instructions: "Use the Stop button, wait for STOPPED, then use Start and wait for READY again -- two real, separate Docker lifecycle operations." },
      { key: "crash-and-recover", title: "Crash it, then recover it", instructions: "Open the instance and use Crash (SIGKILL) under Fault injection. Once it's FAILED, use Start to bring it back to READY." },
    ],
  },
  {
    key: "kubernetes-basics",
    title: "Kubernetes Basics",
    description: "Stand up CloudLab's own lightweight Kubernetes-like orchestrator, deploy a workload, and scale it.",
    steps: [
      { key: "create-cluster", title: "Create a cluster", instructions: "Go to Kubernetes and create a cluster. Wait for it to reach READY -- each node is a real container on a real Docker network." },
      { key: "deploy", title: "Deploy a workload with 2+ replicas", instructions: "Create a deployment on that cluster with at least 2 replicas and wait for it to reach READY." },
      { key: "scale", title: "Scale the deployment", instructions: "Use the deployment's scale control to change its replica count -- a real operation that adds or removes real pods." },
    ],
  },
  {
    key: "observability-alerting",
    title: "Observability & Alerting",
    description: "Generate real metrics, and make a real alert fire and get resolved.",
    steps: [
      { key: "collect-metrics", title: "Let real metrics accumulate", instructions: "With an instance READY, wait about 30s -- the metrics collector samples real container stats every 15s." },
      { key: "trigger-alert", title: "Make a real alert fire", instructions: "Cause a real problem (for example, crash an instance under Fault injection) and check the Observability tab for an open alert." },
      { key: "resolve-alert", title: "Resolve it", instructions: "Fix the underlying issue (recover the instance) or use the Resolve button once the underlying condition clears." },
    ],
  },
];

// Milestone 13: shared IPv4 CIDR arithmetic. This used to live only in
// apps/worker/src/net/ipalloc.ts (subnet containment + static-IP
// allocation); parseCidr is pulled out here so the API can do real,
// synchronous CIDR-overlap validation at network-create time (limitation
// #1 from ROADMAP.md's "known limitations") without a relative cross-app
// import. The worker still owns cidrContains/firstFreeIp -- those are
// allocation details specific to its job processors -- but both packages
// now parse CIDRs the same one way.
function ipToInt(ip: string): number {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) {
    throw new Error(`'${ip}' is not a valid IPv4 address`);
  }
  return ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
}

export function parseCidr(cidr: string): { base: number; prefix: number; size: number } {
  const [ip, prefixStr] = cidr.split("/");
  const prefix = Number(prefixStr);
  if (!ip || Number.isNaN(prefix) || prefix < 0 || prefix > 32) {
    throw new Error(`'${cidr}' is not a valid CIDR block`);
  }
  const size = 2 ** (32 - prefix);
  const base = ipToInt(ip) & ~(size - 1);
  return { base, prefix, size };
}

// Milestone 15 (Cloud Composer equivalent): minimal real 5-field cron
// matcher (minute hour day-of-month month day-of-week, UTC) -- "*", exact
// numbers, comma lists, and a "*/N" step on any field. Shared by the API
// (validates a schedule string at composer-environment create time) and the
// worker (apps/worker/src/composer/scheduler.ts, which actually fires runs
// on it) so both sides parse the exact same, honestly-documented subset of
// real cron syntax (no ranges like "1-5").
function cronFieldMatches(field: string, value: number): boolean {
  if (field === "*") return true;
  for (const part of field.split(",")) {
    if (part.startsWith("*/")) {
      const step = Number(part.slice(2));
      if (step > 0 && value % step === 0) return true;
    } else if (Number(part) === value) {
      return true;
    }
  }
  return false;
}

export function cronMatches(expr: string, at: Date = new Date()): boolean {
  const parts = expr.trim().split(/\s+/);
  if (parts.length !== 5) throw new Error(`'${expr}' is not a valid 5-field cron expression (minute hour day month weekday)`);
  const [min, hour, dom, month, dow] = parts;
  return (
    cronFieldMatches(min, at.getUTCMinutes()) &&
    cronFieldMatches(hour, at.getUTCHours()) &&
    cronFieldMatches(dom, at.getUTCDate()) &&
    cronFieldMatches(month, at.getUTCMonth() + 1) &&
    cronFieldMatches(dow, at.getUTCDay())
  );
}

export function assertValidCron(expr: string): void {
  cronMatches(expr, new Date()); // throws if malformed
}

export function cronMinuteKey(at: Date = new Date()): string {
  return at.toISOString().slice(0, 16); // "YYYY-MM-DDTHH:MM"
}

// True if the address ranges of `a` and `b` share at least one IP -- the
// real precondition for Docker's "Pool overlaps with other one on this
// address space" IPAM error, checked up front instead of surfacing async
// as a FAILED resource after the fact.
export function cidrsOverlap(a: string, b: string): boolean {
  const ra = parseCidr(a);
  const rb = parseCidr(b);
  return ra.base < rb.base + rb.size && rb.base < ra.base + ra.size;
}

// Milestone 16 (real region/zone/machine-type selection): a small, honest
// slice of GCP's real region/zone naming and machine-type shapes. This is
// intentionally not the full ~40-region GCP catalog -- five regions across
// three continents is enough to make region/zone a real, meaningful choice
// in the console and CLIs (and a real constraint: a subnet is regional, an
// instance's zone must fall inside a region that actually has a READY
// subnet if one is requested) without pretending to model GCP's full global
// footprint. A VPC network itself stays region-less here, same as real GCP.
export interface GcpRegion {
  region: string;
  location: string;
  zones: string[];
}

export const GCP_REGIONS: GcpRegion[] = [
  { region: "us-central1", location: "Iowa, USA", zones: ["us-central1-a", "us-central1-b", "us-central1-c"] },
  { region: "us-east1", location: "South Carolina, USA", zones: ["us-east1-b", "us-east1-c", "us-east1-d"] },
  { region: "europe-west1", location: "Belgium", zones: ["europe-west1-b", "europe-west1-c", "europe-west1-d"] },
  { region: "asia-south1", location: "Mumbai, India", zones: ["asia-south1-a", "asia-south1-b", "asia-south1-c"] },
  { region: "australia-southeast1", location: "Sydney, Australia", zones: ["australia-southeast1-a", "australia-southeast1-b", "australia-southeast1-c"] },
];

export const GCP_ZONES: string[] = GCP_REGIONS.flatMap((r) => r.zones);
export const DEFAULT_ZONE = "us-central1-a";
export const DEFAULT_REGION = "us-central1";

/** The region a zone belongs to, e.g. "us-central1-a" -> "us-central1" --
 * the same suffix-stripping rule GCP itself uses (a zone name is always its
 * region name plus one letter). */
export function regionOfZone(zone: string): string {
  return zone.replace(/-[a-z]$/, "");
}

export function isValidZone(zone: string): boolean {
  return GCP_ZONES.includes(zone);
}

export function isValidRegion(region: string): boolean {
  return GCP_REGIONS.some((r) => r.region === region);
}

// Machine types are a real resource-shape choice here, not a cosmetic label:
// the worker applies these vCPU/memory figures as genuine Docker CPU/memory
// limits on the guest container (see apps/worker/src/processors/instance.ts),
// so picking a bigger machine type really does give the simulated VM more
// headroom, and a real `docker inspect` shows the real limit -- honest
// substitutes scaled down from GCP's real e2 family sizes to stay friendly
// to a laptop running this whole stack locally.
export interface MachineTypeSpec {
  name: string;
  vcpus: number;
  memoryMb: number;
  description: string;
}

export const MACHINE_TYPES: MachineTypeSpec[] = [
  { name: "e2-micro", vcpus: 1, memoryMb: 512, description: "1 shared vCPU, 512 MB memory" },
  { name: "e2-small", vcpus: 1, memoryMb: 1024, description: "1 shared vCPU, 1 GB memory" },
  { name: "e2-medium", vcpus: 1, memoryMb: 2048, description: "1 vCPU, 2 GB memory" },
  { name: "e2-standard-2", vcpus: 2, memoryMb: 4096, description: "2 vCPUs, 4 GB memory" },
  { name: "e2-standard-4", vcpus: 4, memoryMb: 8192, description: "4 vCPUs, 8 GB memory" },
];

export const DEFAULT_MACHINE_TYPE = "e2-micro";

export function machineTypeSpec(name: string | undefined): MachineTypeSpec {
  return MACHINE_TYPES.find((m) => m.name === name) ?? MACHINE_TYPES[0];
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { useSearchParams } from "next/navigation";
import { Search, Layers, BookOpen, HelpCircle, TerminalSquare } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useProgressStore } from "@/store/progress-store";
import { GCP_RESOURCES, getResourceDef } from "@/lib/gcp";
import { CATEGORY_META, GcpResourceDef, ResourceCategory } from "@/types/gcp";
import { ResourceCard } from "@/components/gcp-services/resource-card";
import { ResourceDetailDialog } from "@/components/gcp-services/resource-detail-dialog";
import { ConsoleTab } from "@/components/gcp-console/console-tab";
import { cn } from "@/lib/utils";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

const CATEGORY_ORDER: ResourceCategory[] = [
  "networking",
  "compute",
  "storage",
  "database",
  "containers",
  "cicd",
  "security",
  "messaging",
];

const CATEGORY_CHIP_CLASS: Record<string, { active: string; inactive: string }> = {
  "gcp-blue": {
    active: "border-transparent bg-gcp-blue text-white",
    inactive: "border-border text-gcp-blue hover:bg-gcp-blue/10",
  },
  "gcp-green": {
    active: "border-transparent bg-gcp-green text-white",
    inactive: "border-border text-gcp-green hover:bg-gcp-green/10",
  },
  "gcp-yellow": {
    active: "border-transparent bg-gcp-yellow text-black",
    inactive: "border-border text-gcp-yellow hover:bg-gcp-yellow/10",
  },
  "gcp-red": {
    active: "border-transparent bg-gcp-red text-white",
    inactive: "border-border text-gcp-red hover:bg-gcp-red/10",
  },
};

export default function GcpServicesPage() {
  return (
    <React.Suspense fallback={null}>
      <GcpServicesContent />
    </React.Suspense>
  );
}

function GcpServicesContent() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const searchParams = useSearchParams();

  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<ResourceCategory | "all">("all");
  const [activeResource, setActiveResource] = React.useState<GcpResourceDef | null>(null);
  const [activeTab, setActiveTab] = React.useState<"console" | "catalog">("console");

  React.useEffect(() => {
    setModuleProgress("gcp-services", 20);
  }, [setModuleProgress]);

  React.useEffect(() => {
    const focus = searchParams.get("focus");
    if (focus) {
      const def = getResourceDef(focus);
      if (def) {
        setActiveResource(def);
        setActiveTab("catalog");
      }
    }
    // Only run once on mount to honor the initial deep link.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const totalQuizQuestions = React.useMemo(
    () => GCP_RESOURCES.reduce((sum, r) => sum + r.quiz.length, 0),
    [],
  );

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return GCP_RESOURCES.filter((r) => {
      if (category !== "all" && r.category !== category) return false;
      if (!q) return true;
      return (
        r.label.toLowerCase().includes(q) ||
        r.shortLabel.toLowerCase().includes(q) ||
        r.type.toLowerCase().includes(q)
      );
    });
  }, [query, category]);

  const grouped = React.useMemo(() => {
    const map = new Map<ResourceCategory, GcpResourceDef[]>();
    for (const cat of CATEGORY_ORDER) {
      const items = filtered.filter((r) => r.category === cat);
      if (items.length > 0) map.set(cat, items);
    }
    return map;
  }, [filtered]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">
          <span className="gradient-text">GCP Services</span>
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Build and manage simulated GCP resources hands-on in the Console, or browse the full Catalog &mdash; what
          each service is, when to reach for it, how to write it in Terraform, and what tends to go wrong in
          production.
        </p>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp}>
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "console" | "catalog")}>
          <TabsList>
            <TabsTrigger value="console" className="gap-1.5">
              <TerminalSquare className="h-3.5 w-3.5" /> Console
            </TabsTrigger>
            <TabsTrigger value="catalog" className="gap-1.5">
              <BookOpen className="h-3.5 w-3.5" /> Catalog
            </TabsTrigger>
          </TabsList>

          <TabsContent value="console">
            <ConsoleTab />
          </TabsContent>

          <TabsContent value="catalog">
            <div className="mb-6 grid grid-cols-3 gap-3 sm:max-w-md">
              <StatTile icon={Layers} value={GCP_RESOURCES.length} label="Resources" />
              <StatTile icon={BookOpen} value={CATEGORY_ORDER.length} label="Categories" />
              <StatTile icon={HelpCircle} value={totalQuizQuestions} label="Quiz questions" />
            </div>

            <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative w-full sm:max-w-xs">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search services..."
                  className="pl-9"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setCategory("all")}
                  className={cn(
                    "inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                    category === "all"
                      ? "border-transparent bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground hover:bg-accent",
                  )}
                >
                  All
                </button>
                {CATEGORY_ORDER.map((cat) => {
                  const meta = CATEGORY_META[cat];
                  const isActive = category === cat;
                  const cls = CATEGORY_CHIP_CLASS[meta.color] ?? CATEGORY_CHIP_CLASS["gcp-blue"];
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(isActive ? "all" : cat)}
                      className={cn(
                        "inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                        isActive ? cls.active : cls.inactive,
                      )}
                    >
                      {meta.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-10">
              {grouped.size === 0 && (
                <Card>
                  <CardContent className="py-10 text-center text-sm text-muted-foreground">
                    No services match your search.
                  </CardContent>
                </Card>
              )}
              {Array.from(grouped.entries()).map(([cat, items], i) => (
                <motion.section key={cat} initial="hidden" animate="show" custom={i} variants={fadeUp}>
                  <div className="mb-3 flex items-center gap-2">
                    <h2 className="text-lg font-semibold tracking-tight">{CATEGORY_META[cat].label}</h2>
                    <Badge variant="outline">{items.length}</Badge>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {items.map((def) => (
                      <ResourceCard key={def.type} def={def} onClick={() => setActiveResource(def)} />
                    ))}
                  </div>
                </motion.section>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>

      <ResourceDetailDialog
        def={activeResource}
        open={activeResource !== null}
        onOpenChange={(open) => {
          if (!open) setActiveResource(null);
        }}
      />
    </div>
  );
}

function StatTile({
  icon: Icon,
  value,
  label,
}: {
  icon: React.ElementType;
  value: number;
  label: string;
}) {
  return (
    <div className="glass-panel flex flex-col items-center justify-center gap-1 rounded-xl px-3 py-3 text-center">
      <Icon className="h-4 w-4 text-primary" />
      <span className="text-lg font-semibold leading-none">{value}</span>
      <span className="text-[10px] text-muted-foreground">{label}</span>
    </div>
  );
}

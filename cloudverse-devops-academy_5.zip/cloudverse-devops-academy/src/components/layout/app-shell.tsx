"use client";
import * as React from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { CommandPalette } from "@/components/layout/command-palette";
import { OnboardingTour } from "@/components/layout/onboarding-tour";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useGcpConsoleStore } from "@/store/gcp-console-store";

export function AppShell({ children }: { children: React.ReactNode }) {
  // Heal any resource left mid-transition (provisioning/starting/stopping, or a
  // simulated-failure that was mid-recovery) by a hard page reload — run this
  // once, app-wide, rather than only when the user happens to land on the GCP
  // Console tab, so a refresh from any page (Operations Suite included) never
  // leaves a resource stuck in a state that can no longer change on its own.
  React.useEffect(() => {
    useGcpConsoleStore.getState().resumeStuckStates();
  }, []);

  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex h-svh w-full overflow-hidden bg-background">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar />
          <main className="flex-1 overflow-y-auto">{children}</main>
        </div>
        <CommandPalette />
        <OnboardingTour />
        <Toaster position="bottom-right" />
      </div>
    </TooltipProvider>
  );
}

"use client";

import * as React from "react";
import { KeyRound, Activity, CheckCircle2, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";
import { ConsoleResource } from "@/store/gcp-console-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Kept in sync with the identical map in console-tab.tsx — duplicated (rather than
// imported) to avoid a circular import between the two sibling components.
const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "provisioning",
  starting: "starting",
  stopping: "stopping",
  deleting: "deleting",
  running: "running",
  stopped: "stopped",
  error: "in an error state",
};

// ---------------------------------------------------------------------------
// Layout constants
// ---------------------------------------------------------------------------

const LANE_WIDTH = 210;
const ROW_HEIGHT = 96;
const CARD_WIDTH = 180;
const CARD_HEIGHT = 64;
const MARGIN_X = 24;
const MARGIN_TOP = 24;
const IDENTITY_BAND_HEIGHT = 56;

interface Lane {
  key: string;
  label: string;
  types: string[];
}

const LANES: Lane[] = [
  { key: "networking", label: "Networking", types: ["vpc", "subnet", "router", "nat", "dns", "vpn", "interconnect", "lb"] },
  { key: "security", label: "Security", types: ["armor"] },
  { key: "compute", label: "Compute & Containers", types: ["vm", "mig", "gke"] },
  { key: "data", label: "Data", types: ["cloudsql", "redis", "gcs"] },
  { key: "cicd", label: "CI/CD & Messaging", types: ["artifact_registry", "cloud_build", "pubsub"] },
];

// Resource types whose config carries a real binding to a subnet.
const SUBNET_BOUND_TYPES = ["vm", "mig", "gke", "cloudsql", "redis"];

// Same 4 tokens used elsewhere in this app — literal map, never a template string.
const COLOR_DOT_CLASS: Record<string, string> = {
  "gcp-blue": "bg-gcp-blue",
  "gcp-red": "bg-gcp-red",
  "gcp-yellow": "bg-gcp-yellow",
  "gcp-green": "bg-gcp-green",
};

const COLOR_BORDER_CLASS: Record<string, string> = {
  "gcp-blue": "border-t-gcp-blue",
  "gcp-red": "border-t-gcp-red",
  "gcp-yellow": "border-t-gcp-yellow",
  "gcp-green": "border-t-gcp-green",
};

interface PlacedNode {
  resource: ConsoleResource;
  laneIndex: number;
  x: number;
  y: number;
}

interface LayoutResult {
  lanes: { label: string; x: number }[];
  nodes: PlacedNode[];
  width: number;
  height: number;
  maxRows: number;
}

function computeLayout(resources: ConsoleResource[]): LayoutResult {
  const buckets = LANES.map((lane) => resources.filter((r) => lane.types.includes(r.type)));
  const activeLaneIdxs = buckets.map((b, i) => (b.length > 0 ? i : -1)).filter((i) => i >= 0);

  const lanes: { label: string; x: number }[] = [];
  const nodes: PlacedNode[] = [];
  let maxRows = 0;

  activeLaneIdxs.forEach((laneIdx, renderIdx) => {
    const x = MARGIN_X + renderIdx * LANE_WIDTH;
    lanes.push({ label: LANES[laneIdx].label, x });
    const bucket = buckets[laneIdx];
    maxRows = Math.max(maxRows, bucket.length);
    bucket.forEach((resource, rowIdx) => {
      nodes.push({
        resource,
        laneIndex: renderIdx,
        x,
        y: MARGIN_TOP + rowIdx * ROW_HEIGHT,
      });
    });
  });

  const width = activeLaneIdxs.length > 0 ? MARGIN_X * 2 + activeLaneIdxs.length * LANE_WIDTH : 0;
  const height = MARGIN_TOP * 2 + Math.max(maxRows, 1) * ROW_HEIGHT;

  return { lanes, nodes, width, height, maxRows };
}

interface Edge {
  from: PlacedNode;
  to: PlacedNode;
}

// Draws only edges backed by a real binding chosen when the resource was created
// (subnet -> vpcId, vm/mig/gke/cloudsql/redis -> subnetId, lb -> backendTargetIds) —
// never a guess based on which types merely happen to co-exist.
function buildEdges(nodes: PlacedNode[]): Edge[] {
  const byId = new Map(nodes.map((n) => [n.resource.id, n]));
  const edges: Edge[] = [];

  for (const node of nodes) {
    const cfg = node.resource.config;

    if (node.resource.type === "subnet" && typeof cfg.vpcId === "string" && cfg.vpcId) {
      const vpc = byId.get(cfg.vpcId);
      if (vpc) edges.push({ from: vpc, to: node });
    }

    if (SUBNET_BOUND_TYPES.includes(node.resource.type) && typeof cfg.subnetId === "string" && cfg.subnetId) {
      const subnet = byId.get(cfg.subnetId);
      if (subnet) edges.push({ from: subnet, to: node });
    }

    if (node.resource.type === "lb" && Array.isArray(cfg.backendTargetIds)) {
      for (const targetId of cfg.backendTargetIds as string[]) {
        const target = byId.get(targetId);
        if (target) edges.push({ from: node, to: target });
      }
    }
  }

  return edges;
}

// Every type the connectivity test knows how to place on a traffic path — used
// only to flag "orphan" resources that exist but aren't wired into anything.
const CHAIN_TYPES = ["vpc", "subnet", "vm", "mig", "gke", "cloudsql", "redis", "lb"];

export interface HopResult {
  key: string;
  fromLabel: string;
  toLabel: string;
  toResourceId: string;
  status: "pass" | "fail";
  latencyMs?: number;
  reason?: string;
}

export interface OrphanResult {
  resourceId: string;
  label: string;
}

export interface ConnectivityTestResult {
  hops: HopResult[];
  orphans: OrphanResult[];
  ranAt: string;
}

// Walks the real bindings already drawn as edges and checks each hop against the
// target resource's ACTUAL runtime status and logs — never a coin flip. A resource
// that's running passes with a fabricated (but plausible) latency; anything else
// fails with the real reason (its last error log line, or its current status).
function runConnectivityTest(nodes: PlacedNode[], edges: Edge[]): ConnectivityTestResult {
  const hops: HopResult[] = edges.map((edge, i) => {
    const target = edge.to.resource;
    const key = `${edge.from.resource.id}-${target.id}-${i}`;
    const base = { key, fromLabel: edge.from.resource.name, toLabel: target.name, toResourceId: target.id };

    if (target.status === "running") {
      return { ...base, status: "pass" as const, latencyMs: 8 + Math.round(Math.random() * 70) };
    }
    if (target.status === "error") {
      const lastError = [...target.logs].reverse().find((l) => l.level === "error");
      return { ...base, status: "fail" as const, reason: lastError?.message ?? `${target.name} reported an error.` };
    }
    return {
      ...base,
      status: "fail" as const,
      reason: `${target.name} is ${STATUS_LABEL[target.status]} — not currently serving traffic.`,
    };
  });

  const touchedIds = new Set<string>();
  edges.forEach((e) => {
    touchedIds.add(e.from.resource.id);
    touchedIds.add(e.to.resource.id);
  });
  const orphans: OrphanResult[] = nodes
    .filter((n) => CHAIN_TYPES.includes(n.resource.type) && !touchedIds.has(n.resource.id))
    .map((n) => ({ resourceId: n.resource.id, label: n.resource.name }));

  return { hops, orphans, ranAt: new Date().toISOString() };
}

function cardCenter(node: PlacedNode) {
  return {
    cx: node.x + CARD_WIDTH / 2,
    left: node.x,
    right: node.x + CARD_WIDTH,
    top: node.y,
    bottom: node.y + CARD_HEIGHT,
    midY: node.y + CARD_HEIGHT / 2,
  };
}

// Literal stroke-color lookup for tested edges — never interpolated.
const EDGE_STROKE: Record<"neutral" | "pass" | "fail", string> = {
  neutral: "hsl(var(--border))",
  pass: "#22c55e",
  fail: "#ef4444",
};
const EDGE_MARKER: Record<"neutral" | "pass" | "fail", string> = {
  neutral: "url(#arch-diagram-arrow)",
  pass: "url(#arch-diagram-arrow-pass)",
  fail: "url(#arch-diagram-arrow-fail)",
};

function EdgePath({ edge, offsetY, hopStatus }: { edge: Edge; offsetY: number; hopStatus?: "pass" | "fail" }) {
  const from = cardCenter(edge.from);
  const to = cardCenter(edge.to);

  // Elbow: exit right edge of source, enter left edge of target (or the
  // reverse when the target lane is to the left/same lane as the source).
  const sameLane = edge.from.laneIndex === edge.to.laneIndex;
  const forward = to.left >= from.right || sameLane;

  const startX = forward ? from.right : from.left;
  const startY = from.midY + offsetY;
  const endX = forward ? to.left : to.right;
  const endY = to.midY + offsetY;
  const midX = sameLane ? startX + 26 : (startX + endX) / 2;

  const d = sameLane
    ? `M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${startX} ${endY}`
    : `M ${startX} ${startY} L ${midX} ${startY} L ${midX} ${endY} L ${endX} ${endY}`;

  const tone = hopStatus ?? "neutral";

  return (
    <path
      d={d}
      fill="none"
      stroke={EDGE_STROKE[tone]}
      strokeWidth={hopStatus ? 2 : 1.5}
      markerEnd={EDGE_MARKER[tone]}
    />
  );
}

type NodeTestBadge = "pass" | "fail" | "orphan" | undefined;

function NodeCard({
  node,
  serviceAccounts,
  testBadge,
}: {
  node: PlacedNode;
  serviceAccounts: { id: string; name: string; email: string }[];
  testBadge?: NodeTestBadge;
}) {
  const { resource } = node;
  const def = getResourceDef(resource.type);
  if (!def) return null;

  const saId = resource.config.serviceAccountId;
  const attachedSa =
    typeof saId === "string" && saId.length > 0 ? serviceAccounts.find((sa) => sa.id === saId) : undefined;

  return (
    <div
      className={cn(
        "absolute flex items-center gap-2 rounded-xl border border-t-4 bg-card px-2.5 py-2 shadow-sm",
        COLOR_BORDER_CLASS[def.color] ?? COLOR_BORDER_CLASS["gcp-blue"],
        resource.status === "error" && "ring-2 ring-gcp-red/70",
        testBadge === "fail" && "ring-2 ring-red-500/70",
        testBadge === "orphan" && "ring-2 ring-amber-500/60",
      )}
      style={{ left: node.x, top: node.y, width: CARD_WIDTH, height: CARD_HEIGHT }}
      title={`${resource.name} (${def.label})`}
    >
      <ResourceIcon type={def.type} color={def.color} size={16} className="h-7 w-7" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-semibold leading-tight">{resource.name}</p>
        <p className="truncate text-[10px] text-muted-foreground leading-tight">{def.shortLabel}</p>
      </div>
      {resource.status === "error" && (
        <span className="h-2 w-2 shrink-0 rounded-full bg-gcp-red" aria-label="Error" />
      )}
      {attachedSa && (
        <span
          className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-gcp-yellow text-black shadow"
          title={`Runs as ${attachedSa.name}`}
        >
          <KeyRound size={10} strokeWidth={2.5} />
        </span>
      )}
      {testBadge === "pass" && (
        <span className="absolute -bottom-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-white shadow" title="Reachable">
          <CheckCircle2 size={11} strokeWidth={2.5} />
        </span>
      )}
      {testBadge === "fail" && (
        <span className="absolute -bottom-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-white shadow" title="Unreachable">
          <XCircle size={11} strokeWidth={2.5} />
        </span>
      )}
      {testBadge === "orphan" && (
        <span className="absolute -bottom-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-white shadow" title="Not bound to anything">
          <AlertTriangle size={11} strokeWidth={2.5} />
        </span>
      )}
    </div>
  );
}

export function ArchitectureDiagram({
  resources,
  serviceAccounts = [],
  onFixBinding,
}: {
  resources: ConsoleResource[];
  serviceAccounts?: { id: string; name: string; email: string }[];
  /** Called with a resource id when the viewer clicks "Fix binding" on an orphaned node. */
  onFixBinding?: (resourceId: string) => void;
}) {
  const [testResult, setTestResult] = React.useState<ConnectivityTestResult | null>(null);
  const [testing, setTesting] = React.useState(false);

  if (resources.length === 0) {
    return (
      <div className="flex min-h-[220px] items-center justify-center rounded-xl border border-dashed border-border bg-muted/30 px-6 text-center text-sm text-muted-foreground">
        No resources yet — create something in the Console to see it appear here.
      </div>
    );
  }

  const layout = computeLayout(resources);
  const edges = buildEdges(layout.nodes);

  const hopStatusByEdgeTarget = new Map<string, "pass" | "fail">();
  if (testResult) {
    testResult.hops.forEach((h) => hopStatusByEdgeTarget.set(h.toResourceId, h.status));
  }
  const orphanIds = new Set(testResult?.orphans.map((o) => o.resourceId) ?? []);

  function badgeFor(resourceId: string): NodeTestBadge {
    if (!testResult) return undefined;
    if (orphanIds.has(resourceId)) return "orphan";
    const hop = testResult.hops.find((h) => h.toResourceId === resourceId);
    return hop?.status;
  }

  function handleRunTest() {
    setTesting(true);
    // Tiny artificial delay so it reads as "actually probing" rather than instant.
    setTimeout(() => {
      setTestResult(runConnectivityTest(layout.nodes, edges));
      setTesting(false);
    }, 500);
  }

  const attachedSaIds = new Set(
    layout.nodes
      .map((n) => n.resource.config.serviceAccountId)
      .filter((v): v is string => typeof v === "string" && v.length > 0),
  );
  const identitiesInUse = serviceAccounts.filter((sa) => attachedSaIds.has(sa.id));
  const showIdentityBand = identitiesInUse.length > 0;

  const canvasWidth = layout.width;
  const canvasHeight = layout.height + (showIdentityBand ? IDENTITY_BAND_HEIGHT : 0);
  const nodeOffsetY = showIdentityBand ? IDENTITY_BAND_HEIGHT : 0;

  const categoriesPresent = Array.from(
    new Set(
      layout.nodes
        .map((n) => getResourceDef(n.resource.type)?.category)
        .filter((c): c is ResourceCategory => Boolean(c)),
    ),
  );

  return (
    <div className="space-y-3">
      <div className="min-h-[260px] overflow-x-auto rounded-xl border border-border bg-muted/20 p-2">
        <div className="relative" style={{ width: canvasWidth, height: canvasHeight }}>
          {/* Lane headers */}
          {layout.lanes.map((lane) => (
            <div
              key={lane.label}
              className="absolute top-0 truncate text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
              style={{ left: lane.x, width: CARD_WIDTH, top: nodeOffsetY - 18 }}
            >
              {lane.label}
            </div>
          ))}

          {/* Identity band */}
          {showIdentityBand && (
            <div className="absolute left-0 top-0 flex items-center gap-2" style={{ width: canvasWidth, height: IDENTITY_BAND_HEIGHT - 12 }}>
              {identitiesInUse.map((sa) => (
                <span
                  key={sa.id}
                  className="flex items-center gap-1 rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-medium"
                >
                  <KeyRound size={11} className="text-gcp-yellow" />
                  {sa.name}
                </span>
              ))}
            </div>
          )}

          {/* Edge overlay */}
          <svg
            className="pointer-events-none absolute left-0 top-0"
            width={canvasWidth}
            height={canvasHeight}
            style={{ overflow: "visible" }}
          >
            <defs>
              <marker
                id="arch-diagram-arrow"
                viewBox="0 0 8 8"
                refX="7"
                refY="4"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M0,0 L8,4 L0,8 Z" fill="hsl(var(--border))" />
              </marker>
              <marker
                id="arch-diagram-arrow-pass"
                viewBox="0 0 8 8"
                refX="7"
                refY="4"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M0,0 L8,4 L0,8 Z" fill={EDGE_STROKE.pass} />
              </marker>
              <marker
                id="arch-diagram-arrow-fail"
                viewBox="0 0 8 8"
                refX="7"
                refY="4"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M0,0 L8,4 L0,8 Z" fill={EDGE_STROKE.fail} />
              </marker>
            </defs>
            {edges.map((edge, i) => (
              <EdgePath
                key={`${edge.from.resource.id}-${edge.to.resource.id}-${i}`}
                edge={edge}
                offsetY={nodeOffsetY}
                hopStatus={hopStatusByEdgeTarget.get(edge.to.resource.id)}
              />
            ))}
            {showIdentityBand &&
              identitiesInUse.map((sa) =>
                layout.nodes
                  .filter((n) => n.resource.config.serviceAccountId === sa.id)
                  .map((n) => {
                    const c = cardCenter(n);
                    const topX = c.left + 12;
                    return (
                      <line
                        key={`${sa.id}-${n.resource.id}`}
                        x1={topX}
                        y1={IDENTITY_BAND_HEIGHT - 16}
                        x2={topX}
                        y2={c.top + nodeOffsetY}
                        stroke="hsl(var(--border))"
                        strokeWidth={1.5}
                        strokeDasharray="4 3"
                      />
                    );
                  }),
              )}
          </svg>

          {/* Nodes */}
          {layout.nodes.map((node) => (
            <NodeCard
              key={node.resource.id}
              node={{ ...node, y: node.y + nodeOffsetY }}
              serviceAccounts={serviceAccounts}
              testBadge={badgeFor(node.resource.id)}
            />
          ))}
        </div>
      </div>

      {/* Connectivity test */}
      <div className="rounded-xl border border-border bg-card/40 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-sm font-medium">
            <Activity className="h-4 w-4 text-primary" /> Connectivity Test
          </div>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={handleRunTest} disabled={testing}>
            {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Activity className="h-3.5 w-3.5" />}
            {testing ? "Probing..." : testResult ? "Run Again" : "Run Connectivity Test"}
          </Button>
        </div>

        {!testResult && !testing && (
          <p className="mt-2 text-xs text-muted-foreground">
            Simulates traffic across every real binding above and reports whether each hop&apos;s target is actually
            reachable, using that resource&apos;s live status and logs — not a guess.
          </p>
        )}

        {testResult && (
          <div className="mt-3 space-y-3">
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <span className="flex items-center gap-1 font-medium text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" /> {testResult.hops.filter((h) => h.status === "pass").length} healthy
              </span>
              <span className="flex items-center gap-1 font-medium text-red-600 dark:text-red-400">
                <XCircle className="h-3.5 w-3.5" /> {testResult.hops.filter((h) => h.status === "fail").length} failing
              </span>
              {testResult.orphans.length > 0 && (
                <span className="flex items-center gap-1 font-medium text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-3.5 w-3.5" /> {testResult.orphans.length} unreachable (not bound)
                </span>
              )}
            </div>

            {testResult.hops.length === 0 && testResult.orphans.length === 0 && (
              <p className="text-xs text-muted-foreground">No bindings to test yet.</p>
            )}

            <ul className="space-y-1.5">
              {testResult.hops.map((h) => (
                <li key={h.key} className="flex items-start gap-2 rounded-lg border border-border/60 px-2.5 py-1.5 text-xs">
                  {h.status === "pass" ? (
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  ) : (
                    <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-500" />
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="font-medium">
                      {h.fromLabel} → {h.toLabel}
                    </span>
                    {h.status === "pass" ? (
                      <span className="text-muted-foreground"> — reachable ({h.latencyMs}ms)</span>
                    ) : (
                      <span className="block text-red-600 dark:text-red-400">{h.reason}</span>
                    )}
                  </span>
                </li>
              ))}
              {testResult.orphans.map((o) => (
                <li key={o.resourceId} className="flex items-start gap-2 rounded-lg border border-border/60 px-2.5 py-1.5 text-xs">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
                  <span className="min-w-0 flex-1">
                    <span className="font-medium">{o.label}</span>
                    <span className="block text-amber-600 dark:text-amber-400">
                      Not bound to anything — no traffic can reach it. Bind it to include it in the path.
                    </span>
                  </span>
                  {onFixBinding && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 shrink-0 gap-1 px-2 text-[11px]"
                      onClick={() => onFixBinding(o.resourceId)}
                    >
                      Fix binding
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 px-1 text-[11px] text-muted-foreground">
        {categoriesPresent.map((cat) => {
          const meta = CATEGORY_META[cat];
          return (
            <span key={cat} className="flex items-center gap-1.5">
              <span className={cn("h-2 w-2 rounded-full", COLOR_DOT_CLASS[meta.color] ?? COLOR_DOT_CLASS["gcp-blue"])} />
              {meta.label}
            </span>
          );
        })}
        {showIdentityBand && (
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-px w-4 border-t border-dashed border-muted-foreground" />
            runs as this identity
          </span>
        )}
      </div>
      <p className="px-1 text-[11px] text-muted-foreground">
        Lines show real bindings you chose at creation time (subnet → VPC, VM/MIG/GKE/Cloud SQL/Redis → subnet, load
        balancer → backend targets) — a resource with no line simply hasn&apos;t been bound to anything yet.
      </p>
    </div>
  );
}

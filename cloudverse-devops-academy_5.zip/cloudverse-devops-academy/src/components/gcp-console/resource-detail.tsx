"use client";

import * as React from "react";
import { ExternalLink, DollarSign, ShieldCheck } from "lucide-react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { CodeBlock } from "@/components/code-block";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ScenarioList } from "@/components/console-sim/scenario-list";
import { getResourceDef } from "@/lib/gcp";
import { scenariosForResourceType } from "@/lib/console-sim/scenarios-gcp";
import { useGcpConsoleStore, ConsoleResource } from "@/store/gcp-console-store";
import { useIamStore } from "@/store/iam-store";
import { ConfigForm } from "@/components/architecture/config-form";
import { ResourceConfig } from "@/types/gcp";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { cn, formatCurrency, slugify } from "@/lib/utils";
import { useMonitoringTicker } from "@/store/monitoring-store";
import { ResourceMetricsPanel } from "@/components/operations-suite/resource-metrics-panel";

// Kept in sync with the identical map in console-tab.tsx — duplicated (rather than
// imported) to avoid a circular import between the two sibling components.
const STATUS_BADGE_CLASS: Record<ResourceRuntimeStatus, string> = {
  provisioning: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  starting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  stopping: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  deleting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  running: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  stopped: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  error: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
};

const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "Provisioning",
  starting: "Starting",
  stopping: "Stopping",
  deleting: "Deleting",
  running: "Running",
  stopped: "Stopped",
  error: "Error",
};

function formatConfigValue(
  field: { key: string; type: string },
  v: ResourceConfig[string],
  resourceById: Map<string, { name: string }>,
): string {
  if (field.type === "resource-ref") {
    if (typeof v !== "string" || !v) return "Not bound";
    return resourceById.get(v)?.name ?? "Not bound";
  }
  if (field.type === "resource-ref-multi") {
    const ids = Array.isArray(v) ? (v as string[]) : [];
    if (ids.length === 0) return "Not bound";
    return ids.map((id) => resourceById.get(id)?.name ?? "(deleted)").join(", ");
  }
  if (Array.isArray(v)) return v.length ? v.join(", ") : "—";
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (v === "" || v === undefined || v === null) return "—";
  return String(v);
}

export function ResourceDetail({
  resource,
  open,
  onOpenChange,
}: {
  resource: ConsoleResource | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  useMonitoringTicker();
  const simulateScenario = useGcpConsoleStore((s) => s.simulateScenario);
  const allResources = useGcpConsoleStore((s) => s.resources);
  const updateResourceConfig = useGcpConsoleStore((s) => s.updateResourceConfig);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const def = resource ? getResourceDef(resource.type) : undefined;
  const resourceById = React.useMemo(
    () => new Map(allResources.map((r) => [r.id, { name: r.name }])),
    [allResources],
  );
  const refFields = React.useMemo(
    () => (def ? def.configFields.filter((f) => f.type === "resource-ref" || f.type === "resource-ref-multi") : []),
    [def],
  );
  const refCandidates = React.useMemo(
    () =>
      resource
        ? allResources.filter((r) => r.id !== resource.id).map((r) => ({ id: r.id, type: r.type, name: r.name }))
        : [],
    [allResources, resource],
  );

  if (!resource || !def) return null;

  const attachedServiceAccount = resource.config.serviceAccountId
    ? serviceAccounts.find((sa) => sa.id === resource.config.serviceAccountId)
    : undefined;

  const terraform = def.generateTerraform({
    config: resource.config,
    nodeId: resource.id,
    label: resource.name,
    slug: slugify(resource.name || def.type),
    allNodes: [],
    connections: [],
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 sm:max-w-lg">
        <SheetHeader className="border-b border-border pb-4">
          <div className="flex items-center gap-3">
            <ResourceIcon type={def.type} color={def.color} size={18} className="h-10 w-10" />
            <div className="min-w-0 flex-1">
              <SheetTitle className="truncate">{resource.name}</SheetTitle>
              <SheetDescription className="truncate">{def.label}</SheetDescription>
            </div>
            <Badge className={cn("shrink-0", STATUS_BADGE_CLASS[resource.status])}>
              {STATUS_LABEL[resource.status]}
            </Badge>
          </div>
        </SheetHeader>

        <Tabs defaultValue="overview" className="flex flex-1 flex-col overflow-hidden">
          <TabsList className="mx-4 mt-3 grid grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="terraform">Terraform</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
            <TabsTrigger value="fix">Fix</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1">
            <TabsContent value="overview" className="m-0 space-y-4 p-4">
              <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <DollarSign className="h-3.5 w-3.5" /> Est. monthly cost
                </span>
                <span className="text-sm font-semibold">{formatCurrency(def.estimateMonthlyCost(resource.config))}</span>
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5" /> Runs as
                </span>
                <span className="truncate text-right text-sm font-medium">
                  {attachedServiceAccount ? attachedServiceAccount.email : "Default service account"}
                </span>
              </div>

              <div className="rounded-lg border border-border p-3">
                <p className="mb-2 text-xs font-medium text-muted-foreground">Configuration</p>
                <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-sm">
                  {def.configFields.map((field) => (
                    <React.Fragment key={field.key}>
                      <dt className="truncate text-muted-foreground">{field.label}</dt>
                      <dd className="truncate text-right font-medium">
                        {formatConfigValue(field, resource.config[field.key], resourceById)}
                      </dd>
                    </React.Fragment>
                  ))}
                </dl>
              </div>

              {refFields.length > 0 && (
                <div className="rounded-lg border border-border p-3">
                  <p className="mb-1 text-xs font-medium text-muted-foreground">Connections</p>
                  <p className="mb-3 text-[11px] text-muted-foreground">
                    Bind this resource to others so it counts as a real edge in the Architecture Diagram and its
                    Connectivity Test — this updates the live resource immediately, no need to recreate it.
                  </p>
                  <ConfigForm
                    fields={refFields}
                    config={resource.config}
                    onChange={(patch) => updateResourceConfig(resource.id, patch)}
                    resources={refCandidates}
                  />
                </div>
              )}

              <p className="text-xs text-muted-foreground">
                Created {new Date(resource.createdAt).toLocaleString()}
              </p>

              <a
                href={def.docsUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs text-primary hover:underline"
              >
                Read the official GCP docs <ExternalLink className="h-3 w-3" />
              </a>
            </TabsContent>

            <TabsContent value="terraform" className="m-0 p-4">
              <CodeBlock code={terraform} language="hcl" filename={`${def.terraformResourceType}.tf`} />
            </TabsContent>

            <TabsContent value="logs" className="m-0 p-4">
              <TerminalOutput lines={resource.logs} heightClassName="h-96" />
            </TabsContent>

            <TabsContent value="fix" className="m-0 p-4">
              <p className="mb-3 text-xs text-muted-foreground">
                Common issues with {def.label} and how to resolve them. Simulate one to replay realistic CLI output
                into the Logs tab and watch this resource recover.
              </p>
              <ScenarioList
                scenarios={scenariosForResourceType(resource.type)}
                onSimulate={(scenario) => simulateScenario(resource.id, scenario)}
              />
            </TabsContent>

            <TabsContent value="monitoring" className="m-0 p-4">
              <ResourceMetricsPanel resource={resource} />
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}

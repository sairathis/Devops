@echo off
REM ============================================================================
REM run_naukri.bat - launches one NaukriBot cycle. Called by Windows Task Scheduler.
REM Usage: run_naukri.bat [monitor|apply]     (default: monitor)
REM ============================================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "MODE=%~1"
if "%MODE%"=="" set "MODE=monitor"

set "PYTHON_EXE=%~dp0.venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    echo [ERROR] Virtual environment not found. Run setup.bat first.
    exit /b 1
)

REM Timestamped console capture (execution.log is written by the application itself)
if not exist "logs" mkdir "logs"
set "STAMP=%DATE:~-4%%DATE:~4,2%%DATE:~7,2%_%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%"
set "STAMP=%STAMP: =0%"
echo [%DATE% %TIME%] NaukriBot starting. Mode=%MODE%

"%PYTHON_EXE%" main.py run --mode %MODE% --account all > "logs\task_%MODE%_%STAMP%.txt" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

echo [%DATE% %TIME%] NaukriBot finished with exit code %EXIT_CODE%
exit /b %EXIT_CODE%

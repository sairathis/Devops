@echo off
REM ============================================================================
REM setup.bat - one-time setup: virtual environment, dependencies, Playwright
REM browser, runtime folders and database initialisation.
REM ============================================================================
setlocal
cd /d "%~dp0"

echo === NaukriBot setup ===

where py >nul 2>nul
if %ERRORLEVEL%==0 (
    set "PY=py -3.12"
) else (
    set "PY=python"
)

%PY% --version
if errorlevel 1 (
    echo [ERROR] Python 3.12+ not found. Install from https://www.python.org/downloads/windows/
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment in .venv ...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create virtual environment.
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    exit /b 1
)

echo Installing Playwright Chromium ...
python -m playwright install chromium
if errorlevel 1 (
    echo [ERROR] Playwright browser installation failed.
    exit /b 1
)

if not exist "database" mkdir "database"
if not exist "reports" mkdir "reports"
if not exist "screenshots" mkdir "screenshots"
if not exist "logs" mkdir "logs"

python main.py init-db
if errorlevel 1 (
    echo [ERROR] Database initialisation failed.
    exit /b 1
)

echo.
echo === Setup complete ===
echo Next steps:
echo   1. Set credential environment variables (README section 10).
echo   2. Run: python main.py test-email
echo   3. Run: python main.py run --mode monitor
echo   4. When satisfied: python main.py install-schedule --mode monitor
exit /b 0

# NaukriBot

Naukri job monitoring, filtering, reporting, email notification and controlled
auto-apply for two Naukri accounts. Runs on Windows, scheduled with Windows Task Scheduler.

- **Phase 1 - MONITOR (default):** searches, filters, stores, reports and emails. Never applies.
- **Phase 2 - APPLY:** same pipeline, plus Easy Apply for jobs that pass every rule. Enabled only when `AUTO_APPLY: true` **and** `MODE: APPLY`.

Resumes are never uploaded. Each account applies with the default resume already configured in Naukri.

---

## 1. Architecture Diagram

```
                       +-----------------------------+
                       |  Windows Task Scheduler     |
                       |  10:00 / 13:00 / 17:00      |
                       +--------------+--------------+
                                      |  run_naukri.bat monitor|apply
                                      v
+-----------------------------------------------------------------------------+
|                              main.py (orchestrator)                         |
|   RunLock -> load config -> load accounts -> NaukriBotRunner                |
+------+------------------+-------------------+--------------------+----------+
       |                  |                   |                    |
       v                  v                   v                    v
+-------------+   +---------------+   +----------------+   +----------------+
| login.py    |   | search.py     |   | filtering.py   |   | walkin_        |
| Playwright  |-->| cards + detail|-->| location/exp/  |-->| detector.py    |
| per account |   | pages         |   | age            |   |                |
+-------------+   +---------------+   +----------------+   +--------+-------+
                                                                    |
                  +-------------------------------------------------+
                  v
+---------------+    +----------------+    +---------------+    +----------------+
| scoring.py    |--->| database.py    |--->| apply.py      |--->| report.py      |
| 0-100, rank   |    | SQLite (WAL)   |    | Easy Apply    |    | Excel (pandas, |
+---------------+    +-------+--------+    | APPLY mode    |    | openpyxl)      |
                             |             +-------+-------+    +--------+-------+
                             |                     |                     |
                             v                     v                     v
                     +------------------------------------------------------------+
                     | emailer.py  - summary (+Excel), walk-in alert, application |
                     +------------------------------------------------------------+
                             |
                             v
                     logs/execution.log  logs/application.log  logs/error.log
                     screenshots/*.png   reports/*.xlsx
```

## 2. Workflow Diagram

```
START run
  |
  v
For each enabled account (account1, then account2):
  |  login (own browser context)  --fail--> ExecutionLog FAILED, next account
  |  [APPLY mode] apply to reviewed NEW jobs from earlier runs
  |
  |  For each keyword in profile.search_keywords:
  |    search pages (experience=3, jobAge=7 pushed to Naukri)
  |    For each job card:
  |      1. Job ID already in DB?          -> DUPLICATE (touch last_seen)
  |      2. Location / experience / age?   -> SKIPPED (reason)
  |      3. Walk-in keywords in card?      -> WALK_IN + alert email
  |      4. Open detail page (description, Easy Apply)
  |      5. Walk-in keywords in detail?    -> WALK_IN + alert email
  |      6. Easy Apply present?            else SKIPPED "Not Easy Apply"
  |      7. Score >= 60?                   else SKIPPED "Low Score"
  |      8. Qualified
  |           MONITOR -> NEW
  |           APPLY   -> READY_TO_APPLY -> Easy Apply -> APPLIED / FAILED (+ email)
  |
  v
Excel report (Run Jobs, Walk-In Jobs, Summary) -> daily summary email with attachment
  |
  v
END (exit 0 = all accounts OK, 1 = at least one account failed)
```

## 3. Folder Structure

```
NaukriBot/
├── main.py                 # CLI entry point + orchestrator
├── requirements.txt        # pinned dependencies
├── README.md
├── config.yaml             # all behaviour settings (no secrets)
├── setup.bat               # one-time environment setup
├── run_naukri.bat          # launched by Task Scheduler: monitor | apply
├── accounts/
│   └── accounts.json       # account names + env-var names (no passwords)
├── database/
│   └── jobs.db             # SQLite (created by init-db)
├── reports/                # Excel reports per run
├── screenshots/            # timestamped PNG evidence
├── logs/                   # execution.log, application.log, error.log, task_*.txt
└── modules/
    ├── __init__.py
    ├── login.py            # Naukri login per account
    ├── search.py           # search URLs, card extraction, detail pages
    ├── parser.py           # experience / posted-date parsing, JobRecord
    ├── filtering.py        # location, experience and age filters
    ├── scoring.py          # account-specific 0-100 score and priority rank
    ├── walkin_detector.py  # walk-in / direct-interview detection
    ├── database.py         # SQLite repository (Jobs, Applications, WalkInJobs, ExecutionLogs, Notifications)
    ├── report.py           # run summary + Excel workbook
    ├── emailer.py          # SMTP summary, walk-in and application emails
    ├── apply.py            # Easy Apply automation (APPLY mode only)
    ├── scheduler.py        # schtasks wrapper
    └── utils.py            # config, logging, retry, run lock, screenshots, accounts
```

## 4. Installation Steps

1. Copy the `NaukriBot` folder to a permanent location, for example `C:\NaukriBot`. Avoid OneDrive-synced folders, because they lock SQLite files.
2. Install Python 3.12 or newer (section 5).
3. Open **Command Prompt** in the project folder and run `setup.bat`. It creates `.venv`, installs dependencies, downloads Chromium and creates `database/jobs.db`.
4. Set credentials and SMTP variables (sections 9 and 10).
5. Run `python main.py test-email`, then `python main.py run --mode monitor`.

## 5. Python Installation

1. Download Python 3.12+ from https://www.python.org/downloads/windows/.
2. On the first installer screen, tick **Add python.exe to PATH**.
3. Verify in a new terminal:

```bat
python --version
py -3.12 --version
```

## 6. Virtual Environment Creation

```bat
cd C:\NaukriBot
py -3.12 -m venv .venv
.venv\Scripts\activate
```

The prompt should start with `(.venv)`. `setup.bat` does this automatically.

## 7. Dependency Installation

```bat
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

`requirements.txt` pins `playwright`, `pandas`, `openpyxl`, `loguru` and `PyYAML`.

## 8. Playwright Setup

```bat
python -m playwright install chromium
```

Chromium is installed per Windows user. Run `setup.bat` (or the command above) as the same user that will run the scheduled tasks. Keep `headless: true` in `config.yaml` for scheduled runs. Set it to `false` while you check selectors.

## 9. SMTP Configuration

`config.yaml` → `smtp` section. Default values target Gmail:

```yaml
smtp:
  host: smtp.gmail.com
  port: 587
  use_tls: true
  sender: "yourname@gmail.com"          # the same Gmail address you log in with
  username_env: NAUKRI_SMTP_USERNAME
  password_env: NAUKRI_SMTP_PASSWORD
```

Set `email.recipients` to the address(es) that should receive alerts. You can use the same Gmail address.

### 9a. Enable 2-Step Verification

An App Password is only available after 2-Step Verification is on.

1. Go to https://myaccount.google.com and sign in with your Gmail account.
2. Open **Security** from the left menu.
3. Under "How you sign in to Google", click **2-Step Verification** and follow the prompts (phone confirmation, and a code if asked).

### 9b. Create the App Password

1. Go to https://myaccount.google.com/apppasswords. If the page is unavailable, 2-Step Verification is not finished.
2. In **App name**, type `NaukriBot` and click **Create**.
3. Google shows a 16-character code in four groups, for example `abcd efgh ijkl mnop`. Copy it now, because it is shown only once.
4. Use this code as the SMTP password. Spaces do not matter.

An App Password is a separate password for one app. Your normal Gmail password will not work for NaukriBot. If the App Passwords page never appears on a school or work Google account, an administrator must allow it, or use a personal Gmail account.

### 9c. Store the credentials

```bat
setx NAUKRI_SMTP_USERNAME "yourname@gmail.com"
setx NAUKRI_SMTP_PASSWORD "abcdefghijklmnop"
```

Open a new terminal afterwards so the variables load. Never write the App Password into `config.yaml` or any other file.

### 9d. Test the connection

```bat
cd C:\NaukriBot
.venv\Scripts\activate
python main.py test-email
```

Check your inbox (and spam folder) for "[NaukriBot] Test email". Each email attempt is recorded in the `Notifications` table, so you can confirm it with:

```sql
SELECT notification_type, status, error_message, sent_at FROM Notifications ORDER BY id DESC LIMIT 10;
```

Troubleshooting: `535 Authentication failed` means the username or App Password is wrong. A timeout usually means a firewall or proxy is blocking port 587.

## 10. Account Configuration

Credentials are **never** written to files. `accounts/accounts.json` only holds the names of environment variables:

| Account  | Profile  | Username variable          | Password variable          |
|----------|----------|----------------------------|----------------------------|
| account1 | account1 | `NAUKRI_ACCOUNT1_USERNAME` | `NAUKRI_ACCOUNT1_PASSWORD` |
| account2 | account2 | `NAUKRI_ACCOUNT2_USERNAME` | `NAUKRI_ACCOUNT2_PASSWORD` |

Set them permanently for your Windows user (open a **new** terminal afterwards):

```bat
setx NAUKRI_ACCOUNT1_USERNAME "account1-email@example.com"
setx NAUKRI_ACCOUNT1_PASSWORD "your-password-1"
setx NAUKRI_ACCOUNT2_USERNAME "account2-email@example.com"
setx NAUKRI_ACCOUNT2_PASSWORD "your-password-2"
setx NAUKRI_SMTP_USERNAME "yourname@gmail.com"
setx NAUKRI_SMTP_PASSWORD "your-gmail-app-password"
```

`setx` stores values in the user environment. Anyone with access to your Windows user account can read them, so use a locked-down PC. For stronger protection, store the passwords in Windows Credential Manager and load them in your own wrapper.

**Profiles** (keywords, priority ranking and scoring) are in `config.yaml` under `profiles` and `scoring`. Account 1 only uses the `account1` profile and Account 2 only the `account2` profile.

**Resumes:** nothing is uploaded from the local machine. The default resume in each Naukri profile is used.

## 11. Monitor Mode Usage

Monitor mode is the default (`AUTO_APPLY: false`, `MODE: MONITOR`).

```bat
python main.py run                              # uses config MODE (MONITOR)
python main.py run --mode monitor               # explicit
python main.py run --mode monitor --account account2
```

What you get after each run:
- Rows in `Jobs` with status `NEW` for every qualifying job. These are jobs you should review.
- `reports/naukri_report_<timestamp>.xlsx`
- A summary email with the Excel report attached
- Walk-in alert emails, sent immediately

Validate the jobs for a few days before you enable apply mode. Check the `Run Jobs` sheet and open a few `Job URL` links.

## 12. Apply Mode Usage

Apply mode needs both switches:

1. In `config.yaml`: `AUTO_APPLY: true` and `MODE: APPLY`
2. Or override the mode on the command line, `python main.py run --mode apply`. Apply still needs `AUTO_APPLY: true`, otherwise the run falls back to monitor behaviour and logs a warning.

An application is attempted only when **all** of these hold:

- Easy Apply button present
- Not a walk-in
- Not already in `Applications` (never apply twice)
- Location matches (Chennai, Hyderabad, Bangalore, Bengaluru)
- Experience range inside 3 to 6 years
- Posted within 7 days
- Score >= 60

Other safeguards:
- `max_applications_per_run: 10` limits each run.
- Random pauses of 3 to 7 seconds between page actions.
- If Naukri asks an employer questionnaire, the job is marked `FAILED` with the reason, and nothing is answered automatically.
- `apply_pending_from_monitor: true` applies to jobs that you saw as `NEW` in an earlier monitor run. It does not re-evaluate them.

Switching back to monitor is a single edit: set `AUTO_APPLY: false` or `MODE: MONITOR`.

## 13. SQLite Database Structure

`database/jobs.db` (WAL mode). Tables are created by `python main.py init-db`.

| Table | Purpose | Key columns |
|-------|---------|-------------|
| `Jobs` | One row per Naukri job ID, forever. Duplicate prevention and history. | `job_id` (PK), `account_name`, `profile`, `job_title`, `company`, `location`, `min_experience`, `max_experience`, `experience_match`, `posted_date`, `days_old`, `easy_apply`, `walk_in`, `score`, `priority_rank`, `qualified`, `status`, `skip_reason`, `first_seen_at`, `last_seen_at`, `seen_count`, `last_run_status` |
| `Applications` | One attempt per job (`job_id` UNIQUE). | `job_id`, `account_name`, `status` (APPLIED/FAILED), `applied_at`, `error_message`, `screenshot_path`, `email_sent` |
| `WalkInJobs` | Walk-in postings and the reason they were detected. | `job_id`, `company`, `job_title`, `location`, `detection_reason`, `detected_at` |
| `ExecutionLogs` | One row per account per run. | `run_id`, `mode`, `account_name`, `started_at`, `finished_at`, `status`, metrics |
| `Notifications` | Every email attempt, for tracking and for once-only walk-in alerts. | `notification_type`, `job_id`, `recipient`, `status`, `error_message`, `sent_at` |
| `schema_version` | Migration marker. | `version` |

Quick queries (DB Browser for SQLite or `sqlite3`):

```sql
SELECT status, COUNT(*) FROM Jobs GROUP BY status;
SELECT job_id, job_title, company, score FROM Jobs WHERE status='NEW' ORDER BY score DESC;
SELECT * FROM Applications ORDER BY attempted_at DESC;
```

## 14. Reporting

Each run writes `reports/naukri_report_<timestamp>.xlsx` with three sheets:

- **Run Jobs** has every job evaluated in the run, with these columns: Date, Timestamp, Account, Search Keyword, Job ID, Job Title, Company, Location, Experience, Min Experience, Max Experience, Experience Match, Salary, Posted Date, Days Old, Easy Apply, Walk In, Score, Priority Rank, Status, Skip Reason, Job URL, Walk-In Reason, Score Breakdown.
- **Walk-In Jobs** has walk-in postings only.
- **Summary** has the counts used in the email.

Status values: `NEW`, `DUPLICATE`, `WALK_IN`, `READY_TO_APPLY`, `APPLIED`, `FAILED`, `SKIPPED`.

Skip reasons: `Experience Mismatch`, `Duplicate Job`, `Walk-In Job`, `Low Score`, `Location Mismatch`, `Job Older Than 7 Days`. Two extra reasons are added for clarity: `Not Easy Apply` and `Unknown Posted Date`, and `Application Limit Reached` in APPLY mode.

## 15. Logging

Three Loguru files in `logs/`, plus the console:

| File | Contents |
|------|----------|
| `execution.log` | Every event: login, search, filters, duplicate checks, walk-in detection, scoring, reports, emails |
| `application.log` | Application attempts only: start, success, failure |
| `error.log` | ERROR level and above, with stack traces |

Files rotate at 10 MB and are kept for 30 days (see `logging:` in config). The scheduler also writes `logs/task_<mode>_<timestamp>.txt` for each run.

## 16. Screenshots

Stored in `screenshots/` as `YYYYMMDD_HHMMSS_mmm_<account>_<label>.png`. Labels:

- `login_success` / `login_failed`
- `search_results`
- `job_extraction` (first detail page of each run)
- `walkin_detection`
- `auto_apply_success`
- `error_apply` and other error captures

Turn them off with `screenshots.enabled: false`. Old files are not deleted automatically. Delete them manually or by a scheduled cleanup, after the 30 days in `retention_days`.

## 17. Windows Task Scheduler Setup

The project creates three daily tasks: 10:00, 13:00 and 17:00 (edit `schedules.run_times` in `config.yaml`).

**Option A - from the command line (recommended):**

```bat
cd C:\NaukriBot
.venv\Scripts\activate

python main.py print-schedule --mode monitor       # preview the commands
python main.py install-schedule --mode monitor     # create the three tasks
```

When you move to apply mode, recreate the tasks with `python main.py install-schedule --mode apply`. The existing tasks are replaced (`/F`).

Remove them with `python main.py remove-schedule`.

**Option B - from the Task Scheduler UI:**

1. Open **Task Scheduler** → **Create Task…** (not "Basic Task").
2. **General:** name `NaukriBot_1000`. Select *Run only when user is logged on*. Do not select "Run with highest privileges".
3. **Triggers:** New → Daily → 10:00 AM → OK.
4. **Actions:** New → Program/script `C:\NaukriBot\run_naukri.bat` → Add arguments `monitor` → Start in `C:\NaukriBot`.
5. **Conditions:** untick *Start only if on AC power* if this is a laptop.
6. **Settings:** tick *Run task as soon as possible after a scheduled start is missed*. Set *Stop the task if it runs longer than* 2 hours. Tick *Do not start a new instance if the task is already running* (the lock file also prevents overlap).
7. Repeat for `NaukriBot_1300` and `NaukriBot_1700`.

Verify: right-click a task → **Run**, then check `logs\task_monitor_*.txt` and the `Last Run Result` column (`0x0` means success).

Note: with *Run only when user is logged on*, the tasks run while your Windows user is signed in. Credentials are per user, so the tasks must run as the same user who ran `setx`. Running while logged out requires storing your Windows password in the task, which is a separate security decision.

## 18. Troubleshooting

| Symptom | Cause and fix |
|---------|---------------|
| `Configuration error: ...` | A section is missing from `config.yaml`, or `MODE` is not MONITOR or APPLY. |
| `Credentials missing for account1` | Env var not set, or the terminal was opened before `setx`. Open a new terminal. |
| `Login failed` | Wrong password, or Naukri asked for OTP/CAPTCHA. Run once with `headless: false`, log in manually, check `screenshots/*login_failed*.png`. |
| Zero cards extracted | Naukri changed its markup. Open a result page in Chrome, inspect a card, and update `selectors.job_card` / `title` / etc. in `config.yaml`. |
| `SMTP credentials missing` | Set `NAUKRI_SMTP_USERNAME` and `NAUKRI_SMTP_PASSWORD`. Open a new terminal. |
| `535 Authentication failed` (Gmail) | Use an App Password, not the account password. |
| `Another NaukriBot run is active` | A previous run is still running, or it crashed. The lock is reclaimed after 2 hours. Delete `logs\naukribot.lock` if you are sure no run is active. |
| `playwright._impl._errors.Error: Executable doesn't exist` | Run `python -m playwright install chromium`. |
| Excel report is open | Close it in Excel. The next run writes a new file, so this is rarely an issue. |
| `database is locked` | Another process holds `jobs.db` open (for example DB Browser). Close it. |
| Task shows `0x1` | Read the newest file in `logs\task_*.txt` and `logs\error.log`. |
| Walk-in false positive | The word `venue` can appear in unrelated text. Remove it from `walkin_detection.patterns`. |

## 19. Security Best Practices

- Credentials are stored only in Windows user environment variables, never in `config.yaml`, `accounts.json` or the code. Passwords are never logged.
- Keep the project folder out of OneDrive, Git repositories and shared drives. `database/`, `logs/`, `reports/` and `screenshots/` contain personal data.
- Use a Gmail **App Password** instead of your real password.
- Use separate Naukri accounts for automation where possible, and keep Phase 2 disabled until you have validated the monitor output.
- Respect Naukri's Terms of Service. Keep request volume low (`max_pages_per_keyword`, `max_detail_pages_per_run`), keep the schedule at three runs per day, and do not run it in parallel.
- Keep `headless: true` for scheduled runs. Do not share screenshots or Excel files that show account details.
- Review `application.log` regularly and delete old screenshots.

## 20. Future Enhancements

- Replace `setx` with Windows Credential Manager (`keyring`) for passwords.
- Add a Streamlit or Excel dashboard over the SQLite database.
- Store and reuse Playwright storage state to skip login on every run.
- Add an LLM-based job-description classifier as an extra signal beside keyword scoring.
- Support multiple SMTP profiles and Teams / Slack webhooks.
- Add a retry queue for `FAILED` applications, with a manual approval step.
- Use Alembic-style migrations when the schema changes.
- Add unit tests (pytest) for parser, filtering, scoring and walk-in detection, plus recorded HTML fixtures for selectors.

---

## Module Interaction Summary

| Module | Called by | Calls | Output |
|--------|-----------|-------|--------|
| `main.py` | Task Scheduler / CLI | every module | exit code |
| `utils.py` | everyone | - | config, logger, lock, screenshots |
| `login.py` | `main.py` | `utils` | authenticated Playwright page |
| `search.py` | `main.py` | `utils` | raw card dicts, detail dicts |
| `parser.py` | `main.py` | `utils` | `JobRecord` |
| `filtering.py` | `main.py` | `parser` | skip reason |
| `walkin_detector.py` | `main.py` | `parser` | walk-in flag and reason |
| `scoring.py` | `main.py` | `parser` | score, priority rank |
| `database.py` | `main.py`, `emailer.py` | `parser` | persisted rows |
| `apply.py` | `main.py` (APPLY only) | `parser`, `utils` | success or failure |
| `report.py` | `main.py` | `parser`, `utils` | Excel file, summary |
| `emailer.py` | `main.py` | `database`, `report`, `parser` | sent emails and notification rows |
| `scheduler.py` | `main.py` | `utils` | schtasks commands |

## Quick Command Reference

```bat
python main.py init-db
python main.py test-email
python main.py run --mode monitor
python main.py run --mode apply --account account2
python main.py print-schedule --mode monitor
python main.py install-schedule --mode monitor
python main.py remove-schedule
```

"""
walkin_detector.py - Detects walk-in / direct-interview postings.

Patterns come from config.yaml -> walkin_detection.patterns (regular expressions).
Default coverage: walk-in, walk in, walkin, direct interview, venue,
interview venue, interview location, attend interview.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from modules.parser import JobRecord
from modules.utils import get_logger


@dataclass(frozen=True)
class WalkInResult:
    is_walk_in: bool
    reason: str = ""


class WalkInDetector:
    """Scans title, tags, card text and description for walk-in indicators."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        patterns = cfg["walkin_detection"]["patterns"]
        self.patterns = [re.compile(p, re.IGNORECASE) for p in patterns]
        self.log = get_logger("walkin")

    def detect(self, rec: JobRecord) -> WalkInResult:
        """Return the first match and the place it was found, e.g. "Matched 'walk-in' in job title"."""
        for label, text in rec.walkin_text_sources().items():
            if not text:
                continue
            for pattern in self.patterns:
                match = pattern.search(text)
                if match:
                    reason = f"Matched '{match.group(0)}' in {label}"
                    self.log.warning(f"Walk-in detected for {rec.job_id}: {reason}")
                    return WalkInResult(True, reason)
        return WalkInResult(False)

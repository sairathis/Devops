"""
scheduler.py - Creates / removes Windows Task Scheduler entries.

One daily task per configured time (default 10:00, 13:00, 17:00). Each task calls
run_naukri.bat with the mode (monitor or apply). Tasks run under the current user,
so no administrator rights are needed.
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from modules.utils import PROJECT_ROOT, get_logger


class WindowsScheduler:
    """Wraps schtasks.exe. Commands are printed in dry-run mode so they can be run manually."""

    def __init__(self, cfg: dict[str, Any], bat_path: Path | None = None) -> None:
        sched = cfg["schedules"]
        self.times: list[str] = list(sched["run_times"])
        self.prefix: str = sched.get("task_prefix", "NaukriBot")
        self.bat_path = bat_path or (PROJECT_ROOT / "run_naukri.bat")
        self.log = get_logger("scheduler")

    def task_name(self, run_time: str) -> str:
        return f"{self.prefix}_{run_time.replace(':', '')}"

    def build_create_commands(self, mode: str) -> list[str]:
        """
        One schtasks /Create per run time. The /TR value is quoted as
        "\"<bat path>\" <mode>" so paths containing spaces work.
        """
        commands: list[str] = []
        for run_time in self.times:
            target = f'\\"{self.bat_path}\\" {mode.lower()}'
            commands.append(
                f'schtasks /Create /TN "{self.task_name(run_time)}" /TR "{target}" '
                f'/SC DAILY /ST {run_time} /F'
            )
        return commands

    def build_delete_commands(self) -> list[str]:
        return [f'schtasks /Delete /TN "{self.task_name(t)}" /F' for t in self.times]

    def install(self, mode: str, dry_run: bool = False) -> bool:
        commands = self.build_create_commands(mode)
        for command in commands:
            if dry_run:
                print(command)
                continue
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode != 0:
                self.log.error(f"schtasks failed: {result.stderr.strip() or result.stdout.strip()}")
                return False
            self.log.info(f"Scheduled task created: {command.split('/TN')[1].split('/TR')[0].strip()}")
        return True

    def remove(self) -> bool:
        ok = True
        for command in self.build_delete_commands():
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode != 0:
                ok = False
                self.log.warning(f"Could not delete task: {result.stderr.strip() or result.stdout.strip()}")
        return ok

"""
filtering.py - Location, experience and job-age filters.

Skip reasons produced here (exact spellings are used in the Excel report):
  Location Mismatch | Experience Mismatch | Job Older Than 7 Days | Unknown Posted Date
"""
from __future__ import annotations

from typing import Any

from modules.parser import JobRecord
from modules.utils import get_logger


class JobFilter:
    """Applies the business filters defined in config.yaml -> search."""

    REASON_LOCATION = "Location Mismatch"
    REASON_EXPERIENCE = "Experience Mismatch"
    REASON_AGE = "Job Older Than 7 Days"
    REASON_UNKNOWN_AGE = "Unknown Posted Date"

    def __init__(self, cfg: dict[str, Any]) -> None:
        search = cfg["search"]
        self.cities = [city.strip().lower() for city in search["location_filter"]]
        self.min_years = float(search["experience"]["min_years"])
        self.max_years = float(search["experience"]["max_years"])
        self.max_age_days = int(search["max_job_age_days"])
        self.log = get_logger("filter")

    def location_matches(self, location: str) -> bool:
        """True if any allowed city appears in the location text (e.g. 'Chennai / Pune')."""
        text = (location or "").lower()
        return any(city in text for city in self.cities)

    def experience_matches(self, rec: JobRecord) -> bool:
        """
        Job range must sit entirely inside the target range.
        3-6 / 3-5 / 4-5 / 4-6 / 5-6 pass; 1-3 / 0-2 / 6-10 / 10+ fail.
        """
        if rec.min_experience is None or rec.max_experience is None:
            return False
        return self.min_years <= rec.min_experience and rec.max_experience <= self.max_years

    def evaluate(self, rec: JobRecord) -> str:
        """
        Fill location_match / experience_match on the record and return the first
        failing skip reason, or '' when the job passes all three filters.
        """
        rec.location_match = self.location_matches(rec.location)
        rec.experience_match = self.experience_matches(rec)

        if not rec.location_match:
            self.log.info(f"Filter: {rec.job_id} location '{rec.location}' -> {self.REASON_LOCATION}")
            return self.REASON_LOCATION
        if not rec.experience_match:
            self.log.info(
                f"Filter: {rec.job_id} experience '{rec.experience_text}' -> {self.REASON_EXPERIENCE}"
            )
            return self.REASON_EXPERIENCE
        if rec.days_old is None:
            self.log.info(f"Filter: {rec.job_id} posted text '{rec.posted_text}' -> {self.REASON_UNKNOWN_AGE}")
            return self.REASON_UNKNOWN_AGE
        if rec.days_old > self.max_age_days:
            self.log.info(f"Filter: {rec.job_id} is {rec.days_old} days old -> {self.REASON_AGE}")
            return self.REASON_AGE
        self.log.debug(f"Filter: {rec.job_id} passed location/experience/age")
        return ""

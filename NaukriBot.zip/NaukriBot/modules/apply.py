"""
apply.py - Controlled Easy Apply automation (PHASE 2 only).

Safety rules enforced by the caller (main.py) AND here:
  * Only runs when AUTO_APPLY=true and MODE=APPLY
  * Only jobs with status READY_TO_APPLY (all rules passed)
  * Never submits anything that needs a questionnaire answer (fails safely instead)
  * Any failure is recorded as FAILED with a screenshot; the job is not retried
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass
from typing import Any

from playwright.sync_api import BrowserContext, Error as PlaywrightError, Page

from modules.parser import JobRecord
from modules.utils import ScreenshotManager, application_logger, get_logger


@dataclass(frozen=True)
class ApplyResult:
    success: bool
    error: str = ""
    screenshot: str = ""


class NaukriApplier:
    """Applies to one job through its Easy Apply button."""

    CONFIRMATION_TEXT = re.compile(r"successfully applied|applied successfully", re.IGNORECASE)
    EASY_APPLY_TEXT = re.compile(r"easy\s*apply", re.IGNORECASE)

    def __init__(self, context: BrowserContext, cfg: dict[str, Any], screenshots: ScreenshotManager) -> None:
        self.context = context
        self.sel = cfg["selectors"]
        self.timeout = int(cfg["app"]["navigation_timeout_ms"])
        self.delay = cfg["app"]["human_delay_seconds"]
        self.shots = screenshots
        self.log = get_logger("apply")
        self.alog = application_logger()

    def apply(self, rec: JobRecord) -> ApplyResult:
        """Attempt Easy Apply on the job. Never raises; returns an ApplyResult."""
        page = self.context.new_page()
        self.alog.info(
            f"APPLY START | job={rec.job_id} | account={rec.account_name} | "
            f"title={rec.job_title} | company={rec.company} | url={rec.job_url}"
        )
        try:
            page.goto(rec.job_url, wait_until="domcontentloaded", timeout=self.timeout)
            self._pause()
            button = (
                page.locator(self.sel["detail_apply_buttons"])
                .filter(has_text=self.EASY_APPLY_TEXT)
                .first
            )
            if button.count() == 0:
                return self._fail(page, rec, "Easy Apply button not found on job page")

            button.click(timeout=self.timeout)
            self._pause()

            if self._confirmed(page):
                shot = self.shots.capture(page, "auto_apply_success", rec.account_name)
                self.alog.info(f"APPLY SUCCESS | job={rec.job_id} | account={rec.account_name}")
                return ApplyResult(True, "", str(shot) if shot else "")

            if page.locator(self.sel["chatbot_drawer"]).count() > 0:
                return self._fail(page, rec, "Employer questionnaire needs manual input; skipped safely")
            return self._fail(page, rec, "Applied confirmation not detected")
        except PlaywrightError as exc:
            return self._fail(page, rec, f"Playwright error: {exc}")
        finally:
            page.close()

    def _confirmed(self, page: Page, wait_seconds: int = 12) -> bool:
        """Poll for a success marker for up to wait_seconds."""
        deadline = time.time() + wait_seconds
        while time.time() < deadline:
            if page.locator(self.sel["applied_marker"]).count() > 0:
                return True
            if page.get_by_text(self.CONFIRMATION_TEXT).count() > 0:
                return True
            page.wait_for_timeout(1000)
        return False

    def _fail(self, page: Page, rec: JobRecord, message: str) -> ApplyResult:
        shot = self.shots.capture(page, "error_apply", rec.account_name)
        self.alog.error(f"APPLY FAILED | job={rec.job_id} | account={rec.account_name} | {message}")
        self.log.error(f"Apply failed for {rec.job_id}: {message}")
        return ApplyResult(False, message, str(shot) if shot else "")

    def _pause(self) -> None:
        low, high = float(self.delay[0]), float(self.delay[1])
        time.sleep(random.uniform(low, high))

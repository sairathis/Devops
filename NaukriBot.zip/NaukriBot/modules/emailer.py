"""
emailer.py - SMTP notifications.

  * Daily / per-run summary email with the Excel report attached
  * Immediate walk-in alert (once per job)
  * Application confirmation email (per successful application)
  * Every attempt is written to the Notifications table

SMTP credentials come from Windows environment variables (see config.yaml -> smtp).
"""
from __future__ import annotations

import html
import os
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path
from typing import Any

from modules.database import JobDatabase
from modules.parser import JobRecord
from modules.report import RunSummary
from modules.utils import ConfigError, get_logger, retry


class Emailer:
    """Sends NaukriBot emails and records them in the database."""

    def __init__(self, cfg: dict[str, Any], db: JobDatabase) -> None:
        self.smtp_cfg = cfg["smtp"]
        self.email_cfg = cfg["email"]
        self.retry_cfg = cfg["retry"]
        self.db = db
        self.prefix = self.email_cfg.get("subject_prefix", "[NaukriBot]")
        self.recipients: list[str] = list(self.email_cfg.get("recipients", []))
        self.log = get_logger("email")

    # -- low level ----------------------------------------------------------
    def _credentials(self) -> tuple[str, str]:
        user = os.environ.get(self.smtp_cfg["username_env"], "")
        password = os.environ.get(self.smtp_cfg["password_env"], "")
        if not user or not password:
            raise ConfigError(
                f"SMTP credentials missing. Set {self.smtp_cfg['username_env']} and "
                f"{self.smtp_cfg['password_env']} environment variables."
            )
        return user, password

    def _deliver(self, message: EmailMessage) -> None:
        user, password = self._credentials()
        context = ssl.create_default_context()
        with smtplib.SMTP(self.smtp_cfg["host"], int(self.smtp_cfg["port"]), timeout=30) as smtp:
            if self.smtp_cfg.get("use_tls", True):
                smtp.starttls(context=context)
            smtp.login(user, password)
            smtp.send_message(message)

    def _send(self, notification_type: str, job_id: str | None, subject: str,
              text_body: str, html_body: str, attachment: Path | None = None,
              enabled: bool = True) -> bool:
        """Build, send and record one email. Returns True when delivered."""
        recipient = ", ".join(self.recipients)
        if not enabled or not self.email_cfg.get("enabled", True):
            self.log.info(f"Email skipped ({notification_type}): disabled in config")
            self.db.record_notification(notification_type, job_id, recipient, subject, "SKIPPED",
                                        "disabled in config")
            return False
        if not self.recipients:
            self.db.record_notification(notification_type, job_id, "", subject, "SKIPPED", "no recipients")
            return False

        message = EmailMessage()
        message["Subject"] = subject
        message["From"] = self.smtp_cfg["sender"]
        message["To"] = recipient
        message.set_content(text_body)
        message.add_alternative(html_body, subtype="html")
        if attachment and attachment.exists():
            message.add_attachment(
                attachment.read_bytes(),
                maintype="application",
                subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                filename=attachment.name,
            )

        try:
            self._deliver_with_retry(message)
            self.db.record_notification(notification_type, job_id, recipient, subject, "SENT",
                                        "", str(attachment or ""))
            self.log.info(f"Email sent ({notification_type}): {subject}")
            return True
        except Exception as exc:  # noqa: BLE001 - email must never crash a run
            self.db.record_notification(notification_type, job_id, recipient, subject, "FAILED", str(exc))
            self.log.error(f"Email failed ({notification_type}): {exc}")
            return False

    def _deliver_with_retry(self, message: EmailMessage) -> None:
        decorated = retry(
            attempts=int(self.retry_cfg["attempts"]),
            delay=float(self.retry_cfg["delay_seconds"]),
            backoff=float(self.retry_cfg["backoff_multiplier"]),
            exceptions=(smtplib.SMTPException, OSError),
        )(self._deliver)
        decorated(message)

    # -- public API ---------------------------------------------------------
    def send_daily_summary(self, summary: RunSummary, report_path: Path | None) -> bool:
        subject = f"{self.prefix} Job Summary {summary.generated_at[:16]} ({summary.mode})"
        rows = summary.as_rows()
        text_body = "\n".join(f"{k}: {v}" for k, v in rows)
        table = "".join(
            f"<tr><td style='padding:4px 10px;border:1px solid #ccc'>{html.escape(str(k))}</td>"
            f"<td style='padding:4px 10px;border:1px solid #ccc'><b>{html.escape(str(v))}</b></td></tr>"
            for k, v in rows
        )
        html_body = (
            "<html><body style='font-family:Arial,sans-serif'>"
            "<h3>NaukriBot run summary</h3>"
            f"<table style='border-collapse:collapse'>{table}</table>"
            "<p>The Excel report is attached.</p></body></html>"
        )
        attachment = report_path if self.email_cfg.get("attach_excel_report", True) else None
        return self._send("DAILY_SUMMARY", None, subject, text_body, html_body, attachment,
                          enabled=self.email_cfg.get("send_daily_summary", True))

    def send_walkin_alert(self, rec: JobRecord) -> bool:
        """Sends at most one walk-in alert per job ID."""
        if self.db.notification_sent("WALKIN_ALERT", rec.job_id):
            self.log.info(f"Walk-in alert already sent for {rec.job_id}")
            return False
        subject = f"{self.prefix} WALK-IN ALERT: {rec.job_title} at {rec.company}"
        fields = [
            ("Company", rec.company),
            ("Job Title", rec.job_title),
            ("Location", rec.location),
            ("Posted Date", rec.posted_date or rec.posted_text),
            ("Job URL", rec.job_url),
            ("Detection Reason", rec.walkin_reason),
        ]
        text_body = "\n".join(f"{k}: {v}" for k, v in fields)
        html_body = self._fields_html("Walk-In Job Detected - DO NOT APPLY", fields)
        return self._send("WALKIN_ALERT", rec.job_id, subject, text_body, html_body,
                          enabled=self.email_cfg.get("send_walkin_alerts", True))

    def send_application_email(self, rec: JobRecord, applied_at: str) -> bool:
        subject = f"{self.prefix} Applied: {rec.job_title} at {rec.company}"
        fields = [
            ("Company", rec.company),
            ("Job Title", rec.job_title),
            ("Location", rec.location),
            ("Applied Date", applied_at),
            ("Account Used", rec.account_name),
            ("Job URL", rec.job_url),
        ]
        text_body = "\n".join(f"{k}: {v}" for k, v in fields)
        html_body = self._fields_html("Application Submitted", fields)
        return self._send("APPLICATION", rec.job_id, subject, text_body, html_body,
                          enabled=self.email_cfg.get("send_application_emails", True))

    def send_test_email(self) -> bool:
        subject = f"{self.prefix} Test email"
        return self._send("TEST", None, subject, "NaukriBot SMTP test succeeded.",
                          "<p>NaukriBot SMTP test succeeded.</p>", enabled=True)

    @staticmethod
    def _fields_html(title: str, fields: list[tuple[str, str]]) -> str:
        rows = "".join(
            f"<tr><td style='padding:4px 10px;border:1px solid #ccc'>{html.escape(k)}</td>"
            f"<td style='padding:4px 10px;border:1px solid #ccc'>{html.escape(str(v))}</td></tr>"
            for k, v in fields
        )
        return (
            "<html><body style='font-family:Arial,sans-serif'>"
            f"<h3>{html.escape(title)}</h3>"
            f"<table style='border-collapse:collapse'>{rows}</table></body></html>"
        )

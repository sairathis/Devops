"""
report.py - Run summary calculation and Excel report generation (pandas + openpyxl).

Excel workbook sheets
  Run Jobs      every job evaluated in the run (all columns from the specification)
  Walk-In Jobs  walk-in postings only
  Summary       metric / value table used by the daily summary email
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from modules.parser import JobRecord
from modules.utils import file_stamp, get_logger, iso, now_local, path_of

REPORT_COLUMNS = [
    "Date", "Timestamp", "Account", "Search Keyword", "Job ID", "Job Title", "Company",
    "Location", "Experience", "Min Experience", "Max Experience", "Experience Match",
    "Salary", "Posted Date", "Days Old", "Easy Apply", "Walk In", "Score", "Priority Rank",
    "Status", "Skip Reason", "Job URL", "Walk-In Reason", "Score Breakdown",
]


@dataclass
class RunSummary:
    """Counts for one run (or one account within a run)."""

    run_id: str = ""
    mode: str = ""
    generated_at: str = ""
    total_found: int = 0
    apigee_jobs: int = 0
    cloud_jobs: int = 0
    easy_apply: int = 0
    walk_in: int = 0
    duplicates: int = 0
    new_jobs: int = 0
    ready: int = 0
    applied: int = 0
    failed: int = 0
    skipped: int = 0

    def as_rows(self) -> list[tuple[str, Any]]:
        return [
            ("Run ID", self.run_id),
            ("Mode", self.mode),
            ("Generated At", self.generated_at),
            ("Total Jobs Found", self.total_found),
            ("Apigee Jobs Found", self.apigee_jobs),
            ("Cloud Jobs Found", self.cloud_jobs),
            ("Easy Apply Jobs", self.easy_apply),
            ("Walk-In Jobs", self.walk_in),
            ("Duplicate Jobs", self.duplicates),
            ("New Jobs (Monitor)", self.new_jobs),
            ("Ready To Apply Jobs", self.ready),
            ("Applied Jobs", self.applied),
            ("Failed Jobs", self.failed),
            ("Skipped Jobs", self.skipped),
        ]

    def execution_metrics(self) -> dict[str, int]:
        """Keys match ExecutionLogs metric columns."""
        return {
            "jobs_found": self.total_found,
            "new_jobs": self.new_jobs,
            "duplicates": self.duplicates,
            "walk_ins": self.walk_in,
            "ready": self.ready,
            "applied": self.applied,
            "failed": self.failed,
            "skipped": self.skipped,
        }


def summarize(records: Iterable[JobRecord], run_id: str, mode: str) -> RunSummary:
    """Aggregate records into a RunSummary."""
    summary = RunSummary(run_id=run_id, mode=mode, generated_at=iso(now_local()))
    for rec in records:
        summary.total_found += 1
        if rec.profile == "account1":
            summary.apigee_jobs += 1
        elif rec.profile == "account2":
            summary.cloud_jobs += 1
        if rec.easy_apply:
            summary.easy_apply += 1
        if rec.walk_in:
            summary.walk_in += 1
        if rec.qualified and not rec.walk_in:
            summary.ready += 1
        status = rec.status
        if status == "DUPLICATE":
            summary.duplicates += 1
        elif status == "NEW":
            summary.new_jobs += 1
        elif status == "APPLIED":
            summary.applied += 1
        elif status == "FAILED":
            summary.failed += 1
        elif status == "SKIPPED":
            summary.skipped += 1
    return summary


class ReportGenerator:
    """Builds the Excel workbook for one run."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        self.reports_dir = path_of(cfg, "reports_dir")
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.log = get_logger("report")

    def generate(self, records: list[JobRecord], summary: RunSummary) -> Path:
        path = self.reports_dir / f"naukri_report_{file_stamp()}.xlsx"
        rows = [self._row(r) for r in records]
        df = pd.DataFrame(rows, columns=REPORT_COLUMNS)
        walkins = df[df["Walk In"] == "Yes"]
        summary_df = pd.DataFrame(summary.as_rows(), columns=["Metric", "Value"])

        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Run Jobs", index=False)
            walkins.to_excel(writer, sheet_name="Walk-In Jobs", index=False)
            summary_df.to_excel(writer, sheet_name="Summary", index=False)
            for ws in writer.book.worksheets:
                self._format(ws)

        self.log.info(f"Excel report generated: {path.name} ({len(rows)} jobs)")
        return path

    @staticmethod
    def _row(rec: JobRecord) -> dict[str, Any]:
        captured = rec.captured_at or iso(now_local())
        return {
            "Date": captured[:10],
            "Timestamp": captured,
            "Account": rec.account_name,
            "Search Keyword": rec.search_keyword,
            "Job ID": rec.job_id,
            "Job Title": rec.job_title,
            "Company": rec.company,
            "Location": rec.location,
            "Experience": rec.experience_text,
            "Min Experience": rec.min_experience if rec.min_experience is not None else "",
            "Max Experience": rec.max_experience if rec.max_experience is not None else "",
            "Experience Match": "Yes" if rec.experience_match else "No",
            "Salary": rec.salary,
            "Posted Date": rec.posted_date,
            "Days Old": rec.days_old if rec.days_old is not None else "",
            "Easy Apply": "Yes" if rec.easy_apply else "No",
            "Walk In": "Yes" if rec.walk_in else "No",
            "Score": rec.score,
            "Priority Rank": rec.priority_rank if rec.priority_rank is not None else "",
            "Status": rec.status,
            "Skip Reason": rec.skip_reason,
            "Job URL": rec.job_url,
            "Walk-In Reason": rec.walkin_reason,
            "Score Breakdown": rec.score_breakdown,
        }

    @staticmethod
    def _format(ws: Worksheet) -> None:
        """Header styling, frozen header row, filters and sensible column widths."""
        header_fill = PatternFill("solid", fgColor="1F4E78")
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = header_fill
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.freeze_panes = "A2"
        if ws.max_row > 1 and ws.max_column > 0:
            ws.auto_filter.ref = ws.dimensions
        for col_idx in range(1, ws.max_column + 1):
            letter = get_column_letter(col_idx)
            longest = max(
                (len(str(c.value)) for c in ws[letter] if c.value is not None),
                default=10,
            )
            ws.column_dimensions[letter].width = min(max(longest + 2, 12), 60)

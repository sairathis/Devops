"""
utils.py - Shared infrastructure for NaukriBot.

Responsibilities:
  * Configuration and account loading (secrets come from environment variables)
  * Path resolution and directory creation
  * Loguru logging setup (execution.log, application.log, error.log)
  * Retry decorator, single-instance run lock, screenshot helper
"""
from __future__ import annotations

import functools
import json
import os
import random
import re
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, TypeVar

import yaml
from loguru import logger

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config.yaml"

F = TypeVar("F", bound=Callable[..., Any])


class ConfigError(RuntimeError):
    """Raised when configuration files are missing or invalid."""


class RunLockError(RuntimeError):
    """Raised when another NaukriBot run is already active."""


@dataclass(frozen=True)
class AccountConfig:
    """A Naukri account. Credentials are resolved from environment variables at load time."""

    name: str
    display_name: str
    profile: str
    username: str
    password: str
    enabled: bool

    @property
    def has_credentials(self) -> bool:
        return bool(self.username and self.password)


# ---------------------------------------------------------------------------
# Paths and configuration
# ---------------------------------------------------------------------------
def resolve_path(value: str | Path) -> Path:
    """Resolve a config path relative to the project root."""
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def path_of(cfg: dict[str, Any], key: str) -> Path:
    """Return a resolved path from the 'paths' section of the config."""
    return resolve_path(cfg["paths"][key])


def load_config(path: Path = DEFAULT_CONFIG_PATH) -> dict[str, Any]:
    """Load and validate config.yaml."""
    if not path.exists():
        raise ConfigError(f"Configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}

    required = (
        "app", "paths", "naukri", "selectors", "search", "schedules", "profiles",
        "scoring", "walkin_detection", "database", "screenshots", "retry",
        "logging", "smtp", "email",
    )
    missing = [key for key in required if key not in cfg]
    if missing:
        raise ConfigError(f"config.yaml is missing sections: {', '.join(missing)}")

    mode = str(cfg["app"].get("MODE", "MONITOR")).upper()
    if mode not in {"MONITOR", "APPLY"}:
        raise ConfigError(f"Invalid MODE '{mode}'. Use MONITOR or APPLY.")
    cfg["app"]["MODE"] = mode
    cfg["app"]["AUTO_APPLY"] = bool(cfg["app"].get("AUTO_APPLY", False))
    return cfg


def ensure_directories(cfg: dict[str, Any]) -> None:
    """Create runtime directories (database, reports, screenshots, logs)."""
    for key in ("reports_dir", "screenshots_dir", "logs_dir"):
        path_of(cfg, key).mkdir(parents=True, exist_ok=True)
    path_of(cfg, "database_file").parent.mkdir(parents=True, exist_ok=True)


def load_accounts(path: Path | None = None) -> list[AccountConfig]:
    """Read accounts.json and resolve credentials from environment variables."""
    path = path or (PROJECT_ROOT / "accounts" / "accounts.json")
    if not path.exists():
        raise ConfigError(f"Accounts file not found: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    accounts: list[AccountConfig] = []
    for item in data.get("accounts", []):
        accounts.append(
            AccountConfig(
                name=item["name"],
                display_name=item.get("display_name", item["name"]),
                profile=item["profile"],
                username=os.environ.get(item.get("username_env", ""), ""),
                password=os.environ.get(item.get("password_env", ""), ""),
                enabled=bool(item.get("enabled", True)),
            )
        )
    return accounts


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def setup_logging(cfg: dict[str, Any]) -> None:
    """
    Configure Loguru sinks:
      * console          - human readable
      * logs/execution.log   - every event (login, search, filters, reports, ...)
      * logs/application.log - only application-related events (channel=application)
      * logs/error.log       - ERROR and above
    """
    log_cfg = cfg["logging"]
    logs_dir = path_of(cfg, "logs_dir")
    logs_dir.mkdir(parents=True, exist_ok=True)

    logger.remove()
    logger.configure(extra={"channel": "execution", "module": "core"})
    fmt = "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {extra[module]: <12} | {message}"
    rotation = log_cfg.get("rotation", "10 MB")
    retention = log_cfg.get("retention", "30 days")

    logger.add(sys.stderr, level=log_cfg.get("console_level", "INFO"), format=fmt)
    logger.add(
        logs_dir / "execution.log",
        level=log_cfg.get("level", "INFO"),
        format=fmt,
        rotation=rotation,
        retention=retention,
        encoding="utf-8",
        enqueue=True,
    )
    logger.add(
        logs_dir / "application.log",
        level="INFO",
        format=fmt,
        rotation=rotation,
        retention=retention,
        encoding="utf-8",
        enqueue=True,
        filter=lambda record: record["extra"].get("channel") == "application",
    )
    logger.add(
        logs_dir / "error.log",
        level="ERROR",
        format=fmt + "\n{exception}",
        rotation=rotation,
        retention=retention,
        encoding="utf-8",
        enqueue=True,
        backtrace=True,
        diagnose=False,
    )


def get_logger(module: str):
    """Return a Loguru logger bound to a module name, e.g. 'login' or 'search'."""
    return logger.bind(module=module)


def application_logger():
    """Logger that writes to application.log as well as execution.log."""
    return logger.bind(channel="application", module="apply")


# ---------------------------------------------------------------------------
# Time and text helpers
# ---------------------------------------------------------------------------
def now_local() -> datetime:
    """Current time with the local UTC offset attached."""
    return datetime.now().astimezone()


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def file_stamp(dt: datetime | None = None) -> str:
    """Timestamp safe for file names, with milliseconds to avoid collisions."""
    dt = dt or datetime.now()
    return dt.strftime("%Y%m%d_%H%M%S_") + f"{dt.microsecond // 1000:03d}"


def clean(text: str | None) -> str:
    """Collapse whitespace and strip."""
    return re.sub(r"\s+", " ", text or "").strip()


def slugify(text: str) -> str:
    """Lowercase, hyphen-separated slug."""
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")


def human_pause(bounds: tuple[float, float] | list[float]) -> None:
    """Sleep a random duration within bounds to behave less like a bot."""
    low, high = float(bounds[0]), float(bounds[1])
    time.sleep(random.uniform(low, high))


# ---------------------------------------------------------------------------
# Retry decorator
# ---------------------------------------------------------------------------
def retry(attempts: int = 3, delay: float = 3.0, backoff: float = 2.0,
          exceptions: tuple[type[BaseException], ...] = (Exception,)) -> Callable[[F], F]:
    """Retry a function on the given exceptions with exponential backoff."""

    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            wait = delay
            for attempt in range(1, attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as exc:  # noqa: PERF203 - explicit retry loop
                    if attempt == attempts:
                        raise
                    get_logger("retry").warning(
                        f"{fn.__name__} failed (attempt {attempt}/{attempts}): {exc}. "
                        f"Retrying in {wait:.1f}s"
                    )
                    time.sleep(wait)
                    wait *= backoff
        return wrapper  # type: ignore[return-value]

    return decorator


# ---------------------------------------------------------------------------
# Single-instance run lock (prevents overlapping scheduled runs)
# ---------------------------------------------------------------------------
class RunLock:
    """File-based lock. Stale locks older than `stale_after_seconds` are reclaimed."""

    def __init__(self, path: Path, stale_after_seconds: int = 7200) -> None:
        self.path = path
        self.stale_after_seconds = stale_after_seconds
        self.log = get_logger("core")

    def __enter__(self) -> "RunLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            age = time.time() - self.path.stat().st_mtime
            if age < self.stale_after_seconds:
                raise RunLockError(f"Another NaukriBot run is active (lock: {self.path})")
            self.log.warning(f"Removing stale lock file ({age:.0f}s old)")
            self.path.unlink(missing_ok=True)
        self.path.write_text(str(os.getpid()), encoding="utf-8")
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.path.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Screenshots
# ---------------------------------------------------------------------------
class ScreenshotManager:
    """Saves timestamped PNG screenshots. Never raises: screenshot failure must not stop a run."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        self.enabled = bool(cfg["screenshots"].get("enabled", True))
        self.directory = path_of(cfg, "screenshots_dir")
        self.directory.mkdir(parents=True, exist_ok=True)
        self.log = get_logger("screenshot")

    def capture(self, page: Any, label: str, account: str = "na") -> Path | None:
        if not self.enabled or page is None:
            return None
        try:
            name = f"{file_stamp()}_{slugify(account)}_{slugify(label)}.png"
            path = self.directory / name
            page.screenshot(path=str(path), full_page=False)
            self.log.info(f"Screenshot saved: {path.name}")
            return path
        except Exception as exc:  # noqa: BLE001 - screenshots are best effort
            self.log.warning(f"Screenshot '{label}' failed: {exc}")
            return None

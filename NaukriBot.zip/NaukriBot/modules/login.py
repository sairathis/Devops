"""
login.py - Logs into Naukri with the credentials of one account.

Each account runs in its own Playwright browser context, so cookies never mix.
Resume handling: NOTHING is uploaded. The account's default resume stays as configured in Naukri.
"""
from __future__ import annotations

from typing import Any

from playwright.sync_api import Page
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from modules.utils import AccountConfig, ScreenshotManager, get_logger


class LoginError(RuntimeError):
    """Raised when login cannot be completed for an account."""


class NaukriLogin:
    """Performs form login and verifies the session."""

    def __init__(self, page: Page, cfg: dict[str, Any], screenshots: ScreenshotManager) -> None:
        self.page = page
        self.sel = cfg["selectors"]
        self.url = cfg["naukri"]["login_url"]
        self.timeout = int(cfg["app"]["navigation_timeout_ms"])
        self.shots = screenshots
        self.log = get_logger("login")

    def login(self, account: AccountConfig) -> None:
        """Log in and return once the session is verified. Raises LoginError otherwise."""
        if not account.has_credentials:
            raise LoginError(
                f"Credentials missing for {account.name}. Set the environment variables in accounts.json."
            )
        self.log.info(f"Login started: {account.display_name}")
        self.page.goto(self.url, wait_until="domcontentloaded", timeout=self.timeout)
        self.page.locator(self.sel["login_username"]).fill(account.username)
        self.page.locator(self.sel["login_password"]).fill(account.password)  # never logged
        self.page.locator(self.sel["login_submit"]).click()

        try:
            self.page.wait_for_url(lambda url: "nlogin" not in url, timeout=self.timeout)
        except PlaywrightTimeoutError:
            pass  # verified below
        self.page.wait_for_load_state("domcontentloaded")

        if self._is_logged_in():
            self.shots.capture(self.page, "login_success", account.name)
            self.log.info(f"Login successful: {account.display_name}")
            return

        error_text = self._read_error()
        self.shots.capture(self.page, "login_failed", account.name)
        self.log.error(f"Login failed for {account.name}: {error_text or 'no error text found'}")
        raise LoginError(f"Login failed for {account.name}: {error_text or 'unknown reason'}")

    def _is_logged_in(self) -> bool:
        if "nlogin" not in self.page.url:
            return True
        return self.page.locator(self.sel["logged_in_marker"]).count() > 0

    def _read_error(self) -> str:
        try:
            locator = self.page.locator(".err-msg, .server-err, .error")
            if locator.count() > 0:
                return locator.first.inner_text(timeout=2000).strip()
        except Exception:  # noqa: BLE001 - diagnostics only
            pass
        return ""

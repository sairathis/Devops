"""
scoring.py - Account-specific relevance scoring (0-100).

ACCOUNT 1 (API Management)
    skill points  = best single match from skills table (max, not sum)
    location      = 10 if location matches
    experience    = 25 if experience matches

ACCOUNT 2 (Cloud Engineering)
    cloud points  = best single match from clouds table (GCP 35 > Azure 20 > AWS 15)
    role points   = best single match from roles table (20)
    location      = 10
    experience    = 25

Priority rank (1 = best) comes from profiles.<name>.priority_ranking and is used for
ordering and reporting only; it does not change the score.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from modules.parser import JobRecord
from modules.utils import get_logger


@dataclass
class ScoreResult:
    total: int
    skill_points: int
    role_points: int
    location_points: int
    experience_points: int
    priority_rank: int | None
    breakdown: str

    def meets_threshold(self, threshold: int) -> bool:
        return self.total >= threshold


def _term_pattern(term: str) -> re.Pattern[str]:
    """Whole-term, case-insensitive match (so 'AWS' does not match inside 'AWSome')."""
    return re.compile(rf"(?<![a-z0-9]){re.escape(term.lower())}(?![a-z0-9])", re.IGNORECASE)


class JobScorer:
    """Scores jobs according to config.yaml -> scoring and profiles.<name>.priority_ranking."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        scoring = cfg["scoring"]
        self.threshold = int(scoring["apply_threshold"])
        self.location_points = int(scoring["location_points"])
        self.experience_points = int(scoring["experience_points"])
        self.rules: dict[str, dict[str, dict[str, int]]] = scoring["profiles"]
        self.priorities: dict[str, list[dict[str, Any]]] = {
            name: profile.get("priority_ranking", []) for name, profile in cfg["profiles"].items()
        }
        self.log = get_logger("scoring")

    @staticmethod
    def _best_match(text: str, weights: dict[str, int]) -> tuple[str, int] | None:
        best: tuple[str, int] | None = None
        for term, points in weights.items():
            if _term_pattern(term).search(text) and (best is None or int(points) > best[1]):
                best = (term, int(points))
        return best

    def _priority_rank(self, profile: str, title_text: str) -> int | None:
        """Lowest rank number whose every term group (any-of alternatives) matches the title."""
        ranks: list[int] = []
        for entry in self.priorities.get(profile, []):
            groups = entry.get("all_of", [])
            matched = True
            for group in groups:
                alternatives = group if isinstance(group, list) else [group]
                if not any(_term_pattern(alt).search(title_text) for alt in alternatives):
                    matched = False
                    break
            if matched:
                ranks.append(int(entry["rank"]))
        return min(ranks) if ranks else None

    def score(self, rec: JobRecord, location_match: bool, experience_match: bool) -> ScoreResult:
        """Compute the score for a record. Does not mutate the record."""
        text = rec.searchable_text()
        title_text = f"{rec.job_title} {rec.tags}"
        rules = self.rules.get(rec.profile, {})
        parts: list[str] = []

        skill_points = 0
        role_points = 0
        if "skills" in rules:  # Account 1
            best = self._best_match(text, rules["skills"])
            if best:
                skill_points = best[1]
                parts.append(f"skill:{best[0]}={best[1]}")
        if "clouds" in rules:  # Account 2
            best = self._best_match(text, rules["clouds"])
            if best:
                skill_points = best[1]
                parts.append(f"cloud:{best[0]}={best[1]}")
        if "roles" in rules:
            best = self._best_match(text, rules["roles"])
            if best:
                role_points = best[1]
                parts.append(f"role:{best[0]}={best[1]}")

        location_points = self.location_points if location_match else 0
        experience_points = self.experience_points if experience_match else 0
        if location_points:
            parts.append(f"location={location_points}")
        if experience_points:
            parts.append(f"experience={experience_points}")

        total = min(100, skill_points + role_points + location_points + experience_points)
        rank = self._priority_rank(rec.profile, title_text)
        result = ScoreResult(
            total=total,
            skill_points=skill_points,
            role_points=role_points,
            location_points=location_points,
            experience_points=experience_points,
            priority_rank=rank,
            breakdown="; ".join(parts) or "no keyword match",
        )
        self.log.info(f"Score {rec.job_id} = {total} ({result.breakdown}) rank={rank}")
        return result

    def apply_to_record(self, rec: JobRecord, result: ScoreResult) -> None:
        """Copy a ScoreResult onto a JobRecord."""
        rec.score = result.total
        rec.score_breakdown = result.breakdown
        rec.priority_rank = result.priority_rank

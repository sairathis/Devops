"""
search.py - Keyword search and raw job-card extraction.

Responsibilities
  * Build search URLs (keyword, experience, jobAge filters pushed to Naukri)
  * Iterate result pages and extract card fields into plain dictionaries
  * Open job detail pages for description and Easy Apply detection
"""
from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote_plus

from playwright.sync_api import BrowserContext, Error as PlaywrightError, Locator, Page
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from modules.utils import ScreenshotManager, clean, get_logger, human_pause, slugify


class NaukriSearch:
    """Stateless helper bound to one account's configuration."""

    def __init__(self, cfg: dict[str, Any], screenshots: ScreenshotManager, account_name: str) -> None:
        self.sel = cfg["selectors"]
        self.naukri = cfg["naukri"]
        self.search_cfg = cfg["search"]
        self.timeout = int(cfg["app"]["navigation_timeout_ms"])
        self.delay = cfg["app"]["human_delay_seconds"]
        self.max_pages = int(self.search_cfg["max_pages_per_keyword"])
        self.account_name = account_name
        self.shots = screenshots
        self.log = get_logger("search")

    # -- URL --------------------------------------------------------------
    def build_url(self, keyword: str, page_no: int = 1) -> str:
        url = self.naukri["search_url_template"].format(
            slug=slugify(keyword),
            keyword=quote_plus(keyword),
            min_exp=int(self.search_cfg["experience"]["min_years"]),
            job_age=int(self.search_cfg["job_age_param"]),
        )
        if page_no > 1:
            url += f"&{self.naukri.get('page_param', 'pageNo')}={page_no}"
        return url

    # -- Result pages -----------------------------------------------------
    def search_keyword(self, page: Page, keyword: str) -> list[dict[str, str]]:
        """Return raw card dictionaries for every result page of one keyword."""
        results: list[dict[str, str]] = []
        for page_no in range(1, self.max_pages + 1):
            url = self.build_url(keyword, page_no)
            self.log.info(f"[{self.account_name}] Search '{keyword}' page {page_no}")
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=self.timeout)
                page.wait_for_selector(self.sel["job_card"], timeout=15000)
            except PlaywrightTimeoutError:
                self.log.warning(f"[{self.account_name}] No job cards for '{keyword}' page {page_no}")
                break
            if page_no == 1:
                self.shots.capture(page, "search_results", self.account_name)

            cards = self._extract_cards(page, keyword)
            self.log.info(f"[{self.account_name}] Extracted {len(cards)} cards for '{keyword}' page {page_no}")
            if not cards:
                break
            results.extend(cards)
            human_pause(self.delay)
        return results

    def _extract_cards(self, page: Page, keyword: str) -> list[dict[str, str]]:
        cards: list[dict[str, str]] = []
        locator = page.locator(self.sel["job_card"])
        for index in range(locator.count()):
            card = locator.nth(index)
            try:
                title_link = card.locator(self.sel["title"]).first
                cards.append({
                    "job_id": card.get_attribute("data-job-id") or "",
                    "title": self._field(card, self.sel["title"]),
                    "url": title_link.get_attribute("href", timeout=2000) or "" if title_link.count() else "",
                    "company": self._field(card, self.sel["company"]),
                    "location": self._field(card, self.sel["location"]),
                    "experience": self._field(card, self.sel["experience"]),
                    "salary": self._field(card, self.sel["salary"]),
                    "posted": self._field(card, self.sel["posted"]),
                    "tags": " | ".join(self._all_texts(card, self.sel["tags"])),
                    "card_text": self._card_text(card),
                    "keyword": keyword,
                })
            except PlaywrightError as exc:
                self.log.warning(f"[{self.account_name}] Card {index} skipped: {exc}")
        return cards

    # -- Detail pages -----------------------------------------------------
    def fetch_detail(self, context: BrowserContext, url: str, label: str | None = None) -> dict[str, Any]:
        """Open a job page in a temporary tab and return description and Easy Apply info."""
        if not url:
            return {}
        page = context.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=self.timeout)
            try:
                page.wait_for_selector(self.sel["detail_description"], timeout=15000)
            except PlaywrightTimeoutError:
                self.log.warning(f"Description not found for {url}")
            description = self._field(page, self.sel["detail_description"])
            button_texts = [clean(t) for t in self._all_texts(page, self.sel["detail_apply_buttons"])]
            easy_apply = any(re.search(r"easy\s*apply", t, re.IGNORECASE) for t in button_texts)
            if label:
                self.shots.capture(page, label, self.account_name)
            return {"description": description, "easy_apply": easy_apply}
        except PlaywrightError as exc:
            self.log.warning(f"Detail page failed for {url}: {exc}")
            return {}
        finally:
            page.close()

    def capture_url(self, context: BrowserContext, url: str, label: str) -> None:
        """Open a job URL only to take a screenshot (used for walk-in evidence)."""
        if not url:
            return
        page = context.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=self.timeout)
            self.shots.capture(page, label, self.account_name)
        except PlaywrightError as exc:
            self.log.warning(f"Could not capture {label} for {url}: {exc}")
        finally:
            page.close()

    # -- Helpers ----------------------------------------------------------
    @staticmethod
    def _field(scope: Page | Locator, selector: str) -> str:
        try:
            locator = scope.locator(selector).first
            if locator.count() == 0:
                return ""
            return clean(locator.inner_text(timeout=2000))
        except PlaywrightError:
            return ""

    @staticmethod
    def _all_texts(scope: Page | Locator, selector: str) -> list[str]:
        try:
            return [clean(t) for t in scope.locator(selector).all_inner_texts() if clean(t)]
        except PlaywrightError:
            return []

    @staticmethod
    def _card_text(card: Locator) -> str:
        try:
            return clean(card.inner_text(timeout=2000))
        except PlaywrightError:
            return ""

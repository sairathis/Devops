"""
parser.py - Converts raw scraped text into normalised JobRecord objects.

Handles:
  * Experience text  ("3-6 Yrs", "10+ Years", "5 Years")  -> min / max
  * Posted text      ("Just Now", "3 Days Ago", "30+ days ago") -> date / days old
  * Job ID extraction from the data-job-id attribute or the job URL
"""
from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Mapping
from urllib.parse import urlparse

from modules.utils import clean, iso, now_local

_RANGE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:-|–|—|to)\s*(\d+(?:\.\d+)?)", re.IGNORECASE)
_PLUS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*\+\s*(?:yrs?|years?)", re.IGNORECASE)
_SINGLE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:yrs?|years?)", re.IGNORECASE)
_DAYS_RE = re.compile(r"(\d+)\s*\+?\s*day", re.IGNORECASE)
_MONTHS_RE = re.compile(r"(\d+)\s*\+?\s*month", re.IGNORECASE)
_TODAY_RE = re.compile(
    r"just now|today|few (?:minutes|hours)|\b(?:\d+\s*)?(?:minute|hour)s?\b", re.IGNORECASE
)


@dataclass
class JobRecord:
    """Normalised job information used by filtering, scoring, reporting and storage."""

    job_id: str
    account_name: str
    profile: str
    search_keyword: str = ""
    job_title: str = ""
    company: str = ""
    location: str = ""
    experience_text: str = ""
    min_experience: float | None = None
    max_experience: float | None = None
    experience_match: bool = False
    salary: str = ""
    posted_text: str = ""
    posted_date: str = ""
    days_old: int | None = None
    easy_apply: bool = False
    walk_in: bool = False
    walkin_reason: str = ""
    score: int = 0
    score_breakdown: str = ""
    priority_rank: int | None = None
    location_match: bool = False
    qualified: bool = False          # passed every apply rule (ignoring whether apply is enabled)
    job_url: str = ""
    description: str = ""
    status: str = "NEW"
    skip_reason: str = ""
    captured_at: str = ""
    # Transient fields (not persisted)
    tags: str = ""
    card_text: str = ""

    def searchable_text(self) -> str:
        """Text used by scoring: title, tags and description."""
        return " ".join(part for part in (self.job_title, self.tags, self.description) if part)

    def walkin_text_sources(self) -> dict[str, str]:
        """Named text fragments scanned by the walk-in detector."""
        return {
            "job title": self.job_title,
            "job tags": self.tags,
            "job card": self.card_text,
            "job description": self.description,
        }

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, Any]) -> "JobRecord":
        """Build a record from a DB row (sqlite3.Row or dict), ignoring unknown columns."""
        names = {f.name for f in dataclasses.fields(cls)}
        data = {k: mapping[k] for k in mapping.keys() if k in names}
        for flag in ("experience_match", "location_match", "easy_apply", "walk_in", "qualified"):
            if flag in data and data[flag] is not None:
                data[flag] = bool(data[flag])
        return cls(**data)


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------
def parse_experience(text: str | None) -> tuple[float | None, float | None]:
    """
    Return (min_years, max_years).
      '3-6 Yrs'     -> (3, 6)
      '10+ Years'   -> (10, None)
      '5 Years'     -> (5, 5)
      ''            -> (None, None)
    """
    if not text:
        return None, None
    match = _RANGE_RE.search(text)
    if match:
        low, high = float(match.group(1)), float(match.group(2))
        return min(low, high), max(low, high)
    match = _PLUS_RE.search(text)
    if match:
        return float(match.group(1)), None
    match = _SINGLE_RE.search(text)
    if match:
        value = float(match.group(1))
        return value, value
    return None, None


def parse_posted(text: str | None, today: date | None = None) -> tuple[date | None, int | None]:
    """
    Return (posted_date, days_old) from Naukri's relative text.
      'Just Now' / 'Today' / 'x hours ago' -> 0 days
      'Yesterday'                          -> 1 day
      '3 Days Ago' / '30+ days ago'        -> 3 / 30 days
    Returns (None, None) when the text cannot be interpreted.
    """
    today = today or now_local().date()
    value = clean(text).lower()
    if not value:
        return None, None
    if _TODAY_RE.search(value):
        days = 0
    elif "yesterday" in value:
        days = 1
    else:
        match = _DAYS_RE.search(value)
        if match:
            days = int(match.group(1))
        else:
            match = _MONTHS_RE.search(value)
            if not match:
                return None, None
            days = int(match.group(1)) * 30
    return today - timedelta(days=days), days


def extract_job_id(url: str | None, fallback: str = "") -> str:
    """Naukri job URLs end with '-<numeric id>'. Fall back to the first long number."""
    if url:
        path = urlparse(url).path.rstrip("/")
        match = re.search(r"-(\d{6,})$", path) or re.search(r"(\d{6,})", path)
        if match:
            return match.group(1)
    return fallback


# ---------------------------------------------------------------------------
# Record builders
# ---------------------------------------------------------------------------
def build_record_from_card(raw: dict[str, str], account_name: str, profile: str, keyword: str) -> JobRecord:
    """Create a JobRecord from the raw dictionary produced by NaukriSearch."""
    url = raw.get("url", "")
    min_exp, max_exp = parse_experience(raw.get("experience", ""))
    posted_date, days_old = parse_posted(raw.get("posted", ""))
    card_text = raw.get("card_text", "")
    return JobRecord(
        job_id=raw.get("job_id") or extract_job_id(url),
        account_name=account_name,
        profile=profile,
        search_keyword=keyword,
        job_title=clean(raw.get("title", "")),
        company=clean(raw.get("company", "")),
        location=clean(raw.get("location", "")),
        experience_text=clean(raw.get("experience", "")),
        min_experience=min_exp,
        max_experience=max_exp,
        salary=clean(raw.get("salary", "")),
        posted_text=clean(raw.get("posted", "")),
        posted_date=posted_date.isoformat() if posted_date else "",
        days_old=days_old,
        easy_apply=bool(re.search(r"easy\s*apply", card_text, re.IGNORECASE)),
        job_url=url,
        captured_at=iso(now_local()),
        tags=clean(raw.get("tags", "")),
        card_text=clean(card_text),
    )


def apply_detail(record: JobRecord, detail: dict[str, Any]) -> None:
    """Merge information from the job detail page into an existing record."""
    if detail.get("description"):
        record.description = clean(detail["description"])
    if detail.get("easy_apply"):
        record.easy_apply = True
    if not record.location and detail.get("location"):
        record.location = clean(detail["location"])
    if record.min_experience is None and detail.get("experience"):
        record.min_experience, record.max_experience = parse_experience(detail["experience"])
        record.experience_text = clean(detail["experience"])

"""
database.py - SQLite persistence layer for NaukriBot.

Tables
  Jobs            one row per Naukri job ID (duplicate prevention + history)
  Applications    one row per job we attempted to apply to (UNIQUE job_id = never apply twice)
  WalkInJobs      walk-in / direct-interview postings detected
  ExecutionLogs   one row per account per run (audit trail)
  Notifications   every email sent or attempted (tracking)
  schema_version  migration marker
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Iterable, Optional

from modules.parser import JobRecord
from modules.utils import get_logger, iso, now_local

SCHEMA_VERSION = 1

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS Jobs (
    job_id              TEXT PRIMARY KEY,
    account_name        TEXT NOT NULL,
    profile             TEXT,
    search_keyword      TEXT,
    job_title           TEXT,
    company             TEXT,
    location            TEXT,
    experience_text     TEXT,
    min_experience      REAL,
    max_experience      REAL,
    experience_match    INTEGER DEFAULT 0,
    salary              TEXT,
    posted_text         TEXT,
    posted_date         TEXT,
    days_old            INTEGER,
    easy_apply          INTEGER DEFAULT 0,
    walk_in             INTEGER DEFAULT 0,
    walkin_reason       TEXT,
    score               INTEGER DEFAULT 0,
    score_breakdown     TEXT,
    priority_rank       INTEGER,
    location_match      INTEGER DEFAULT 0,
    qualified           INTEGER DEFAULT 0,
    job_url             TEXT,
    description         TEXT,
    status              TEXT NOT NULL,
    skip_reason         TEXT,
    captured_at         TEXT,
    first_seen_at       TEXT NOT NULL,
    last_seen_at        TEXT NOT NULL,
    seen_count          INTEGER DEFAULT 1,
    last_run_id         TEXT,
    last_run_status     TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON Jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_account ON Jobs(account_name);

CREATE TABLE IF NOT EXISTS Applications (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id          TEXT NOT NULL UNIQUE,          -- one application attempt per job, ever
    account_name    TEXT NOT NULL,
    status          TEXT NOT NULL,                 -- APPLIED | FAILED
    applied_at      TEXT,
    attempted_at    TEXT NOT NULL,
    error_message   TEXT,
    screenshot_path TEXT,
    email_sent      INTEGER DEFAULT 0,
    FOREIGN KEY (job_id) REFERENCES Jobs(job_id)
);
CREATE INDEX IF NOT EXISTS idx_apps_account ON Applications(account_name);

CREATE TABLE IF NOT EXISTS WalkInJobs (
    job_id              TEXT PRIMARY KEY,
    account_name        TEXT,
    company             TEXT,
    job_title           TEXT,
    location            TEXT,
    posted_date         TEXT,
    job_url             TEXT,
    detection_reason    TEXT,
    detected_at         TEXT NOT NULL,
    run_id              TEXT
);

CREATE TABLE IF NOT EXISTS ExecutionLogs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id          TEXT NOT NULL,
    mode            TEXT,
    account_name    TEXT,
    started_at      TEXT NOT NULL,
    finished_at     TEXT,
    status          TEXT,
    message         TEXT,
    jobs_found      INTEGER DEFAULT 0,
    new_jobs        INTEGER DEFAULT 0,
    duplicates      INTEGER DEFAULT 0,
    walk_ins        INTEGER DEFAULT 0,
    ready           INTEGER DEFAULT 0,
    applied         INTEGER DEFAULT 0,
    failed          INTEGER DEFAULT 0,
    skipped         INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS Notifications (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    notification_type TEXT NOT NULL,        -- DAILY_SUMMARY | WALKIN_ALERT | APPLICATION | TEST
    job_id            TEXT,
    recipient         TEXT,
    subject           TEXT,
    status            TEXT NOT NULL,        -- SENT | FAILED | SKIPPED
    error_message     TEXT,
    attachment_path   TEXT,
    sent_at           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_job ON Notifications(notification_type, job_id);
"""

# Columns written from JobRecord (names match the dataclass fields).
JOB_FIELDS = [
    "job_id", "account_name", "profile", "search_keyword", "job_title", "company",
    "location", "experience_text", "min_experience", "max_experience", "experience_match",
    "salary", "posted_text", "posted_date", "days_old", "easy_apply", "walk_in",
    "walkin_reason", "score", "score_breakdown", "priority_rank", "location_match",
    "qualified", "job_url", "description", "status", "skip_reason", "captured_at",
]

METRIC_COLUMNS = ("jobs_found", "new_jobs", "duplicates", "walk_ins", "ready", "applied", "failed", "skipped")


class JobDatabase:
    """Thin repository around SQLite. Every write is committed immediately."""

    def __init__(self, db_path: Path, busy_timeout_seconds: int = 30, wal_mode: bool = True) -> None:
        self.db_path = db_path
        self.log = get_logger("database")
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path), timeout=busy_timeout_seconds, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        if wal_mode:
            self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.executescript(SCHEMA_SQL)
        self.conn.execute(
            "INSERT INTO schema_version(version) SELECT ? WHERE NOT EXISTS (SELECT 1 FROM schema_version)",
            (SCHEMA_VERSION,),
        )
        self.conn.commit()
        self.log.info(f"Database ready: {db_path}")

    # -- lifecycle -----------------------------------------------------------
    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "JobDatabase":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # -- Jobs ----------------------------------------------------------------
    def job_exists(self, job_id: str) -> bool:
        """Duplicate check: has this Naukri job ID ever been stored?"""
        row = self.conn.execute("SELECT 1 FROM Jobs WHERE job_id = ?", (job_id,)).fetchone()
        return row is not None

    def get_job(self, job_id: str) -> Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM Jobs WHERE job_id = ?", (job_id,)).fetchone()

    def insert_job(self, rec: JobRecord, run_id: str) -> None:
        """Store a job on first sighting. Callers must check job_exists() first."""
        now = iso(now_local())
        values: list[Any] = [int(v) if isinstance(v, bool) else v for v in (getattr(rec, f) for f in JOB_FIELDS)]
        columns = JOB_FIELDS + ["first_seen_at", "last_seen_at", "seen_count", "last_run_id", "last_run_status"]
        values += [now, now, 1, run_id, rec.status]
        placeholders = ", ".join("?" for _ in columns)
        self.conn.execute(
            f"INSERT INTO Jobs ({', '.join(columns)}) VALUES ({placeholders})", values
        )
        self.conn.commit()

    def mark_duplicate(self, job_id: str, run_id: str) -> None:
        """Record another sighting of an already-stored job. Original status is preserved."""
        self.conn.execute(
            """UPDATE Jobs SET last_seen_at = ?, seen_count = seen_count + 1,
                   last_run_id = ?, last_run_status = 'DUPLICATE'
               WHERE job_id = ?""",
            (iso(now_local()), run_id, job_id),
        )
        self.conn.commit()

    def update_job_status(self, job_id: str, status: str, skip_reason: str, run_id: str) -> None:
        self.conn.execute(
            """UPDATE Jobs SET status = ?, skip_reason = ?, last_run_status = ?,
                   last_run_id = ?, last_seen_at = ?
               WHERE job_id = ?""",
            (status, skip_reason, status, run_id, iso(now_local()), job_id),
        )
        self.conn.commit()

    def pending_monitor_jobs(self, account_name: str, limit: int) -> list[sqlite3.Row]:
        """
        Jobs stored as NEW (qualified, not walk-in) by MONITOR runs that were never applied to.
        Used by APPLY mode to act on jobs the user has reviewed. Never re-evaluates them.
        """
        return self.conn.execute(
            """SELECT * FROM Jobs
               WHERE account_name = ? AND status = 'NEW' AND qualified = 1 AND walk_in = 0
                 AND job_id NOT IN (SELECT job_id FROM Applications)
               ORDER BY score DESC, COALESCE(priority_rank, 99) ASC, first_seen_at ASC
               LIMIT ?""",
            (account_name, limit),
        ).fetchall()

    # -- WalkInJobs ----------------------------------------------------------
    def record_walkin(self, rec: JobRecord, run_id: str) -> bool:
        """Store a walk-in job once. Returns True if it was newly inserted."""
        cur = self.conn.execute(
            """INSERT OR IGNORE INTO WalkInJobs
               (job_id, account_name, company, job_title, location, posted_date, job_url,
                detection_reason, detected_at, run_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (rec.job_id, rec.account_name, rec.company, rec.job_title, rec.location,
             rec.posted_date, rec.job_url, rec.walkin_reason, iso(now_local()), run_id),
        )
        self.conn.commit()
        return cur.rowcount == 1

    # -- Applications --------------------------------------------------------
    def application_exists(self, job_id: str) -> bool:
        row = self.conn.execute("SELECT 1 FROM Applications WHERE job_id = ?", (job_id,)).fetchone()
        return row is not None

    def record_application(self, job_id: str, account_name: str, status: str,
                           applied_at: str, error: str, screenshot: str) -> bool:
        """Insert an application attempt. UNIQUE(job_id) guarantees a job is attempted once."""
        try:
            self.conn.execute(
                """INSERT INTO Applications
                   (job_id, account_name, status, applied_at, attempted_at, error_message, screenshot_path)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (job_id, account_name, status, applied_at or None, iso(now_local()), error, screenshot),
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            self.log.warning(f"Application for job {job_id} already exists; not recorded twice")
            return False

    def mark_application_email(self, job_id: str) -> None:
        self.conn.execute("UPDATE Applications SET email_sent = 1 WHERE job_id = ?", (job_id,))
        self.conn.commit()

    # -- ExecutionLogs -------------------------------------------------------
    def start_execution(self, run_id: str, mode: str, account_name: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO ExecutionLogs (run_id, mode, account_name, started_at, status) VALUES (?, ?, ?, ?, 'RUNNING')",
            (run_id, mode, account_name, iso(now_local())),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def finish_execution(self, exec_id: int, status: str, message: str, metrics: dict[str, int]) -> None:
        cols = ", ".join(f"{m} = ?" for m in METRIC_COLUMNS)
        values = [metrics.get(m, 0) for m in METRIC_COLUMNS]
        self.conn.execute(
            f"UPDATE ExecutionLogs SET finished_at = ?, status = ?, message = ?, {cols} WHERE id = ?",
            [iso(now_local()), status, message[:1000], *values, exec_id],
        )
        self.conn.commit()

    # -- Notifications -------------------------------------------------------
    def record_notification(self, notification_type: str, job_id: str | None, recipient: str,
                            subject: str, status: str, error: str = "",
                            attachment: str = "") -> None:
        self.conn.execute(
            """INSERT INTO Notifications
               (notification_type, job_id, recipient, subject, status, error_message, attachment_path, sent_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (notification_type, job_id, recipient, subject, status, error[:1000], attachment, iso(now_local())),
        )
        self.conn.commit()

    def notification_sent(self, notification_type: str, job_id: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM Notifications WHERE notification_type = ? AND job_id = ? AND status = 'SENT'",
            (notification_type, job_id),
        ).fetchone()
        return row is not None

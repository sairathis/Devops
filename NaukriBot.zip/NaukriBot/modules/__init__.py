"""NaukriBot application modules."""

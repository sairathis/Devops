#!/usr/bin/env python
"""
main.py - NaukriBot entry point and pipeline orchestrator.

Commands
  python main.py run [--mode monitor|apply] [--account all|account1|account2]
  python main.py init-db
  python main.py test-email
  python main.py print-schedule [--mode monitor|apply]
  python main.py install-schedule [--mode monitor|apply] [--dry-run]
  python main.py remove-schedule

Pipeline per account (Account 1, then Account 2):
  login -> search every keyword -> for each job card:
    duplicate check -> filters (location, experience, age) -> walk-in check (card)
    -> detail page (description, Easy Apply) -> walk-in check (detail)
    -> Easy Apply check -> score -> threshold -> NEW (monitor) or apply (apply mode)
  -> Excel report -> summary email
"""
from __future__ import annotations

import argparse
import sys
from typing import Any

from playwright.sync_api import Browser, BrowserContext
from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import sync_playwright

from modules.apply import NaukriApplier
from modules.database import JobDatabase
from modules.emailer import Emailer
from modules.filtering import JobFilter
from modules.login import LoginError, NaukriLogin
from modules.parser import JobRecord, apply_detail, build_record_from_card
from modules.report import ReportGenerator, summarize
from modules.scheduler import WindowsScheduler
from modules.scoring import JobScorer
from modules.search import NaukriSearch
from modules.utils import (
    AccountConfig,
    ConfigError,
    RunLock,
    RunLockError,
    ScreenshotManager,
    file_stamp,
    get_logger,
    iso,
    load_accounts,
    load_config,
    now_local,
    path_of,
    ensure_directories,
    setup_logging,
)
from modules.walkin_detector import WalkInDetector


class NaukriBotRunner:
    """Coordinates login, search, filtering, storage, apply, reporting and email for one run."""

    def __init__(self, cfg: dict[str, Any], accounts: list[AccountConfig]) -> None:
        self.cfg = cfg
        self.accounts = accounts
        self.run_id = file_stamp()
        app = cfg["app"]
        self.mode = app["MODE"]
        self.apply_enabled = bool(app["AUTO_APPLY"]) and self.mode == "APPLY"
        self.effective_mode = "APPLY" if self.apply_enabled else "MONITOR"
        self.max_applications = int(app["max_applications_per_run"])
        self.detail_budget = int(cfg["search"]["max_detail_pages_per_run"])
        self.detail_shot_taken = False
        self.threshold = int(cfg["scoring"]["apply_threshold"])

        self.db = JobDatabase(
            path_of(cfg, "database_file"),
            busy_timeout_seconds=int(cfg["database"].get("busy_timeout_seconds", 30)),
            wal_mode=bool(cfg["database"].get("wal_mode", True)),
        )
        self.shots = ScreenshotManager(cfg)
        self.filter = JobFilter(cfg)
        self.scorer = JobScorer(cfg)
        self.walkin = WalkInDetector(cfg)
        self.emailer = Emailer(cfg, self.db)
        self.records: list[JobRecord] = []
        self.applications_this_run = 0
        self.searcher: NaukriSearch | None = None
        self.log = get_logger("core")

    # ------------------------------------------------------------------
    # Run lifecycle
    # ------------------------------------------------------------------
    def run(self, account_filter: str) -> int:
        selected = [a for a in self.accounts if a.enabled and account_filter in ("all", a.name)]
        if not selected:
            self.log.error(f"No enabled account matches '{account_filter}'")
            return 1

        self.log.info(
            f"Run {self.run_id} started | mode={self.effective_mode} | "
            f"accounts={[a.name for a in selected]}"
        )
        if self.mode == "APPLY" and not self.apply_enabled:
            self.log.warning("MODE=APPLY but AUTO_APPLY=false. Running in MONITOR behaviour (no applications).")

        failures = 0
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=bool(self.cfg["app"]["headless"]))
            try:
                for account in selected:
                    if not self._run_account(browser, account):
                        failures += 1
            finally:
                browser.close()

        summary = summarize(self.records, self.run_id, self.effective_mode)
        report_path = None
        try:
            report_path = ReportGenerator(self.cfg).generate(self.records, summary)
        except Exception as exc:  # noqa: BLE001 - report failure must not hide job results
            self.log.exception(f"Report generation failed: {exc}")
        self.emailer.send_daily_summary(summary, report_path)

        self.log.info(
            f"Run {self.run_id} finished | found={summary.total_found} new={summary.new_jobs} "
            f"duplicates={summary.duplicates} walk_ins={summary.walk_in} ready={summary.ready} "
            f"applied={summary.applied} failed={summary.failed} skipped={summary.skipped}"
        )
        self.db.close()
        return 0 if failures == 0 else 1

    def _run_account(self, browser: Browser, account: AccountConfig) -> bool:
        """Run the full pipeline for one account in its own isolated browser context."""
        start_index = len(self.records)
        exec_id = self.db.start_execution(self.run_id, self.effective_mode, account.name)
        context: BrowserContext = browser.new_context(
            viewport={"width": 1366, "height": 900}, locale="en-IN", timezone_id="Asia/Kolkata"
        )
        context.set_default_timeout(int(self.cfg["app"]["default_timeout_ms"]))
        status, message, ok = "SUCCESS", "", True
        try:
            page = context.new_page()
            NaukriLogin(page, self.cfg, self.shots).login(account)
            self.searcher = NaukriSearch(self.cfg, self.shots, account.name)

            if self.apply_enabled and self.cfg["app"].get("apply_pending_from_monitor", True):
                self._apply_pending(context, account)

            for keyword in self._keywords(account.profile):
                raw_cards = self.searcher.search_keyword(page, keyword)
                self.log.info(f"[{account.name}] '{keyword}' produced {len(raw_cards)} cards")
                for raw in raw_cards:
                    self._process_card(context, account, keyword, raw)
        except LoginError as exc:
            status, message, ok = "FAILED", str(exc), False
        except PlaywrightError as exc:
            status, message, ok = "FAILED", f"Browser error: {exc}", False
            self.log.error(f"[{account.name}] Browser error: {exc}")
        except Exception as exc:  # noqa: BLE001 - one account must not stop the other
            status, message, ok = "FAILED", f"Unexpected error: {exc}", False
            self.log.exception(f"[{account.name}] Unexpected error")
        finally:
            context.close()
            account_summary = summarize(self.records[start_index:], self.run_id, self.effective_mode)
            self.db.finish_execution(exec_id, status, message, account_summary.execution_metrics())
        return ok

    def _keywords(self, profile: str) -> list[str]:
        """Unique keywords for the profile, preserving the configured priority order."""
        configured = self.cfg["profiles"][profile]["search_keywords"]
        return list(dict.fromkeys(configured))

    # ------------------------------------------------------------------
    # Per-job pipeline
    # ------------------------------------------------------------------
    def _process_card(self, context: BrowserContext, account: AccountConfig,
                      keyword: str, raw: dict[str, str]) -> None:
        rec = build_record_from_card(raw, account.name, account.profile, keyword)
        if not rec.job_id:
            self.log.warning(f"[{account.name}] Card without job ID skipped: '{rec.job_title}'")
            return

        # 1. Duplicate prevention (never process the same job ID twice)
        if self.db.job_exists(rec.job_id):
            self.db.mark_duplicate(rec.job_id, self.run_id)
            rec.status, rec.skip_reason = "DUPLICATE", "Duplicate Job"
            self.log.info(f"Duplicate check: {rec.job_id} already stored -> DUPLICATE")
            self.records.append(rec)
            return

        # 2. Location / experience / age filters (card data)
        reason = self.filter.evaluate(rec)
        if reason:
            self._skip(rec, reason)
            return

        # 3. Walk-in detection on card text
        if self._walkin_check(context, rec):
            return

        # 4. Job detail page: description and Easy Apply, then walk-in check again
        self._enrich(context, rec)
        if self._walkin_check(context, rec):
            return

        # 5. Scoring and apply rules
        result = self.scorer.score(rec, rec.location_match, rec.experience_match)
        self.scorer.apply_to_record(rec, result)
        if not rec.easy_apply:
            self._skip(rec, "Not Easy Apply")
            return
        if result.total < self.threshold:
            self._skip(rec, "Low Score")
            return

        rec.qualified = True
        if self.apply_enabled:
            self._apply_flow(context, rec)
        else:
            rec.status = "NEW"  # qualifies; awaiting your validation in MONITOR mode
            self._finalize(rec)
            self.log.info(f"NEW (monitor): {rec.job_id} score={rec.score} | {rec.job_title} | {rec.company}")

    def _walkin_check(self, context: BrowserContext, rec: JobRecord) -> bool:
        result = self.walkin.detect(rec)
        if not result.is_walk_in:
            return False
        rec.walk_in = True
        rec.walkin_reason = result.reason
        rec.status = "WALK_IN"
        rec.skip_reason = "Walk-In Job"
        self.db.record_walkin(rec, self.run_id)
        if self.searcher is not None:
            self.searcher.capture_url(context, rec.job_url, "walkin_detection")
        self.emailer.send_walkin_alert(rec)
        self._finalize(rec)
        return True

    def _enrich(self, context: BrowserContext, rec: JobRecord) -> None:
        if self.detail_budget <= 0 or not rec.job_url or self.searcher is None:
            return
        self.detail_budget -= 1
        label = None if self.detail_shot_taken else "job_extraction"
        self.detail_shot_taken = True
        detail = self.searcher.fetch_detail(context, rec.job_url, label)
        if detail:
            apply_detail(rec, detail)

    def _skip(self, rec: JobRecord, reason: str) -> None:
        rec.status = "SKIPPED"
        rec.skip_reason = reason
        self._finalize(rec)
        self.log.info(f"SKIPPED: {rec.job_id} | {reason} | {rec.job_title} | {rec.location}")

    def _finalize(self, rec: JobRecord) -> None:
        """Persist a first-seen job and add it to the run's report rows."""
        if not self.db.job_exists(rec.job_id):
            self.db.insert_job(rec, self.run_id)
        self.records.append(rec)

    # ------------------------------------------------------------------
    # Apply mode
    # ------------------------------------------------------------------
    def _apply_flow(self, context: BrowserContext, rec: JobRecord) -> None:
        if self.applications_this_run >= self.max_applications:
            rec.status = "READY_TO_APPLY"
            rec.skip_reason = "Application Limit Reached"
            self._finalize(rec)
            return
        rec.status = "READY_TO_APPLY"
        self._finalize(rec)  # persist the decision before the attempt
        self._attempt_and_record(context, rec)

    def _apply_pending(self, context: BrowserContext, account: AccountConfig) -> None:
        """Apply to jobs reviewed from earlier MONITOR runs (status NEW, never applied)."""
        rows = self.db.pending_monitor_jobs(account.name, self.max_applications)
        if rows:
            self.log.info(f"[{account.name}] {len(rows)} monitored job(s) pending application")
        for row in rows:
            if self.applications_this_run >= self.max_applications:
                break
            rec = JobRecord.from_mapping(dict(row))
            rec.status = "READY_TO_APPLY"
            self.db.update_job_status(rec.job_id, "READY_TO_APPLY", "", self.run_id)
            self._attempt_and_record(context, rec)
            self.records.append(rec)

    def _attempt_and_record(self, context: BrowserContext, rec: JobRecord) -> None:
        applier = NaukriApplier(context, self.cfg, self.shots)
        result = applier.apply(rec)
        applied_at = iso(now_local())
        if result.success:
            rec.status, rec.skip_reason = "APPLIED", ""
            self.applications_this_run += 1
            self.db.record_application(rec.job_id, rec.account_name, "APPLIED", applied_at, "", result.screenshot)
            self.db.update_job_status(rec.job_id, "APPLIED", "", self.run_id)
            if self.emailer.send_application_email(rec, applied_at):
                self.db.mark_application_email(rec.job_id)
        else:
            rec.status, rec.skip_reason = "FAILED", result.error[:200]
            self.db.record_application(rec.job_id, rec.account_name, "FAILED", "", result.error, result.screenshot)
            self.db.update_job_status(rec.job_id, "FAILED", rec.skip_reason, self.run_id)


# ----------------------------------------------------------------------
# Command line
# ----------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="naukribot", description="Naukri monitoring and controlled auto-apply")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="Run one monitoring or apply cycle")
    run.add_argument("--mode", choices=["monitor", "apply"], default=None,
                     help="Overrides config MODE. Apply still requires AUTO_APPLY=true.")
    run.add_argument("--account", default="all", help="all | account1 | account2")

    sub.add_parser("init-db", help="Create or verify the SQLite database")
    sub.add_parser("test-email", help="Send a test email using SMTP settings")

    sched_print = sub.add_parser("print-schedule", help="Print schtasks commands")
    sched_print.add_argument("--mode", choices=["monitor", "apply"], default=None)

    sched_install = sub.add_parser("install-schedule", help="Create Windows Task Scheduler tasks")
    sched_install.add_argument("--mode", choices=["monitor", "apply"], default=None)
    sched_install.add_argument("--dry-run", action="store_true", help="Only print the commands")

    sub.add_parser("remove-schedule", help="Delete Windows Task Scheduler tasks")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        cfg = load_config()
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    ensure_directories(cfg)
    setup_logging(cfg)
    log = get_logger("core")

    try:
        if args.command == "init-db":
            JobDatabase(path_of(cfg, "database_file")).close()
            log.info("Database initialised")
            return 0

        if args.command == "test-email":
            db = JobDatabase(path_of(cfg, "database_file"))
            ok = Emailer(cfg, db).send_test_email()
            db.close()
            return 0 if ok else 1

        if args.command in ("print-schedule", "install-schedule"):
            mode = (args.mode or cfg["app"]["MODE"]).lower()
            scheduler = WindowsScheduler(cfg)
            if args.command == "print-schedule":
                print("\n".join(scheduler.build_create_commands(mode)))
                return 0
            ok = scheduler.install(mode, dry_run=args.dry_run)
            return 0 if ok else 1

        if args.command == "remove-schedule":
            return 0 if WindowsScheduler(cfg).remove() else 1

        if args.command == "run":
            if args.mode:
                cfg["app"]["MODE"] = args.mode.upper()
            accounts = load_accounts(path_of(cfg, "accounts_file"))
            lock_path = path_of(cfg, "logs_dir") / "naukribot.lock"
            with RunLock(lock_path):
                runner = NaukriBotRunner(cfg, accounts)
                return runner.run(args.account)
    except RunLockError as exc:
        log.error(str(exc))
        return 2
    except ConfigError as exc:
        log.error(f"Configuration error: {exc}")
        return 2
    except Exception:  # noqa: BLE001 - last-resort handler so the scheduler records a failure
        log.exception("Fatal error")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

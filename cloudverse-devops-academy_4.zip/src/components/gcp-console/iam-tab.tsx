"use client";

import * as React from "react";
import {
  ShieldCheck,
  Bot,
  Layers,
  Plus,
  X,
  Trash2,
  KeyRound,
  Users,
  Mail,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge, type BadgeProps } from "@/components/ui/badge";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectGroup,
  SelectLabel,
  SelectItem,
} from "@/components/ui/select";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Switch } from "@/components/ui/switch";
import { useIamStore, ServiceAccount, SA_EMAIL_DOMAIN } from "@/store/iam-store";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { IAM_ROLES, IamRole, getIamRole } from "@/lib/gcp/iam-roles";
import { cn, slugify } from "@/lib/utils";

// ───────────────────────── literal lookup maps (never build Tailwind classes dynamically) ─────────────────────────

const RISK_VARIANT: Record<IamRole["riskLevel"], BadgeProps["variant"]> = {
  low: "success",
  medium: "warning",
  high: "danger",
};

const RISK_LABEL: Record<IamRole["riskLevel"], string> = {
  low: "Low risk",
  medium: "Medium risk",
  high: "High risk",
};

const CATEGORY_LABEL: Record<IamRole["category"], string> = {
  basic: "Basic (primitive)",
  security: "Security & Identity",
  compute: "Compute Engine",
  storage: "Cloud Storage",
  database: "Cloud SQL",
  containers: "Kubernetes Engine",
  networking: "Networking",
  cicd: "CI/CD",
  messaging: "Pub/Sub",
};

const CATEGORY_ORDER: IamRole["category"][] = [
  "basic",
  "security",
  "compute",
  "storage",
  "database",
  "containers",
  "networking",
  "cicd",
  "messaging",
];

function RiskBadge({ level, className }: { level: IamRole["riskLevel"]; className?: string }) {
  return (
    <Badge variant={RISK_VARIANT[level]} className={cn("shrink-0 text-[10px]", className)}>
      {RISK_LABEL[level]}
    </Badge>
  );
}

// ───────────────────────── Concepts callout row ─────────────────────────

const CONCEPTS: { title: string; icon: typeof Bot; badge: string; variant: BadgeProps["variant"]; body: string }[] = [
  {
    title: "Identities for workloads, not people",
    icon: Bot,
    badge: "Service Account",
    variant: "info",
    body: "Every VM, GKE pod, or CI/CD pipeline runs AS some identity — never as \"nobody.\" A service account is that identity for code and workloads, separate from the human users who sign in to the console.",
  },
  {
    title: "Principle of least privilege",
    icon: ShieldCheck,
    badge: "PoLP",
    variant: "warning",
    body: "Grant the narrowest role that does the job. The seeded default service account below holds the broad Editor role (high risk) — a well-scoped account for the same workload might hold only Storage Object Viewer (low risk) instead.",
  },
  {
    title: "Three flavors of IAM roles",
    icon: Layers,
    badge: "Roles",
    variant: "success",
    body: "Primitive roles (Owner/Editor/Viewer) are broad and legacy. Predefined roles like roles/storage.objectViewer are scoped to one service. Custom roles assemble individual permissions. This app only lets you grant primitive and predefined roles — the realistic starting point for learning IAM.",
  },
];

function ConceptsRow() {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      {CONCEPTS.map((c) => (
        <Card key={c.title}>
          <CardHeader className="gap-2">
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <c.icon className="h-4 w-4" />
              </span>
              <Badge variant={c.variant} className="text-[10px]">
                {c.badge}
              </Badge>
            </div>
            <CardTitle className="text-sm">{c.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">{c.body}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ───────────────────────── Create Service Account dialog ─────────────────────────

function CreateServiceAccountDialog() {
  const createServiceAccount = useIamStore((s) => s.createServiceAccount);
  const [open, setOpen] = React.useState(false);
  const [name, setName] = React.useState("");
  const [displayName, setDisplayName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [selectedRoleIds, setSelectedRoleIds] = React.useState<string[]>([]);

  const slug = slugify(name);
  const emailPreview = `${slug || "your-sa-name"}@${SA_EMAIL_DOMAIN}`;
  const canSubmit = slug.length > 0;

  function resetForm() {
    setName("");
    setDisplayName("");
    setDescription("");
    setSelectedRoleIds([]);
  }

  function toggleRole(roleId: string) {
    setSelectedRoleIds((prev) => (prev.includes(roleId) ? prev.filter((r) => r !== roleId) : [...prev, roleId]));
  }

  function handleSubmit() {
    if (!canSubmit) return;
    createServiceAccount(slug, displayName.trim() || slug, description.trim(), selectedRoleIds);
    resetForm();
    setOpen(false);
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) resetForm();
      }}
    >
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1.5">
          <Plus className="h-4 w-4" /> Create Service Account
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Create service account</DialogTitle>
          <DialogDescription>
            A service account is an identity for a workload — give it a name and only the roles it actually needs.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="sa-name">Service account name</Label>
            <Input
              id="sa-name"
              placeholder="web-app-runner"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Mail className="h-3 w-3 shrink-0" />
              <span className="truncate font-mono">{emailPreview}</span>
            </p>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="sa-display-name">Display name</Label>
            <Input
              id="sa-display-name"
              placeholder="Web App Runner"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="sa-description">Description</Label>
            <Textarea
              id="sa-description"
              placeholder="What workload uses this identity?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Roles ({selectedRoleIds.length} selected)</Label>
            <Accordion type="multiple" className="rounded-lg border border-border px-3">
              {CATEGORY_ORDER.map((category) => {
                const roles = IAM_ROLES.filter((r) => r.category === category);
                if (roles.length === 0) return null;
                const selectedInCategory = roles.filter((r) => selectedRoleIds.includes(r.id)).length;
                return (
                  <AccordionItem key={category} value={category}>
                    <AccordionTrigger>
                      <span className="flex items-center gap-2">
                        {CATEGORY_LABEL[category]}
                        {selectedInCategory > 0 && (
                          <Badge variant="secondary" className="text-[10px]">
                            {selectedInCategory}
                          </Badge>
                        )}
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-3">
                        {roles.map((role) => (
                          <label
                            key={role.id}
                            className="flex cursor-pointer items-start gap-2.5 rounded-md p-1 hover:bg-accent"
                          >
                            <Checkbox
                              checked={selectedRoleIds.includes(role.id)}
                              onCheckedChange={() => toggleRole(role.id)}
                              className="mt-0.5"
                            />
                            <span className="min-w-0 flex-1">
                              <span className="flex flex-wrap items-center gap-1.5">
                                <span className="text-sm font-medium text-foreground">{role.title}</span>
                                <RiskBadge level={role.riskLevel} />
                              </span>
                              <span className="block text-xs text-muted-foreground">{role.description}</span>
                            </span>
                          </label>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!canSubmit}>
            Create service account
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ───────────────────────── Service Account detail sheet ─────────────────────────

function ServiceAccountDetail({
  serviceAccount,
  onOpenChange,
}: {
  serviceAccount: ServiceAccount | null;
  onOpenChange: (open: boolean) => void;
}) {
  const grantRole = useIamStore((s) => s.grantRole);
  const revokeRole = useIamStore((s) => s.revokeRole);
  const toggleDisabled = useIamStore((s) => s.toggleDisabled);
  const deleteServiceAccount = useIamStore((s) => s.deleteServiceAccount);
  const resources = useGcpConsoleStore((s) => s.resources);

  const [confirmingDelete, setConfirmingDelete] = React.useState(false);
  const [grantKey, setGrantKey] = React.useState(0);

  React.useEffect(() => {
    setConfirmingDelete(false);
  }, [serviceAccount?.id]);

  if (!serviceAccount) return null;

  const grantedRoles = serviceAccount.roleIds.map((id) => getIamRole(id)).filter((r): r is IamRole => Boolean(r));
  const grantableRoles = IAM_ROLES.filter((r) => !serviceAccount.roleIds.includes(r.id));
  const usedByResources = resources.filter((r) => r.config.serviceAccountId === serviceAccount.id);

  function handleDeleteClick() {
    if (!confirmingDelete) {
      setConfirmingDelete(true);
      return;
    }
    if (serviceAccount) deleteServiceAccount(serviceAccount.id);
    onOpenChange(false);
  }

  return (
    <Sheet open={Boolean(serviceAccount)} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="flex w-full flex-col gap-0 overflow-y-auto sm:max-w-lg">
        <SheetHeader className="border-b border-border pb-4">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Bot className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <SheetTitle className="truncate">{serviceAccount.displayName}</SheetTitle>
              <SheetDescription className="truncate font-mono text-xs">{serviceAccount.email}</SheetDescription>
            </div>
            <Badge variant={serviceAccount.disabled ? "secondary" : "success"} className="shrink-0">
              {serviceAccount.disabled ? "Disabled" : "Enabled"}
            </Badge>
          </div>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-5 p-4">
            {serviceAccount.description && (
              <p className="text-sm text-muted-foreground">{serviceAccount.description}</p>
            )}

            <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2.5">
              <div>
                <p className="text-sm font-medium">Account status</p>
                <p className="text-xs text-muted-foreground">
                  Disabling keeps IAM bindings but stops new access tokens from being issued.
                </p>
              </div>
              <Switch
                checked={!serviceAccount.disabled}
                onCheckedChange={() => toggleDisabled(serviceAccount.id)}
              />
            </div>

            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                Current roles ({grantedRoles.length})
              </p>
              {grantedRoles.length === 0 ? (
                <p className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
                  No roles granted yet — this identity can authenticate but can&apos;t call any APIs.
                </p>
              ) : (
                <ul className="space-y-2">
                  {grantedRoles.map((role) => (
                    <li
                      key={role.id}
                      className="flex items-start justify-between gap-2 rounded-lg border border-border p-2.5"
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-sm font-medium">{role.title}</span>
                          <RiskBadge level={role.riskLevel} />
                        </div>
                        <p className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground">{role.id}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="iconSm"
                        className="shrink-0 text-muted-foreground hover:text-danger"
                        onClick={() => revokeRole(serviceAccount.id, role.id)}
                        aria-label={`Revoke ${role.title}`}
                      >
                        <X className="h-3.5 w-3.5" />
                      </Button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-1.5">
              <Label>Grant another role</Label>
              {grantableRoles.length === 0 ? (
                <p className="text-xs text-muted-foreground">Every catalog role is already granted.</p>
              ) : (
                <Select
                  key={grantKey}
                  onValueChange={(roleId) => {
                    grantRole(serviceAccount.id, roleId);
                    setGrantKey((k) => k + 1);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a role to grant..." />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORY_ORDER.map((category) => {
                      const roles = grantableRoles.filter((r) => r.category === category);
                      if (roles.length === 0) return null;
                      return (
                        <SelectGroup key={category}>
                          <SelectLabel>{CATEGORY_LABEL[category]}</SelectLabel>
                          {roles.map((role) => (
                            <SelectItem key={role.id} value={role.id}>
                              {role.title} — {RISK_LABEL[role.riskLevel]}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      );
                    })}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                Resources using this identity ({usedByResources.length})
              </p>
              {usedByResources.length === 0 ? (
                <p className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
                  No resources are currently attached to this service account.
                </p>
              ) : (
                <ul className="space-y-1.5">
                  {usedByResources.map((r) => (
                    <li
                      key={r.id}
                      className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm"
                    >
                      <span className="truncate">{r.name}</span>
                      <Badge variant="outline" className="shrink-0 text-[10px]">
                        {r.type}
                      </Badge>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="border-t border-border pt-4">
              <Button
                variant={confirmingDelete ? "destructive" : "outline"}
                className="w-full gap-1.5"
                onClick={handleDeleteClick}
              >
                <Trash2 className="h-3.5 w-3.5" />
                {confirmingDelete ? "Click again to confirm delete" : "Delete service account"}
              </Button>
              {confirmingDelete && (
                <button
                  type="button"
                  className="mt-1.5 w-full text-center text-xs text-muted-foreground hover:underline"
                  onClick={() => setConfirmingDelete(false)}
                >
                  Cancel
                </button>
              )}
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

// ───────────────────────── Service Accounts list ─────────────────────────

function ServiceAccountRow({ sa, onSelect }: { sa: ServiceAccount; onSelect: () => void }) {
  const resources = useGcpConsoleStore((s) => s.resources);
  const roles = sa.roleIds.map((id) => getIamRole(id)).filter((r): r is IamRole => Boolean(r));
  const usedByCount = resources.filter((r) => r.config.serviceAccountId === sa.id).length;

  return (
    <button
      type="button"
      onClick={onSelect}
      className="flex w-full flex-col gap-2 rounded-lg border border-border p-3 text-left transition-colors hover:bg-accent sm:flex-row sm:items-center sm:justify-between"
    >
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
            <Bot className="h-3.5 w-3.5" />
          </span>
          <span className="text-sm font-medium">{sa.displayName}</span>
          <Badge variant={sa.disabled ? "secondary" : "success"} className="text-[10px]">
            {sa.disabled ? "Disabled" : "Enabled"}
          </Badge>
        </div>
        <p className="mt-1 truncate pl-9 font-mono text-xs text-muted-foreground">{sa.email}</p>
        <div className="mt-1.5 flex flex-wrap gap-1.5 pl-9">
          {roles.length === 0 ? (
            <span className="text-xs text-muted-foreground">No roles granted</span>
          ) : (
            roles.map((role) => (
              <Badge key={role.id} variant={RISK_VARIANT[role.riskLevel]} className="text-[10px]">
                {role.title}
              </Badge>
            ))
          )}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1.5 pl-9 text-xs text-muted-foreground sm:pl-0">
        <Users className="h-3.5 w-3.5" />
        {usedByCount} {usedByCount === 1 ? "resource" : "resources"}
      </div>
    </button>
  );
}

function ServiceAccountsSection() {
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const [selectedId, setSelectedId] = React.useState<string | null>(null);
  const selected = serviceAccounts.find((sa) => sa.id === selectedId) ?? null;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3 space-y-0">
        <div>
          <CardTitle>Service Accounts</CardTitle>
          <CardDescription>Identities your workloads authenticate as — never as a person.</CardDescription>
        </div>
        <CreateServiceAccountDialog />
      </CardHeader>
      <CardContent>
        {serviceAccounts.length === 0 ? (
          <p className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
            No service accounts yet. Create one to give a workload its own least-privilege identity.
          </p>
        ) : (
          <div className="space-y-2">
            {serviceAccounts.map((sa) => (
              <ServiceAccountRow key={sa.id} sa={sa} onSelect={() => setSelectedId(sa.id)} />
            ))}
          </div>
        )}
      </CardContent>

      <ServiceAccountDetail serviceAccount={selected} onOpenChange={(open) => !open && setSelectedId(null)} />
    </Card>
  );
}

// ───────────────────────── Role catalog reference ─────────────────────────

function RoleCatalogSection() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <KeyRound className="h-4 w-4" /> Role Catalog
        </CardTitle>
        <CardDescription>
          Every predefined role available in this app, grouped by category — a read-only reference for studying real
          GCP IAM roles.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" className="w-full">
          {CATEGORY_ORDER.map((category) => {
            const roles = IAM_ROLES.filter((r) => r.category === category);
            if (roles.length === 0) return null;
            return (
              <AccordionItem key={category} value={category}>
                <AccordionTrigger>
                  <span className="flex items-center gap-2">
                    {CATEGORY_LABEL[category]}
                    <Badge variant="secondary" className="text-[10px]">
                      {roles.length}
                    </Badge>
                  </span>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3">
                    {roles.map((role) => (
                      <div key={role.id} className="rounded-lg border border-border p-3">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-medium text-foreground">{role.title}</span>
                          <RiskBadge level={role.riskLevel} />
                        </div>
                        <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">{role.id}</p>
                        <p className="mt-1.5 text-xs text-muted-foreground">{role.description}</p>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </CardContent>
    </Card>
  );
}

// ───────────────────────── Top-level tab ─────────────────────────

export function IamTab() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <ShieldCheck className="h-5 w-5" />
        </span>
        <div>
          <h2 className="text-lg font-semibold leading-tight">IAM &amp; Admin</h2>
          <p className="text-sm text-muted-foreground">
            Every resource in real GCP is tied to an identity through IAM. Create service accounts, grant them
            narrowly-scoped roles, and see exactly which resources depend on which identity — the same model that
            governs access in a real Google Cloud project.
          </p>
        </div>
      </div>

      <ConceptsRow />
      <ServiceAccountsSection />
      <RoleCatalogSection />
    </div>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Plus, Play, Square, Trash2, Eye, Boxes, DollarSign, Clock, Waypoints } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { useGcpConsoleStore, ConsoleResource } from "@/store/gcp-console-store";
import { useIamStore } from "@/store/iam-store";
import { ResourceRuntimeStatus } from "@/lib/console-sim/types";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";
import { cn, formatCurrency } from "@/lib/utils";
import { CreateWizard } from "@/components/gcp-console/create-wizard";
import { ResourceDetail } from "@/components/gcp-console/resource-detail";
import { ArchitectureDiagram } from "@/components/gcp-console/architecture-diagram";
import { toast } from "sonner";

export const CONSOLE_RESOURCE_TYPES = [
  // networking
  "vpc",
  "subnet",
  "lb",
  "router",
  "nat",
  "dns",
  "vpn",
  "interconnect",
  // compute
  "vm",
  "mig",
  // storage
  "gcs",
  // database
  "cloudsql",
  "redis",
  // containers
  "gke",
  // cicd
  "artifact_registry",
  "cloud_build",
  // security
  "armor",
  // messaging
  "pubsub",
] as const;
export type ConsoleResourceType = (typeof CONSOLE_RESOURCE_TYPES)[number];

// Same category ordering used by the Catalog tab, for visual consistency.
const CATEGORY_ORDER: ResourceCategory[] = [
  "networking",
  "compute",
  "storage",
  "database",
  "containers",
  "cicd",
  "security",
  "messaging",
];

// Group the nav's resource types by category once — CONSOLE_RESOURCE_TYPES is static.
const NAV_GROUPS: { category: ResourceCategory; types: ConsoleResourceType[] }[] = (() => {
  const map = new Map<ResourceCategory, ConsoleResourceType[]>();
  for (const type of CONSOLE_RESOURCE_TYPES) {
    const typeDef = getResourceDef(type);
    if (!typeDef) continue;
    const list = map.get(typeDef.category) ?? [];
    list.push(type);
    map.set(typeDef.category, list);
  }
  return CATEGORY_ORDER.filter((cat) => map.has(cat)).map((category) => ({
    category,
    types: map.get(category)!,
  }));
})();

// Literal Tailwind class lookup — never construct classes dynamically.
export const STATUS_BADGE_CLASS: Record<ResourceRuntimeStatus, string> = {
  provisioning: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  starting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  stopping: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  deleting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  running: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  stopped: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  error: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
};

export const STATUS_LABEL: Record<ResourceRuntimeStatus, string> = {
  provisioning: "Provisioning",
  starting: "Starting",
  stopping: "Stopping",
  deleting: "Deleting",
  running: "Running",
  stopped: "Stopped",
  error: "Error",
};

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export function ConsoleTab() {
  const resources = useGcpConsoleStore((s) => s.resources);
  const startResource = useGcpConsoleStore((s) => s.startResource);
  const stopResource = useGcpConsoleStore((s) => s.stopResource);
  const deleteResource = useGcpConsoleStore((s) => s.deleteResource);
  const resumeStuckStates = useGcpConsoleStore((s) => s.resumeStuckStates);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);

  const [selectedType, setSelectedType] = React.useState<ConsoleResourceType>("vm");
  const [wizardOpen, setWizardOpen] = React.useState(false);
  const [detailId, setDetailId] = React.useState<string | null>(null);
  const [diagramOpen, setDiagramOpen] = React.useState(false);

  React.useEffect(() => {
    resumeStuckStates();
    // Only run once on mount — a real setTimeout chain is lost on reload/navigation,
    // so any resource left in a transient state needs to be resolved immediately.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const def = getResourceDef(selectedType);
  const typeResources = React.useMemo(
    () => resources.filter((r) => r.type === selectedType),
    [resources, selectedType],
  );
  const detailResource = resources.find((r) => r.id === detailId) ?? null;

  const totalMonthlyCost = React.useMemo(() => {
    if (!def) return 0;
    return typeResources.reduce((sum, r) => sum + def.estimateMonthlyCost(r.config), 0);
  }, [def, typeResources]);

  if (!def) return null;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-end">
        <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setDiagramOpen(true)}>
          <Waypoints className="h-4 w-4" /> View Architecture Diagram
        </Button>
      </div>

      <div className="flex flex-col gap-6 lg:flex-row">
      <motion.nav
        initial="hidden"
        animate="show"
        custom={0}
        variants={fadeUp}
        className="flex max-h-[70vh] shrink-0 flex-col gap-4 overflow-y-auto pr-1 lg:w-64"
      >
        {NAV_GROUPS.map(({ category, types }) => (
          <div key={category}>
            <p className="mb-1.5 px-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              {CATEGORY_META[category].label}
            </p>
            <div className="flex flex-col gap-1.5">
              {types.map((type) => {
                const typeDef = getResourceDef(type);
                if (!typeDef) return null;
                const count = resources.filter((r) => r.type === type).length;
                const isActive = type === selectedType;
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setSelectedType(type)}
                    className={cn(
                      "flex shrink-0 items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left text-sm transition-colors",
                      isActive
                        ? "border-primary/40 bg-primary/10 text-foreground"
                        : "border-border bg-card/40 text-muted-foreground hover:bg-accent hover:text-foreground",
                    )}
                  >
                    <ResourceIcon type={typeDef.type} color={typeDef.color} size={16} className="h-8 w-8 shrink-0" />
                    <span className="min-w-0 flex-1 truncate font-medium">{typeDef.shortLabel}</span>
                    <Badge variant={isActive ? "default" : "secondary"} className="shrink-0 text-[10px]">
                      {count}
                    </Badge>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </motion.nav>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp} className="min-w-0 flex-1">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <ResourceIcon type={def.type} color={def.color} size={20} className="h-11 w-11" />
            <div>
              <h2 className="text-lg font-semibold leading-tight">{def.label}</h2>
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <DollarSign className="h-3 w-3" /> {formatCurrency(totalMonthlyCost)}/mo across {typeResources.length}{" "}
                resource{typeResources.length === 1 ? "" : "s"}
              </p>
            </div>
          </div>
          <Button onClick={() => setWizardOpen(true)} className="gap-1.5 sm:self-start">
            <Plus className="h-4 w-4" /> Create {def.shortLabel}
          </Button>
        </div>

        {typeResources.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
              <Boxes className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm font-medium">No {def.label} resources yet</p>
              <p className="max-w-sm text-xs text-muted-foreground">
                Click &ldquo;Create {def.shortLabel}&rdquo; to spin up a fully simulated instance — configure it, watch
                it provision, and practice troubleshooting it, with zero real GCP calls or billing.
              </p>
              <Button size="sm" onClick={() => setWizardOpen(true)} className="mt-2 gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Create {def.shortLabel}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {typeResources.map((resource) => (
              <ResourceRow
                key={resource.id}
                resource={resource}
                onView={() => setDetailId(resource.id)}
                onStart={() => startResource(resource.id)}
                onStop={() => stopResource(resource.id)}
                onDelete={() => {
                  deleteResource(resource.id);
                  toast.info(`Deleting ${resource.name}...`);
                }}
              />
            ))}
          </div>
        )}
      </motion.div>
      </div>

      <CreateWizard type={selectedType} open={wizardOpen} onOpenChange={setWizardOpen} />
      <ResourceDetail
        resource={detailResource}
        open={detailResource !== null}
        onOpenChange={(open) => {
          if (!open) setDetailId(null);
        }}
      />

      <Dialog open={diagramOpen} onOpenChange={setDiagramOpen}>
        <DialogContent className="max-h-[85vh] max-w-5xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Architecture Diagram</DialogTitle>
            <DialogDescription>
              Live view of everything currently provisioned in your Console, auto-laid-out by category with
              identity attachments shown as dashed lines.
            </DialogDescription>
          </DialogHeader>
          <ArchitectureDiagram
            resources={resources}
            serviceAccounts={serviceAccounts.map((sa) => ({ id: sa.id, name: sa.name, email: sa.email }))}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ResourceRow({
  resource,
  onView,
  onStart,
  onStop,
  onDelete,
}: {
  resource: ConsoleResource;
  onView: () => void;
  onStart: () => void;
  onStop: () => void;
  onDelete: () => void;
}) {
  const def = getResourceDef(resource.type);
  const isBusy =
    resource.status === "provisioning" ||
    resource.status === "starting" ||
    resource.status === "stopping" ||
    resource.status === "deleting";

  return (
    <Card className="transition-shadow hover:shadow-md">
      <CardContent className="flex flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{resource.name}</p>
            <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <Clock className="h-3 w-3" /> {new Date(resource.createdAt).toLocaleString()}
            </p>
          </div>
          <Badge className={cn("shrink-0 text-[10px]", STATUS_BADGE_CLASS[resource.status])}>
            {isBusy && <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-current" />}
            {STATUS_LABEL[resource.status]}
          </Badge>
        </div>

        {def && (
          <p className="text-xs text-muted-foreground">
            Est. {formatCurrency(def.estimateMonthlyCost(resource.config))}/mo
          </p>
        )}

        <div className="flex flex-wrap items-center gap-1.5">
          <Button size="sm" variant="outline" className="gap-1.5" onClick={onView}>
            <Eye className="h-3.5 w-3.5" /> View
          </Button>
          {resource.status === "stopped" && (
            <Button size="sm" variant="outline" className="gap-1.5" onClick={onStart}>
              <Play className="h-3.5 w-3.5" /> Start
            </Button>
          )}
          {resource.status === "running" && (
            <Button size="sm" variant="outline" className="gap-1.5" onClick={onStop}>
              <Square className="h-3.5 w-3.5" /> Stop
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            className="ml-auto gap-1.5 text-danger hover:bg-danger/10"
            disabled={resource.status === "deleting"}
            onClick={onDelete}
          >
            <Trash2 className="h-3.5 w-3.5" /> Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

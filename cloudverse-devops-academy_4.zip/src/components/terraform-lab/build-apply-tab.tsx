"use client";

import * as React from "react";
import { toast } from "sonner";
import { Boxes, Rocket, Flame, ListChecks, Waypoints, Info } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { CodeBlock } from "@/components/code-block";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ArchitectureDiagram } from "@/components/gcp-console/architecture-diagram";
import { ResourceDetail } from "@/components/gcp-console/resource-detail";
import { ResourcePicker } from "@/components/terraform-lab/build-apply/resource-picker";
import { BlockFormDialog } from "@/components/terraform-lab/build-apply/block-form-dialog";
import { PlannedBlockRow } from "@/components/terraform-lab/build-apply/planned-block-row";
import { useTerraformLabStore, PlannedBlock } from "@/store/terraform-lab-store";
import { useGcpConsoleStore } from "@/store/gcp-console-store";
import { useIamStore } from "@/store/iam-store";
import { useProgressStore } from "@/store/progress-store";
import { getResourceDef } from "@/lib/gcp";
import { ResourceConfig } from "@/types/gcp";
import { SimLogEntry, makeLog } from "@/lib/console-sim/types";
import {
  blockDisplayName,
  buildRefCandidates,
  computePlanSummary,
  generatePlanHcl,
  remapConfigForApply,
  resolveApplyOrder,
} from "@/lib/terraform-lab/build-apply";
import { cn } from "@/lib/utils";

// Literal Tailwind class lookup — never construct classes dynamically.
const BUSY_BADGE_CLASS = "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400";

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * "Build & Apply" — the live counterpart to the Terraform Lab's HCL sandbox.
 * Plans are built from a structured resource picker (never free-text HCL), so
 * Apply always succeeds: every planned block is a real, valid config for a
 * real resource type. Applying creates that resource for real in
 * useGcpConsoleStore — the same shared store the GCP Services Console,
 * Demo Architectures, and Troubleshooting Center all read from — so it's
 * fully troubleshootable and destroyable from there too.
 */
export function BuildApplyTab() {
  const blocks = useTerraformLabStore((s) => s.blocks);
  const addBlock = useTerraformLabStore((s) => s.addBlock);
  const updateBlockConfig = useTerraformLabStore((s) => s.updateBlockConfig);
  const removeBlock = useTerraformLabStore((s) => s.removeBlock);
  const markApplied = useTerraformLabStore((s) => s.markApplied);
  const markDestroyed = useTerraformLabStore((s) => s.markDestroyed);

  const consoleResources = useGcpConsoleStore((s) => s.resources);
  const createResource = useGcpConsoleStore((s) => s.createResource);
  const deleteResource = useGcpConsoleStore((s) => s.deleteResource);
  const serviceAccounts = useIamStore((s) => s.serviceAccounts);
  const addXp = useProgressStore((s) => s.addXp);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const [addingType, setAddingType] = React.useState<string | null>(null);
  const [editingBlock, setEditingBlock] = React.useState<PlannedBlock | null>(null);
  const [detailResourceId, setDetailResourceId] = React.useState<string | null>(null);
  const [diagramOpen, setDiagramOpen] = React.useState(false);
  const [busy, setBusy] = React.useState<"apply" | "destroy" | null>(null);
  const [progress, setProgress] = React.useState<{ index: number; total: number; label: string } | null>(null);
  const [logs, setLogs] = React.useState<SimLogEntry[]>([]);
  const xpAwardedRef = React.useRef(false);

  const refCandidates = React.useMemo(() => buildRefCandidates(blocks, consoleResources), [blocks, consoleResources]);
  const plan = React.useMemo(() => computePlanSummary(blocks), [blocks]);
  const hcl = React.useMemo(() => generatePlanHcl(blocks), [blocks]);

  const appliedResources = React.useMemo(() => {
    const ids = new Set(blocks.map((b) => b.appliedResourceId).filter((v): v is string => Boolean(v)));
    return consoleResources.filter((r) => ids.has(r.id));
  }, [blocks, consoleResources]);

  const detailResource = React.useMemo(
    () => (detailResourceId ? (consoleResources.find((r) => r.id === detailResourceId) ?? null) : null),
    [detailResourceId, consoleResources],
  );

  const appendLog = React.useCallback((level: SimLogEntry["level"], message: string) => {
    setLogs((prev) => [...prev, makeLog(level, message)]);
  }, []);

  const runApply = React.useCallback(
    async (targetId?: string) => {
      if (busy) return;
      const pendingAll = resolveApplyOrder(blocks).filter((b) => !b.appliedResourceId);
      let list = pendingAll;
      if (targetId) {
        const idx = pendingAll.findIndex((b) => b.id === targetId);
        if (idx < 0) return;
        list = pendingAll.slice(0, idx + 1);
      }
      if (list.length === 0) {
        toast.info("Nothing to apply — every planned block is already applied.");
        return;
      }

      setBusy("apply");
      appendLog("command", "terraform apply");
      appendLog("info", "Do you want to perform these actions?");
      appendLog("command", "  Enter a value: yes");

      // Seed with everything already applied, so a block referencing a
      // previously-applied dependency resolves immediately.
      const resolvedIds = new Map<string, string>();
      blocks.forEach((b) => {
        if (b.appliedResourceId) resolvedIds.set(b.id, b.appliedResourceId);
      });

      for (let i = 0; i < list.length; i++) {
        const block = list[i];
        const def = getResourceDef(block.type);
        if (!def) continue;
        const name = blockDisplayName(block);
        setProgress({ index: i + 1, total: list.length, label: def.label });
        appendLog("info", `${def.terraformResourceType}."${name}": Creating...`);

        const finalConfig = remapConfigForApply(block, resolvedIds);
        const resourceId = createResource(block.type, finalConfig);
        resolvedIds.set(block.id, resourceId);
        markApplied(block.id, resourceId);

        appendLog("success", `${def.terraformResourceType}."${name}": Creation complete [id=${resourceId}]`);
        if (i < list.length - 1) await sleep(450);
      }

      appendLog("success", `Apply complete! Resources: ${list.length} added, 0 changed, 0 destroyed.`);
      setProgress(null);
      setBusy(null);
      toast.success(
        `${list.length} resource${list.length === 1 ? "" : "s"} created — real, troubleshootable, and on the Architecture Diagram.`,
      );
      if (!xpAwardedRef.current) {
        xpAwardedRef.current = true;
        addXp(20);
        setModuleProgress("terraform-lab", 60);
      }
    },
    [addXp, appendLog, blocks, busy, createResource, markApplied, setModuleProgress],
  );

  const runDestroy = React.useCallback(
    async (targetId?: string) => {
      if (busy) return;
      const appliedOrdered = resolveApplyOrder(blocks)
        .filter((b) => b.appliedResourceId)
        .reverse();
      const list = targetId ? appliedOrdered.filter((b) => b.id === targetId) : appliedOrdered;
      if (list.length === 0) {
        toast.info("Nothing applied to destroy.");
        return;
      }

      setBusy("destroy");
      appendLog("command", "terraform destroy");
      appendLog("info", "Do you really want to destroy all resources?");
      appendLog("command", "  Enter a value: yes");

      for (let i = 0; i < list.length; i++) {
        const block = list[i];
        const def = getResourceDef(block.type);
        const name = blockDisplayName(block);
        setProgress({ index: i + 1, total: list.length, label: def?.label ?? block.type });
        appendLog("info", `${def?.terraformResourceType ?? block.type}."${name}": Destroying...`);

        deleteResource(block.appliedResourceId!);
        markDestroyed(block.id);

        appendLog("success", `${def?.terraformResourceType ?? block.type}."${name}": Destruction complete`);
        if (i < list.length - 1) await sleep(350);
      }

      appendLog("success", `Destroy complete! Resources: ${list.length} destroyed.`);
      setProgress(null);
      setBusy(null);
      toast.info(`${list.length} resource${list.length === 1 ? "" : "s"} removed from the Console.`);
    },
    [appendLog, blocks, busy, deleteResource, markDestroyed],
  );

  function handleAddSubmit(config: ResourceConfig) {
    if (!addingType) return;
    addBlock(addingType, config);
    toast.success("Added to plan — run Apply to create it for real.");
  }

  function handleEditSubmit(config: ResourceConfig) {
    if (!editingBlock) return;
    updateBlockConfig(editingBlock.id, config);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-2 rounded-xl border border-info/30 bg-info/5 p-3 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-info" />
        <p>
          This tab is the real thing: pick resource types from the actual GCP catalog, configure them with the same
          forms the Console&apos;s Create wizard uses, then Apply creates real resources in the shared GCP Services
          Console — troubleshoot, inspect logs, and view them on the Architecture Diagram exactly like anything else
          you create there. Destroy removes them again.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="outline" className="gap-1">
          <ListChecks className="h-3 w-3" /> {plan.toAdd} to add, {plan.applied} already applied
        </Badge>
        <Button size="sm" onClick={() => runApply()} disabled={busy !== null || plan.toAdd === 0} className="gap-1.5">
          <Rocket className="h-3.5 w-3.5" /> Apply plan
        </Button>
        <Button
          size="sm"
          variant="destructive"
          onClick={() => runDestroy()}
          disabled={busy !== null || plan.applied === 0}
          className="gap-1.5"
        >
          <Flame className="h-3.5 w-3.5" /> Destroy all
        </Button>
        {plan.applied > 0 && (
          <Button size="sm" variant="outline" onClick={() => setDiagramOpen(true)} className="gap-1.5">
            <Waypoints className="h-3.5 w-3.5" /> View diagram
          </Button>
        )}
        {busy && progress && (
          <Badge className={cn("gap-1", BUSY_BADGE_CLASS)}>
            {busy === "apply" ? "Applying" : "Destroying"} {progress.index}/{progress.total} — {progress.label}
          </Badge>
        )}
      </div>
      {busy && progress && <Progress value={(progress.index / progress.total) * 100} />}

      <div className="grid gap-5 lg:grid-cols-[260px_1fr_1fr]">
        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Resource catalog</CardTitle>
            <CardDescription className="text-xs">Pick a real GCP resource type to stage.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto pt-0">
            <ResourcePicker onPick={(type) => setAddingType(type)} />
          </CardContent>
        </Card>

        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-1.5 text-sm">
              <Boxes className="h-4 w-4" /> Planned blocks ({blocks.length})
            </CardTitle>
            <CardDescription className="text-xs">
              Bind a block to another via its config form&apos;s reference fields — same as the Console&apos;s wizard.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-1 flex-col gap-2 overflow-y-auto pt-0">
            {blocks.length === 0 ? (
              <p className="flex flex-1 items-center justify-center text-center text-sm text-muted-foreground">
                Nothing staged yet — add a resource from the catalog to start building a plan.
              </p>
            ) : (
              blocks.map((block) => (
                <PlannedBlockRow
                  key={block.id}
                  block={block}
                  busy={busy !== null}
                  onEdit={() => setEditingBlock(block)}
                  onRemove={() => removeBlock(block.id)}
                  onViewDetail={() => block.appliedResourceId && setDetailResourceId(block.appliedResourceId)}
                  onDestroy={() => runDestroy(block.id)}
                  onApply={() => runApply(block.id)}
                />
              ))
            )}
          </CardContent>
        </Card>

        <Card className="flex flex-col lg:h-[560px]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Generated Terraform</CardTitle>
            <CardDescription className="text-xs">
              {hcl.resourceCount} resource block{hcl.resourceCount === 1 ? "" : "s"} — real generateTerraform() output,
              concatenated.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden pt-0">
            <CodeBlock code={hcl.full} language="hcl" filename="build-and-apply.tf" maxHeight="480px" />
          </CardContent>
        </Card>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold">Apply / destroy log</p>
        <TerminalOutput
          lines={logs}
          heightClassName="h-56"
          emptyLabel='Nothing has run yet. Add resources from the catalog, then click "Apply plan".'
        />
      </div>

      <Dialog open={diagramOpen} onOpenChange={setDiagramOpen}>
        <DialogContent className="max-h-[85vh] max-w-5xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Terraform Lab — Architecture Diagram</DialogTitle>
            <DialogDescription>
              Only the resources this lab has actually applied, wired by the real bindings you chose.
            </DialogDescription>
          </DialogHeader>
          <ArchitectureDiagram
            resources={appliedResources}
            serviceAccounts={serviceAccounts.map((sa) => ({ id: sa.id, name: sa.name, email: sa.email }))}
          />
        </DialogContent>
      </Dialog>

      <BlockFormDialog
        type={addingType}
        open={addingType !== null}
        onOpenChange={(open) => !open && setAddingType(null)}
        resources={refCandidates}
        onSubmit={handleAddSubmit}
      />

      <BlockFormDialog
        type={editingBlock?.type ?? null}
        open={editingBlock !== null}
        onOpenChange={(open) => !open && setEditingBlock(null)}
        initialConfig={editingBlock?.config}
        resources={refCandidates.filter((r) => r.id !== editingBlock?.id)}
        onSubmit={handleEditSubmit}
      />

      <ResourceDetail
        resource={detailResource}
        open={detailResource !== null}
        onOpenChange={(open) => !open && setDetailResourceId(null)}
      />
    </div>
  );
}

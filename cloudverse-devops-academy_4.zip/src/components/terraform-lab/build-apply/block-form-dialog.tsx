"use client";

import * as React from "react";
import { Plus, Save } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ConfigForm, RefCandidate } from "@/components/architecture/config-form";
import { CodeBlock } from "@/components/code-block";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { ResourceConfig } from "@/types/gcp";
import { slugify } from "@/lib/utils";

/**
 * The one and only way a block's config is authored: pick real fields off the
 * same ConfigForm the Console's Create wizard uses (including resource-ref
 * bindings), never free-text HCL. Used both to add a new planned block and to
 * edit an existing (not-yet-applied) one.
 */
export function BlockFormDialog({
  type,
  open,
  onOpenChange,
  initialConfig,
  resources,
  onSubmit,
}: {
  type: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Present only when editing an existing block. */
  initialConfig?: ResourceConfig;
  resources: RefCandidate[];
  onSubmit: (config: ResourceConfig) => void;
}) {
  const def = type ? getResourceDef(type) : undefined;
  const [config, setConfig] = React.useState<ResourceConfig>(initialConfig ?? def?.defaultConfig ?? {});

  React.useEffect(() => {
    if (open && def) setConfig(initialConfig ?? def.defaultConfig);
    // Reset only when the dialog opens (or the target type changes while open).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, type]);

  if (!def) return null;

  const isEdit = Boolean(initialConfig);
  const name = String(config.name ?? def.label);
  const terraform = def.generateTerraform({
    config,
    nodeId: "preview",
    label: name,
    slug: slugify(name || def.type).replace(/-/g, "_"),
    allNodes: [],
    connections: [],
  });
  const canSubmit = Boolean(String(config.name ?? "").trim());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <ResourceIcon type={def.type} color={def.color} size={20} className="h-10 w-10" />
            <div>
              <DialogTitle>{isEdit ? `Edit ${def.label}` : `Add ${def.label} to plan`}</DialogTitle>
              <DialogDescription>
                {isEdit
                  ? "Update this block's configuration — it hasn't been applied, so nothing real changes until you Apply."
                  : "Configure the block. Nothing is created yet — it's staged as an unapplied plan block until you run Apply."}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ConfigForm
          fields={def.configFields}
          config={config}
          onChange={(patch) => setConfig((c) => ({ ...c, ...patch } as ResourceConfig))}
          resources={resources}
        />

        <div>
          <p className="mb-2 text-sm font-medium">Generated Terraform for this block</p>
          <CodeBlock code={terraform} language="hcl" filename={`${def.terraformResourceType}.tf`} maxHeight="220px" />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            disabled={!canSubmit}
            onClick={() => {
              onSubmit(config);
              onOpenChange(false);
            }}
            className="gap-1.5"
          >
            {isEdit ? (
              <>
                <Save className="h-4 w-4" /> Save changes
              </>
            ) : (
              <>
                <Plus className="h-4 w-4" /> Add to plan
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

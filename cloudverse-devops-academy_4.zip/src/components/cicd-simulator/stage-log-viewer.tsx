"use client";

import * as React from "react";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { LogPanel } from "@/components/cicd-simulator/log-panel";
import { STATUS_BADGE_VARIANT, STATUS_LABEL } from "@/components/cicd-simulator/pipeline-config";
import type { StageLogGroup } from "@/store/cicd-simulator-store";

type BadgeVariant = "secondary" | "info" | "success" | "danger";

/** "skipped" is not part of the pipeline's own StageStatus union — handled only here. */
const SKIPPED_BADGE_VARIANT: BadgeVariant = "secondary";
const SKIPPED_LABEL = "Not reached";

function groupBadge(status: StageLogGroup["status"]): { variant: BadgeVariant; label: string } {
  if (status === "skipped") {
    return { variant: SKIPPED_BADGE_VARIANT, label: SKIPPED_LABEL };
  }
  return { variant: STATUS_BADGE_VARIANT[status], label: STATUS_LABEL[status] };
}

export function StageLogViewer({ stageLogs }: { stageLogs: StageLogGroup[] }) {
  if (stageLogs.length === 0) {
    return (
      <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
        No stage logs recorded for this deployment.
      </p>
    );
  }

  return (
    <Accordion type="multiple" defaultValue={stageLogs.map((g) => g.stageId)} className="w-full">
      {stageLogs.map((group) => {
        const badge = groupBadge(group.status);
        return (
          <AccordionItem key={group.stageId} value={group.stageId}>
            <AccordionTrigger>
              <span className="flex items-center gap-2">
                <span className="text-sm font-medium">{group.label}</span>
                <Badge variant={badge.variant}>{badge.label}</Badge>
              </span>
            </AccordionTrigger>
            <AccordionContent>
              {group.lines.length > 0 ? (
                <LogPanel entries={group.lines} />
              ) : (
                <p className="px-1 text-sm text-muted-foreground">This stage did not run.</p>
              )}
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
}

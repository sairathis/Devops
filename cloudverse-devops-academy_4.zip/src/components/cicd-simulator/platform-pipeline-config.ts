import { TerminalSquare, ShieldCheck, ClipboardList, Layers, Trash2, HeartPulse } from "lucide-react";
import type { StageDef } from "./pipeline-config";

// Stage defs for the Platform (Terraform) pipeline's apply path. Shares the exact StageDef shape
// (and therefore the exact per-stage random-failure / retry-from-failed-stage UX) used by the
// App Deployment pipeline's PIPELINE_STAGES.
export const APPLY_STAGES: StageDef[] = [
  {
    id: "init",
    label: "Init",
    icon: TerminalSquare,
    minMs: 500,
    maxMs: 800,
    failChance: 0.03,
    runningLog: [
      "Initializing the backend...",
      "Initializing provider plugins for hashicorp/google...",
    ],
    successLog: "Terraform has been successfully initialized!",
    failureLogPool: [
      "FAIL: Error: Failed to install provider — could not connect to registry.terraform.io",
      "FAIL: Error: Failed to get existing workspaces — state backend is locked",
    ],
  },
  {
    id: "validate",
    label: "Validate",
    icon: ShieldCheck,
    minMs: 400,
    maxMs: 700,
    failChance: 0.03,
    runningLog: ["Validating configuration syntax and resource-ref bindings..."],
    successLog: "Success! The configuration is valid.",
    failureLogPool: [
      "FAIL: Error: Reference to undeclared resource — a resource-ref points at a removed block",
      "FAIL: Error: Missing required argument — a required field was left empty",
    ],
  },
  {
    id: "plan",
    label: "Plan",
    icon: ClipboardList,
    minMs: 600,
    maxMs: 900,
    failChance: 0.03,
    runningLog: ["Refreshing Terraform state...", "Building the execution plan..."],
    successLog: "Plan generated.",
    failureLogPool: ["FAIL: Error: could not refresh state — a resource tracked in state no longer exists"],
  },
  {
    id: "apply",
    label: "Apply",
    icon: Layers,
    minMs: 600,
    maxMs: 900,
    failChance: 0.1,
    runningLog: ["Applying the execution plan..."],
    successLog: "Apply complete!",
    failureLogPool: [
      "FAIL: Error: Quota 'CPUS' exceeded — limit 24.0 in region us-central1",
      "FAIL: Error: googleapi: Error 403 — insufficient permission to create resource",
      "FAIL: Error: googleapi: Error 409 — a resource with this name already exists",
    ],
  },
  {
    id: "verify",
    label: "Verify",
    icon: HeartPulse,
    minMs: 500,
    maxMs: 800,
    failChance: 0.06,
    runningLog: ["Polling resource status..."],
    successLog: "Verify complete.",
    failureLogPool: ["FAIL: Verify timed out waiting for resources to report a healthy status"],
  },
];

// Stage defs for the destroy path — Init + Verify are shared in spirit but kept as separate
// objects (own ids/logs) since they run against different targets and outcomes.
export const DESTROY_STAGES: StageDef[] = [
  {
    id: "init",
    label: "Init",
    icon: TerminalSquare,
    minMs: 500,
    maxMs: 800,
    failChance: 0.03,
    runningLog: ["Initializing the backend...", "Initializing provider plugins for hashicorp/google..."],
    successLog: "Terraform has been successfully initialized!",
    failureLogPool: ["FAIL: Error: Failed to get existing workspaces — state backend is locked"],
  },
  {
    id: "plan",
    label: "Plan (destroy)",
    icon: ClipboardList,
    minMs: 600,
    maxMs: 900,
    failChance: 0.03,
    runningLog: ["Refreshing Terraform state...", "Building the destroy plan..."],
    successLog: "Destroy plan generated.",
    failureLogPool: ["FAIL: Error: could not refresh state — a resource tracked in state no longer exists"],
  },
  {
    id: "destroy",
    label: "Destroy",
    icon: Trash2,
    minMs: 600,
    maxMs: 900,
    failChance: 0.08,
    runningLog: ["Destroying resources..."],
    successLog: "Destroy complete!",
    failureLogPool: [
      "FAIL: Error: instance cannot be deleted because it is currently in use by another resource",
      "FAIL: Error: googleapi: Error 403 — insufficient permission to delete resource",
    ],
  },
  {
    id: "verify",
    label: "Verify",
    icon: HeartPulse,
    minMs: 500,
    maxMs: 800,
    failChance: 0.06,
    runningLog: ["Confirming resources were removed..."],
    successLog: "Verify complete.",
    failureLogPool: ["FAIL: Verify timed out waiting for resources to be removed"],
  },
];

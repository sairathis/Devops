"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { Ship, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DeploymentForm } from "@/components/kubernetes-lab/deployment-form";
import { NetworkForm } from "@/components/kubernetes-lab/network-form";
import { ManifestViewer } from "@/components/kubernetes-lab/manifest-viewer";
import { Topology } from "@/components/kubernetes-lab/topology";
import { ApplySimulator } from "@/components/kubernetes-lab/apply-simulator";
import { PodList } from "@/components/kubernetes-lab/pod-list";
import { Cheatsheet } from "@/components/kubernetes-lab/cheatsheet";
import { Concepts } from "@/components/kubernetes-lab/concepts";
import { generateDeploymentYaml, generateServiceYaml, generateIngressYaml } from "@/components/kubernetes-lab/yaml";
import { DEFAULT_DEPLOYMENT, DEFAULT_SERVICE, DEFAULT_INGRESS } from "@/components/kubernetes-lab/types";
import type { DeploymentConfig, ServiceConfig, IngressConfig } from "@/components/kubernetes-lab/types";
import { useProgressStore } from "@/store/progress-store";
import { useKubernetesLabStore } from "@/store/kubernetes-lab-store";
import { useCicdSimulatorStore } from "@/store/cicd-simulator-store";

export default function KubernetesLabPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);
  const setDeploySource = useCicdSimulatorStore((s) => s.setDeploySource);
  const router = useRouter();

  const [deployment, setDeployment] = React.useState<DeploymentConfig>(DEFAULT_DEPLOYMENT);
  const [service, setService] = React.useState<ServiceConfig>(DEFAULT_SERVICE);
  const [ingress, setIngress] = React.useState<IngressConfig>(DEFAULT_INGRESS);
  const hasAwardedReplicaXp = React.useRef(false);

  React.useEffect(() => {
    setModuleProgress("kubernetes-lab", 20);
  }, [setModuleProgress]);

  React.useEffect(() => {
    useKubernetesLabStore.getState().resumeStuckStates();
  }, []);

  const handleReplicasChange = React.useCallback(
    (replicas: number) => {
      setDeployment((prev) => (prev.replicas === replicas ? prev : { ...prev, replicas }));
      if (!hasAwardedReplicaXp.current) {
        hasAwardedReplicaXp.current = true;
        addXp(10);
      }
    },
    [addXp],
  );

  const deploymentYaml = React.useMemo(() => generateDeploymentYaml(deployment), [deployment]);
  const serviceYaml = React.useMemo(
    () => generateServiceYaml(deployment.name, service),
    [deployment.name, service],
  );
  const ingressYaml = React.useMemo(
    () => (ingress.enabled ? generateIngressYaml(deployment.name, service, ingress) : null),
    [deployment.name, service, ingress],
  );

  const handleDeployViaCicd = React.useCallback(() => {
    setDeploySource({
      kind: "kubernetes",
      summary: `Deployment ${deployment.name} (${deployment.replicas} replica${deployment.replicas === 1 ? "" : "s"})`,
    });
    router.push("/cicd-simulator");
  }, [deployment.name, deployment.replicas, setDeploySource, router]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-6 flex flex-wrap items-start justify-between gap-3"
      >
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <Ship className="h-6 w-6 text-gcp-blue" />
            Kubernetes Lab
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Configure Kubernetes workloads and see the manifests and topology come to life.
          </p>
        </div>
        <Button variant="outline" onClick={handleDeployViaCicd} className="shrink-0">
          <Rocket className="h-4 w-4" /> Deploy via CI/CD Pipeline
        </Button>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-5">
          <DeploymentForm value={deployment} onChange={setDeployment} onReplicasChange={handleReplicasChange} />
          <NetworkForm service={service} onServiceChange={setService} ingress={ingress} onIngressChange={setIngress} />
        </div>
        <div className="space-y-5">
          <Topology name={deployment.name} replicas={deployment.replicas} service={service} ingress={ingress} />
          <ManifestViewer deploymentYaml={deploymentYaml} serviceYaml={serviceYaml} ingressYaml={ingressYaml} />
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1fr]">
        <ApplySimulator
          deploymentName={deployment.name}
          replicas={deployment.replicas}
          ingressEnabled={ingress.enabled}
        />
        <PodList deploymentName={deployment.name} />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Cheatsheet />
        <Concepts />
      </div>
    </div>
  );
}

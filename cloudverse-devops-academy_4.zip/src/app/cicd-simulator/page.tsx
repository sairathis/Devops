"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { GitMerge, Boxes } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ConceptsSection } from "@/components/cicd-simulator/concepts-section";
import { AppDeploymentPanel } from "@/components/cicd-simulator/app-deployment-panel";
import { PlatformPipelinePanel } from "@/components/cicd-simulator/platform-pipeline-panel";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function CicdSimulatorPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  React.useEffect(() => {
    setModuleProgress("cicd-simulator", 20);
  }, [setModuleProgress]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <GitMerge className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">CI/CD Simulator</h1>
        </div>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Two pipelines, two jobs. <strong className="font-medium text-foreground">App Deployment</strong> ships
          application code through Commit → Build → Test → Push → Deploy → Smoke Test, optionally against a real
          resource from the GCP Console. <strong className="font-medium text-foreground">Platform (Terraform)</strong>{" "}
          provisions or tears down real infrastructure through Init → Validate → Plan → Apply/Destroy → Verify.
          Every run is simulated client-side, so it&apos;s safe to break things.
        </p>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp} className="mb-8">
        <Tabs defaultValue="app">
          <TabsList>
            <TabsTrigger value="app" className="gap-1.5">
              <GitMerge className="h-3.5 w-3.5" /> App Deployment
            </TabsTrigger>
            <TabsTrigger value="platform" className="gap-1.5">
              <Boxes className="h-3.5 w-3.5" /> Platform (Terraform)
            </TabsTrigger>
          </TabsList>

          <TabsContent value="app" className="pt-5">
            <AppDeploymentPanel />
          </TabsContent>

          <TabsContent value="platform" className="pt-5">
            <PlatformPipelinePanel />
          </TabsContent>
        </Tabs>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp}>
        <h2 className="mb-3 text-lg font-semibold tracking-tight">Concepts</h2>
        <ConceptsSection />
      </motion.div>
    </div>
  );
}

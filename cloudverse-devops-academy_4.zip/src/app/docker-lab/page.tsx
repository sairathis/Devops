"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { Rocket } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CodeBlock } from "@/components/code-block";
import { DockerfileForm } from "@/components/docker-lab/dockerfile-form";
import { BuildSimulator } from "@/components/docker-lab/build-simulator";
import { ImageLayers } from "@/components/docker-lab/image-layers";
import { DockerCheatsheet } from "@/components/docker-lab/cheatsheet";
import { RunSimulator } from "@/components/docker-lab/run-simulator";
import { ContainerList } from "@/components/docker-lab/container-list";
import { useDockerfileBuilder } from "@/components/docker-lab/use-dockerfile-builder";
import { buildDockerfileLines, generateDockerfile } from "@/components/docker-lab/dockerfile-config";
import { useProgressStore } from "@/store/progress-store";
import { useDockerLabStore } from "@/store/docker-lab-store";
import { useCicdSimulatorStore } from "@/store/cicd-simulator-store";

export default function DockerLabPage() {
  const builder = useDockerfileBuilder();
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);
  const setDeploySource = useCicdSimulatorStore((s) => s.setDeploySource);
  const router = useRouter();
  const [builtOnce, setBuiltOnce] = React.useState(false);

  React.useEffect(() => {
    setModuleProgress("docker-lab", 20);
  }, [setModuleProgress]);

  React.useEffect(() => {
    useDockerLabStore.getState().resumeStuckStates();
  }, []);

  const lines = React.useMemo(() => buildDockerfileLines(builder.config), [builder.config]);
  const dockerfile = React.useMemo(() => generateDockerfile(builder.config), [builder.config]);

  const handleFirstBuild = React.useCallback(() => {
    addXp(10);
  }, [addXp]);

  const handleBuildComplete = React.useCallback(() => {
    setBuiltOnce(true);
  }, []);

  const handleDeployViaCicd = React.useCallback(() => {
    const image = builder.config.baseImage.trim() || "node:20-slim";
    const port = builder.config.exposePort.trim();
    setDeploySource({
      kind: "docker",
      summary: `Docker image built from ${image}${port ? ` (exposes port ${port})` : ""}`,
    });
    router.push("/cicd-simulator");
  }, [builder.config.baseImage, builder.config.exposePort, setDeploySource, router]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Docker Lab</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Build and understand Dockerfiles and image layers hands-on &mdash; configure instructions, watch a
          simulated build, and see how layer caching actually works.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
        <DockerfileForm builder={builder} />

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle>Generated Dockerfile</CardTitle>
              <CardDescription>Regenerates live as you edit the configuration on the left.</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock language="dockerfile" filename="Dockerfile" code={dockerfile} />
            </CardContent>
          </Card>

          <BuildSimulator lines={lines} onFirstBuild={handleFirstBuild} onBuildComplete={handleBuildComplete} />
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <ImageLayers lines={lines} config={builder.config} />
        <DockerCheatsheet />
      </div>

      <div className="mt-8 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Run &amp; manage containers</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Once you&apos;ve simulated a build, run the resulting image as a container &mdash; watch it pull, boot, and
            show up below, then stop it, restart it, or trigger a realistic failure to practice troubleshooting.
          </p>
        </div>
        {builtOnce && (
          <Button variant="outline" onClick={handleDeployViaCicd} className="shrink-0">
            <Rocket className="h-4 w-4" /> Deploy via CI/CD Pipeline
          </Button>
        )}
      </div>

      <div className="mt-4 grid gap-5 lg:grid-cols-2">
        <RunSimulator enabled={builtOnce} exposePort={builder.config.exposePort} />
        <ContainerList />
      </div>
    </div>
  );
}

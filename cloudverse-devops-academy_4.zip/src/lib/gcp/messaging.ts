import { GcpResourceDef } from "@/types/gcp";

export const messagingResources: GcpResourceDef[] = [
  {
    type: "pubsub",
    label: "Pub/Sub",
    shortLabel: "Pub/Sub",
    category: "messaging",
    color: "gcp-yellow",
    description: "A fully managed, asynchronous messaging service for decoupling producers and consumers at global scale.",
    learningNotes:
      "Pub/Sub decouples services: producers publish to a topic without knowing who (or how many) subscribers exist. Push subscriptions deliver to an HTTP(S) endpoint (e.g. Cloud Run); pull subscriptions let a consumer fetch messages at its own pace. Set an appropriate acknowledgement deadline and dead-letter topic to handle poison messages gracefully.",
    tooltip: "Asynchronous, decoupled messaging between services.",
    docsUrl: "https://cloud.google.com/pubsub/docs/overview",
    terraformResourceType: "google_pubsub_topic",
    configFields: [
      { key: "name", label: "Topic Name", type: "text", required: true, placeholder: "order-events" },
      { key: "subscriptionType", label: "Subscription Type", type: "select", options: [{ label: "Pull", value: "pull" }, { label: "Push", value: "push" }] },
      { key: "ackDeadlineSeconds", label: "Ack Deadline (seconds)", type: "number", min: 10, max: 600 },
      { key: "messageRetentionDays", label: "Message Retention (days)", type: "number", min: 1, max: 31 },
      { key: "deadLetterEnabled", label: "Enable Dead-Letter Topic", type: "boolean" },
    ],
    defaultConfig: { name: "order-events", subscriptionType: "pull", ackDeadlineSeconds: 30, messageRetentionDays: 7, deadLetterEnabled: true },
    generateTerraform: ({ slug, config }) => `resource "google_pubsub_topic" "${slug}" {
  name                       = "${config.name}"
  message_retention_duration = "${Number(config.messageRetentionDays) * 86400}s"
}

resource "google_pubsub_subscription" "${slug}_sub" {
  name  = "${config.name}-sub"
  topic = google_pubsub_topic.${slug}.name

  ack_deadline_seconds = ${config.ackDeadlineSeconds}

  ${
    config.subscriptionType === "push"
      ? `push_config {
    push_endpoint = "https://example.com/pubsub/push"
  }`
      : ""
  }

  ${
    config.deadLetterEnabled
      ? `dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.${slug}_dlq.id
    max_delivery_attempts = 5
  }`
      : ""
  }
}
${config.deadLetterEnabled ? `\nresource "google_pubsub_topic" "${slug}_dlq" {\n  name = "${config.name}-dlq"\n}` : ""}`,
    estimateMonthlyCost: () => 4,
    troubleshooting: [
      { issue: "Messages redelivered repeatedly", cause: "Consumer doesn't ack within the deadline (too short for processing time)", fix: "Increase ackDeadlineSeconds or use ack extension (modifyAckDeadline) during long processing." },
      { issue: "Push subscription gets no traffic", cause: "Push endpoint unreachable or missing OIDC auth token verification", fix: "Verify the endpoint is publicly reachable and configure push auth with a service account." },
    ],
    quiz: [
      { question: "What is the purpose of a dead-letter topic in Pub/Sub?", options: ["To store all messages permanently", "To capture messages that repeatedly fail delivery", "To increase throughput", "To encrypt messages"], answerIndex: 1, explanation: "Dead-letter topics catch messages that exceed max delivery attempts, preventing infinite redelivery loops.", difficulty: "beginner" },
      {
        question: "What is the difference between a push and a pull subscription in Pub/Sub?",
        options: [
          "Push delivers messages to an HTTP(S) endpoint you control; pull requires the consumer to actively fetch messages at its own pace",
          "Pull subscriptions are always faster than push",
          "Push subscriptions don't support acknowledgement",
          "They are functionally identical, just named differently",
        ],
        answerIndex: 0,
        explanation: "Push inverts control — Pub/Sub calls your endpoint as messages arrive — while pull lets the consumer decide when and how many messages to retrieve, which suits workers that need to control their own concurrency.",
        difficulty: "beginner",
      },
      {
        question: "A consumer keeps receiving the same messages multiple times even though it did eventually process each one successfully. What's the most likely cause?",
        options: [
          "The dead-letter topic is misconfigured",
          "The consumer isn't acknowledging messages within the ack deadline, so Pub/Sub redelivers them before processing finishes",
          "The topic's message retention period is too short",
          "The subscription type is push instead of pull",
        ],
        answerIndex: 1,
        explanation: "If processing takes longer than the ack deadline, Pub/Sub assumes delivery failed and redelivers — the fix is to increase ackDeadlineSeconds or actively extend it (modifyAckDeadline) during long-running processing, not to change retention or subscription type.",
        difficulty: "intermediate",
      },
      {
        question: "A Pub/Sub push subscription is configured with a valid, publicly reachable HTTPS endpoint, but it never receives any requests. Besides basic network reachability, what commonly-missed setting causes this?",
        options: [
          "Message retention is set too low",
          "The push endpoint requires OIDC token authentication that Pub/Sub isn't configured to provide",
          "The topic doesn't support push subscriptions",
          "The ack deadline is set too high",
        ],
        answerIndex: 1,
        explanation: "Many endpoints (e.g. Cloud Run, authenticated services) require a valid OIDC identity token on incoming requests; if the push subscription isn't configured with a service account to generate that token, the endpoint silently rejects (or never sees) the calls.",
        difficulty: "intermediate",
      },
      {
        question: "By default, does Pub/Sub guarantee messages are delivered exactly once and strictly in order?",
        options: [
          "Yes, both are guaranteed by default",
          "No — default delivery is at-least-once and unordered; ordering requires enabling message ordering with ordering keys, and exactly-once delivery is a separate opt-in setting",
          "Ordering is guaranteed by default, but exactly-once is not",
          "Exactly-once is guaranteed by default, but ordering is not",
        ],
        answerIndex: 1,
        explanation: "Pub/Sub's baseline model favors availability and throughput: at-least-once delivery (so duplicates are possible) with no ordering guarantee across messages. Both stronger guarantees exist but must be explicitly enabled and come with tradeoffs (ordering keys limit parallelism per key; exactly-once adds latency).",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["vm", "mig", "gke", "cloud_build"],
  },
];

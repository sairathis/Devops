import { GcpResourceDef } from "@/types/gcp";

export const securityResources: GcpResourceDef[] = [
  {
    type: "armor",
    label: "Cloud Armor",
    shortLabel: "Armor",
    category: "security",
    color: "gcp-red",
    description: "A web application firewall (WAF) and DDoS protection service attached to your external load balancers.",
    learningNotes:
      "Cloud Armor evaluates security policies (ordered rules) before traffic reaches your backend service. It provides pre-configured WAF rules for OWASP Top 10 threats (SQLi, XSS), rate-limiting, geo-based access control, and always-on L3/L4 DDoS protection for internet-facing services fronted by an external HTTP(S) load balancer.",
    tooltip: "WAF + DDoS protection for your load balancer.",
    docsUrl: "https://cloud.google.com/armor/docs/cloud-armor-overview",
    terraformResourceType: "google_compute_security_policy",
    configFields: [
      { key: "name", label: "Policy Name", type: "text", required: true, placeholder: "cloud-armor-policy" },
      { key: "defaultAction", label: "Default Action", type: "select", options: [{ label: "Allow", value: "allow" }, { label: "Deny (403)", value: "deny(403)" }] },
      { key: "owaspRules", label: "Enable OWASP Top-10 Rules (SQLi/XSS)", type: "boolean" },
      { key: "rateLimitThreshold", label: "Rate Limit (req/min per IP)", type: "number", min: 10, max: 10000 },
      { key: "geoBlockList", label: "Blocked Country Codes", type: "tags", placeholder: "CN, RU" },
    ],
    defaultConfig: { name: "cloud-armor-policy", defaultAction: "allow", owaspRules: true, rateLimitThreshold: 300, geoBlockList: [] },
    generateTerraform: ({ slug, config }) => `resource "google_compute_security_policy" "${slug}" {
  name = "${config.name}"

  rule {
    action   = "${config.defaultAction}"
    priority = 2147483647
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    description = "default rule"
  }
${
  config.owaspRules
    ? `
  rule {
    action   = "deny(403)"
    priority = 1000
    match {
      expr { expression = "evaluatePreconfiguredExpr('sqli-v33-stable')" }
    }
    description = "Block SQL injection (OWASP)"
  }

  rule {
    action   = "deny(403)"
    priority = 1001
    match {
      expr { expression = "evaluatePreconfiguredExpr('xss-v33-stable')" }
    }
    description = "Block XSS (OWASP)"
  }`
    : ""
}

  rule {
    action   = "throttle"
    priority = 2000
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"
      rate_limit_threshold {
        count        = ${config.rateLimitThreshold}
        interval_sec = 60
      }
    }
    description = "Rate limiting"
  }
}`,
    estimateMonthlyCost: () => 5,
    troubleshooting: [
      { issue: "Legitimate traffic getting blocked (false positive)", cause: "OWASP preconfigured rule too aggressive for the app's payloads", fix: "Add an exclusion/sensitivity override for the specific rule ID, or move it to preview mode first." },
      { issue: "Rate limiting triggers too early", cause: "Threshold set too low for legitimate burst traffic", fix: "Raise rateLimitThreshold or use a longer interval to smooth bursts." },
    ],
    quiz: [
      { question: "What must Cloud Armor be attached to in order to filter traffic?", options: ["A VPC", "An external HTTP(S) load balancer backend service", "A Cloud NAT gateway", "A subnet"], answerIndex: 1, explanation: "Cloud Armor policies attach to backend services behind external load balancers.", difficulty: "beginner" },
      {
        question: "Cloud Armor's preconfigured OWASP Top-10 WAF rules are primarily designed to block which kind of attack?",
        options: [
          "Volumetric DDoS floods",
          "Application-layer attacks like SQL injection (SQLi) and cross-site scripting (XSS)",
          "DNS cache poisoning",
          "Physical network intrusion",
        ],
        answerIndex: 1,
        explanation: "The OWASP preconfigured rules inspect request content (parameters, headers, bodies) for known SQLi and XSS attack patterns. Basic L3/L4 DDoS protection is a separate, always-on capability of Cloud Armor, not what the OWASP rule set targets.",
        difficulty: "beginner",
      },
      {
        question: "After enabling the OWASP preconfigured rules, some legitimate customer requests start getting blocked with 403s. What's the most likely cause and fix?",
        options: [
          "The rate limit threshold is too low — raise it",
          "A preconfigured rule (e.g. the SQLi rule) is matching legitimate payloads too aggressively — add a targeted exclusion or test it in preview mode first",
          "The default action is set to deny — switch it to allow",
          "Geo-blocking is enabled for the customer's country",
        ],
        answerIndex: 1,
        explanation: "Preconfigured WAF rules pattern-match request content and can false-positive on legitimate input that resembles an attack signature (e.g. certain SQL-like text in a form field). The fix is a scoped exclusion or sensitivity tuning, not touching rate limits or the default action, which are unrelated controls.",
        difficulty: "intermediate",
      },
      {
        question: "A Cloud Armor policy sets rateLimitThreshold to 300 requests/min with a throttle rule. What happens to a client that exceeds this rate?",
        options: [
          "The client is permanently banned from the load balancer",
          "Once the threshold is exceeded within the interval, further requests are denied (HTTP 429) per the rule's conform/exceed actions",
          "The connection is dropped at the TCP level with no HTTP response",
          "The client's DNS resolution is blackholed",
        ],
        answerIndex: 1,
        explanation: "Rate-limit rules define a conform_action (e.g. allow) below the threshold and an exceed_action (e.g. deny(429)) once it's crossed within the interval — it's a temporary, per-window throttle, not a permanent ban.",
        difficulty: "intermediate",
      },
      {
        question: "Setting a Cloud Armor policy's defaultAction to deny(403) instead of allow changes its behavior significantly. What does this imply for policy design?",
        options: [
          "All traffic is now blocked with no further configuration needed",
          "You must now explicitly add higher-priority allow rules for any traffic you want permitted, since anything unmatched falls through to the deny default",
          "It automatically enables the OWASP preconfigured rules",
          "It disables rate limiting for all clients",
        ],
        answerIndex: 1,
        explanation: "The default rule is evaluated last (lowest priority) when nothing else matches, so switching it to deny flips the policy to a default-deny, allowlist-style model — every legitimate traffic pattern needs its own explicit allow rule with higher priority, or it gets rejected.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["lb"],
  },
];

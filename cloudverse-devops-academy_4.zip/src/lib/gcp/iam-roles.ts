// Real GCP IAM role catalog used to teach how identity + access control works
// across the simulated console. Role IDs, titles, and descriptions describe
// actual GCP IAM roles so this doubles as an accurate study reference.

export interface IamRole {
  id: string; // e.g. "roles/storage.objectViewer" — a real GCP role ID string
  title: string; // e.g. "Storage Object Viewer"
  description: string; // one sentence, plain-English, what it actually grants
  category:
    | "basic"
    | "compute"
    | "storage"
    | "networking"
    | "database"
    | "containers"
    | "cicd"
    | "security"
    | "messaging";
  riskLevel: "low" | "medium" | "high"; // for teaching least-privilege
}

export const IAM_ROLES: IamRole[] = [
  // ───────────────────────── Basic (primitive) roles ─────────────────────────
  {
    id: "roles/viewer",
    title: "Viewer",
    description:
      "Read-only access to view most Google Cloud resources and their configuration, but not their underlying data (e.g. object contents) and no ability to modify anything.",
    category: "basic",
    riskLevel: "low",
  },
  {
    id: "roles/editor",
    title: "Editor",
    description:
      "Broad read-write access to create, modify, and delete most Google Cloud resources across nearly every service in the project — a legacy primitive role that is far broader than almost any single workload actually needs.",
    category: "basic",
    riskLevel: "high",
  },
  {
    id: "roles/owner",
    title: "Owner",
    description:
      "Every Editor permission plus the ability to manage IAM policies and billing for the project — the single most powerful primitive role a project has.",
    category: "basic",
    riskLevel: "high",
  },
  {
    id: "roles/logging.viewer",
    title: "Logs Viewer",
    description:
      "View logs and log-based metrics in Cloud Logging, without the ability to modify log sinks, exclusions, or delete log entries.",
    category: "basic",
    riskLevel: "low",
  },
  {
    id: "roles/monitoring.viewer",
    title: "Monitoring Viewer",
    description:
      "Read-only access to Cloud Monitoring dashboards, metrics, uptime checks, and alerting policies.",
    category: "basic",
    riskLevel: "low",
  },

  // ───────────────────────── Compute ─────────────────────────
  {
    id: "roles/compute.admin",
    title: "Compute Admin",
    description:
      "Full control over all Compute Engine resources — creating, modifying, and deleting VMs, disks, images, networks, and firewall rules.",
    category: "compute",
    riskLevel: "high",
  },
  {
    id: "roles/compute.instanceAdmin.v1",
    title: "Compute Instance Admin (v1)",
    description:
      "Full control over Compute Engine instances and disks — create, start, stop, and delete them — but not networking resources like firewall rules or VPCs.",
    category: "compute",
    riskLevel: "medium",
  },

  // ───────────────────────── Storage ─────────────────────────
  {
    id: "roles/storage.admin",
    title: "Storage Admin",
    description:
      "Full control over Cloud Storage buckets and objects, including creating and deleting buckets and managing IAM policies directly on them.",
    category: "storage",
    riskLevel: "high",
  },
  {
    id: "roles/storage.objectViewer",
    title: "Storage Object Viewer",
    description:
      "Read-only access to view and download objects inside Cloud Storage buckets, without permission to list or change bucket-level configuration.",
    category: "storage",
    riskLevel: "low",
  },
  {
    id: "roles/storage.objectCreator",
    title: "Storage Object Creator",
    description:
      "Allows uploading new objects into a Cloud Storage bucket, but not reading, overwriting, or deleting objects that already exist.",
    category: "storage",
    riskLevel: "low",
  },

  // ───────────────────────── Database ─────────────────────────
  {
    id: "roles/cloudsql.admin",
    title: "Cloud SQL Admin",
    description:
      "Full control over Cloud SQL instances, including creating and deleting databases, managing users, and configuring backups and replicas.",
    category: "database",
    riskLevel: "high",
  },
  {
    id: "roles/cloudsql.client",
    title: "Cloud SQL Client",
    description:
      "Allows connecting to Cloud SQL instances — for example through the Cloud SQL Auth Proxy — without any permission to manage instance configuration.",
    category: "database",
    riskLevel: "low",
  },

  // ───────────────────────── Containers ─────────────────────────
  {
    id: "roles/container.admin",
    title: "Kubernetes Engine Admin",
    description:
      "Full control over GKE clusters and the Kubernetes API objects inside them, including creating, deleting, and reconfiguring clusters and node pools.",
    category: "containers",
    riskLevel: "high",
  },
  {
    id: "roles/container.developer",
    title: "Kubernetes Engine Developer",
    description:
      "Access to deploy and manage workloads — Deployments, Pods, Services — inside existing GKE clusters, without permission to create or delete the clusters themselves.",
    category: "containers",
    riskLevel: "medium",
  },

  // ───────────────────────── Security / Identity ─────────────────────────
  {
    id: "roles/iam.serviceAccountUser",
    title: "Service Account User",
    description:
      "Allows an identity to \"act as\" a service account by attaching it to a resource such as a VM or Cloud Run service — required for deploying any workload that runs as that service account.",
    category: "security",
    riskLevel: "medium",
  },
  {
    id: "roles/iam.serviceAccountTokenCreator",
    title: "Service Account Token Creator",
    description:
      "Allows an identity to impersonate a service account by minting short-lived OAuth access tokens or signed JWTs on its behalf, without ever needing that account's private key.",
    category: "security",
    riskLevel: "high",
  },
  {
    id: "roles/compute.securityAdmin",
    title: "Compute Security Admin",
    description:
      "Full control over Compute Engine security-related resources, specifically firewall rules and SSL certificates, without broader compute or networking permissions.",
    category: "security",
    riskLevel: "medium",
  },

  // ───────────────────────── Networking ─────────────────────────
  {
    id: "roles/compute.networkAdmin",
    title: "Compute Network Admin",
    description:
      "Full control over networking resources — VPCs, subnets, routes, VPN tunnels, and Cloud Router — but explicitly excludes firewall rules and SSL certificates.",
    category: "networking",
    riskLevel: "medium",
  },

  // ───────────────────────── CI/CD ─────────────────────────
  {
    id: "roles/artifactregistry.writer",
    title: "Artifact Registry Writer",
    description:
      "Allows pushing (uploading) container images and other build artifacts to an Artifact Registry repository, and reading artifacts already there.",
    category: "cicd",
    riskLevel: "medium",
  },
  {
    id: "roles/artifactregistry.reader",
    title: "Artifact Registry Reader",
    description:
      "Read-only access to pull or download artifacts, such as container images, from an Artifact Registry repository.",
    category: "cicd",
    riskLevel: "low",
  },
  {
    id: "roles/cloudbuild.builds.editor",
    title: "Cloud Build Editor",
    description:
      "Allows creating, viewing, and canceling Cloud Build builds, letting an identity trigger and manage CI/CD pipelines.",
    category: "cicd",
    riskLevel: "medium",
  },

  // ───────────────────────── Messaging ─────────────────────────
  {
    id: "roles/pubsub.publisher",
    title: "Pub/Sub Publisher",
    description:
      "Allows publishing messages to a Pub/Sub topic, without permission to read from subscriptions or manage topic configuration.",
    category: "messaging",
    riskLevel: "low",
  },
  {
    id: "roles/pubsub.subscriber",
    title: "Pub/Sub Subscriber",
    description:
      "Allows consuming messages from a Pub/Sub subscription — pulling and acknowledging them — without permission to publish or manage configuration.",
    category: "messaging",
    riskLevel: "low",
  },
];

export function rolesByCategory(category: IamRole["category"]): IamRole[] {
  return IAM_ROLES.filter((r) => r.category === category);
}

export function getIamRole(id: string): IamRole | undefined {
  return IAM_ROLES.find((r) => r.id === id);
}

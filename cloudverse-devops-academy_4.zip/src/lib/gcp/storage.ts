import { GcpResourceDef } from "@/types/gcp";

export const storageResources: GcpResourceDef[] = [
  {
    type: "gcs",
    label: "Cloud Storage",
    shortLabel: "GCS",
    category: "storage",
    color: "gcp-yellow",
    description: "Unified object storage for unstructured data — from serving static websites to storing backups and ML training data.",
    learningNotes:
      "Storage classes trade access frequency for price: Standard for hot data, Nearline (30-day minimum) for monthly access, Coldline (90-day) for quarterly, and Archive (365-day) for long-term retention. Lifecycle rules automate transitions between classes or deletion. Uniform bucket-level access (recommended) applies IAM consistently instead of mixing in legacy ACLs. Versioning protects against accidental overwrite/delete.",
    tooltip: "Object storage bucket for files, backups, and static assets.",
    docsUrl: "https://cloud.google.com/storage/docs/introduction",
    terraformResourceType: "google_storage_bucket",
    configFields: [
      { key: "name", label: "Bucket Name (globally unique)", type: "text", required: true, placeholder: "my-app-assets-prod" },
      { key: "location", label: "Location", type: "select", options: [{ label: "US (multi-region)", value: "US" }, { label: "EU (multi-region)", value: "EU" }, { label: "us-central1", value: "us-central1" }, { label: "asia-south1", value: "asia-south1" }] },
      { key: "storageClass", label: "Storage Class", type: "select", options: [{ label: "Standard", value: "STANDARD" }, { label: "Nearline", value: "NEARLINE" }, { label: "Coldline", value: "COLDLINE" }, { label: "Archive", value: "ARCHIVE" }] },
      { key: "access", label: "Access", type: "select", options: [{ label: "Private", value: "private" }, { label: "Public Read", value: "public" }] },
      { key: "versioning", label: "Enable Versioning", type: "boolean" },
      { key: "lifecycleDays", label: "Delete Objects After (days, 0 = never)", type: "number", min: 0, max: 3650 },
      { key: "uniformAccess", label: "Uniform Bucket-Level Access", type: "boolean" },
    ],
    defaultConfig: { name: "my-app-assets-prod", location: "US", storageClass: "STANDARD", access: "private", versioning: true, lifecycleDays: 365, uniformAccess: true },
    generateTerraform: ({ slug, config }) => `resource "google_storage_bucket" "${slug}" {
  name                        = "${config.name}"
  location                    = "${config.location}"
  storage_class               = "${config.storageClass}"
  uniform_bucket_level_access = ${config.uniformAccess}

  versioning {
    enabled = ${config.versioning}
  }

  ${
    Number(config.lifecycleDays) > 0
      ? `lifecycle_rule {
    condition { age = ${config.lifecycleDays} }
    action    { type = "Delete" }
  }`
      : ""
  }
}
${
  config.access === "public"
    ? `
resource "google_storage_bucket_iam_member" "${slug}_public" {
  bucket = google_storage_bucket.${slug}.name
  role   = "roles/storage.objectViewer"
  member = "allUsers"
}`
    : ""
}`,
    estimateMonthlyCost: () => 2.3,
    troubleshooting: [
      { issue: "403 Forbidden when downloading a public asset", cause: "Bucket/object still private, or org policy blocks public access", fix: "Grant roles/storage.objectViewer to allUsers, and check the domain-restricted-sharing org policy." },
      { issue: "Old data won't delete automatically", cause: "No lifecycle rule configured", fix: "Add a lifecycle rule with an age condition and a Delete or SetStorageClass action." },
    ],
    quiz: [
      { question: "Which storage class is cheapest for data accessed roughly once a year?", options: ["Standard", "Nearline", "Coldline", "Archive"], answerIndex: 3, explanation: "Archive class is optimized for data touched less than once a year, with the lowest storage price and a 365-day minimum.", difficulty: "beginner" },
      {
        question: "What is the minimum storage duration for Nearline storage before early-deletion / early-access fees start applying?",
        options: ["7 days", "30 days", "90 days", "365 days"],
        answerIndex: 1,
        explanation: "Nearline is priced for data accessed roughly once a month, and carries a 30-day minimum storage duration — deleting or moving an object sooner incurs a pro-rated early-deletion charge. Coldline's minimum is 90 days and Archive's is 365 days.",
        difficulty: "beginner",
      },
      {
        question: "A user gets a 403 Forbidden error trying to download an object from a bucket that's supposed to be public. What's the most likely cause?",
        options: [
          "The bucket's storage class is set to Standard",
          "The object/bucket IAM doesn't actually grant allUsers read access, or an org policy blocks public access",
          "Versioning is disabled",
          "The bucket's location is multi-region instead of regional",
        ],
        answerIndex: 1,
        explanation: "Serving a public object requires an explicit IAM grant (e.g. roles/storage.objectViewer to allUsers) — without it, GCS defaults to private. A domain-restricted-sharing org policy can also block public grants even if you configure them, which is worth checking too.",
        difficulty: "intermediate",
      },
      {
        question: "What does enabling 'Uniform bucket-level access' change about how permissions are managed on a bucket?",
        options: [
          "It disables IAM entirely in favor of ACLs",
          "It applies IAM permissions consistently at the bucket level and disables legacy per-object ACLs, simplifying access management",
          "It automatically makes every object in the bucket public",
          "It enables object versioning automatically",
        ],
        answerIndex: 1,
        explanation: "Uniform access removes the possibility of individual objects having their own, inconsistent ACLs layered on top of bucket IAM — everything is governed by one consistent IAM policy, which is why Google recommends it for predictable, auditable access control.",
        difficulty: "intermediate",
      },
      {
        question: "A bucket has versioning enabled and a lifecycle rule that deletes objects after 365 days, with no additional conditions like isLive or numNewerVersions specified. What happens to older (noncurrent) versions of a frequently-overwritten object?",
        options: [
          "They are always kept forever regardless of lifecycle rules, since versioning takes precedence",
          "A basic age-based rule applies to any version — live or noncurrent — once it reaches 365 days old, so old versions get deleted too unless the rule is scoped more narrowly",
          "Lifecycle rules can only ever affect the live/current version",
          "Versioning and lifecycle rules cannot be used together",
        ],
        answerIndex: 1,
        explanation: "An Age condition matches based on a version's own age, live or not, unless you add a condition like isLive:true (to target only current versions) or numNewerVersions (to target only stale noncurrent ones). Without that scoping, a simple age rule will eventually delete noncurrent versions too, which can surprise teams who assumed versioning alone preserved history indefinitely.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: [],
  },
];

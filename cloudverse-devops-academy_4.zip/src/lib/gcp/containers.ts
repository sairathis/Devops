import { GcpResourceDef } from "@/types/gcp";

export const containerResources: GcpResourceDef[] = [
  {
    type: "gke",
    label: "GKE Cluster",
    shortLabel: "GKE",
    category: "containers",
    color: "gcp-green",
    description: "A managed Kubernetes cluster for deploying, managing, and scaling containerized applications.",
    learningNotes:
      "Autopilot mode manages nodes for you (pay per pod resource requests) and is recommended for most teams; Standard mode gives full node-pool control. Private clusters keep node IPs internal-only, reducing attack surface — access the control plane via an authorized network or a bastion. Workload Identity is the recommended way for pods to authenticate to GCP APIs, replacing node-level service account keys.",
    tooltip: "Managed Kubernetes for container workloads.",
    docsUrl: "https://cloud.google.com/kubernetes-engine/docs/concepts/kubernetes-engine-overview",
    terraformResourceType: "google_container_cluster",
    configFields: [
      { key: "name", label: "Cluster Name", type: "text", required: true, placeholder: "prod-gke" },
      { key: "mode", label: "Mode", type: "select", options: [{ label: "Autopilot (recommended)", value: "autopilot" }, { label: "Standard", value: "standard" }] },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      {
        key: "subnetId", label: "Subnet", type: "resource-ref", refTypes: ["subnet"],
        helpText: "Which subnet this cluster's nodes and pod/service ranges live in. Bind one so the architecture diagram shows the real connection.",
      },
      { key: "nodeCount", label: "Nodes per Zone (Standard only)", type: "number", min: 1, max: 20 },
      { key: "privateCluster", label: "Private Cluster", type: "boolean" },
      { key: "workloadIdentity", label: "Enable Workload Identity", type: "boolean" },
      { key: "release_channel", label: "Release Channel", type: "select", options: [{ label: "Rapid", value: "RAPID" }, { label: "Regular", value: "REGULAR" }, { label: "Stable", value: "STABLE" }] },
    ],
    defaultConfig: { name: "prod-gke", mode: "autopilot", region: "us-central1", subnetId: "", nodeCount: 3, privateCluster: true, workloadIdentity: true, release_channel: "REGULAR" },
    generateTerraform: ({ slug, config }) => `resource "google_container_cluster" "${slug}" {
  name             = "${config.name}"
  location         = "${config.region}"
  enable_autopilot = ${config.mode === "autopilot"}
  ${config.mode !== "autopilot" ? `initial_node_count       = ${config.nodeCount}\n  remove_default_node_pool = true` : ""}

  release_channel {
    channel = "${config.release_channel}"
  }

  ${
    config.privateCluster
      ? `private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }`
      : ""
  }

  ${config.workloadIdentity ? `workload_identity_config {\n    workload_pool = "\${var.project_id}.svc.id.goog"\n  }` : ""}

  network    = google_compute_network.prod_vpc.id
  subnetwork = google_compute_subnetwork.public_subnet_1.id
}`,
    estimateMonthlyCost: (c) => (c.mode === "autopilot" ? 74 : 74 + Number(c.nodeCount ?? 3) * 24),
    troubleshooting: [
      { issue: "kubectl can't reach the cluster", cause: "Private cluster endpoint not authorized for your source IP", fix: "Add your IP to the cluster's master authorized networks, or connect via a bastion/Cloud Shell." },
      { issue: "Pods stuck in Pending", cause: "Insufficient node capacity or unsatisfiable resource requests", fix: "Scale the node pool, or, on Autopilot, adjust the pod's resource requests to a supported compute class." },
    ],
    quiz: [
      { question: "Which GKE feature lets pods authenticate to Google Cloud APIs without node-level service account keys?", options: ["Cloud IAP", "Workload Identity", "Cloud Armor", "Binary Authorization"], answerIndex: 1, explanation: "Workload Identity maps Kubernetes service accounts to IAM service accounts securely.", difficulty: "beginner" },
      {
        question: "In GKE Autopilot mode, how are you primarily billed compared to Standard mode?",
        options: [
          "Per underlying node, regardless of what's scheduled on it",
          "Per pod resource requests (vCPU, memory, and ephemeral storage), since Google manages the nodes for you",
          "A single flat monthly fee regardless of usage",
          "Per Kubernetes API call",
        ],
        answerIndex: 1,
        explanation: "Autopilot abstracts away node management and charges based on the compute resources your pods actually request, whereas Standard mode bills for the node pool's VMs whether or not they're fully utilized. This is why right-sizing pod requests matters more directly in Autopilot.",
        difficulty: "beginner",
      },
      {
        question: "Pods in a GKE Standard cluster are stuck in Pending. Describing the pod shows 'Insufficient cpu'. What is the most likely fix?",
        options: [
          "Enable Workload Identity",
          "Scale up the node pool, or reduce the pod's CPU resource requests to fit available capacity",
          "Switch the release channel to Rapid",
          "Enable DNSSEC on the cluster",
        ],
        answerIndex: 1,
        explanation: "'Insufficient cpu' means no node in the pool has enough allocatable CPU left to satisfy the pod's request, so the scheduler leaves it Pending. On Autopilot, the platform provisions capacity automatically, but pod requests must still fit within supported compute-class limits.",
        difficulty: "intermediate",
      },
      {
        question: "A platform team needs custom node taints/tolerations, specific node OS images, and DaemonSets requiring privileged host access across heterogeneous node pools. Which GKE mode should they choose?",
        options: ["Autopilot", "Standard", "Cloud Run", "Autopilot with a Rapid release channel"],
        answerIndex: 1,
        explanation: "Standard mode gives full control over node pools, machine types, and privileged workloads. Autopilot deliberately restricts or disallows privileged pods and fine-grained node control in exchange for a hands-off, hardened-by-default operating model.",
        difficulty: "intermediate",
      },
      {
        question: "A private GKE cluster is up, but `kubectl get pods` from your laptop times out even though your credentials and IAM roles are correct. What is the most likely cause?",
        options: [
          "Workload Identity is disabled",
          "The control plane's authorized networks don't include your current public IP",
          "The release channel is set to Stable",
          "The cluster's nodes are missing a public IP",
        ],
        answerIndex: 1,
        explanation: "A private cluster's control plane endpoint restricts access to explicitly authorized CIDR ranges; a valid IAM role doesn't help if your source IP isn't on that allowlist. Private *nodes* having no public IP is the intended, unrelated security posture, not the cause of this symptom.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["cloudsql", "redis", "artifact_registry", "pubsub"],
  },
];

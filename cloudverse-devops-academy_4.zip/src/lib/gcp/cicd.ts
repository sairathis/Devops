import { GcpResourceDef } from "@/types/gcp";

export const cicdResources: GcpResourceDef[] = [
  {
    type: "artifact_registry",
    label: "Artifact Registry",
    shortLabel: "Registry",
    category: "cicd",
    color: "gcp-blue",
    description: "A universal package manager for container images, language packages, and other build artifacts.",
    learningNotes:
      "Artifact Registry is the successor to Container Registry and supports multiple formats (Docker, Maven, npm, Python, Go) in a single service, with per-repository IAM and optional vulnerability scanning. Regional repositories reduce pull latency and egress cost for GKE clusters in the same region.",
    tooltip: "Managed registry for container images and packages.",
    docsUrl: "https://cloud.google.com/artifact-registry/docs/overview",
    terraformResourceType: "google_artifact_registry_repository",
    configFields: [
      { key: "name", label: "Repository Name", type: "text", required: true, placeholder: "app-images" },
      { key: "format", label: "Format", type: "select", options: [{ label: "Docker", value: "DOCKER" }, { label: "npm", value: "NPM" }, { label: "Maven", value: "MAVEN" }, { label: "Python", value: "PYTHON" }] },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "vulnerabilityScanning", label: "Enable Vulnerability Scanning", type: "boolean" },
      { key: "immutableTags", label: "Immutable Tags", type: "boolean" },
    ],
    defaultConfig: { name: "app-images", format: "DOCKER", region: "us-central1", vulnerabilityScanning: true, immutableTags: true },
    generateTerraform: ({ slug, config }) => `resource "google_artifact_registry_repository" "${slug}" {
  location      = "${config.region}"
  repository_id = "${config.name}"
  format        = "${config.format}"
  docker_config {
    immutable_tags = ${config.immutableTags}
  }
}`,
    estimateMonthlyCost: () => 5,
    troubleshooting: [
      { issue: "docker push denied: permission error", cause: "Missing roles/artifactregistry.writer on the CI service account", fix: "Grant the CI/CD service account the Artifact Registry Writer role on the repository." },
    ],
    quiz: [
      { question: "What did Artifact Registry replace?", options: ["Cloud Source Repositories", "Container Registry (GCR)", "Cloud Build", "Cloud Storage"], answerIndex: 1, explanation: "Artifact Registry is Google's next-gen replacement for the older Container Registry.", difficulty: "beginner" },
      {
        question: "Besides Docker images, what other kinds of artifacts can Artifact Registry store?",
        options: [
          "Only Docker images — it's container-only",
          "Language packages such as npm, Maven, and Python, each in its own repository of the matching format",
          "Only Compute Engine VM images",
          "Only Terraform state files",
        ],
        answerIndex: 1,
        explanation: "Artifact Registry is a universal artifact manager: a single repository is created with one specific format (Docker, npm, Maven, Python, Go, etc.), and you can host multiple repositories of different formats in the same project.",
        difficulty: "beginner",
      },
      {
        question: "A CI pipeline's `docker push` to Artifact Registry fails with a permission-denied error. What's the most likely fix?",
        options: [
          "Enable vulnerability scanning on the repository",
          "Grant the CI/CD service account the Artifact Registry Writer role on the repository",
          "Switch the repository format to Docker",
          "Enable immutable tags",
        ],
        answerIndex: 1,
        explanation: "Pushing an image requires write access to the target repository; without roles/artifactregistry.writer (or an equivalent custom role) granted to the identity running the push, the request is rejected regardless of repository format or other settings.",
        difficulty: "intermediate",
      },
      {
        question: "What's the benefit of creating a regional (not multi-region) Artifact Registry repository for a GKE cluster running in that same region?",
        options: [
          "It's required to enable vulnerability scanning",
          "Reduced image pull latency and lower network egress cost, since traffic stays within the region",
          "It's the only way to use the Docker format",
          "It automatically enables immutable tags",
        ],
        answerIndex: 1,
        explanation: "Keeping the registry co-located with the cluster that pulls from it avoids cross-region network transfer, which is both faster (lower latency image pulls, useful during node scale-ups) and cheaper (regional traffic vs. cross-region egress).",
        difficulty: "intermediate",
      },
      {
        question: "What problem does enabling 'Immutable Tags' on a Docker repository solve?",
        options: [
          "It reduces storage costs by deduplicating layers",
          "It prevents a tag (e.g. `:v1.2.0`) from being overwritten once published, so the tag always resolves to the same image digest — important for reproducible deployments",
          "It automatically encrypts images at rest",
          "It enables automatic vulnerability scanning",
        ],
        answerIndex: 1,
        explanation: "Without immutability, someone could push a new image under an existing tag, silently changing what that tag deploys — a real supply-chain and reproducibility risk. Immutable tags force a new, distinct tag for any new image content.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["gke", "mig"],
  },
  {
    type: "cloud_build",
    label: "Cloud Build",
    shortLabel: "Build",
    category: "cicd",
    color: "gcp-blue",
    description: "A serverless CI/CD platform that executes builds as a series of containerized steps, triggered by source changes.",
    learningNotes:
      "Cloud Build triggers can fire on a push, pull request, or tag to a connected repo (GitHub, GitLab, Cloud Source Repositories). Each build step runs in its own container, chaining together via a shared workspace volume — enabling build, test, containerize, and deploy in one pipeline defined in cloudbuild.yaml.",
    tooltip: "Serverless CI/CD pipeline runner.",
    docsUrl: "https://cloud.google.com/build/docs/overview",
    terraformResourceType: "google_cloudbuild_trigger",
    configFields: [
      { key: "name", label: "Trigger Name", type: "text", required: true, placeholder: "deploy-on-push" },
      { key: "repoOwner", label: "Repository Owner", type: "text", placeholder: "my-org" },
      { key: "repoName", label: "Repository Name", type: "text", placeholder: "my-app" },
      { key: "branchPattern", label: "Branch Pattern", type: "text", placeholder: "^main$" },
      { key: "deployTarget", label: "Deploy Target", type: "select", options: [{ label: "GKE", value: "gke" }, { label: "Cloud Run", value: "cloud_run" }, { label: "MIG (rolling update)", value: "mig" }] },
    ],
    defaultConfig: { name: "deploy-on-push", repoOwner: "my-org", repoName: "my-app", branchPattern: "^main$", deployTarget: "gke" },
    generateTerraform: ({ slug, config }) => `resource "google_cloudbuild_trigger" "${slug}" {
  name = "${config.name}"

  github {
    owner = "${config.repoOwner}"
    name  = "${config.repoName}"
    push {
      branch = "${config.branchPattern}"
    }
  }

  filename = "cloudbuild.yaml"
}`,
    estimateMonthlyCost: () => 3,
    troubleshooting: [
      { issue: "Trigger doesn't fire on push", cause: "GitHub app not installed/authorized for the repo, or branch pattern mismatch", fix: "Reconnect the repository via the Cloud Build GitHub App and verify the regex branch pattern." },
      { issue: "Build fails at the deploy step", cause: "Cloud Build service account lacks IAM permissions on the target (e.g. GKE)", fix: "Grant roles/container.developer (or equivalent) to the Cloud Build service account." },
    ],
    quiz: [
      { question: "How are Cloud Build pipeline steps typically defined?", options: ["A Jenkinsfile", "cloudbuild.yaml with containerized steps", "A Dockerfile only", "A Terraform module"], answerIndex: 1, explanation: "Cloud Build pipelines are defined in cloudbuild.yaml, with each step running in its own container.", difficulty: "beginner" },
      {
        question: "Which of these events can trigger a Cloud Build pipeline to run automatically?",
        options: [
          "Only a manually-triggered invocation from the console",
          "A push, pull request, or tag event on a connected source repository (GitHub, GitLab, or Cloud Source Repositories)",
          "Only a fixed cron schedule",
          "Only a change to a Cloud Storage bucket",
        ],
        answerIndex: 1,
        explanation: "Cloud Build triggers are commonly wired to source-control events like pushes, pull requests, or tags on a connected repository, letting builds run automatically as part of a CI/CD workflow, though manual and scheduled invocations are also possible.",
        difficulty: "beginner",
      },
      {
        question: "A Cloud Build trigger connected to a GitHub repo doesn't fire when code is pushed to main. What's the most likely cause?",
        options: [
          "The build steps reference the wrong image",
          "The GitHub App isn't installed/authorized for the repo, or the trigger's branch pattern regex doesn't match the pushed branch",
          "The Artifact Registry repository is in the wrong region",
          "The service account lacks Cloud SQL permissions",
        ],
        answerIndex: 1,
        explanation: "Trigger firing depends on Cloud Build actually receiving the webhook (which needs the GitHub App connected) and the event matching the configured branch pattern — a regex like `^main$` won't match a push to `main-hotfix`, for example.",
        difficulty: "intermediate",
      },
      {
        question: "A Cloud Build pipeline builds and tests successfully but fails at the deployment step targeting GKE. What's the most likely cause?",
        options: [
          "The build steps aren't running in containers",
          "The Cloud Build service account lacks IAM permissions on the target (e.g. missing roles/container.developer) to deploy to the cluster",
          "cloudbuild.yaml is missing a Dockerfile",
          "The repository format is set to Maven instead of Docker",
        ],
        answerIndex: 1,
        explanation: "Cloud Build executes each step as a specific service account; if that identity hasn't been granted permissions on the deploy target (like a GKE cluster), the deploy step will fail with an authorization error even though the build and test steps succeeded.",
        difficulty: "intermediate",
      },
      {
        question: "Each Cloud Build step runs in its own container, yet a later step can use a compiled binary produced by an earlier step. How is this possible?",
        options: [
          "All steps actually run in the same container despite appearing separate",
          "Every step mounts a shared /workspace volume, so files written by one step are visible to subsequent steps despite each running in an isolated container",
          "Cloud Build automatically commits intermediate outputs to Artifact Registry between steps",
          "Steps communicate directly over an internal gRPC channel",
        ],
        answerIndex: 1,
        explanation: "The shared workspace volume is what lets a pipeline chain together otherwise-isolated containerized steps — e.g. a compile step's output binary is picked up by a later containerize step — without needing to explicitly copy artifacts between them.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["artifact_registry", "gke", "mig"],
  },
];

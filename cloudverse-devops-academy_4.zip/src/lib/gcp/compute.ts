import { GcpResourceDef } from "@/types/gcp";

const MACHINE_COST: Record<string, number> = {
  "e2-micro": 6.5, "e2-small": 13, "e2-medium": 26, "e2-standard-2": 52,
  "e2-standard-4": 104, "n2-standard-2": 71, "n2-standard-4": 142, "c2-standard-4": 168,
};

export const computeResources: GcpResourceDef[] = [
  {
    type: "vm",
    label: "Compute Engine VM",
    shortLabel: "VM",
    category: "compute",
    color: "gcp-green",
    description: "A configurable virtual machine running in a GCP zone, the fundamental building block of Compute Engine.",
    learningNotes:
      "Machine families trade off price vs. performance: E2 for cost-optimized general workloads, N2/N2D for balanced workloads, C2/C3 for compute-intensive tasks, and M-series for memory-optimized. Persistent Disks are network-attached and durable independent of the VM lifecycle. Attaching a public IP exposes the instance directly to the internet — pair with firewall rules and prefer a load balancer + private VM in production.",
    tooltip: "A single virtual machine instance.",
    docsUrl: "https://cloud.google.com/compute/docs/instances",
    terraformResourceType: "google_compute_instance",
    configFields: [
      { key: "name", label: "Instance Name", type: "text", required: true, placeholder: "web-vm-1" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "zone", label: "Zone", type: "select", options: [{ label: "a", value: "-a" }, { label: "b", value: "-b" }, { label: "c", value: "-c" }] },
      {
        key: "subnetId", label: "Subnet", type: "resource-ref", refTypes: ["subnet"],
        helpText: "Which subnet this VM's network interface lives in. Bind one so the architecture diagram shows the real connection.",
      },
      { key: "machineFamily", label: "Machine Family", type: "select", options: [{ label: "E2 (cost-optimized)", value: "E2" }, { label: "N2 (balanced)", value: "N2" }, { label: "C2 (compute-optimized)", value: "C2" }] },
      { key: "machineType", label: "Machine Type", type: "select", options: Object.keys(MACHINE_COST).map((m) => ({ label: m, value: m })) },
      { key: "osImage", label: "OS Image", type: "select", options: [
        { label: "Debian 12", value: "debian-cloud/debian-12" }, { label: "Ubuntu 22.04 LTS", value: "ubuntu-os-cloud/ubuntu-2204-lts" },
        { label: "Container-Optimized OS", value: "cos-cloud/cos-stable" }, { label: "Windows Server 2022", value: "windows-cloud/windows-2022" },
      ] },
      { key: "diskSizeGb", label: "Boot Disk Size (GB)", type: "number", min: 10, max: 2000 },
      { key: "diskType", label: "Disk Type", type: "select", options: [{ label: "Standard (pd-standard)", value: "pd-standard" }, { label: "Balanced (pd-balanced)", value: "pd-balanced" }, { label: "SSD (pd-ssd)", value: "pd-ssd" }] },
      { key: "publicIp", label: "Assign Public IP", type: "boolean" },
      { key: "enableSsh", label: "Allow SSH (port 22)", type: "boolean" },
      { key: "tags", label: "Network Tags", type: "tags", placeholder: "web, prod" },
    ],
    defaultConfig: { name: "web-vm-1", region: "us-central1", zone: "-a", subnetId: "", machineFamily: "E2", machineType: "e2-medium", osImage: "debian-cloud/debian-12", diskSizeGb: 20, diskType: "pd-balanced", publicIp: true, enableSsh: true, tags: ["web"] },
    generateTerraform: ({ slug, config }) => `resource "google_compute_instance" "${slug}" {
  name         = "${config.name}"
  machine_type = "${config.machineType}"
  zone         = "${config.region}${config.zone}"
  tags         = ${JSON.stringify(config.tags ?? [])}

  boot_disk {
    initialize_params {
      image = "${config.osImage}"
      size  = ${config.diskSizeGb}
      type  = "${config.diskType}"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.public_subnet_1.id
    ${config.publicIp ? "access_config {}" : ""}
  }

  metadata = {
    enable-oslogin = "TRUE"
  }
}`,
    estimateMonthlyCost: (c) => MACHINE_COST[c.machineType as string] ?? 26,
    troubleshooting: [
      { issue: "Cannot SSH into the instance", cause: "Firewall rule missing for tcp:22 or no public IP assigned", fix: "Add a firewall rule allowing tcp:22 from your IP/IAP range, and confirm a public IP or use IAP TCP forwarding." },
      { issue: "Instance stuck in 'Provisioning'", cause: "Insufficient quota or capacity in the selected zone", fix: "Request a quota increase or select a different zone/region." },
    ],
    quiz: [
      { question: "Which machine family is best for cost-optimized, general-purpose workloads?", options: ["C2", "M2", "E2", "A2"], answerIndex: 2, explanation: "E2 instances are GCP's cost-optimized general-purpose family.", difficulty: "beginner" },
      {
        question: "Which Compute Engine disk type is optimized for the lowest cost, at the expense of the lowest performance, and is best suited for infrequently accessed data?",
        options: ["pd-ssd", "pd-balanced", "pd-standard", "pd-extreme"],
        answerIndex: 2,
        explanation: "pd-standard uses spinning-disk-class HDD performance and is the cheapest Persistent Disk type. pd-balanced is the tempting distractor, but it's a middle-ground option that trades some cost for meaningfully better throughput and IOPS than pd-standard.",
        difficulty: "beginner",
      },
      {
        question: "You SSH into a Compute Engine VM and get 'Connection refused,' although the instance shows RUNNING and has a public IP assigned. What is the most likely cause?",
        options: ["The boot disk is too small", "No firewall rule allows ingress on tcp:22 to the instance", "The machine type doesn't support SSH", "The VM's zone is wrong"],
        answerIndex: 1,
        explanation: "GCP VPC firewalls deny all ingress by default, so tcp:22 must be explicitly allowed (from your IP or an IAP range) even though the instance itself is healthy. A public IP alone does not open any ports — only firewall rules do.",
        difficulty: "intermediate",
      },
      {
        question: "A batch job needs a burst of high CPU for under an hour, once a week, and can tolerate being interrupted and restarted. Which pricing model minimizes cost for this workload?",
        options: ["A 1-year committed use discount", "Sustained use discounts on an on-demand instance", "A Spot VM", "A reserved instance"],
        answerIndex: 2,
        explanation: "Spot VMs offer the deepest discount (up to ~60-91% off on-demand) in exchange for possible preemption, which is a good trade for short, interruption-tolerant batch work. Committed use discounts require a 1- or 3-year commitment to steady usage, which doesn't fit an intermittent weekly job.",
        difficulty: "intermediate",
      },
      {
        question: "The Terraform this platform generates for a VM sets instance metadata enable-oslogin = \"TRUE\". What security benefit does OS Login provide over managing SSH keys in instance/project metadata?",
        options: [
          "It automatically encrypts the boot disk",
          "It ties SSH access to IAM identities and roles instead of static keys in metadata, so access can be centrally granted and revoked via IAM",
          "It disables SSH entirely for stronger security",
          "It is required before a public IP can be attached",
        ],
        answerIndex: 1,
        explanation: "OS Login links Linux user accounts to Google identities and IAM roles (roles/compute.osLogin), so revoking IAM access immediately revokes SSH access without hunting down keys pasted into metadata. Metadata-based SSH keys, by contrast, persist until someone manually removes them.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["cloudsql", "redis", "gcs", "pubsub"],
  },
  {
    type: "mig",
    label: "Managed Instance Group",
    shortLabel: "MIG",
    category: "compute",
    color: "gcp-green",
    description: "A group of identical VM instances created from a template, with autoscaling, autohealing, and rolling updates.",
    learningNotes:
      "MIGs are created from an Instance Template (an immutable blueprint of machine type, image, and metadata). Autoscaling policies react to CPU utilization, load balancing capacity, or custom Cloud Monitoring metrics. Autohealing uses a health check to detect and automatically recreate unhealthy instances — a foundational building block for self-healing infrastructure.",
    tooltip: "Auto-scaling, self-healing fleet of identical VMs.",
    docsUrl: "https://cloud.google.com/compute/docs/instance-groups",
    terraformResourceType: "google_compute_instance_group_manager",
    configFields: [
      { key: "name", label: "MIG Name", type: "text", required: true, placeholder: "web-mig" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" }] },
      {
        key: "subnetId", label: "Subnet", type: "resource-ref", refTypes: ["subnet"],
        helpText: "Which subnet this group's instances launch into. Bind one so the architecture diagram shows the real connection.",
      },
      { key: "minReplicas", label: "Min Instances", type: "number", min: 1, max: 50 },
      { key: "maxReplicas", label: "Max Instances", type: "number", min: 1, max: 200 },
      { key: "targetCpu", label: "Target CPU Utilization (%)", type: "slider", min: 10, max: 100, step: 5 },
      { key: "autoHealing", label: "Enable Autohealing", type: "boolean" },
      { key: "updatePolicy", label: "Update Policy", type: "select", options: [{ label: "Rolling Update", value: "PROACTIVE" }, { label: "Opportunistic", value: "OPPORTUNISTIC" }] },
    ],
    defaultConfig: { name: "web-mig", region: "us-central1", subnetId: "", minReplicas: 2, maxReplicas: 10, targetCpu: 60, autoHealing: true, updatePolicy: "PROACTIVE" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_instance_template" "${slug}_template" {
  name_prefix  = "${config.name}-tmpl-"
  machine_type = "e2-medium"
  disk { source_image = "debian-cloud/debian-12" auto_delete = true boot = true }
  network_interface { subnetwork = google_compute_subnetwork.public_subnet_1.id }
  lifecycle { create_before_destroy = true }
}

resource "google_compute_region_instance_group_manager" "${slug}" {
  name               = "${config.name}"
  region             = "${config.region}"
  base_instance_name = "${config.name}"
  version {
    instance_template = google_compute_instance_template.${slug}_template.id
  }
  target_size = ${config.minReplicas}
  ${
    config.autoHealing
      ? `auto_healing_policies {
    health_check      = google_compute_health_check.web_lb_hc.id
    initial_delay_sec = 60
  }`
      : ""
  }
  update_policy {
    type                  = "${config.updatePolicy}"
    minimal_action        = "REPLACE"
    max_surge_fixed       = 3
    max_unavailable_fixed = 0
  }
}

resource "google_compute_region_autoscaler" "${slug}_autoscaler" {
  name   = "${config.name}-autoscaler"
  region = "${config.region}"
  target = google_compute_region_instance_group_manager.${slug}.id
  autoscaling_policy {
    min_replicas    = ${config.minReplicas}
    max_replicas    = ${config.maxReplicas}
    cooldown_period = 60
    cpu_utilization { target = ${Number(config.targetCpu) / 100} }
  }
}`,
    estimateMonthlyCost: (c) => (MACHINE_COST["e2-medium"] ?? 26) * Number(c.minReplicas ?? 2),
    troubleshooting: [
      { issue: "MIG keeps recreating instances in a loop", cause: "Autohealing health check fails immediately after boot (too-short initial delay)", fix: "Increase initial_delay_sec to allow the app to finish starting before health checks begin." },
      { issue: "Scaling doesn't react to load", cause: "Autoscaler target metric doesn't match actual bottleneck", fix: "Switch to a custom Cloud Monitoring metric (e.g. queue depth) that reflects real load." },
    ],
    quiz: [
      { question: "What triggers a Managed Instance Group to automatically recreate an instance?", options: ["Autoscaling policy", "Autohealing health check failure", "Instance template change", "Manual restart"], answerIndex: 1, explanation: "Autohealing detects unhealthy instances via health checks and recreates them.", difficulty: "beginner" },
      {
        question: "What is an Instance Template in the context of a Managed Instance Group?",
        options: [
          "A live VM that other instances are cloned from at runtime",
          "An immutable blueprint defining machine type, boot image, and metadata used to create every instance in the group",
          "A firewall rule set applied to the MIG",
          "A load balancer configuration attached to the MIG",
        ],
        answerIndex: 1,
        explanation: "Instance Templates are immutable — you can't edit one in place, only create a new version and roll it out via an update policy. This immutability is what makes MIG rollouts predictable and reproducible.",
        difficulty: "beginner",
      },
      {
        question: "A MIG's instances repeatedly get destroyed and recreated in a loop shortly after each one boots. What is the most likely cause?",
        options: [
          "The autoscaler's max replica count is too low",
          "The autohealing health check's initial delay is too short, so it fails the check before the app finishes starting and triggers a recreate",
          "The instance template references a nonexistent image",
          "minReplicas is set higher than maxReplicas",
        ],
        answerIndex: 1,
        explanation: "If autohealing starts probing before the application has finished booting, it sees failures and recreates the instance — which then boots slowly again, repeating the loop. Increasing initial_delay_sec gives the app time to become healthy before autohealing evaluates it.",
        difficulty: "intermediate",
      },
      {
        question: "A MIG is configured with minReplicas=2, maxReplicas=10, and a target CPU utilization of 60%. Backend CPU sustains 85% during a traffic spike. What does the autoscaler do?",
        options: [
          "Nothing, until CPU hits 100%",
          "Gradually adds instances to bring average CPU back down toward the 60% target, up to the 10-instance cap",
          "Immediately jumps straight to 10 instances regardless of need",
          "Lowers minReplicas to compensate",
        ],
        answerIndex: 1,
        explanation: "Cloud Monitoring-based autoscaling adjusts capacity incrementally toward the configured target utilization rather than jumping straight to the maximum, and it will never scale below minReplicas or above maxReplicas.",
        difficulty: "intermediate",
      },
      {
        question: "What is the key functional difference between a PROACTIVE and an OPPORTUNISTIC update policy when rolling out a new instance template version to a MIG?",
        options: [
          "PROACTIVE actively replaces instances according to the rollout policy right away; OPPORTUNISTIC only updates an instance the next time it's recreated for some other reason (e.g. autohealing or manual deletion)",
          "They behave identically in all cases",
          "OPPORTUNISTIC forces an immediate replacement of every instance at once",
          "PROACTIVE only affects autoscaling events, not template changes",
        ],
        answerIndex: 0,
        explanation: "PROACTIVE (rolling update) actively churns through instances per the max_surge/max_unavailable settings until all are on the new template. OPPORTUNISTIC is lazier — it lets existing instances keep running and only applies the new template when an instance happens to be replaced anyway.",
        difficulty: "advanced",
      },
    ],
    validConnectionTargets: ["cloudsql", "redis"],
  },
];

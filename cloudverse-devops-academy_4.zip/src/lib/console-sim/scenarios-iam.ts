import { ErrorScenario } from "@/lib/console-sim/types";

/**
 * Realistic "what goes wrong" scenarios for IAM & Service Accounts. Same
 * shape/tone as scenarios-gcp.ts — these cover identity and access-control
 * failure modes rather than a specific resource type, so most entries omit
 * resourceType (project-level) except where they're clearly about a single
 * service account.
 */
export const IAM_SCENARIOS: ErrorScenario[] = [
  {
    id: "iam-sa-missing-storage-viewer",
    module: "gcp-services",
    resourceType: "service_account",
    title: "403 Forbidden calling a Cloud Storage API from a service account",
    symptom: "A workload authenticating as a service account gets a 403 reading objects, even though the bucket exists and is otherwise healthy.",
    cliOutput: [
      "$ gcloud storage objects describe gs://my-app-assets-prod/config.json --impersonate-service-account=web-app-runner@cloudverse-demo.iam.gserviceaccount.com",
      "ERROR: (gcloud.storage.objects.describe) HTTPError 403: web-app-runner@cloudverse-demo.iam.gserviceaccount.com does not have storage.objects.get access to the Google Cloud Storage object.",
    ],
    cause: "The service account has no IAM binding granting roles/storage.objectViewer (or broader) on the bucket, so every read call from that identity is denied.",
    fixSteps: [
      "Open IAM & Admin → Service Accounts, select the service account, and grant it roles/storage.objectViewer.",
      "Scope the grant to just the bucket the workload actually needs, not project-wide Storage Admin.",
      "Re-run the read call; IAM changes typically take effect within seconds to a couple of minutes.",
    ],
    preventionTip: "Grant storage roles to a workload's service account at creation time, as part of the same change that provisions the workload — not after the first 403 shows up in production.",
    docsUrl: "https://cloud.google.com/storage/docs/access-control/iam",
  },
  {
    id: "iam-missing-service-account-user",
    module: "gcp-services",
    title: "Deploy fails: caller lacks Service Account User on the runtime service account",
    symptom: "A Cloud Build or Cloud Run deploy fails immediately at the step that attaches a service account to the new revision, even though that service account itself has all the roles it needs.",
    cliOutput: [
      "$ gcloud run deploy api --image=us-central1-docker.pkg.dev/proj/repo/api:latest --service-account=api-runner@cloudverse-demo.iam.gserviceaccount.com",
      "ERROR: (gcloud.run.deploy) PERMISSION_DENIED: Permission 'iam.serviceaccounts.actAs' denied on service account api-runner@cloudverse-demo.iam.gserviceaccount.com (or it may not exist).",
    ],
    cause: "Attaching a service account to a resource (a Cloud Run service, a VM, a Cloud Build step) requires the deploying identity to hold roles/iam.serviceAccountUser on that specific service account — this is a separate grant from any role the service account itself holds.",
    fixSteps: [
      "Grant the deploying identity (a user or the CI service account) roles/iam.serviceAccountUser scoped to api-runner@cloudverse-demo.iam.gserviceaccount.com.",
      "Confirm you're granting it on the service account resource itself, not on the project — the 'actAs' permission is checked at the service-account level.",
      "Re-trigger the deploy once the binding is in place.",
    ],
    preventionTip: "Whenever a pipeline deploys 'as' a service account, grant its own CI/CD service account roles/iam.serviceAccountUser on that target in the same Terraform module that creates both.",
    docsUrl: "https://cloud.google.com/iam/docs/service-account-permissions",
  },
  {
    id: "iam-default-sa-overprivileged-finding",
    module: "gcp-services",
    resourceType: "service_account",
    title: "Security review flags the default service account's broad Editor role",
    symptom: "An IAM security review (or the Recommender's role-usage insights) flags the project's default Compute Engine service account as high-risk.",
    cliOutput: [
      "$ gcloud recommender insights list --project=my-project --location=global --insight-type=google.iam.policy.Insight",
      "INSIGHT: 'default' service account (default@cloudverse-demo.iam.gserviceaccount.com) holds roles/editor at the project level.",
      "SEVERITY: HIGH — this identity can modify nearly every resource in the project and is likely attached to more than one workload.",
    ],
    cause: "GCP automatically creates a project-wide default Compute Engine service account with the broad, legacy Editor role, and unless a team deliberately swaps it out, every new VM or workload that doesn't specify its own service account silently inherits that broad access.",
    fixSteps: [
      "Create a narrowly-scoped service account per workload instead of reusing the default one (e.g. one for a web app that only needs Storage Object Viewer and Cloud SQL Client).",
      "Revoke roles/editor from the default service account, or disable the default service account entirely if nothing legitimately depends on it.",
      "Re-point any workloads still using the default service account at their new narrowly-scoped replacements before revoking.",
      "Re-run the Recommender scan to confirm the finding clears.",
    ],
    preventionTip: "Treat 'uses the default service account' as a code-review blocker for new workloads — always name an explicit, narrowly-scoped service account instead.",
    docsUrl: "https://cloud.google.com/iam/docs/service-account-overview",
  },
  {
    id: "iam-impersonation-denied",
    module: "gcp-services",
    resourceType: "service_account",
    title: "\"Permission denied\" attempting to impersonate a service account",
    symptom: "A developer tries to impersonate a service account from their own gcloud session to test its permissions, and the call is rejected outright.",
    cliOutput: [
      "$ gcloud auth print-access-token --impersonate-service-account=data-pipeline@cloudverse-demo.iam.gserviceaccount.com",
      "ERROR: (gcloud.auth.print-access-token) User [dev@company.com] does not have permission to access service account [data-pipeline@cloudverse-demo.iam.gserviceaccount.com] (or it may not exist), missing permission [iam.serviceAccounts.getAccessToken].",
    ],
    cause: "Impersonating a service account (minting a short-lived token on its behalf) requires roles/iam.serviceAccountTokenCreator on that specific service account — holding other roles, even Editor, does not implicitly grant impersonation rights.",
    fixSteps: [
      "Grant the developer roles/iam.serviceAccountTokenCreator scoped to data-pipeline@cloudverse-demo.iam.gserviceaccount.com.",
      "Re-run the impersonation command; a successful call returns a short-lived OAuth access token, not a permanent credential.",
      "Prefer impersonation over downloading a long-lived JSON key whenever a human just needs to test a service account's access temporarily.",
    ],
    preventionTip: "Grant roles/iam.serviceAccountTokenCreator sparingly and only to the specific accounts someone genuinely needs to test as — it is effectively equivalent to holding that service account's own permissions.",
    docsUrl: "https://cloud.google.com/iam/docs/impersonating-service-accounts",
  },
  {
    id: "iam-terraform-apply-403",
    module: "gcp-services",
    title: "Terraform apply fails with 403: identity lacks a required role",
    symptom: "`terraform apply` fails partway through, on a resource the plan clearly shows as new, with an IAM permission error rather than a syntax or state problem.",
    cliOutput: [
      "$ terraform apply",
      "google_compute_instance.web: Creating...",
      "Error: Error creating instance: googleapi: Error 403: Required 'compute.instances.create' permission for 'projects/my-project/zones/us-central1-a/instances/web-vm-1', forbidden",
    ],
    cause: "The identity Terraform is authenticating as (a user's application-default credentials, or a CI service account) doesn't hold a role that includes compute.instances.create in this project.",
    fixSteps: [
      "Identify which identity Terraform is actually using: `gcloud auth application-default print-access-token` locally, or check the CI job's configured service account.",
      "Grant that identity roles/compute.instanceAdmin.v1 (or roles/compute.admin for broader infra work).",
      "Re-run `terraform plan` then `apply` — no state changes are needed, this was purely an IAM gap.",
    ],
    preventionTip: "Grant your Terraform-runner identity every role its modules will ever need as part of onboarding a new module, rather than discovering gaps one 403 at a time during apply.",
    docsUrl: "https://cloud.google.com/iam/docs/understanding-roles",
  },
  {
    id: "iam-disabled-service-account-api-call",
    module: "gcp-services",
    resourceType: "service_account",
    title: "\"Service account has been disabled\" calling an API",
    symptom: "A workload that was authenticating fine suddenly fails every API call with an authentication error, right after the service account was disabled during a cleanup.",
    cliOutput: [
      "$ curl -H \"Authorization: Bearer $TOKEN\" https://storage.googleapis.com/storage/v1/b/my-app-assets-prod",
      "HTTP/2 400",
      "{\"error\":\"invalid_grant\",\"error_description\":\"Service account api-runner@cloudverse-demo.iam.gserviceaccount.com has been disabled.\"}",
    ],
    cause: "A disabled service account keeps its IAM role bindings and its email address, but Google immediately stops issuing it new access tokens — every call from it fails, without deleting anything.",
    fixSteps: [
      "Confirm which service account is disabled and why: check IAM & Admin → Service Accounts for the 'Disabled' status, and any recent cleanup or offboarding change.",
      "If the account is still needed, re-enable it: `gcloud iam service-accounts enable api-runner@cloudverse-demo.iam.gserviceaccount.com`.",
      "If it should stay retired, migrate the workload to a different, active service account instead of re-enabling it.",
      "Re-test the failing call once the account is enabled (or the workload is repointed).",
    ],
    preventionTip: "Disable (rather than delete) a service account first when retiring it, watch for a quiet period with zero calls in Cloud Logging, and only delete it once nothing depends on it.",
    docsUrl: "https://cloud.google.com/iam/docs/creating-managing-service-accounts#disabling",
  },
  {
    id: "iam-role-grant-propagation-delay",
    module: "gcp-services",
    title: "A just-granted IAM role doesn't seem to work yet",
    symptom: "A role was granted moments ago, but the very next API call from that identity still gets a 403 — then a retry a minute later succeeds with no other change.",
    cliOutput: [
      "$ gcloud projects add-iam-policy-binding my-project --member=serviceAccount:reporting@cloudverse-demo.iam.gserviceaccount.com --role=roles/bigquery.dataViewer",
      "Updated IAM policy for project [my-project].",
      "$ bq query --use_legacy_sql=false 'SELECT 1'",
      "BigQuery error in query operation: Access Denied: Table my-project:reports.summary: Permission bigquery.tables.getData denied",
    ],
    cause: "IAM policy changes are eventually consistent, not instantaneous — propagation across Google's backends typically completes within seconds but can occasionally take a couple of minutes, especially for a brand-new binding.",
    fixSteps: [
      "Wait roughly 60-120 seconds and retry the exact same call before assuming the grant itself is wrong.",
      "Double-check the binding actually targets the right member and role with `gcloud projects get-iam-policy my-project`.",
      "If it still fails after a few minutes, treat it as a real permissions gap rather than a propagation delay and re-check the role's included permissions.",
    ],
    preventionTip: "Build a short retry/backoff into automation that grants a role and immediately uses it in the same script, instead of assuming the grant is live on the very next call.",
    docsUrl: "https://cloud.google.com/iam/docs/access-change-propagation",
  },
];

export function scenariosForServiceAccount(): ErrorScenario[] {
  return IAM_SCENARIOS.filter((s) => s.resourceType === "service_account");
}

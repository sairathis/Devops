import { GCP_SERVICE_SCENARIOS } from "@/lib/console-sim/scenarios-gcp";
import { TERRAFORM_SCENARIOS } from "@/lib/console-sim/scenarios-terraform";
import { DOCKER_SCENARIOS } from "@/lib/console-sim/scenarios-docker";
import { KUBERNETES_SCENARIOS } from "@/lib/console-sim/scenarios-k8s";
import { IAM_SCENARIOS } from "@/lib/console-sim/scenarios-iam";
import { ErrorScenario, SimModule } from "@/lib/console-sim/types";

/**
 * Every hands-on lab (GCP Services Console, Terraform Lab, Docker Lab,
 * Kubernetes Lab) owns its own error-scenario file so each could be built
 * independently. This is the single aggregator the Troubleshooting Center
 * uses to index all of them in one searchable place.
 */
export const ALL_LAB_SCENARIOS: ErrorScenario[] = [
  ...GCP_SERVICE_SCENARIOS,
  ...TERRAFORM_SCENARIOS,
  ...DOCKER_SCENARIOS,
  ...KUBERNETES_SCENARIOS,
  ...IAM_SCENARIOS,
];

export function scenariosByModule(module: SimModule): ErrorScenario[] {
  return ALL_LAB_SCENARIOS.filter((s) => s.module === module);
}

export function getLabModules(): SimModule[] {
  const set = new Set<SimModule>();
  ALL_LAB_SCENARIOS.forEach((s) => set.add(s.module));
  return Array.from(set);
}

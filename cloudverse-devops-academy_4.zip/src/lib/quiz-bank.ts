export interface QuizQuestion {
  id: string;
  topic: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

import { GCP_RESOURCES } from "@/lib/gcp";

const resourceQuestions: QuizQuestion[] = GCP_RESOURCES.flatMap((r) =>
  r.quiz.map((q, i) => ({
    id: `${r.type}-${i}`,
    topic: r.label,
    difficulty: q.difficulty ?? "beginner",
    question: q.question,
    options: q.options,
    answerIndex: q.answerIndex,
    explanation: q.explanation,
  })),
);

const networkingQuestions: QuizQuestion[] = [
  {
    id: "net-1", topic: "Networking", difficulty: "beginner",
    question: "What is the primary purpose of Cloud NAT?",
    options: ["Load balancing across regions", "Outbound-only internet access for private instances", "DNS resolution", "Encrypting VPC traffic"],
    answerIndex: 1,
    explanation: "Cloud NAT performs source NAT so private instances can reach the internet without an inbound path.",
  },
  {
    id: "net-2", topic: "Networking", difficulty: "intermediate",
    question: "Traffic between two VMs in the same VPC, across subnets, is typically called:",
    options: ["North-south traffic", "East-west traffic", "Transit traffic", "Egress traffic"],
    answerIndex: 1,
    explanation: "East-west describes traffic flowing between services inside the same network, as opposed to north-south (in/out of the network).",
  },
  {
    id: "net-3", topic: "Networking", difficulty: "beginner",
    question: "Which GCP resource authoritatively answers DNS queries for a domain?",
    options: ["Cloud Router", "Cloud DNS", "Cloud Armor", "Cloud NAT"],
    answerIndex: 1,
    explanation: "Cloud DNS provides managed, authoritative DNS zones for public or private resolution.",
  },
  {
    id: "net-4", topic: "Networking", difficulty: "advanced",
    question: "A Cloud Router is a required prerequisite for which two features?",
    options: ["Cloud Armor and Cloud CDN", "Cloud NAT and dynamic BGP routing over VPN/Interconnect", "IAM and Org Policy", "Cloud Build and Artifact Registry"],
    answerIndex: 1,
    explanation: "Cloud Router provides the BGP control plane both Cloud NAT and dynamic hybrid connectivity rely on.",
  },
  {
    id: "net-5", topic: "Networking", difficulty: "intermediate",
    question: "What happens to a request when every backend behind a load balancer fails its health check?",
    options: ["The LB queues requests indefinitely", "The LB returns a 502/503 error", "Traffic is silently dropped with no error", "The LB automatically creates a new backend"],
    answerIndex: 1,
    explanation: "With no healthy backends, the load balancer cannot forward traffic and returns a 502/503 to the client.",
  },
];

const iamQuestions: QuizQuestion[] = [
  {
    id: "iam-1", topic: "IAM & Admin", difficulty: "beginner",
    question: "What is the key difference between a Google Cloud user account and a service account?",
    options: [
      "User accounts are for people; service accounts are identities used by applications, VMs, and workloads",
      "Service accounts can only be used for billing",
      "User accounts always have more permissions than service accounts",
      "There is no difference — they're interchangeable terms",
    ],
    answerIndex: 0,
    explanation: "A user account represents a real person authenticating (typically via a Google identity), while a service account is an identity that code or infrastructure uses to call GCP APIs on its own behalf, without a human entering credentials.",
  },
  {
    id: "iam-2", topic: "IAM & Admin", difficulty: "beginner",
    question: "Which of these is a predefined IAM role, as opposed to a primitive or custom role?",
    options: ["Owner", "roles/storage.objectViewer", "A hand-assembled role with 12 chosen permissions", "Editor"],
    answerIndex: 1,
    explanation: "Predefined roles like roles/storage.objectViewer are curated by Google and scoped to a specific service. Owner and Editor are broad, legacy primitive roles, and a hand-assembled set of permissions describes a custom role instead.",
  },
  {
    id: "iam-3", topic: "IAM & Admin", difficulty: "beginner",
    question: "What does the principle of least privilege mean in the context of IAM?",
    options: [
      "Every identity should be granted Owner by default for convenience",
      "Every identity should be granted only the permissions it actually needs to do its job, and nothing more",
      "Only the project owner should have any permissions",
      "Permissions should be reviewed once a year and never before",
    ],
    answerIndex: 1,
    explanation: "Least privilege minimizes the damage a compromised or misused identity can do by limiting its access to exactly what's required — no broader, no more convenient, just sufficient.",
  },
  {
    id: "iam-4", topic: "IAM & Admin", difficulty: "beginner",
    question: "In the IAM policy hierarchy, in what order does a grant flow?",
    options: [
      "Resource → Project → Folder → Organization",
      "Organization → Folder → Project → Resource, with broader grants inherited downward",
      "They are all independent and never inherit from one another",
      "Project → Organization → Folder → Resource",
    ],
    answerIndex: 1,
    explanation: "IAM policies attached higher in the hierarchy (Organization, then Folder, then Project) are inherited by everything beneath them, down to individual resources — a role granted at the Organization level applies everywhere under it unless a more specific policy is layered on top.",
  },
  {
    id: "iam-5", topic: "IAM & Admin", difficulty: "intermediate",
    question: "A developer gets 'Permission denied' (403) calling a Google Cloud API they believe they should have access to. What does this error fundamentally indicate?",
    options: [
      "Their username or password is wrong",
      "They are authenticated (GCP knows who they are) but not authorized for that specific action on that resource",
      "The API is down",
      "Their internet connection is unstable",
    ],
    answerIndex: 1,
    explanation: "A 403 is an authorization failure, not an authentication one — the caller's identity was accepted, but no IAM binding grants them the permission the API call requires. Diagnosing it means checking which role(s) the identity has on that resource (and its parent hierarchy), not their login credentials.",
  },
  {
    id: "iam-6", topic: "IAM & Admin", difficulty: "intermediate",
    question: "What is the practical difference between authentication and authorization in IAM?",
    options: [
      "They are two words for the same concept",
      "Authentication verifies who you are; authorization determines what you're allowed to do once identified",
      "Authorization happens before authentication",
      "Authentication only applies to service accounts",
    ],
    answerIndex: 1,
    explanation: "These are distinct steps: authentication confirms identity (e.g. via a login or a service account key/token), and authorization — governed by IAM roles and policies — then decides which specific actions that confirmed identity may perform.",
  },
  {
    id: "iam-7", topic: "IAM & Admin", difficulty: "intermediate",
    question: "Why are service account keys (downloadable JSON credentials) considered a security liability?",
    options: [
      "They expire automatically after one hour, causing outages",
      "They are long-lived, static secrets that can be copied, leaked, or committed to source control, and don't automatically rotate or revoke themselves",
      "They only work within the project they were created in",
      "They cannot be used for authentication at all",
    ],
    answerIndex: 1,
    explanation: "Unlike short-lived, automatically-rotated credentials, a downloaded key is a durable bearer secret — anyone who obtains the file can act as that service account until it's manually disabled, which is why alternatives like Workload Identity are recommended wherever possible.",
  },
  {
    id: "iam-8", topic: "IAM & Admin", difficulty: "intermediate",
    question: "What does 'Workload Identity' (or short-lived credential approaches generally) aim to replace?",
    options: [
      "IAM roles entirely",
      "The need to distribute long-lived service account key files to workloads, by issuing short-lived, automatically-managed credentials instead",
      "The concept of a project",
      "Cloud Audit Logs",
    ],
    answerIndex: 1,
    explanation: "Workload Identity lets a workload (e.g. a GKE pod) obtain short-lived tokens tied to an IAM service account's permissions without ever having a static key file to leak, directly addressing the key-management risk of traditional service account keys.",
  },
  {
    id: "iam-9", topic: "IAM & Admin", difficulty: "intermediate",
    question: "What does service account impersonation, backed by roles/iam.serviceAccountTokenCreator, allow an identity to do?",
    options: [
      "Permanently take ownership of the service account",
      "Temporarily generate short-lived credentials/tokens to act as that service account, without ever holding its keys",
      "Delete the service account",
      "Rename the service account",
    ],
    answerIndex: 1,
    explanation: "roles/iam.serviceAccountTokenCreator lets an authorized caller mint a short-lived access token or signed JWT for the target service account on demand — a safer alternative to handing out a permanent key, since the impersonation is auditable and the resulting credential expires quickly.",
  },
  {
    id: "iam-10", topic: "IAM & Admin", difficulty: "advanced",
    question: "Why is it considered a security anti-pattern, commonly flagged in real-world audits, for a project's default Compute Engine service account to retain the Editor role?",
    options: [
      "It's not actually a problem — Editor is the recommended default",
      "It grants extremely broad write access across nearly every resource in the project to every VM using that default identity, violating least privilege and creating a lateral-movement risk if any VM is compromised",
      "Editor is a role that doesn't exist for service accounts",
      "It only affects billing, not security",
    ],
    answerIndex: 1,
    explanation: "The default Compute Engine service account historically got Editor automatically, which means any workload running on any VM using that identity — including a compromised one — inherits broad edit access across the project. Audits flag this because it violates least privilege far more than the workload usually needs.",
  },
  {
    id: "iam-11", topic: "IAM & Admin", difficulty: "advanced",
    question: "A custom IAM role is created by combining specific permissions from several predefined roles. What is the main tradeoff of using custom roles instead of predefined ones?",
    options: [
      "Custom roles are always less secure than predefined roles",
      "Custom roles give tighter least-privilege control, but you take on the maintenance burden of keeping the permission list current as GCP APIs evolve",
      "Custom roles cannot be assigned to service accounts",
      "Custom roles are free while predefined roles cost money",
    ],
    answerIndex: 1,
    explanation: "Predefined roles are maintained by Google and automatically updated as services evolve; a custom role gives precise control over exactly which permissions are granted, but your team is responsible for updating it if new permissions are needed or old ones become deprecated.",
  },
  {
    id: "iam-12", topic: "IAM & Admin", difficulty: "advanced",
    question: "In basic Google Cloud IAM (allow policies), is there a direct, general-purpose way to explicitly 'deny' a principal a permission, the way some other access-control systems support explicit deny rules?",
    options: [
      "Yes, every basic IAM allow policy supports an equivalent inline deny rule",
      "No — basic IAM allow policies are additive/grant-only; explicit deny is a separate, more advanced feature (IAM Deny policies) layered on top",
      "Deny is the default for every new project and must be manually removed",
      "Denies only apply to primitive roles, never predefined ones",
    ],
    answerIndex: 1,
    explanation: "Standard IAM allow policies only grant access — permissions accumulate from every applicable binding up the resource hierarchy, with no built-in 'subtract' rule at that layer. IAM Deny policies exist as a distinct, separately-configured mechanism for organizations that need explicit deny semantics.",
  },
  {
    id: "iam-13", topic: "IAM & Admin", difficulty: "beginner",
    question: "What do Cloud Audit Logs record?",
    options: [
      "Only billing changes",
      "A record of who did what, when, and to which resource, across administrative activity and (optionally) data access",
      "Only failed login attempts",
      "Nothing unless manually enabled per API call",
    ],
    answerIndex: 1,
    explanation: "Cloud Audit Logs capture API calls made against your GCP resources, including the identity making the call, the action taken, and the target resource — Admin Activity logs are on by default, while Data Access logs for most services must be explicitly enabled.",
  },
  {
    id: "iam-14", topic: "IAM & Admin", difficulty: "intermediate",
    question: "A team wants a role that lets an engineer manage Compute Engine resources but grants no access to IAM, billing, or other services. Which type of role best fits this need out of the box?",
    options: [
      "A primitive role like Editor",
      "A predefined role scoped to Compute Engine, such as roles/compute.admin",
      "The Owner role",
      "There is no role that can do this",
    ],
    answerIndex: 1,
    explanation: "Predefined roles are scoped to a single service, so roles/compute.admin grants broad control over Compute Engine specifically without touching unrelated services — exactly the kind of targeted access primitive roles like Editor or Owner can't offer, since those span the entire project.",
  },
];

export const QUIZ_BANK: QuizQuestion[] = [...networkingQuestions, ...resourceQuestions, ...iamQuestions];

export function questionsForTopic(topic: string): QuizQuestion[] {
  return QUIZ_BANK.filter((q) => q.topic.toLowerCase() === topic.toLowerCase());
}

export function randomQuestions(count: number, topic?: string): QuizQuestion[] {
  const pool = topic ? questionsForTopic(topic) : QUIZ_BANK;
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

export const QUIZ_TOPICS = Array.from(new Set(QUIZ_BANK.map((q) => q.topic)));

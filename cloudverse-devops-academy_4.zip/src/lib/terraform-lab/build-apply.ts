// Pure logic for the Terraform Lab's "Build & Apply" tab — no React, no store
// access, so it's trivial to reason about and reuse from the tab component.
//
// This deliberately reuses the exact same Terraform generator the
// Architecture Builder uses (src/lib/terraform/generate.ts), which in turn
// calls each resource type's own `generateTerraform(ctx)` — never reinvented
// here. Cross-resource HCL references (e.g. a subnet's `network = ...`) rely
// on the same canonical-address convention the Architecture Builder already
// uses (see assignSlugs / CANONICAL_ADDRESS in generate.ts), so a plan with a
// VPC + subnet produces the same interlinked HCL a hand-built one would.
import type { Edge, Node } from "reactflow";
import { getResourceDef } from "@/lib/gcp";
import { generateTerraform as generateArchTerraform } from "@/lib/terraform/generate";
import { CanvasNodeData, ResourceConfig } from "@/types/gcp";
import type { RefCandidate } from "@/components/architecture/config-form";
import type { PlannedBlock } from "@/store/terraform-lab-store";
import type { ConsoleResource } from "@/store/gcp-console-store";

export function blockDisplayName(block: PlannedBlock): string {
  const def = getResourceDef(block.type);
  return String(block.config.name ?? def?.label ?? block.type);
}

/**
 * Candidates a "resource-ref" / "resource-ref-multi" field on a NEW or EDITED
 * block can bind to: every real resource already in the shared Console store,
 * plus every other staged-but-not-yet-applied block in this session (using
 * the block's own id as the reference value). Once a block is applied it's
 * already represented by its real Console resource above, so it isn't listed
 * twice.
 */
export function buildRefCandidates(blocks: PlannedBlock[], consoleResources: ConsoleResource[]): RefCandidate[] {
  const real: RefCandidate[] = consoleResources.map((r) => ({ id: r.id, type: r.type, name: r.name }));
  const planned: RefCandidate[] = blocks
    .filter((b) => !b.appliedResourceId)
    .map((b) => ({ id: b.id, type: b.type, name: `${blockDisplayName(b)} (planned)` }));
  return [...real, ...planned];
}

/**
 * Orders blocks so that any block referenced by another block's resource-ref
 * field is applied first (a subnet's VPC before the subnet, etc.) — a
 * topological sort (Kahn's algorithm) over the dependency graph implied by
 * resource-ref / resource-ref-multi config values that point at another
 * planned block's id. Falls back to original order for anything left over on
 * a cycle (shouldn't happen for this catalog, but never drop a block).
 */
export function resolveApplyOrder(blocks: PlannedBlock[]): PlannedBlock[] {
  const idSet = new Set(blocks.map((b) => b.id));
  const byId = new Map(blocks.map((b) => [b.id, b]));
  const deps = new Map<string, Set<string>>();

  for (const b of blocks) {
    const def = getResourceDef(b.type);
    const refFields = def?.configFields.filter((f) => f.type === "resource-ref" || f.type === "resource-ref-multi") ?? [];
    const depSet = new Set<string>();
    for (const f of refFields) {
      const v = b.config[f.key];
      const values = Array.isArray(v) ? (v as string[]) : typeof v === "string" && v ? [v] : [];
      for (const val of values) {
        if (idSet.has(val) && val !== b.id) depSet.add(val);
      }
    }
    deps.set(b.id, depSet);
  }

  const result: PlannedBlock[] = [];
  const remaining = new Set(blocks.map((b) => b.id));
  let progressed = true;
  while (remaining.size > 0 && progressed) {
    progressed = false;
    for (const id of Array.from(remaining)) {
      const depSet = deps.get(id) ?? new Set<string>();
      const satisfied = Array.from(depSet).every((d) => !remaining.has(d));
      if (satisfied) {
        result.push(byId.get(id)!);
        remaining.delete(id);
        progressed = true;
      }
    }
  }
  for (const b of blocks) {
    if (remaining.has(b.id)) result.push(b);
  }
  return result;
}

/**
 * Rewrites a block's resource-ref(-multi) fields that currently point at
 * another planned block's id into that block's real, just-applied resource
 * id — the shared Console store only understands its own resource ids.
 * `resolvedIds` maps planned-block id -> real Console resource id and is
 * built up incrementally as apply proceeds in dependency order.
 */
export function remapConfigForApply(block: PlannedBlock, resolvedIds: Map<string, string>): ResourceConfig {
  const def = getResourceDef(block.type);
  const config: ResourceConfig = { ...block.config };
  if (!def) return config;
  for (const f of def.configFields) {
    if (f.type === "resource-ref") {
      const v = config[f.key];
      if (typeof v === "string" && resolvedIds.has(v)) config[f.key] = resolvedIds.get(v)!;
    } else if (f.type === "resource-ref-multi") {
      const v = config[f.key];
      if (Array.isArray(v)) config[f.key] = (v as string[]).map((id) => resolvedIds.get(id) ?? id);
    }
  }
  return config;
}

export function computePlanSummary(blocks: PlannedBlock[]) {
  const applied = blocks.filter((b) => Boolean(b.appliedResourceId)).length;
  return { toAdd: blocks.length - applied, applied, total: blocks.length };
}

export interface PlanHcl {
  full: string;
  perBlock: Record<string, string>;
  resourceCount: number;
}

/** Concatenated Terraform for every staged block, in the order they were added. */
export function generatePlanHcl(blocks: PlannedBlock[]): PlanHcl {
  const nodes: Node<CanvasNodeData>[] = blocks.map((b, i) => ({
    id: b.id,
    type: "gcpNode",
    position: { x: (i % 4) * 260, y: Math.floor(i / 4) * 160 },
    data: { resourceType: b.type, label: blockDisplayName(b), config: b.config },
  }));
  const edges: Edge[] = [];
  const { perNode, resourceCount } = generateArchTerraform(nodes, edges);

  const header = `# ============================================================
# Generated by CloudVerse DevOps Academy — Terraform Lab (Build & Apply)
# ${blocks.length} planned resource${blocks.length === 1 ? "" : "s"}
#
# This is the real generateTerraform() output for each staged block,
# concatenated — the same generator and canonical-address convention
# (prod_vpc, prod_router, public_subnet_1 / private_subnet_1, web_lb,
# cloud_armor_policy) the Architecture Builder uses, so cross-resource
# references resolve the same way here.
# ============================================================
`;

  if (blocks.length === 0) {
    return { full: `${header}\n# Add resources from the catalog to generate Terraform.\n`, perBlock: perNode, resourceCount };
  }

  const body = blocks
    .map((b) => {
      const def = getResourceDef(b.type);
      const label = def?.label ?? b.type;
      const status = b.appliedResourceId ? "applied" : "planned";
      return `\n# --- ${label}: ${blockDisplayName(b)} (${status}) ---\n${perNode[b.id] ?? ""}`;
    })
    .join("\n");

  return { full: `${header}${body}\n`, perBlock: perNode, resourceCount };
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ResourceConfig } from "@/types/gcp";
import { randomId } from "@/lib/utils";

/**
 * A single "resource" block staged in the Terraform Lab's Build & Apply mode.
 * Blocks are authored via the same structured resource picker (and the same
 * ConfigForm / resource-ref binding fields) the GCP Console's Create wizard
 * uses — never free-form HCL parsing — so `apply` is guaranteed to always
 * succeed at creating something real and correctly configured.
 *
 * `appliedResourceId` is set once `terraform apply` has actually created this
 * block as a real resource in `useGcpConsoleStore`. Destroying it clears the
 * id back to undefined but keeps the block around so it can be re-applied.
 */
export interface PlannedBlock {
  id: string;
  type: string;
  config: ResourceConfig;
  appliedResourceId?: string;
}

interface TerraformLabState {
  blocks: PlannedBlock[];
  addBlock: (type: string, config: ResourceConfig) => string;
  updateBlockConfig: (id: string, patch: Partial<ResourceConfig>) => void;
  removeBlock: (id: string) => void;
  markApplied: (id: string, resourceId: string) => void;
  markDestroyed: (id: string) => void;
  clearAll: () => void;
}

export const useTerraformLabStore = create<TerraformLabState>()(
  persist(
    (set, get) => ({
      blocks: [],

      addBlock: (type, config) => {
        const id = randomId("tf");
        set({ blocks: [...get().blocks, { id, type, config }] });
        return id;
      },

      updateBlockConfig: (id, patch) => {
        set({
          blocks: get().blocks.map((b) =>
            b.id === id ? { ...b, config: { ...b.config, ...patch } as ResourceConfig } : b,
          ),
        });
      },

      removeBlock: (id) => {
        set({ blocks: get().blocks.filter((b) => b.id !== id) });
      },

      markApplied: (id, resourceId) => {
        set({ blocks: get().blocks.map((b) => (b.id === id ? { ...b, appliedResourceId: resourceId } : b)) });
      },

      markDestroyed: (id) => {
        set({ blocks: get().blocks.map((b) => (b.id === id ? { ...b, appliedResourceId: undefined } : b)) });
      },

      clearAll: () => set({ blocks: [] }),
    }),
    { name: "cloudverse-terraform-lab-store" },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import { DEFAULT_APP_CODE } from "@/components/cicd-simulator/sample-app";

export type DeployTarget = "cloud-run" | "gke" | "compute-engine";
export type DeploymentStatus = "success" | "failed" | "rolled-back";

export interface StageLogGroup {
  stageId: string;
  label: string;
  status: "success" | "failed" | "skipped";
  lines: { id: string; text: string; tone: "muted" | "info" | "success" | "error" }[];
}

export interface DeploymentEntry {
  id: string;
  version: number;
  timestamp: string;
  target: DeployTarget;
  status: DeploymentStatus;
  commitMessage: string;
  codeSnapshot: string;
  stageLogs: StageLogGroup[];
  /** Optional real resource (vm/mig/gke) from the GCP Console this deployment targets. */
  targetResourceId?: string;
}

/** What a "Deploy via CI/CD Pipeline" handoff from Docker Lab / Kubernetes Lab is bringing over. */
export type DeploySourceKind = "docker" | "kubernetes";

export interface DeploySource {
  kind: DeploySourceKind;
  summary: string;
}

interface CicdSimulatorState {
  code: string;
  deployments: DeploymentEntry[];
  deploySource?: DeploySource;
  setCode: (code: string) => void;
  recordDeployment: (entry: Omit<DeploymentEntry, "id" | "version" | "timestamp">) => void;
  rollbackTo: (id: string) => void;
  resetToDefault: () => void;
  setDeploySource: (source: DeploySource) => void;
  clearDeploySource: () => void;
}

export const useCicdSimulatorStore = create<CicdSimulatorState>()(
  persist(
    (set, get) => ({
      code: DEFAULT_APP_CODE,
      deployments: [],

      setCode: (code) => set({ code }),

      recordDeployment: (entry) => {
        const { deployments } = get();
        const nextVersion = (deployments[0]?.version ?? 0) + 1;
        const newEntry: DeploymentEntry = {
          ...entry,
          id: randomId("deploy"),
          version: nextVersion,
          timestamp: new Date().toISOString(),
        };
        set({ deployments: [newEntry, ...deployments] });
      },

      rollbackTo: (id) => {
        const { deployments } = get();
        const target = deployments.find((d) => d.id === id);
        if (!target) return;
        const nextVersion = (deployments[0]?.version ?? 0) + 1;
        const rollbackEntry: DeploymentEntry = {
          id: randomId("deploy"),
          version: nextVersion,
          timestamp: new Date().toISOString(),
          target: target.target,
          status: "rolled-back",
          commitMessage: `Rollback to v${target.version} ("${target.commitMessage}")`,
          codeSnapshot: target.codeSnapshot,
          stageLogs: target.stageLogs ?? [],
          targetResourceId: target.targetResourceId,
        };
        set({
          code: target.codeSnapshot,
          deployments: [rollbackEntry, ...deployments],
        });
      },

      resetToDefault: () => set({ code: DEFAULT_APP_CODE, deployments: [] }),

      setDeploySource: (source) => set({ deploySource: source }),
      clearDeploySource: () => set({ deploySource: undefined }),
    }),
    { name: "cloudverse-cicd-store" },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import type { StageLogGroup } from "@/store/cicd-simulator-store";

export type PlatformRunType = "apply" | "destroy";
export type PlatformRunStatus = "success" | "failed";

export interface PlatformRunEntry {
  id: string;
  version: number;
  timestamp: string;
  runType: PlatformRunType;
  status: PlatformRunStatus;
  /** Short human-readable outcome, e.g. "3 resources applied" or "2 resources destroyed". */
  summary: string;
  stageLogs: StageLogGroup[];
}

interface PlatformPipelineState {
  runs: PlatformRunEntry[];
  recordRun: (entry: Omit<PlatformRunEntry, "id" | "version" | "timestamp">) => void;
  clearHistory: () => void;
}

export const usePlatformPipelineStore = create<PlatformPipelineState>()(
  persist(
    (set, get) => ({
      runs: [],

      recordRun: (entry) => {
        const { runs } = get();
        const nextVersion = (runs[0]?.version ?? 0) + 1;
        const newEntry: PlatformRunEntry = {
          ...entry,
          id: randomId("run"),
          version: nextVersion,
          timestamp: new Date().toISOString(),
        };
        set({ runs: [newEntry, ...runs] });
      },

      clearHistory: () => set({ runs: [] }),
    }),
    { name: "cloudverse-platform-pipeline-store" },
  ),
);

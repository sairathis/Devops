import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId, slugify } from "@/lib/utils";

export interface ServiceAccount {
  id: string;
  name: string; // slug-like short id the user chose, e.g. "web-app-runner"
  displayName: string;
  email: string; // `${name}@cloudverse-demo.iam.gserviceaccount.com`
  description: string;
  roleIds: string[];
  disabled: boolean;
  createdAt: string;
}

export const SA_EMAIL_DOMAIN = "cloudverse-demo.iam.gserviceaccount.com";

function emailFor(name: string): string {
  return `${name}@${SA_EMAIL_DOMAIN}`;
}

interface IamState {
  serviceAccounts: ServiceAccount[];
  createServiceAccount: (name: string, displayName: string, description: string, roleIds: string[]) => string;
  deleteServiceAccount: (id: string) => void;
  grantRole: (saId: string, roleId: string) => void;
  revokeRole: (saId: string, roleId: string) => void;
  toggleDisabled: (saId: string) => void;
}

export const useIamStore = create<IamState>()(
  persist(
    (set, get) => ({
      // Seeded to match real GCP: every new project gets a Compute Engine
      // default service account, and it really does start with the broad
      // Editor role — a well-known real-world security anti-pattern.
      serviceAccounts: [
        {
          id: "sa-default-compute",
          name: "default",
          displayName: "Compute Engine default service account",
          email: emailFor("default"),
          description:
            "Automatically created for this project. Broad Editor access — a common real-world security anti-pattern; prefer creating narrowly-scoped service accounts instead.",
          roleIds: ["roles/editor"],
          disabled: false,
          createdAt: "2024-01-01T00:00:00.000Z",
        },
      ],

      createServiceAccount: (name, displayName, description, roleIds) => {
        const slug = slugify(name) || randomId("sa").slice(3);
        const id = randomId("sa");
        const account: ServiceAccount = {
          id,
          name: slug,
          displayName,
          email: emailFor(slug),
          description,
          roleIds: [...roleIds],
          disabled: false,
          createdAt: new Date().toISOString(),
        };
        set({ serviceAccounts: [...get().serviceAccounts, account] });
        return id;
      },

      deleteServiceAccount: (id) => {
        set({ serviceAccounts: get().serviceAccounts.filter((sa) => sa.id !== id) });
      },

      grantRole: (saId, roleId) => {
        set({
          serviceAccounts: get().serviceAccounts.map((sa) =>
            sa.id === saId && !sa.roleIds.includes(roleId)
              ? { ...sa, roleIds: [...sa.roleIds, roleId] }
              : sa,
          ),
        });
      },

      revokeRole: (saId, roleId) => {
        set({
          serviceAccounts: get().serviceAccounts.map((sa) =>
            sa.id === saId ? { ...sa, roleIds: sa.roleIds.filter((r) => r !== roleId) } : sa,
          ),
        });
      },

      toggleDisabled: (saId) => {
        set({
          serviceAccounts: get().serviceAccounts.map((sa) =>
            sa.id === saId ? { ...sa, disabled: !sa.disabled } : sa,
          ),
        });
      },
    }),
    { name: "cloudverse-iam-store" },
  ),
);

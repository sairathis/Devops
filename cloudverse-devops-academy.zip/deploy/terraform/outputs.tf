output "vpc_id" {
  value       = google_compute_network.vpc.id
  description = "Self link of the VPC network"
}

output "gke_cluster_name" {
  value       = google_container_cluster.gke.name
  description = "GKE Autopilot cluster name"
}

output "gke_cluster_endpoint" {
  value       = google_container_cluster.gke.endpoint
  description = "GKE control plane endpoint (private)"
  sensitive   = true
}

output "artifact_registry_repository" {
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.images.repository_id}"
  description = "Push images here, e.g. docker push <this>/frontend:latest"
}

output "cloud_sql_connection_name" {
  value       = google_sql_database_instance.postgres.connection_name
  description = "Use with the Cloud SQL Auth Proxy, or build a private DATABASE_URL from the instance's private IP"
}

output "app_service_account_email" {
  value       = google_service_account.app.email
  description = "Workload Identity-bound service account for the backend pod"
}

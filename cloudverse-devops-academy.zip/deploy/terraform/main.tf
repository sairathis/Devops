# ============================================================================
# CloudVerse DevOps Academy — reference infrastructure
#
# This deploys the same reference architecture the platform teaches in its
# own Architecture Builder and Networking Academy modules: a custom-mode VPC
# with public/private subnets, Cloud NAT for private egress, a private GKE
# Autopilot cluster, Cloud SQL for PostgreSQL, and Artifact Registry for
# container images. It's meant as a realistic starting point, not a
# one-click production deploy — review sizing, IAM scope, and backup policy
# before applying this against a real project.
# ============================================================================

locals {
  name = "cloudverse-${var.environment}"
}

# ---------------------------------------------------------------------------
# Networking
# ---------------------------------------------------------------------------

resource "google_compute_network" "vpc" {
  name                    = "${local.name}-vpc"
  auto_create_subnetworks = false
  routing_mode            = "REGIONAL"
}

resource "google_compute_subnetwork" "public" {
  name                     = "${local.name}-public-subnet"
  ip_cidr_range            = "10.10.0.0/20"
  region                   = var.region
  network                  = google_compute_network.vpc.id
  private_ip_google_access = true
}

resource "google_compute_subnetwork" "private" {
  name                     = "${local.name}-private-subnet"
  ip_cidr_range            = "10.20.0.0/20"
  region                   = var.region
  network                  = google_compute_network.vpc.id
  private_ip_google_access = true

  secondary_ip_range {
    range_name    = "gke-pods"
    ip_cidr_range = "10.30.0.0/16"
  }
  secondary_ip_range {
    range_name    = "gke-services"
    ip_cidr_range = "10.40.0.0/20"
  }
}

resource "google_compute_router" "router" {
  name    = "${local.name}-router"
  region  = var.region
  network = google_compute_network.vpc.id
}

resource "google_compute_router_nat" "nat" {
  name                               = "${local.name}-nat"
  router                             = google_compute_router.router.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
}

resource "google_compute_firewall" "allow_internal" {
  name          = "${local.name}-allow-internal"
  network       = google_compute_network.vpc.id
  direction     = "INGRESS"
  source_ranges = ["10.10.0.0/20", "10.20.0.0/20"]
  allow {
    protocol = "tcp"
  }
  allow {
    protocol = "udp"
  }
  allow {
    protocol = "icmp"
  }
}

resource "google_compute_firewall" "allow_health_checks" {
  name          = "${local.name}-allow-health-checks"
  network       = google_compute_network.vpc.id
  direction     = "INGRESS"
  source_ranges = ["130.211.0.0/22", "35.191.0.0/16"]
  allow {
    protocol = "tcp"
  }
}

# ---------------------------------------------------------------------------
# GKE Autopilot cluster — runs the frontend + backend containers
# ---------------------------------------------------------------------------

resource "google_container_cluster" "gke" {
  provider         = google-beta
  name             = "${local.name}-gke"
  location         = var.region
  enable_autopilot = true

  network    = google_compute_network.vpc.id
  subnetwork = google_compute_subnetwork.private.id

  ip_allocation_policy {
    cluster_secondary_range_name  = "gke-pods"
    services_secondary_range_name = "gke-services"
  }

  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }

  release_channel {
    channel = "REGULAR"
  }

  workload_identity_config {
    workload_pool = "${var.project_id}.svc.id.goog"
  }

  deletion_protection = true
}

# ---------------------------------------------------------------------------
# Cloud SQL for PostgreSQL — application database
# ---------------------------------------------------------------------------

resource "google_sql_database_instance" "postgres" {
  name             = "${local.name}-db"
  database_version = "POSTGRES_16"
  region           = var.region

  settings {
    tier              = var.db_tier
    availability_type = "REGIONAL"
    disk_autoresize   = true

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
    }

    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.vpc.id
      require_ssl     = true
    }
  }

  deletion_protection = true
  depends_on          = [google_service_networking_connection.private_vpc_connection]
}

resource "google_sql_database" "app" {
  name     = "cloudverse_devops_academy"
  instance = google_sql_database_instance.postgres.name
}

resource "google_sql_user" "app" {
  name     = "cloudverse"
  instance = google_sql_database_instance.postgres.name
  password = var.db_password
}

resource "google_compute_global_address" "private_ip_range" {
  name          = "${local.name}-private-ip-range"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = google_compute_network.vpc.id
}

resource "google_service_networking_connection" "private_vpc_connection" {
  network                 = google_compute_network.vpc.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.private_ip_range.name]
}

# ---------------------------------------------------------------------------
# Artifact Registry — container images for frontend + backend
# ---------------------------------------------------------------------------

resource "google_artifact_registry_repository" "images" {
  location      = var.region
  repository_id = "cloudverse"
  format        = "DOCKER"
  docker_config {
    immutable_tags = true
  }
}

# ---------------------------------------------------------------------------
# Workload Identity service account for the app's pods
# ---------------------------------------------------------------------------

resource "google_service_account" "app" {
  account_id   = "${local.name}-app"
  display_name = "CloudVerse DevOps Academy application identity"
}

resource "google_project_iam_member" "app_sql_client" {
  project = var.project_id
  role    = "roles/cloudsql.client"
  member  = "serviceAccount:${google_service_account.app.email}"
}

resource "google_service_account_iam_member" "workload_identity_binding" {
  service_account_id = google_service_account.app.name
  role                = "roles/iam.workloadIdentityUser"
  member              = "serviceAccount:${var.project_id}.svc.id.goog[cloudverse/cloudverse-backend]"
}

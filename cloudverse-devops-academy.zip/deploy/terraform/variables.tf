variable "project_id" {
  description = "GCP project ID to deploy CloudVerse DevOps Academy into"
  type        = string
}

variable "region" {
  description = "Primary GCP region"
  type        = string
  default     = "us-central1"
}

variable "environment" {
  description = "Deployment environment name, used as a resource-naming suffix"
  type        = string
  default     = "prod"
}

variable "gke_min_node_count" {
  description = "Minimum nodes per zone for the GKE Standard node pool (ignored in Autopilot mode)"
  type        = number
  default     = 1
}

variable "gke_max_node_count" {
  description = "Maximum nodes per zone for the GKE Standard node pool (ignored in Autopilot mode)"
  type        = number
  default     = 5
}

variable "db_tier" {
  description = "Cloud SQL machine tier"
  type        = string
  default     = "db-custom-2-8192"
}

variable "db_password" {
  description = "Password for the application database user (pass via TF_VAR_db_password or a secret manager data source — never commit this)"
  type        = string
  sensitive   = true
}

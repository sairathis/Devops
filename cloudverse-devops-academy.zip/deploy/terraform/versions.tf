terraform {
  required_version = ">= 1.5"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "~> 5.0"
    }
  }

  # Uncomment and configure for team use — local state is fine for a demo,
  # but a shared GCS backend is what CloudVerse teaches in the Terraform Lab.
  # backend "gcs" {
  #   bucket = "cloudverse-devops-academy-tfstate"
  #   prefix = "infra/prod"
  # }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}

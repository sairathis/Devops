# Deployment

Three ways to run CloudVerse DevOps Academy beyond `npm run dev`, from simplest to most production-like.

## 1. Docker Compose (local full stack)

From the repo root:

```bash
docker compose up --build
```

This builds and runs:

- `postgres` — Postgres 16, seeded with an empty `cloudverse_devops_academy` database
- `backend` — the NestJS API on `http://localhost:4000` (Swagger UI at `/api/docs`), started with `AUTH_DEV_BYPASS=true` so you don't need real Firebase credentials to explore it
- `frontend` — the Next.js app on `http://localhost:3000`
- `adminer` — a lightweight DB browser on `http://localhost:8080` (server: `postgres`, user/pass: `cloudverse`/`cloudverse`)

The backend won't have run its Prisma migrations automatically — once the containers are up, run:

```bash
docker compose exec backend npx prisma migrate deploy
```

## 2. Kubernetes (`deploy/kubernetes/`)

Manifests are numbered in apply order and assume images already pushed to a registry (see the Terraform section below for one way to get an Artifact Registry). They target GKE by default (`kubernetes.io/ingress.class: "gce"` in the Ingress) but the Deployments/Services are portable to any cluster.

```bash
kubectl apply -f deploy/kubernetes/00-namespace.yaml
kubectl apply -f deploy/kubernetes/01-configmap.yaml
cp deploy/kubernetes/02-secret.example.yaml deploy/kubernetes/02-secret.yaml
# edit 02-secret.yaml with real values, then:
kubectl apply -f deploy/kubernetes/02-secret.yaml
kubectl apply -f deploy/kubernetes/10-postgres.yaml   # skip if using Cloud SQL instead
kubectl apply -f deploy/kubernetes/20-backend.yaml
kubectl apply -f deploy/kubernetes/30-frontend.yaml
kubectl apply -f deploy/kubernetes/40-ingress.yaml
```

Before applying, replace the placeholder image references (`REGION-docker.pkg.dev/PROJECT_ID/cloudverse/...`) in `20-backend.yaml` and `30-frontend.yaml` with your actual Artifact Registry path, and the placeholder `host` in `40-ingress.yaml`.

`10-postgres.yaml` runs a single-replica, non-HA Postgres `StatefulSet` — fine for trying the app on Kubernetes, not a substitute for a managed database. For anything real, provision Cloud SQL (see below) and point `DATABASE_URL` in your secret at it instead, skipping `10-postgres.yaml` entirely.

## 3. Terraform (`deploy/terraform/`) — GCP reference infrastructure

Provisions the same architecture the platform teaches in its own Architecture Builder and Networking Academy modules: a custom-mode VPC with public/private subnets, Cloud Router + Cloud NAT, a private GKE Autopilot cluster with Workload Identity, Cloud SQL for PostgreSQL (private IP, regional HA, automated backups), and an Artifact Registry repository.

```bash
cd deploy/terraform
cp terraform.tfvars.example terraform.tfvars   # fill in project_id, region, etc.
terraform init
terraform plan -var="db_password=$(openssl rand -base64 24)"
terraform apply -var="db_password=..."          # reuse the same password from plan
```

**Before you `apply` against a real project:** this was authored and reviewed for correctness but not run through `terraform validate` or `terraform plan` in this environment (no network access to the Terraform provider registry here) — read through `main.tf` once, confirm the sizing (`db_tier`, `gke_max_node_count`) and the `deletion_protection = true` settings match your intent, and consider enabling the commented-out `backend "gcs"` block in `versions.tf` for shared state before a team uses this.

After `apply`, `terraform output` gives you the Artifact Registry path and Cloud SQL connection name you'll need to fill into the Kubernetes secret and to push images:

```bash
gcloud auth configure-docker $(terraform output -raw artifact_registry_repository | cut -d/ -f1)
docker build -t $(terraform output -raw artifact_registry_repository)/frontend:latest .
docker push $(terraform output -raw artifact_registry_repository)/frontend:latest
docker build -t $(terraform output -raw artifact_registry_repository)/backend:latest ./backend
docker push $(terraform output -raw artifact_registry_repository)/backend:latest
```

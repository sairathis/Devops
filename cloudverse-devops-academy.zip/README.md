# CloudVerse DevOps Academy

The hands-on GCP & DevOps learning platform: build cloud architectures visually, watch traffic actually flow through them, generate real Terraform automatically, and learn every concept by doing rather than reading.

Two modules are the heart of the platform:

- **Architecture Builder** — a drag-and-drop canvas (React Flow) with 18 real GCP resource types. Every resource you place gets a configuration form, learning notes, a troubleshooting guide, a quiz question, and live-generated Terraform HCL — automatically, every time. Auto-arrange, and export your diagram as PNG, SVG, or PDF.
- **Networking Academy** — an animated topology (Internet → Load Balancer → public subnet → private subnet → Cloud SQL) that simulates inbound traffic, outbound traffic, east-west traffic, load-balancer routing, NAT translation, and DNS resolution, with an editable firewall rule set that actually gates whether traffic gets through.

Twelve more modules round out the platform: GCP Services catalog, Terraform Lab, Docker Lab, Kubernetes Lab, CI/CD Simulator, Monitoring Academy, Troubleshooting Center, Certification Paths, Quiz Engine, Resource Explorer, User Progress, and a Dashboard tying it all together with XP, streaks, and badges.

## Tech stack

| Layer | Choices |
|---|---|
| Frontend | Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS v4, shadcn-style UI components, Framer Motion, React Flow, Zustand, Recharts |
| Backend | NestJS, TypeScript, PostgreSQL, Prisma ORM — modular monolith (see `backend/`) |
| Auth | Firebase Auth (backend scaffold verifies Firebase ID tokens) |
| Deployment | Docker, Kubernetes, Terraform (see `deploy/`) |

## Project layout

```
.
├── src/                  Next.js frontend (the app you'll actually run first)
│   ├── app/              One route per module (14 total)
│   ├── components/       Shared UI kit + one folder per module
│   ├── lib/               GCP resource catalog, Terraform generation, quiz bank
│   ├── store/             Zustand stores (architecture canvas, progress, networking, ui)
│   └── types/
├── backend/              NestJS + Prisma modular-monolith API scaffold (standalone, not yet wired to the frontend — see backend/README.md)
├── deploy/
│   ├── docker/            (Dockerfiles live at the repo root and in backend/)
│   ├── kubernetes/        Manifests: namespace, config/secrets, Postgres, backend, frontend, ingress, HPAs
│   └── terraform/         GCP reference infrastructure: VPC, private GKE Autopilot, Cloud SQL, Artifact Registry
├── Dockerfile             Frontend production image (multi-stage, Next.js standalone output)
├── docker-compose.yml     Full local stack: postgres + backend + frontend + adminer
└── deploy/README.md       Deployment instructions for all three paths above
```

## Running the frontend (the main deliverable)

This is a self-contained frontend-first prototype — all state (your architecture diagrams, quiz scores, progress, XP) lives in the browser via Zustand + localStorage, so there's nothing to configure to start exploring:

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Press **⌘K** / **Ctrl+K** anywhere to search modules and GCP resources.

To build and run the production bundle:

```bash
npm run build
npm start
```

## Running the backend

The `backend/` folder is a genuine, independently buildable NestJS + Prisma API demonstrating the platform's intended modular-monolith architecture (Projects, Progress, Certifications, Resources, Users, Auth, Health modules) — it is **not wired up to the frontend yet** by design (this delivery is a frontend-first prototype per spec). To explore it on its own:

```bash
cd backend
npm install
cp .env.example .env       # fill in DATABASE_URL, or use docker-compose's postgres service
npx prisma generate
npx prisma migrate dev
npm run start:dev
```

Swagger UI: `http://localhost:4000/api/docs`. Set `AUTH_DEV_BYPASS=true` in `.env` to skip real Firebase token verification while developing locally. See `backend/README.md` for the full endpoint list and schema.

## Running everything together

```bash
docker compose up --build
```

See [`deploy/README.md`](./deploy/README.md) for Docker Compose, Kubernetes, and Terraform instructions in full, including how to provision real GCP infrastructure for this app with the included Terraform.

## Notes on scope

This was built as a working prototype prioritizing depth on the two flagship modules (Architecture Builder, Networking Academy) over shallow coverage of all fourteen — the remaining twelve are fully functional and interactive, built on the same design system and shared data (the 18-resource GCP catalog, the quiz bank, the progress store), but intentionally simpler than the two flagship builds. The backend is a structural scaffold: real NestJS modules and a real Prisma schema, verified to compile, but not connected to the running frontend or a live database in this delivery.

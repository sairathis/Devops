# CloudVerse DevOps Academy - Backend

This is the backend **scaffold** for CloudVerse DevOps Academy: a NestJS +
TypeScript + PostgreSQL (Prisma) modular monolith, authenticated with
Firebase Auth.

**Status:** this is a structural scaffold that demonstrates the intended
backend architecture and a real, buildable API surface (in-memory logic
where a database call isn't needed, Prisma-backed logic everywhere else). It
is **not yet wired up** to the Next.js frontend in `../src` - the frontend
currently runs standalone against local/mock state. Wiring them together
(swapping the frontend's local state for real fetch calls against this API,
and adding a Firebase client SDK on the frontend to obtain ID tokens) is
future work.

## Architecture

A "modular monolith": one NestJS application, one deployable unit, but
internally organized into self-contained feature modules that each own their
controller/service/DTOs, similar to how you'd eventually split the app into
services if needed.

```
src/
  prisma/          Global PrismaService + PrismaModule (DB access)
  auth/             FirebaseAuthGuard, @CurrentUser() decorator, AuthModule
  users/            User profile (just-in-time provisioning from Firebase)
  projects/         CRUD for saved Architecture Builder diagrams
  progress/         Module progress, quiz attempts, badges
  certifications/   Certification path topic completion tracking
  resources/        Static catalog of GCP resource metadata
  health/           Liveness endpoint
  app.module.ts     Wires all of the above together
  main.ts           Bootstrap: ValidationPipe, CORS, /api prefix, Swagger
```

## Data model (Prisma / PostgreSQL)

See `prisma/schema.prisma`. Models: `User`, `Project`, `ModuleProgress`,
`QuizAttempt`, `Badge`, `CertificationTopicCompletion`.

## Authentication

Protected routes are guarded by `FirebaseAuthGuard`, which expects
`Authorization: Bearer <Firebase ID token>` and verifies it with
`firebase-admin`'s `getAuth().verifyIdToken()`.

Firebase Admin initialization is lazy and wrapped in try/catch: if
`FIREBASE_PROJECT_ID` / `FIREBASE_CLIENT_EMAIL` / `FIREBASE_PRIVATE_KEY`
aren't set, the app still boots (unprotected routes like `/api/health` and
`/api/resources` keep working); protected routes will reject with 401 until
credentials are provided or dev bypass is enabled.

### Dev bypass

Set `AUTH_DEV_BYPASS=true` in `.env` to skip real token verification and
authenticate every request as a fake local user
(`dev-user@cloudverse.local`). This lets you exercise every protected
endpoint locally without a configured Firebase project. **Never enable this
in production.**

## Running locally

```bash
cp .env.example .env
# Edit .env: point DATABASE_URL at a local/dev PostgreSQL instance
# (the frontend repo may eventually provide a docker-compose for this;
# in the meantime any local Postgres 14+ works), and either fill in the
# FIREBASE_* variables or leave AUTH_DEV_BYPASS=true for local dev.

npm install
npx prisma generate       # generates the Prisma client from schema.prisma
npx prisma migrate dev    # creates the database schema (requires a live DB)

npm run start:dev         # starts the API on http://localhost:3001
```

Swagger UI is served at `http://localhost:3001/api/docs` once the app is
running.

> Note: `prisma generate` only reads `schema.prisma` and does not need a
> live database connection, so it works even before Postgres is set up.
> `prisma migrate dev` and `start:dev` do need a reachable PostgreSQL
> instance.

## Endpoints

All routes are mounted under the `/api` prefix. Routes marked **auth**
require a Bearer token (or `AUTH_DEV_BYPASS=true`).

| Method | Path                                              | Auth | Description                                   |
| ------ | ------------------------------------------------- | ---- | ---------------------------------------------- |
| GET    | `/api/health`                                     | no   | Liveness check                                 |
| GET    | `/api/resources`                                  | no   | Static catalog of GCP resource types           |
| GET    | `/api/users/me`                                   | yes  | Current user's profile (JIT-provisioned)       |
| GET    | `/api/projects`                                   | yes  | List the caller's saved architecture diagrams  |
| GET    | `/api/projects/:id`                               | yes  | Get one saved diagram                          |
| POST   | `/api/projects`                                   | yes  | Create a saved diagram                         |
| PATCH  | `/api/projects/:id`                               | yes  | Update a saved diagram                         |
| DELETE | `/api/projects/:id`                               | yes  | Delete a saved diagram                         |
| GET    | `/api/progress/me`                                | yes  | Aggregate progress: modules, XP, badges, quiz  |
| POST   | `/api/progress/module`                            | yes  | Upsert progress for one learning module        |
| POST   | `/api/progress/quiz-attempt`                      | yes  | Record a quiz attempt                          |
| POST   | `/api/progress/badge`                             | yes  | Award (upsert) a badge                         |
| POST   | `/api/certifications/:pathId/topics/:topicId/toggle` | yes | Toggle completion of a certification topic  |
| GET    | `/api/certifications/me`                          | yes  | Get the caller's certification progress        |

Full request/response schemas are available in Swagger at `/api/docs`.

## Scripts

- `npm run build` - compiles with `nest build` (tsc under the hood)
- `npm run start:dev` - runs with hot reload
- `npm test` - unit tests (Jest)
- `npm run test:e2e` - end-to-end tests against an in-memory Nest app
- `npm run prisma:generate` - regenerate the Prisma client
- `npm run prisma:migrate` - run Prisma migrations against `DATABASE_URL`

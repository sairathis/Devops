import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FirebaseAuthGuard } from '../auth/firebase-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthenticatedUser } from '../auth/auth.types';
import { UsersService } from '../users/users.service';
import { CertificationsService } from './certifications.service';

@ApiTags('certifications')
@ApiBearerAuth()
@UseGuards(FirebaseAuthGuard)
@Controller('certifications')
export class CertificationsController {
  constructor(
    private readonly certificationsService: CertificationsService,
    private readonly usersService: UsersService,
  ) {}

  @Post(':pathId/topics/:topicId/toggle')
  async toggleTopic(
    @CurrentUser() authUser: AuthenticatedUser,
    @Param('pathId') pathId: string,
    @Param('topicId') topicId: string,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.certificationsService.toggleTopic(user.id, pathId, topicId);
  }

  @Get('me')
  async getMe(@CurrentUser() authUser: AuthenticatedUser) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.certificationsService.getMyCompletions(user.id);
  }
}

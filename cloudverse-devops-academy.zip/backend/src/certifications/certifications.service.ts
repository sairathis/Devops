import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CertificationsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Toggles completion of a single topic within a certification path: if the
   * topic is already marked complete for this user it is un-marked, and vice
   * versa.
   */
  async toggleTopic(userId: string, pathId: string, topicId: string) {
    const existing = await this.prisma.certificationTopicCompletion.findUnique(
      {
        where: {
          userId_pathId_topicId: { userId, pathId, topicId },
        },
      },
    );

    if (existing) {
      await this.prisma.certificationTopicCompletion.delete({
        where: { id: existing.id },
      });
      return { pathId, topicId, completed: false };
    }

    await this.prisma.certificationTopicCompletion.create({
      data: { userId, pathId, topicId },
    });
    return { pathId, topicId, completed: true };
  }

  /**
   * Returns every completed topic for the user, grouped by certification
   * path, e.g. { "associate-cloud-engineer": ["iam-basics", "vpc-networking"] }.
   */
  async getMyCompletions(userId: string) {
    const rows = await this.prisma.certificationTopicCompletion.findMany({
      where: { userId },
      orderBy: { completedAt: 'asc' },
    });

    const byPath: Record<string, string[]> = {};
    for (const row of rows) {
      if (!byPath[row.pathId]) {
        byPath[row.pathId] = [];
      }
      byPath[row.pathId].push(row.topicId);
    }

    return { paths: byPath, totalCompletedTopics: rows.length };
  }
}

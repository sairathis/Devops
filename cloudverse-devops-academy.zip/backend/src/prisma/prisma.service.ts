import {
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Thin wrapper around PrismaClient that hooks into the Nest lifecycle so the
 * database connection is opened/closed alongside the application.
 */
@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  private readonly logger = new Logger(PrismaService.name);

  async onModuleInit(): Promise<void> {
    try {
      await this.$connect();
      this.logger.log('Connected to PostgreSQL via Prisma');
    } catch (error) {
      // This scaffold is expected to run in environments without a live
      // Postgres instance available (e.g. CI, first-time setup). We log the
      // failure instead of crashing the whole app at boot so that
      // non-database routes (health, resources, swagger) remain usable.
      this.logger.warn(
        `Could not connect to the database at startup: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }
}

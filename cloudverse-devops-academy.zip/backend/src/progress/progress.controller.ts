import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FirebaseAuthGuard } from '../auth/firebase-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthenticatedUser } from '../auth/auth.types';
import { UsersService } from '../users/users.service';
import { ProgressService } from './progress.service';
import { UpsertModuleProgressDto } from './dto/upsert-module-progress.dto';
import { CreateQuizAttemptDto } from './dto/create-quiz-attempt.dto';
import { AwardBadgeDto } from './dto/award-badge.dto';

@ApiTags('progress')
@ApiBearerAuth()
@UseGuards(FirebaseAuthGuard)
@Controller('progress')
export class ProgressController {
  constructor(
    private readonly progressService: ProgressService,
    private readonly usersService: UsersService,
  ) {}

  @Get('me')
  async getMe(@CurrentUser() authUser: AuthenticatedUser) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.progressService.getAggregateForUser(user.id);
  }

  @Post('module')
  async upsertModule(
    @CurrentUser() authUser: AuthenticatedUser,
    @Body() dto: UpsertModuleProgressDto,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.progressService.upsertModuleProgress(user.id, dto);
  }

  @Post('quiz-attempt')
  async createQuizAttempt(
    @CurrentUser() authUser: AuthenticatedUser,
    @Body() dto: CreateQuizAttemptDto,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.progressService.createQuizAttempt(user.id, dto);
  }

  @Post('badge')
  async awardBadge(
    @CurrentUser() authUser: AuthenticatedUser,
    @Body() dto: AwardBadgeDto,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.progressService.awardBadge(user.id, dto);
  }
}

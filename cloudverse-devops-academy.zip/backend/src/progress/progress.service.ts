import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpsertModuleProgressDto } from './dto/upsert-module-progress.dto';
import { CreateQuizAttemptDto } from './dto/create-quiz-attempt.dto';
import { AwardBadgeDto } from './dto/award-badge.dto';

@Injectable()
export class ProgressService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Aggregates everything the frontend dashboard needs in one call: module
   * progress rows, total XP across all modules, earned badges and simple
   * quiz statistics.
   */
  async getAggregateForUser(userId: string) {
    const [modules, badges, quizAttempts] = await Promise.all([
      this.prisma.moduleProgress.findMany({
        where: { userId },
        orderBy: { lastVisitedAt: 'desc' },
      }),
      this.prisma.badge.findMany({
        where: { userId },
        orderBy: { earnedAt: 'desc' },
      }),
      this.prisma.quizAttempt.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    const totalXp = modules.reduce((sum, m) => sum + m.xp, 0);
    const totalCorrect = quizAttempts.reduce((sum, q) => sum + q.correct, 0);
    const totalQuestions = quizAttempts.reduce((sum, q) => sum + q.total, 0);

    return {
      modules,
      totalXp,
      badges,
      quiz: {
        attempts: quizAttempts,
        totalAttempts: quizAttempts.length,
        totalCorrect,
        totalQuestions,
        accuracy:
          totalQuestions > 0
            ? Math.round((totalCorrect / totalQuestions) * 100)
            : 0,
      },
    };
  }

  async upsertModuleProgress(userId: string, dto: UpsertModuleProgressDto) {
    return this.prisma.moduleProgress.upsert({
      where: { userId_moduleId: { userId, moduleId: dto.moduleId } },
      create: {
        userId,
        moduleId: dto.moduleId,
        percent: dto.percent,
        xp: dto.xp,
      },
      update: {
        percent: dto.percent,
        xp: dto.xp,
        lastVisitedAt: new Date(),
      },
    });
  }

  async createQuizAttempt(userId: string, dto: CreateQuizAttemptDto) {
    return this.prisma.quizAttempt.create({
      data: {
        userId,
        topic: dto.topic,
        correct: dto.correct,
        total: dto.total,
      },
    });
  }

  async awardBadge(userId: string, dto: AwardBadgeDto) {
    return this.prisma.badge.upsert({
      where: { userId_badgeKey: { userId, badgeKey: dto.badgeKey } },
      create: { userId, badgeKey: dto.badgeKey },
      update: {},
    });
  }
}

import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString, Min } from 'class-validator';

export class CreateQuizAttemptDto {
  @ApiProperty({ example: 'iam-fundamentals' })
  @IsString()
  @IsNotEmpty()
  topic!: string;

  @ApiProperty({ minimum: 0 })
  @IsInt()
  @Min(0)
  correct!: number;

  @ApiProperty({ minimum: 0 })
  @IsInt()
  @Min(0)
  total!: number;
}

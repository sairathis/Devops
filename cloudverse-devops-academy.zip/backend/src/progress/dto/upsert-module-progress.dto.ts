import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsString, Max, Min } from 'class-validator';

export class UpsertModuleProgressDto {
  @ApiProperty({ description: 'Stable identifier of the learning module', example: 'compute-engine' })
  @IsString()
  @IsNotEmpty()
  moduleId!: string;

  @ApiProperty({ minimum: 0, maximum: 100 })
  @IsInt()
  @Min(0)
  @Max(100)
  percent!: number;

  @ApiProperty({ minimum: 0, description: 'XP earned so far in this module' })
  @IsInt()
  @Min(0)
  xp!: number;
}

import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class AwardBadgeDto {
  @ApiProperty({ example: 'first-deployment', description: 'Stable key identifying the badge' })
  @IsString()
  @IsNotEmpty()
  badgeKey!: string;
}

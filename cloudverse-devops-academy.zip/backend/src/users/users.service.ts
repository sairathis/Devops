import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { User } from '@prisma/client';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Finds the User row matching an authenticated Firebase principal,
   * creating it on first sight ("just-in-time" provisioning). This is the
   * bridge between Firebase Auth identities and our own User records.
   */
  async findOrCreateFromFirebase(
    authUser: AuthenticatedUser,
  ): Promise<User> {
    const existing = await this.prisma.user.findUnique({
      where: { firebaseUid: authUser.firebaseUid },
    });
    if (existing) {
      return existing;
    }

    return this.prisma.user.create({
      data: {
        firebaseUid: authUser.firebaseUid,
        email: authUser.email || `${authUser.firebaseUid}@unknown.local`,
        displayName: authUser.displayName,
      },
    });
  }

  async findById(id: string): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { id } });
  }
}

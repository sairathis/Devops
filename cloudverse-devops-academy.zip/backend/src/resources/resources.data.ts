export type ResourceCategory =
  | 'networking'
  | 'compute'
  | 'storage'
  | 'database'
  | 'containers'
  | 'cicd'
  | 'security'
  | 'messaging';

export interface GcpResourceSummary {
  type: string;
  label: string;
  category: ResourceCategory;
  description: string;
}

/**
 * Compact, backend-owned catalog of GCP resource types. This intentionally
 * mirrors the taxonomy used by the frontend's Architecture Builder
 * (see src/types/gcp.ts) without depending on it, demonstrating the shape a
 * real client would fetch from GET /api/resources.
 */
export const GCP_RESOURCES: GcpResourceSummary[] = [
  {
    type: 'compute-engine',
    label: 'Compute Engine',
    category: 'compute',
    description: 'Configurable virtual machines running in Google Cloud, billed per second.',
  },
  {
    type: 'cloud-run',
    label: 'Cloud Run',
    category: 'compute',
    description: 'Fully managed platform for running stateless containers that scale to zero.',
  },
  {
    type: 'cloud-functions',
    label: 'Cloud Functions',
    category: 'compute',
    description: 'Event-driven serverless functions for lightweight, single-purpose code.',
  },
  {
    type: 'gke',
    label: 'Google Kubernetes Engine',
    category: 'containers',
    description: 'Managed Kubernetes cluster for orchestrating containerized workloads.',
  },
  {
    type: 'artifact-registry',
    label: 'Artifact Registry',
    category: 'containers',
    description: 'Managed registry for storing and versioning container images and packages.',
  },
  {
    type: 'vpc-network',
    label: 'VPC Network',
    category: 'networking',
    description: 'Global, software-defined private network connecting your GCP resources.',
  },
  {
    type: 'cloud-load-balancer',
    label: 'Cloud Load Balancing',
    category: 'networking',
    description: 'Globally distributed load balancing for HTTP(S), TCP and UDP traffic.',
  },
  {
    type: 'cloud-cdn',
    label: 'Cloud CDN',
    category: 'networking',
    description: 'Content delivery network that caches content at Google edge locations.',
  },
  {
    type: 'cloud-dns',
    label: 'Cloud DNS',
    category: 'networking',
    description: 'Managed, highly available DNS hosting service.',
  },
  {
    type: 'cloud-storage',
    label: 'Cloud Storage',
    category: 'storage',
    description: 'Unified object storage for unstructured data, from hot to archival tiers.',
  },
  {
    type: 'cloud-sql',
    label: 'Cloud SQL',
    category: 'database',
    description: 'Fully managed relational database service for MySQL, PostgreSQL and SQL Server.',
  },
  {
    type: 'firestore',
    label: 'Firestore',
    category: 'database',
    description: 'Serverless NoSQL document database with real-time sync and offline support.',
  },
  {
    type: 'bigquery',
    label: 'BigQuery',
    category: 'database',
    description: 'Serverless, highly scalable data warehouse for analytics at petabyte scale.',
  },
  {
    type: 'cloud-build',
    label: 'Cloud Build',
    category: 'cicd',
    description: 'Serverless CI/CD platform for building, testing and deploying software.',
  },
  {
    type: 'cloud-deploy',
    label: 'Cloud Deploy',
    category: 'cicd',
    description: 'Managed continuous delivery service for automating releases to GKE and Cloud Run.',
  },
  {
    type: 'iam',
    label: 'Identity and Access Management',
    category: 'security',
    description: 'Fine-grained access control for GCP resources based on roles and policies.',
  },
  {
    type: 'secret-manager',
    label: 'Secret Manager',
    category: 'security',
    description: 'Centralized, encrypted storage and versioning of API keys and credentials.',
  },
  {
    type: 'pub-sub',
    label: 'Pub/Sub',
    category: 'messaging',
    description: 'Asynchronous, globally distributed messaging service for event-driven systems.',
  },
];

import { ResourcesService } from './resources.service';

describe('ResourcesService', () => {
  const service = new ResourcesService();

  it('returns a non-empty catalog', () => {
    const result = service.findAll();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });

  it('returns entries with unique type identifiers', () => {
    const result = service.findAll();
    const types = result.map((r) => r.type);
    expect(new Set(types).size).toBe(types.length);
  });

  it('every entry has the required fields', () => {
    const result = service.findAll();
    for (const entry of result) {
      expect(entry.type).toBeTruthy();
      expect(entry.label).toBeTruthy();
      expect(entry.category).toBeTruthy();
      expect(entry.description).toBeTruthy();
    }
  });
});

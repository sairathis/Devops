import { Injectable } from '@nestjs/common';
import { GCP_RESOURCES, GcpResourceSummary } from './resources.data';

@Injectable()
export class ResourcesService {
  findAll(): GcpResourceSummary[] {
    return GCP_RESOURCES;
  }
}

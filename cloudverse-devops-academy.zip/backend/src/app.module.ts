import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { ProjectsModule } from './projects/projects.module';
import { ProgressModule } from './progress/progress.module';
import { CertificationsModule } from './certifications/certifications.module';
import { ResourcesModule } from './resources/resources.module';
import { HealthModule } from './health/health.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    UsersModule,
    ProjectsModule,
    ProgressModule,
    CertificationsModule,
    ResourcesModule,
    HealthModule,
  ],
})
export class AppModule {}

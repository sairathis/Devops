import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class CreateProjectDto {
  @ApiProperty({ description: 'Human-readable name for the saved diagram' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  name!: string;

  @ApiProperty({
    description: 'Architecture Builder canvas nodes, as produced by the frontend',
    type: [Object],
  })
  @IsArray()
  nodes!: unknown[];

  @ApiProperty({
    description: 'Architecture Builder canvas edges, as produced by the frontend',
    type: [Object],
  })
  @IsArray()
  edges!: unknown[];
}

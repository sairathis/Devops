import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FirebaseAuthGuard } from '../auth/firebase-auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthenticatedUser } from '../auth/auth.types';
import { UsersService } from '../users/users.service';
import { ProjectsService } from './projects.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';

@ApiTags('projects')
@ApiBearerAuth()
@UseGuards(FirebaseAuthGuard)
@Controller('projects')
export class ProjectsController {
  constructor(
    private readonly projectsService: ProjectsService,
    private readonly usersService: UsersService,
  ) {}

  @Get()
  async list(@CurrentUser() authUser: AuthenticatedUser) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.projectsService.listForUser(user.id);
  }

  @Get(':id')
  async findOne(
    @CurrentUser() authUser: AuthenticatedUser,
    @Param('id') id: string,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.projectsService.findOneForUser(user.id, id);
  }

  @Post()
  async create(
    @CurrentUser() authUser: AuthenticatedUser,
    @Body() dto: CreateProjectDto,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.projectsService.create(user.id, dto);
  }

  @Patch(':id')
  async update(
    @CurrentUser() authUser: AuthenticatedUser,
    @Param('id') id: string,
    @Body() dto: UpdateProjectDto,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.projectsService.update(user.id, id, dto);
  }

  @Delete(':id')
  async remove(
    @CurrentUser() authUser: AuthenticatedUser,
    @Param('id') id: string,
  ) {
    const user = await this.usersService.findOrCreateFromFirebase(authUser);
    return this.projectsService.remove(user.id, id);
  }
}

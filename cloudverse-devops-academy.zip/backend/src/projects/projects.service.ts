import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';

@Injectable()
export class ProjectsService {
  constructor(private readonly prisma: PrismaService) {}

  async listForUser(userId: string) {
    return this.prisma.project.findMany({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async findOneForUser(userId: string, id: string) {
    const project = await this.prisma.project.findUnique({ where: { id } });
    if (!project) {
      throw new NotFoundException(`Project ${id} not found`);
    }
    if (project.userId !== userId) {
      throw new ForbiddenException('You do not have access to this project');
    }
    return project;
  }

  async create(userId: string, dto: CreateProjectDto) {
    return this.prisma.project.create({
      data: {
        userId,
        name: dto.name,
        nodesJson: dto.nodes as Prisma.InputJsonValue,
        edgesJson: dto.edges as Prisma.InputJsonValue,
      },
    });
  }

  async update(userId: string, id: string, dto: UpdateProjectDto) {
    // Ensures the project exists and belongs to this user before mutating.
    await this.findOneForUser(userId, id);

    return this.prisma.project.update({
      where: { id },
      data: {
        ...(dto.name !== undefined ? { name: dto.name } : {}),
        ...(dto.nodes !== undefined
          ? { nodesJson: dto.nodes as Prisma.InputJsonValue }
          : {}),
        ...(dto.edges !== undefined
          ? { edgesJson: dto.edges as Prisma.InputJsonValue }
          : {}),
      },
    });
  }

  async remove(userId: string, id: string) {
    await this.findOneForUser(userId, id);
    await this.prisma.project.delete({ where: { id } });
    return { id, deleted: true };
  }
}

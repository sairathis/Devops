import {
  CanActivate,
  ExecutionContext,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { Request } from 'express';
import { getFirebaseApp } from './firebase-admin';
import { AuthenticatedUser } from './auth.types';

/**
 * Verifies the `Authorization: Bearer <idToken>` header against Firebase
 * Auth via firebase-admin's `getAuth().verifyIdToken()`.
 *
 * Dev bypass: when AUTH_DEV_BYPASS=true, real verification is skipped and a
 * fake user is injected instead, so the API is usable end-to-end without a
 * configured Firebase project (e.g. local development, this sandbox).
 */
@Injectable()
export class FirebaseAuthGuard implements CanActivate {
  private readonly logger = new Logger(FirebaseAuthGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<Request>();

    if (process.env.AUTH_DEV_BYPASS === 'true') {
      const devUser: AuthenticatedUser = {
        firebaseUid: 'dev-user-local',
        email: 'dev-user@cloudverse.local',
        displayName: 'Dev User',
      };
      (request as Request & { user: AuthenticatedUser }).user = devUser;
      return true;
    }

    const authHeader = request.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('Missing Bearer token');
    }
    const idToken = authHeader.slice('Bearer '.length).trim();

    const app = getFirebaseApp();
    if (!app) {
      this.logger.error(
        'FirebaseAuthGuard invoked but firebase-admin is not configured. ' +
          'Set FIREBASE_PROJECT_ID/FIREBASE_CLIENT_EMAIL/FIREBASE_PRIVATE_KEY, ' +
          'or set AUTH_DEV_BYPASS=true for local development.',
      );
      throw new UnauthorizedException('Authentication is not configured');
    }

    try {
      const decoded = await app.auth().verifyIdToken(idToken);
      const user: AuthenticatedUser = {
        firebaseUid: decoded.uid,
        email: decoded.email ?? '',
        displayName:
          (decoded as { name?: string }).name ?? decoded.email ?? decoded.uid,
      };
      (request as Request & { user: AuthenticatedUser }).user = user;
      return true;
    } catch (error) {
      this.logger.warn(
        `Failed to verify Firebase ID token: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      throw new UnauthorizedException('Invalid or expired token');
    }
  }
}

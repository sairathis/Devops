import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { Request } from 'express';
import { AuthenticatedUser } from './auth.types';

/**
 * Extracts the authenticated user attached to the request by
 * FirebaseAuthGuard. Use alongside @UseGuards(FirebaseAuthGuard).
 *
 * @example
 * @UseGuards(FirebaseAuthGuard)
 * @Get('me')
 * getMe(@CurrentUser() user: AuthenticatedUser) { ... }
 */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): AuthenticatedUser => {
    const request = ctx
      .switchToHttp()
      .getRequest<Request & { user: AuthenticatedUser }>();
    return request.user;
  },
);

/**
 * Shape of the authenticated user attached to `request.user` by
 * FirebaseAuthGuard, and returned by the `@CurrentUser()` decorator.
 */
export interface AuthenticatedUser {
  firebaseUid: string;
  email: string;
  displayName?: string;
}

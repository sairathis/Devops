import { Logger } from '@nestjs/common';
import * as admin from 'firebase-admin';

const logger = new Logger('FirebaseAdmin');

let app: admin.app.App | null = null;
let initAttempted = false;

/**
 * Lazily initializes the firebase-admin SDK the first time a token needs to
 * be verified, and memoizes the result. Wrapped in try/catch so that missing
 * or malformed credentials never crash the whole process at boot - routes
 * that don't need auth (health, resources, swagger) keep working, and
 * protected routes fail with a clear 401/500 instead of an unhandled crash.
 */
export function getFirebaseApp(): admin.app.App | null {
  if (app || initAttempted) {
    return app;
  }
  initAttempted = true;

  try {
    const projectId = process.env.FIREBASE_PROJECT_ID;
    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
    const privateKeyRaw = process.env.FIREBASE_PRIVATE_KEY;

    if (!projectId || !clientEmail || !privateKeyRaw) {
      logger.warn(
        'Firebase credentials are not fully configured (FIREBASE_PROJECT_ID / ' +
          'FIREBASE_CLIENT_EMAIL / FIREBASE_PRIVATE_KEY). Real token verification ' +
          'is disabled until they are set. Use AUTH_DEV_BYPASS=true for local development.',
      );
      return null;
    }

    const privateKey = privateKeyRaw.replace(/\\n/g, '\n');

    app =
      admin.apps.length > 0 && admin.apps[0]
        ? (admin.apps[0] as admin.app.App)
        : admin.initializeApp({
            credential: admin.credential.cert({
              projectId,
              clientEmail,
              privateKey,
            }),
          });

    logger.log('firebase-admin initialized');
    return app;
  } catch (error) {
    logger.error(
      `Failed to initialize firebase-admin: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    return null;
  }
}

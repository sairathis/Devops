"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { Award } from "lucide-react";
import { CertificationPathCard } from "@/components/certification-paths/certification-path-card";
import { CERTIFICATION_PATHS } from "@/lib/certification-paths/paths";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function CertificationPathsPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  React.useEffect(() => {
    setModuleProgress("certification-paths", 20);
  }, [setModuleProgress]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6 flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gcp-yellow/10 text-gcp-yellow">
          <Award className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Certification <span className="gradient-text">Paths</span>
          </h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Structured, ordered study tracks toward real Google Cloud certifications &mdash; work through each topic
            in sequence and check things off as you go.
          </p>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {CERTIFICATION_PATHS.map((path, i) => (
          <motion.div key={path.id} initial="hidden" animate="show" custom={i} variants={fadeUp}>
            <CertificationPathCard path={path} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

"use client";
import { ReactFlowProvider } from "reactflow";
import { ResourcePalette } from "@/components/architecture/palette";
import { ArchitectureCanvas } from "@/components/architecture/canvas";
import { InspectorPanel } from "@/components/architecture/inspector-panel";
import { ArchitectureToolbar } from "@/components/architecture/toolbar";

export default function ArchitectureBuilderPage() {
  return (
    <ReactFlowProvider>
      <div className="flex h-[calc(100svh-4rem)] flex-col overflow-hidden">
        <ArchitectureToolbar />
        <div className="flex flex-1 overflow-hidden">
          <ResourcePalette />
          <ArchitectureCanvas />
          <InspectorPanel />
        </div>
      </div>
    </ReactFlowProvider>
  );
}

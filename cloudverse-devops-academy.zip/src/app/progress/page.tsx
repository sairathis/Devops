"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { HeroStats } from "@/components/progress/hero-stats";
import { BadgeGrid } from "@/components/progress/badge-grid";
import { ModuleProgressList } from "@/components/progress/module-progress-list";
import { QuizPerformanceChart } from "@/components/progress/quiz-performance-chart";
import { ResetProgressButton } from "@/components/progress/reset-progress-button";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function ProgressPage() {
  const level = useProgressStore((s) => s.level);
  const totalXp = useProgressStore((s) => s.totalXp);
  const streakDays = useProgressStore((s) => s.streakDays);
  const badges = useProgressStore((s) => s.badges);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">
            <span className="gradient-text">Your Progress</span>
          </h1>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            XP, streaks, badges, and mastery across the whole platform.
          </p>
        </div>
        <ResetProgressButton />
      </div>

      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-5">
        <HeroStats level={level} totalXp={totalXp} streakDays={streakDays} />
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp} className="mb-5">
        <BadgeGrid earnedBadges={badges} />
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-2">
        <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp}>
          <ModuleProgressList />
        </motion.div>

        <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp}>
          <QuizPerformanceChart />
        </motion.div>
      </div>
    </div>
  );
}

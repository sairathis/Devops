"use client";
import * as React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { CodeBlock } from "@/components/code-block";
import { DockerfileForm } from "@/components/docker-lab/dockerfile-form";
import { BuildSimulator } from "@/components/docker-lab/build-simulator";
import { ImageLayers } from "@/components/docker-lab/image-layers";
import { DockerCheatsheet } from "@/components/docker-lab/cheatsheet";
import { useDockerfileBuilder } from "@/components/docker-lab/use-dockerfile-builder";
import { buildDockerfileLines, generateDockerfile } from "@/components/docker-lab/dockerfile-config";
import { useProgressStore } from "@/store/progress-store";

export default function DockerLabPage() {
  const builder = useDockerfileBuilder();
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);

  React.useEffect(() => {
    setModuleProgress("docker-lab", 20);
  }, [setModuleProgress]);

  const lines = React.useMemo(() => buildDockerfileLines(builder.config), [builder.config]);
  const dockerfile = React.useMemo(() => generateDockerfile(builder.config), [builder.config]);

  const handleFirstBuild = React.useCallback(() => {
    addXp(10);
  }, [addXp]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Docker Lab</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Build and understand Dockerfiles and image layers hands-on &mdash; configure instructions, watch a
          simulated build, and see how layer caching actually works.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
        <DockerfileForm builder={builder} />

        <div className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle>Generated Dockerfile</CardTitle>
              <CardDescription>Regenerates live as you edit the configuration on the left.</CardDescription>
            </CardHeader>
            <CardContent>
              <CodeBlock language="dockerfile" filename="Dockerfile" code={dockerfile} />
            </CardContent>
          </Card>

          <BuildSimulator lines={lines} onFirstBuild={handleFirstBuild} />
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <ImageLayers lines={lines} config={builder.config} />
        <DockerCheatsheet />
      </div>
    </div>
  );
}

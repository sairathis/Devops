"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ConceptExplainer } from "@/components/monitoring-academy/concept-explainer";
import { LiveDashboard } from "@/components/monitoring-academy/live-dashboard";
import { SloTracker } from "@/components/monitoring-academy/slo-tracker";
import { AlertRules } from "@/components/monitoring-academy/alert-rules";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function MonitoringAcademyPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  React.useEffect(() => {
    setModuleProgress("monitoring-academy", 20);
  }, [setModuleProgress]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">
          <span className="gradient-text">Monitoring</span> Academy
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Learn the vocabulary of observability — SLIs, SLOs, the four golden signals, and error budgets — then see
          it applied on a live-looking dashboard with a real SLO tracker and an alerting rule builder.
        </p>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-[1fr_420px]">
        <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp} className="space-y-5">
          <ConceptExplainer />
          <AlertRules />
        </motion.div>

        <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp} className="space-y-5">
          <LiveDashboard />
          <SloTracker />
        </motion.div>
      </div>
    </div>
  );
}

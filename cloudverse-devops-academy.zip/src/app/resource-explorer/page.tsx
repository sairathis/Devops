"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { Compass, Boxes, Workflow, FolderOpen } from "lucide-react";
import { useArchitectureStore } from "@/store/architecture-store";
import { useProgressStore } from "@/store/progress-store";
import { GCP_RESOURCES } from "@/lib/gcp";
import { StatStrip } from "@/components/resource-explorer/stat-strip";
import { SearchControls, type CategoryFilter } from "@/components/resource-explorer/search-controls";
import { ExplorerSection } from "@/components/resource-explorer/explorer-section";
import { CatalogCard } from "@/components/resource-explorer/catalog-card";
import { CanvasNodeCard } from "@/components/resource-explorer/canvas-node-card";
import { ProjectCard } from "@/components/resource-explorer/project-card";
import { EmptyState } from "@/components/resource-explorer/empty-state";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function ResourceExplorerPage() {
  const nodes = useArchitectureStore((s) => s.nodes);
  const projects = useArchitectureStore((s) => s.projects);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<CategoryFilter>("all");

  React.useEffect(() => {
    setModuleProgress("resource-explorer", 20);
  }, [setModuleProgress]);

  const normalizedQuery = query.trim().toLowerCase();

  const filteredCatalog = React.useMemo(() => {
    return GCP_RESOURCES.filter((def) => {
      const matchesCategory = category === "all" || def.category === category;
      const matchesQuery = normalizedQuery === "" || def.label.toLowerCase().includes(normalizedQuery);
      return matchesCategory && matchesQuery;
    });
  }, [category, normalizedQuery]);

  const filteredNodes = React.useMemo(() => {
    if (normalizedQuery === "") return nodes;
    return nodes.filter((n) => n.data.label.toLowerCase().includes(normalizedQuery));
  }, [nodes, normalizedQuery]);

  const filteredProjects = React.useMemo(() => {
    if (normalizedQuery === "") return projects;
    return projects.filter((p) => p.name.toLowerCase().includes(normalizedQuery));
  }, [projects, normalizedQuery]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <div className="mb-1 flex items-center gap-2">
          <Compass className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-semibold tracking-tight">
            Resource <span className="gradient-text">Explorer</span>
          </h1>
        </div>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Search and browse everything available on the platform — the full GCP catalog — and everything you&apos;ve
          built, from resources on your current canvas to every project you&apos;ve saved.
        </p>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp} className="mb-6">
        <StatStrip
          totalResourceTypes={GCP_RESOURCES.length}
          canvasNodeCount={nodes.length}
          savedProjectCount={projects.length}
        />
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp}>
        <SearchControls query={query} onQueryChange={setQuery} category={category} onCategoryChange={setCategory} />
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp}>
        <ExplorerSection
          title="GCP Catalog"
          description="Every resource type supported on the platform"
          count={filteredCatalog.length}
        >
          {filteredCatalog.length === 0 ? (
            <EmptyState icon={Boxes} message="No GCP resources match your search or category filter." />
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredCatalog.map((def) => (
                <CatalogCard key={def.type} def={def} />
              ))}
            </div>
          )}
        </ExplorerSection>

        <ExplorerSection
          title="Your Canvas"
          description="Resources currently on your Architecture Builder canvas"
          count={filteredNodes.length}
        >
          {filteredNodes.length === 0 ? (
            <EmptyState
              icon={Workflow}
              message={
                nodes.length === 0
                  ? "Your canvas is empty — add resources in the Architecture Builder to see them here."
                  : "No resources on your canvas match your search."
              }
            />
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredNodes.map((node) => (
                <CanvasNodeCard key={node.id} node={node} />
              ))}
            </div>
          )}
        </ExplorerSection>

        <ExplorerSection
          title="Saved Projects"
          description="Architecture Builder diagrams you've saved"
          count={filteredProjects.length}
        >
          {filteredProjects.length === 0 ? (
            <EmptyState
              icon={FolderOpen}
              message={
                projects.length === 0
                  ? "No saved projects yet — build something in the Architecture Builder!"
                  : "No saved projects match your search."
              }
            />
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </ExplorerSection>
      </motion.div>
    </div>
  );
}

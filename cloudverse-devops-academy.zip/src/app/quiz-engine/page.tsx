"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { useProgressStore } from "@/store/progress-store";
import { randomQuestions, type QuizQuestion } from "@/lib/quiz-bank";
import { QuizSetup } from "@/components/quiz-engine/quiz-setup";
import { QuizSession } from "@/components/quiz-engine/quiz-session";
import { QuizResults } from "@/components/quiz-engine/quiz-results";
import { ALL_TOPICS_LABEL, type ScoreMap } from "@/components/quiz-engine/constants";

type Screen = "setup" | "session" | "results";

interface SessionResults {
  correct: number;
  total: number;
  byTopic: ScoreMap;
}

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
};

/**
 * QuizCard records answers into useProgressStore's cumulative `quizScores`
 * (keyed by topic) as the user answers, but doesn't expose per-question
 * correctness to its parent. Rather than re-implement the multiple-choice
 * UI, we snapshot `quizScores` right before a session starts and again once
 * every question has been answered, then diff the two snapshots per topic
 * to recover exactly how many were answered / answered correctly during
 * this session.
 */
function diffScores(before: ScoreMap, after: ScoreMap, topics: string[]): SessionResults {
  const byTopic: ScoreMap = {};
  let correct = 0;
  let total = 0;
  for (const topic of topics) {
    const b = before[topic] ?? { correct: 0, total: 0 };
    const a = after[topic] ?? { correct: 0, total: 0 };
    const topicCorrect = Math.max(0, a.correct - b.correct);
    const topicTotal = Math.max(0, a.total - b.total);
    byTopic[topic] = { correct: topicCorrect, total: topicTotal };
    correct += topicCorrect;
    total += topicTotal;
  }
  return { correct, total, byTopic };
}

export default function QuizEnginePage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const [screen, setScreen] = React.useState<Screen>("setup");
  const [session, setSession] = React.useState<QuizQuestion[]>([]);
  const [index, setIndex] = React.useState(0);
  const [selectedTopic, setSelectedTopic] = React.useState<string>(ALL_TOPICS_LABEL);
  const [startSnapshot, setStartSnapshot] = React.useState<ScoreMap>({});
  const [results, setResults] = React.useState<SessionResults | null>(null);

  React.useEffect(() => {
    setModuleProgress("quiz-engine", 20);
  }, [setModuleProgress]);

  const beginSession = React.useCallback((questions: QuizQuestion[], topic: string) => {
    setSelectedTopic(topic);
    setSession(questions);
    setIndex(0);
    setResults(null);
    // Snapshot cumulative scores now, before any answer in this session lands.
    setStartSnapshot(useProgressStore.getState().quizScores);
    setScreen("session");
  }, []);

  const handleStart = (topic: string, count: number) => {
    // Math.random() lives inside randomQuestions; only ever called from this
    // click handler, never during render, so hydration stays deterministic.
    const questions = randomQuestions(count, topic === ALL_TOPICS_LABEL ? undefined : topic);
    beginSession(questions, topic);
  };

  const handleRetry = () => beginSession(session, selectedTopic);

  const handleNewQuiz = () => {
    setScreen("setup");
    setSession([]);
    setResults(null);
  };

  const handleNext = () => {
    const isLastQuestion = index >= session.length - 1;
    if (!isLastQuestion) {
      setIndex((i) => i + 1);
      return;
    }
    const afterSnapshot = useProgressStore.getState().quizScores;
    const topics = Array.from(new Set(session.map((q) => q.topic)));
    setResults(diffScores(startSnapshot, afterSnapshot, topics));
    setScreen("results");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Quiz Engine</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Test your knowledge across every topic on the platform.
        </p>
      </div>

      <motion.div
        key={screen}
        initial="hidden"
        animate="show"
        variants={fadeUp}
        className="mx-auto max-w-2xl"
      >
        {screen === "setup" && <QuizSetup onStart={handleStart} />}

        {screen === "session" && session.length > 0 && (
          <QuizSession questions={session} index={index} onNext={handleNext} />
        )}

        {screen === "results" && results && (
          <QuizResults
            correct={results.correct}
            total={results.total}
            byTopic={results.byTopic}
            onRetry={handleRetry}
            onNewQuiz={handleNewQuiz}
          />
        )}
      </motion.div>
    </div>
  );
}

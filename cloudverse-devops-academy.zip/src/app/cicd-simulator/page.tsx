"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Play, RotateCcw, AlertTriangle, GitMerge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CodeBlock } from "@/components/code-block";
import { PipelineStepper } from "@/components/cicd-simulator/pipeline-stepper";
import { LogPanel, type LogEntry } from "@/components/cicd-simulator/log-panel";
import { ConceptsSection } from "@/components/cicd-simulator/concepts-section";
import { CLOUDBUILD_YAML } from "@/components/cicd-simulator/cloudbuild-yaml";
import { PIPELINE_STAGES, type StageStatus } from "@/components/cicd-simulator/pipeline-config";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function randomBetween(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

let logIdCounter = 0;
function nextLogId() {
  logIdCounter += 1;
  return `log-${logIdCounter}`;
}

export default function CicdSimulatorPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);

  const [statuses, setStatuses] = React.useState<StageStatus[]>(() => PIPELINE_STAGES.map(() => "pending"));
  const [logs, setLogs] = React.useState<LogEntry[]>([]);
  const [running, setRunning] = React.useState(false);
  const [failedIndex, setFailedIndex] = React.useState<number | null>(null);
  const [failureMessage, setFailureMessage] = React.useState<string | null>(null);
  const [, setHasEarnedXp] = React.useState(false);

  // Guards against duplicate/overlapping runs from double-clicks.
  const runTokenRef = React.useRef(0);

  React.useEffect(() => {
    setModuleProgress("cicd-simulator", 20);
  }, [setModuleProgress]);

  const appendLog = React.useCallback((text: string, tone: LogEntry["tone"]) => {
    setLogs((prev) => [...prev, { id: nextLogId(), text, tone }]);
  }, []);

  const runPipeline = React.useCallback(
    async (startIndex: number) => {
      const myToken = ++runTokenRef.current;
      setRunning(true);
      setFailureMessage(null);
      setFailedIndex(null);
      setStatuses((prev) => prev.map((s, i) => (i < startIndex ? s : "pending")));

      if (startIndex === 0) {
        setLogs([]);
        appendLog("Starting pipeline run for commit 4f2a9c1 on branch main...", "muted");
      } else {
        appendLog(`Retrying from stage "${PIPELINE_STAGES[startIndex].label}"...`, "muted");
      }

      for (let i = startIndex; i < PIPELINE_STAGES.length; i++) {
        if (runTokenRef.current !== myToken) return; // a newer run superseded this one
        const stage = PIPELINE_STAGES[i];

        setStatuses((prev) => prev.map((s, idx) => (idx === i ? "running" : s)));
        appendLog(`Stage started: ${stage.label}`, "muted");

        const totalMs = randomBetween(stage.minMs, stage.maxMs);
        const perLineMs = Math.max(150, Math.floor(totalMs / (stage.runningLog.length + 1)));

        for (const line of stage.runningLog) {
          await sleep(perLineMs);
          if (runTokenRef.current !== myToken) return;
          appendLog(line, "info");
        }
        await sleep(Math.max(0, totalMs - perLineMs * stage.runningLog.length));
        if (runTokenRef.current !== myToken) return;

        const failed = Math.random() < stage.failChance;

        if (failed) {
          const message =
            stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ??
            `FAIL: ${stage.label} failed unexpectedly`;
          appendLog(message, "error");
          setStatuses((prev) => prev.map((s, idx) => (idx === i ? "failed" : s)));
          setFailedIndex(i);
          setFailureMessage(message);
          setRunning(false);
          return;
        }

        appendLog(stage.successLog, "success");
        setStatuses((prev) => prev.map((s, idx) => (idx === i ? "success" : s)));
      }

      appendLog("Pipeline finished — all stages succeeded.", "success");
      setRunning(false);
      setFailedIndex(null);
      setHasEarnedXp((already) => {
        if (!already) addXp(15);
        return true;
      });
    },
    [appendLog, addXp],
  );

  const handleRun = () => {
    void runPipeline(0);
  };

  const handleRetry = () => {
    if (failedIndex === null) return;
    void runPipeline(failedIndex);
  };

  const allSucceeded = statuses.every((s) => s === "success");

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <GitMerge className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">CI/CD Simulator</h1>
          {allSucceeded && <Badge variant="success">All stages green</Badge>}
        </div>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Watch a deployment pipeline run stage by stage, from commit to a live smoke test — including the
          occasional failure. Every run is simulated client-side, so it is safe to break things.
        </p>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp}>
        <Card className="mb-5">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle>Pipeline</CardTitle>
              <CardDescription>Commit → Build → Unit Tests → Push → Deploy → Smoke Test</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {failedIndex !== null && !running && (
                <Button variant="outline" onClick={handleRetry}>
                  <RotateCcw className="h-4 w-4" /> Retry from failed stage
                </Button>
              )}
              <Button onClick={handleRun} disabled={running}>
                <Play className="h-4 w-4" /> {running ? "Running..." : "Run Pipeline"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <PipelineStepper statuses={statuses} />

            {failureMessage && (
              <div className="flex items-start gap-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <div className="min-w-0">
                  <p className="font-medium">Pipeline failed</p>
                  <p className="mt-0.5 break-words font-mono text-xs text-danger/90">{failureMessage}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp} className="mb-5 grid gap-5 lg:grid-cols-2">
        <div>
          <h2 className="mb-2 text-sm font-medium text-muted-foreground">Live build log</h2>
          <LogPanel entries={logs} />
        </div>
        <div>
          <h2 className="mb-2 text-sm font-medium text-muted-foreground">Pipeline as code</h2>
          <CodeBlock code={CLOUDBUILD_YAML} language="yaml" filename="cloudbuild.yaml" maxHeight="18rem" />
        </div>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp}>
        <h2 className="mb-3 text-lg font-semibold tracking-tight">Concepts</h2>
        <ConceptsSection />
      </motion.div>
    </div>
  );
}

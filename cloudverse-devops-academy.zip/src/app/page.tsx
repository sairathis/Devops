"use client";
import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight, Workflow, Network, Trophy, Flame, Sparkles, Award, Server, GitMerge, BookOpen,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useProgressStore } from "@/store/progress-store";
import { useArchitectureStore } from "@/store/architecture-store";
import { MODULES } from "@/lib/modules";
import { GCP_RESOURCES } from "@/lib/gcp";
import { cn } from "@/lib/utils";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

const PATH_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "bg-gcp-blue/10 text-gcp-blue",
  "gcp-green": "bg-gcp-green/10 text-gcp-green",
  "gcp-yellow": "bg-gcp-yellow/10 text-gcp-yellow",
  "gcp-red": "bg-gcp-red/10 text-gcp-red",
};

const STAT_TILE_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "text-gcp-blue",
  "gcp-green": "text-gcp-green",
  "gcp-yellow": "text-gcp-yellow",
  "gcp-red": "text-gcp-red",
};

export default function DashboardPage() {
  const totalXp = useProgressStore((s) => s.totalXp);
  const level = useProgressStore((s) => s.level);
  const streakDays = useProgressStore((s) => s.streakDays);
  const modules = useProgressStore((s) => s.modules);
  const badges = useProgressStore((s) => s.badges);
  const nodes = useArchitectureStore((s) => s.nodes);

  const overallPercent = Math.round(
    (Object.values(modules).reduce((sum, m) => sum + m.percent, 0) / (MODULES.length * 100)) * 100,
  ) || 0;
  const xpToNextLevel = level * 500 - totalXp;

  const paths = [
    { title: "Associate Cloud Engineer", href: "/certification-paths", percent: 35, icon: Award, color: "gcp-blue" },
    { title: "Professional Cloud DevOps Engineer", href: "/certification-paths", percent: 12, icon: GitMerge, color: "gcp-green" },
    { title: "Professional Cloud Architect", href: "/certification-paths", percent: 5, icon: Server, color: "gcp-yellow" },
  ];

  const quickActions = [
    { title: "Open Architecture Builder", desc: "Continue your last diagram or start fresh", href: "/architecture-builder", icon: Workflow },
    { title: "Simulate Traffic Flow", desc: "Watch packets move through a live topology", href: "/networking-academy", icon: Network },
    { title: "Take a Quiz", desc: "5-question rapid quiz on Compute Engine", href: "/quiz-engine", icon: BookOpen },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div
        initial="hidden"
        animate="show"
        custom={0}
        variants={fadeUp}
        className="relative mb-8 overflow-hidden rounded-2xl border border-border bg-grid p-6 md:p-10"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-gcp-blue/10 via-transparent to-gcp-green/10" />
        <div className="relative flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="mb-2 flex items-center gap-1.5 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4 text-gcp-yellow" /> Welcome back, Sai
            </p>
            <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">
              Learn GCP &amp; DevOps by <span className="gradient-text">building it</span>
            </h1>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Every resource you create updates diagrams, generates Terraform, simulates traffic, and explains what
              just happened — the full loop, every time.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <Button asChild>
                <Link href="/architecture-builder">
                  Open Architecture Builder <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/certification-paths">View certification paths</Link>
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 md:min-w-[280px]">
            <StatTile icon={Trophy} label="Level" value={String(level)} color="gcp-yellow" />
            <StatTile icon={Flame} label="Streak" value={`${streakDays}d`} color="gcp-red" />
            <StatTile icon={Sparkles} label="XP" value={String(totalXp)} color="gcp-blue" />
          </div>
        </div>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-3">
        <motion.div custom={1} initial="hidden" animate="show" variants={fadeUp} className="lg:col-span-2 space-y-5">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle>Overall progress</CardTitle>
                <CardDescription>Across all 14 modules</CardDescription>
              </div>
              <Badge variant="info">{overallPercent}%</Badge>
            </CardHeader>
            <CardContent>
              <Progress value={overallPercent} />
              <p className="mt-3 text-xs text-muted-foreground">
                {xpToNextLevel > 0 ? `${xpToNextLevel} XP to level ${level + 1}` : "Ready to level up!"} ·{" "}
                {nodes.length} resource{nodes.length === 1 ? "" : "s"} in your current architecture
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Continue where you left off</CardTitle>
              <CardDescription>Jump back into a module or start something new</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-3">
              {quickActions.map((a) => (
                <Link
                  key={a.title}
                  href={a.href}
                  className="group flex flex-col gap-2 rounded-xl border border-border p-4 transition-all hover:border-primary/40 hover:shadow-md"
                >
                  <a.icon className="h-5 w-5 text-primary" />
                  <span className="text-sm font-medium">{a.title}</span>
                  <span className="text-xs text-muted-foreground">{a.desc}</span>
                  <ArrowRight className="mt-1 h-3.5 w-3.5 text-muted-foreground transition-transform group-hover:translate-x-1" />
                </Link>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Certification paths</CardTitle>
              <CardDescription>Structured tracks toward real GCP certifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {paths.map((p) => (
                <div key={p.title} className="flex items-center gap-4">
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${PATH_COLOR_CLASS[p.color]}`}>
                    <p.icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="truncate text-sm font-medium">{p.title}</span>
                      <span className="text-xs text-muted-foreground">{p.percent}%</span>
                    </div>
                    <Progress value={p.percent} className="mt-1.5 h-1.5" />
                  </div>
                </div>
              ))}
              <Button asChild variant="ghost" size="sm" className="w-full justify-center">
                <Link href="/certification-paths">View all paths <ArrowRight className="h-3.5 w-3.5" /></Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div custom={2} initial="hidden" animate="show" variants={fadeUp} className="space-y-5">
          <Card>
            <CardHeader>
              <CardTitle>Badges earned</CardTitle>
              <CardDescription>{badges.length} of 12 unlocked</CardDescription>
            </CardHeader>
            <CardContent>
              {badges.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  Complete quizzes and build your first architecture to earn your first badge.
                </p>
              ) : (
                <div className="grid grid-cols-3 gap-2">
                  {badges.map((b) => (
                    <div key={b.id} className="flex flex-col items-center gap-1 rounded-lg border border-border p-2 text-center">
                      <Award className="h-5 w-5 text-gcp-yellow" />
                      <span className="text-[10px] leading-tight">{b.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Platform stats</CardTitle>
              <CardDescription>What you can build here</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3 text-center">
              <StatBlock value={GCP_RESOURCES.length} label="GCP resources" />
              <StatBlock value={MODULES.length} label="Learning modules" />
              <StatBlock value={GCP_RESOURCES.reduce((s, r) => s + r.quiz.length, 0)} label="Quiz questions" />
              <StatBlock value={GCP_RESOURCES.reduce((s, r) => s + r.troubleshooting.length, 0)} label="Troubleshooting cases" />
            </CardContent>
          </Card>

          <Card className="glass-panel border-none">
            <CardContent className="pt-5">
              <p className="text-sm">
                <span className="font-medium">Tip:</span> press{" "}
                <kbd className="rounded border border-border bg-background px-1.5 py-0.5 text-xs">⌘K</kbd> anywhere
                to search modules, GCP services, and quick actions.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

function StatTile({ icon: Icon, label, value, color }: { icon: React.ElementType; label: string; value: string; color: string }) {
  return (
    <div className="glass-panel flex flex-col items-center justify-center gap-1 rounded-xl px-3 py-3 text-center">
      <Icon className={cn("h-4 w-4", STAT_TILE_COLOR_CLASS[color])} />
      <span className="text-lg font-semibold leading-none">{value}</span>
      <span className="text-[10px] text-muted-foreground">{label}</span>
    </div>
  );
}

function StatBlock({ value, label }: { value: number; label: string }) {
  return (
    <div className="rounded-lg border border-border py-3">
      <div className="text-xl font-semibold">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

"use client";
import * as React from "react";
import { Play, Pause, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { TopologyDiagram } from "@/components/networking/topology-diagram";
import { FirewallRules } from "@/components/networking/firewall-rules";
import { ModeExplainer } from "@/components/networking/mode-explainer";
import { QuizCard } from "@/components/quiz-card";
import { useNetworkingStore, isInboundHttpsAllowed } from "@/store/networking-store";
import { TRAFFIC_MODES } from "@/lib/networking/topology";
import { randomQuestions } from "@/lib/quiz-bank";
import { useProgressStore } from "@/store/progress-store";

export default function NetworkingAcademyPage() {
  const mode = useNetworkingStore((s) => s.mode);
  const setMode = useNetworkingStore((s) => s.setMode);
  const simulationRunning = useNetworkingStore((s) => s.simulationRunning);
  const setSimulationRunning = useNetworkingStore((s) => s.setSimulationRunning);
  const speed = useNetworkingStore((s) => s.speed);
  const setSpeed = useNetworkingStore((s) => s.setSpeed);
  const rules = useNetworkingStore((s) => s.rules);
  const lbCounter = useNetworkingStore((s) => s.lbCounter);
  const bumpLbCounter = useNetworkingStore((s) => s.bumpLbCounter);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  const modeMeta = TRAFFIC_MODES.find((m) => m.id === mode)!;
  const blocked = mode === "inbound" && !isInboundHttpsAllowed(rules);
  const packets = React.useMemo(() => modeMeta.packets(lbCounter, blocked), [modeMeta, lbCounter, blocked]);

  const [quizQuestions] = React.useState(() => randomQuestions(5, "Networking"));
  const [quizIndex, setQuizIndex] = React.useState(0);

  React.useEffect(() => {
    setModuleProgress("networking-academy", 30);
  }, [setModuleProgress]);

  React.useEffect(() => {
    if (mode !== "lbrouting" || !simulationRunning) return;
    const interval = setInterval(() => bumpLbCounter(), 2600 / speed);
    return () => clearInterval(interval);
  }, [mode, simulationRunning, speed, bumpLbCounter]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Networking Academy</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Build the mental model for how traffic actually moves through a GCP network — then watch it happen.
        </p>
      </div>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={mode} onValueChange={(v) => setMode(v as typeof mode)}>
          <TabsList className="flex-wrap h-auto">
            {TRAFFIC_MODES.map((m) => (
              <TabsTrigger key={m.id} value={m.id}>{m.label}</TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-3">
          <Button variant={simulationRunning ? "default" : "outline"} size="sm" onClick={() => setSimulationRunning(!simulationRunning)}>
            {simulationRunning ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {simulationRunning ? "Pause" : "Play"}
          </Button>
          <div className="flex w-32 items-center gap-2">
            <Gauge className="h-3.5 w-3.5 text-muted-foreground" />
            <Slider min={0.5} max={2} step={0.5} value={[speed]} onValueChange={([v]) => setSpeed(v)} />
          </div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          <TopologyDiagram packets={packets} running={simulationRunning} mode={mode} />
          <FirewallRules />
        </div>
        <div className="space-y-5">
          <Card>
            <CardContent className="pt-5">
              <ModeExplainer mode={modeMeta} packets={packets} blocked={blocked} />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Quick check</CardTitle>
              <CardDescription>Question {quizIndex + 1} of {quizQuestions.length}</CardDescription>
            </CardHeader>
            <CardContent>
              <QuizCard
                question={quizQuestions[quizIndex]}
                onNext={() => setQuizIndex((i) => (i + 1) % quizQuestions.length)}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

"use client";
import * as React from "react";
import { toast } from "sonner";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useProgressStore } from "@/store/progress-store";

export function ResetProgressButton() {
  const resetProgress = useProgressStore((s) => s.resetProgress);

  const handleReset = () => {
    const confirmed = window.confirm(
      "Reset all progress? This clears your XP, level, streak, badges, module progress, and quiz scores. This can't be undone.",
    );
    if (!confirmed) return;
    resetProgress();
    toast.success("Progress reset", { description: "Your stats are back to a clean slate." });
  };

  return (
    <Button variant="destructive" size="sm" onClick={handleReset}>
      <RotateCcw className="h-3.5 w-3.5" />
      Reset progress
    </Button>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { MODULES } from "@/lib/modules";
import { useProgressStore } from "@/store/progress-store";

export function ModuleProgressList() {
  const modules = useProgressStore((s) => s.modules);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Module mastery</CardTitle>
        <CardDescription>How far you&apos;ve gotten in each part of the platform</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {MODULES.map((m) => {
          const percent = modules[m.id]?.percent ?? 0;
          const Icon = m.icon;
          return (
            <Link
              key={m.id}
              href={m.href}
              className="flex items-center gap-4 rounded-lg -mx-2 px-2 py-1.5 transition-colors hover:bg-accent"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-medium">{m.label}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{percent}%</span>
                </div>
                <Progress value={percent} className="mt-1.5 h-1.5" />
              </div>
            </Link>
          );
        })}
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { CheckCircle2, Lock } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { BADGE_CATALOG } from "@/lib/progress/badge-catalog";
import type { Badge as EarnedBadge } from "@/store/progress-store";

export function BadgeGrid({ earnedBadges }: { earnedBadges: EarnedBadge[] }) {
  const earnedById = React.useMemo(() => {
    const map = new Map<string, EarnedBadge>();
    for (const b of earnedBadges) map.set(b.id, b);
    return map;
  }, [earnedBadges]);

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle>Badge catalog</CardTitle>
          <CardDescription>
            {earnedById.size} of {BADGE_CATALOG.length} unlocked
          </CardDescription>
        </div>
      </CardHeader>
      <div className="grid grid-cols-2 gap-3 p-5 pt-0 sm:grid-cols-3 md:grid-cols-5">
        {BADGE_CATALOG.map((def) => {
          const earned = earnedById.get(def.id);
          const Icon = def.icon;
          return (
            <div
              key={def.id}
              className={cn(
                "relative flex flex-col items-center gap-2 rounded-xl border p-3 text-center transition-colors",
                earned ? "border-gcp-yellow/40 bg-gcp-yellow/5" : "border-border bg-muted/30",
              )}
              title={def.description}
            >
              {earned ? (
                <CheckCircle2 className="absolute right-1.5 top-1.5 h-3.5 w-3.5 text-success" />
              ) : (
                <Lock className="absolute right-1.5 top-1.5 h-3 w-3 text-muted-foreground" />
              )}
              <div
                className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-full",
                  earned ? "bg-gcp-yellow/15 text-gcp-yellow" : "bg-muted text-muted-foreground grayscale",
                )}
              >
                <Icon className="h-5 w-5" />
              </div>
              <span className={cn("text-xs font-medium leading-tight", !earned && "text-muted-foreground")}>
                {def.label}
              </span>
              <span className="text-[10px] leading-tight text-muted-foreground">
                {earned ? `Earned ${new Date(earned.earnedAt).toLocaleDateString()}` : def.description}
              </span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

"use client";
import * as React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { HelpCircle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useProgressStore } from "@/store/progress-store";

export function QuizPerformanceChart() {
  const quizScores = useProgressStore((s) => s.quizScores);

  const data = React.useMemo(
    () =>
      Object.entries(quizScores).map(([topic, { correct, total }]) => ({
        topic,
        correct,
        total,
      })),
    [quizScores],
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quiz performance</CardTitle>
        <CardDescription>Correct answers vs. total attempts, by topic</CardDescription>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border py-10 text-center">
            <HelpCircle className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm font-medium">No quiz attempts yet</p>
            <p className="max-w-xs text-xs text-muted-foreground">
              Take a quiz in the Quiz Engine or any module to see your topic-by-topic breakdown here.
            </p>
          </div>
        ) : (
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="topic"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  cursor={{ fill: "hsl(var(--muted))" }}
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                    fontSize: "12px",
                  }}
                />
                <Bar dataKey="total" name="Total attempts" fill="hsl(var(--muted-foreground))" fillOpacity={0.3} radius={[4, 4, 0, 0]} />
                <Bar dataKey="correct" name="Correct" fill="hsl(var(--gcp-green))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

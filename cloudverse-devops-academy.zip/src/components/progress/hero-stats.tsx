"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { Trophy, Flame, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { clamp } from "@/lib/utils";

export function HeroStats({
  level,
  totalXp,
  streakDays,
}: {
  level: number;
  totalXp: number;
  streakDays: number;
}) {
  const xpForNextLevel = level * 500;
  const xpIntoLevel = totalXp - (level - 1) * 500;
  const levelSpan = xpForNextLevel - (level - 1) * 500;
  const levelProgressPercent = clamp(Math.round((xpIntoLevel / levelSpan) * 100), 0, 100);

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Trophy className="h-3.5 w-3.5 text-gcp-yellow" /> Current level
            </CardDescription>
            <CardTitle className="text-4xl font-semibold tracking-tight">{level}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">
              {xpIntoLevel} / {levelSpan} XP toward level {level + 1}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: 0.05 }}>
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-gcp-blue" /> Total XP
            </CardDescription>
            <CardTitle className="text-4xl font-semibold tracking-tight">{totalXp}</CardTitle>
          </CardHeader>
          <CardContent>
            <Progress value={levelProgressPercent} />
            <p className="mt-2 text-xs text-muted-foreground">{levelProgressPercent}% of the way to level {level + 1}</p>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: 0.1 }}>
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Flame className="h-3.5 w-3.5 text-gcp-red" /> Current streak
            </CardDescription>
            <CardTitle className="text-4xl font-semibold tracking-tight">
              {streakDays} <span className="text-base font-normal text-muted-foreground">day{streakDays === 1 ? "" : "s"}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">
              {streakDays >= 3 ? "Keep it going — consistency compounds." : "Visit again tomorrow to build your streak."}
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

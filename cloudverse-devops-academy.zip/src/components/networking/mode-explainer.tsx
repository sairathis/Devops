"use client";
import { CheckCircle2, ArrowRightLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ModeMeta, PacketSpec } from "@/lib/networking/topology";

export function ModeExplainer({ mode, packets, blocked }: { mode: ModeMeta; packets: PacketSpec[]; blocked: boolean }) {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <div className="mb-1 flex items-center gap-2">
          <h3 className="text-sm font-semibold">{mode.label}</h3>
          {blocked && <Badge variant="danger">Blocked by firewall</Badge>}
        </div>
        <p className="text-xs leading-relaxed text-muted-foreground">{mode.description}</p>
      </div>

      <div>
        <p className="mb-2 text-xs font-medium text-muted-foreground">What&apos;s happening, step by step</p>
        <ol className="space-y-2">
          {mode.steps.map((step, i) => (
            <li key={i} className="flex items-start gap-2 text-xs">
              <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[9px] font-semibold text-primary">
                {i + 1}
              </span>
              <span className="leading-relaxed">{step}</span>
            </li>
          ))}
        </ol>
      </div>

      <div>
        <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <ArrowRightLeft className="h-3.5 w-3.5" /> Packet details
        </p>
        <div className="space-y-2">
          {packets.map((p, i) => (
            <div key={i} className="rounded-lg border border-border p-2.5 font-mono text-[11px]">
              <div className="flex justify-between"><span className="text-muted-foreground">proto</span><span>{p.proto}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">src</span><span className="truncate pl-2 text-right">{p.srcIp}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">dst</span><span className="truncate pl-2 text-right">{p.dstIp}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">port</span><span>{p.port}</span></div>
            </div>
          ))}
        </div>
      </div>

      {!blocked && (
        <div className="flex items-center gap-2 rounded-lg bg-success/10 px-3 py-2 text-xs text-success">
          <CheckCircle2 className="h-3.5 w-3.5" /> Traffic is flowing as expected
        </div>
      )}
    </div>
  );
}

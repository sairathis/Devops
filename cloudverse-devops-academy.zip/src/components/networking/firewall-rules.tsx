"use client";
import * as React from "react";
import { toast } from "sonner";
import { Plus, Trash2, RotateCcw, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNetworkingStore, isInboundHttpsAllowed } from "@/store/networking-store";
import { ScrollArea } from "@/components/ui/scroll-area";

export function FirewallRules() {
  const rules = useNetworkingStore((s) => s.rules);
  const addRule = useNetworkingStore((s) => s.addRule);
  const removeRule = useNetworkingStore((s) => s.removeRule);
  const toggleRule = useNetworkingStore((s) => s.toggleRule);
  const resetRules = useNetworkingStore((s) => s.resetRules);

  const [open, setOpen] = React.useState(false);
  const [form, setForm] = React.useState({
    name: "", direction: "INGRESS" as const, action: "ALLOW" as const, protocol: "TCP", ports: "443", range: "0.0.0.0/0", priority: 1000,
  });

  const allowed = isInboundHttpsAllowed(rules);

  const handleAdd = () => {
    if (!form.name) {
      toast.error("Rule needs a name");
      return;
    }
    addRule({ ...form, enabled: true });
    setOpen(false);
    setForm({ name: "", direction: "INGRESS", action: "ALLOW", protocol: "TCP", ports: "443", range: "0.0.0.0/0", priority: 1000 });
    toast.success("Firewall rule added — re-run the Inbound simulation to see its effect");
  };

  return (
    <div className="rounded-xl border border-border">
      <div className="flex items-center justify-between border-b border-border p-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">VPC Firewall Rules</span>
          <Badge variant={allowed ? "success" : "danger"}>{allowed ? "HTTPS reachable" : "HTTPS blocked"}</Badge>
        </div>
        <div className="flex gap-1.5">
          <Button size="sm" variant="ghost" onClick={resetRules}>
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline">
                <Plus className="h-3.5 w-3.5" /> Add rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>New firewall rule</DialogTitle>
                <DialogDescription>Rules are evaluated in priority order (lowest number first).</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 flex flex-col gap-1.5">
                  <Label className="text-xs">Name</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="allow-custom-port" />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">Direction</Label>
                  <Select value={form.direction} onValueChange={(v) => setForm({ ...form, direction: v as "INGRESS" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="INGRESS">Ingress</SelectItem>
                      <SelectItem value="EGRESS">Egress</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">Action</Label>
                  <Select value={form.action} onValueChange={(v) => setForm({ ...form, action: v as "ALLOW" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALLOW">Allow</SelectItem>
                      <SelectItem value="DENY">Deny</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">Protocol</Label>
                  <Input value={form.protocol} onChange={(e) => setForm({ ...form, protocol: e.target.value })} placeholder="TCP" />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">Ports</Label>
                  <Input value={form.ports} onChange={(e) => setForm({ ...form, ports: e.target.value })} placeholder="443" />
                </div>
                <div className="col-span-2 flex flex-col gap-1.5">
                  <Label className="text-xs">Source/Target Range</Label>
                  <Input value={form.range} onChange={(e) => setForm({ ...form, range: e.target.value })} placeholder="0.0.0.0/0" />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs">Priority</Label>
                  <Input type="number" value={form.priority} onChange={(e) => setForm({ ...form, priority: Number(e.target.value) })} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={handleAdd}>Add rule</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      <ScrollArea className="max-h-64">
        <div className="divide-y divide-border">
          {rules
            .slice()
            .sort((a, b) => a.priority - b.priority)
            .map((rule) => (
              <div key={rule.id} className="flex items-center gap-3 px-3 py-2 text-xs">
                <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                <span className="w-36 truncate font-medium">{rule.name}</span>
                <Badge variant={rule.action === "ALLOW" ? "success" : "danger"} className="w-14 justify-center">
                  {rule.action}
                </Badge>
                <Badge variant="outline" className="w-16 justify-center">{rule.direction}</Badge>
                <span className="w-24 truncate text-muted-foreground">{rule.protocol}:{rule.ports}</span>
                <span className="flex-1 truncate text-muted-foreground">{rule.range}</span>
                <span className="w-10 text-right text-muted-foreground">{rule.priority}</span>
                <Button size="iconSm" variant="ghost" onClick={() => removeRule(rule.id)}>
                  <Trash2 className="h-3.5 w-3.5 text-danger" />
                </Button>
              </div>
            ))}
        </div>
      </ScrollArea>
    </div>
  );
}

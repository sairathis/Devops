"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { Globe2, Laptop, Ban } from "lucide-react";
import { RESOURCE_ICONS } from "@/components/gcp/resource-icon";
import {
  TOPOLOGY_NODES, STATIC_EDGES, SUBNET_BOXES, VIEWBOX, nodeCenter, PacketSpec,
} from "@/lib/networking/topology";
import type { TrafficMode } from "@/store/networking-store";

const pct = (v: number, total: number) => `${(v / total) * 100}%`;

function NodeIcon({ icon }: { icon: string }) {
  if (icon === "internet") return <Globe2 className="h-4 w-4" />;
  if (icon === "client") return <Laptop className="h-4 w-4" />;
  const Icon = RESOURCE_ICONS[icon];
  if (Icon) return <Icon className="h-4 w-4" />;
  return <Globe2 className="h-4 w-4" />;
}

export function TopologyDiagram({
  packets,
  running,
  mode,
}: {
  packets: PacketSpec[];
  running: boolean;
  mode: TrafficMode;
}) {
  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-border bg-grid" style={{ aspectRatio: `${VIEWBOX.w} / ${VIEWBOX.h}` }}>
      <svg viewBox={`0 0 ${VIEWBOX.w} ${VIEWBOX.h}`} className="absolute inset-0 h-full w-full" preserveAspectRatio="none">
        {SUBNET_BOXES.map((box) => (
          <g key={box.label}>
            <rect
              x={box.x} y={box.y} width={box.w} height={box.h} rx={12}
              fill="hsl(var(--gcp-blue) / 0.04)" stroke="hsl(var(--gcp-blue) / 0.35)" strokeDasharray="6 5" strokeWidth={1.5}
            />
            <text x={box.x + 10} y={box.y - 8} className="fill-muted-foreground" style={{ fontSize: 12 }}>
              {box.label}
            </text>
          </g>
        ))}
        {STATIC_EDGES.map(([a, b]) => {
          const p1 = nodeCenter(a);
          const p2 = nodeCenter(b);
          return (
            <line
              key={`${a}-${b}`}
              x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
              stroke="hsl(var(--border))" strokeWidth={1.5}
            />
          );
        })}
      </svg>

      {TOPOLOGY_NODES.map((n) => (
        <div
          key={n.id}
          className="absolute flex flex-col items-center justify-center gap-1 rounded-lg border border-border bg-card px-2 py-1.5 text-center shadow-sm"
          style={{ left: pct(n.x, VIEWBOX.w), top: pct(n.y, VIEWBOX.h), width: pct(n.w, VIEWBOX.w), height: pct(n.h, VIEWBOX.h) }}
        >
          <div className="flex items-center gap-1.5">
            <ResourceIconOrCustom icon={n.icon} />
            <span className="truncate text-[11px] font-medium leading-tight">{n.label}</span>
          </div>
          {n.sub && <span className="truncate text-[9px] text-muted-foreground leading-tight">{n.sub}</span>}
        </div>
      ))}

      {running &&
        packets.map((p, i) => (
          <Packet key={`${mode}-${i}-${p.path.join("-")}`} packet={p} delay={i * 0.9} />
        ))}

      {running &&
        packets
          .filter((p) => p.blockedAt)
          .map((p, i) => {
            const c = nodeCenter(p.blockedAt!);
            return (
              <div
                key={`blocked-${i}`}
                className="pointer-events-none absolute z-10 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center"
                style={{ left: pct(c.x, VIEWBOX.w), top: pct(c.y, VIEWBOX.h) }}
              >
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-danger/40" />
                <Ban className="relative h-4 w-4 text-danger" />
              </div>
            );
          })}
    </div>
  );
}

function ResourceIconOrCustom({ icon }: { icon: string }) {
  return (
    <span className="inline-flex h-5 w-5 items-center justify-center rounded">
      <NodeIcon icon={icon} />
    </span>
  );
}

function Packet({ packet, delay }: { packet: PacketSpec; delay: number }) {
  const points = packet.path.map((id) => nodeCenter(id));
  const left = points.map((p) => pct(p.x, VIEWBOX.w));
  const top = points.map((p) => pct(p.y, VIEWBOX.h));
  const duration = Math.max(1.2, (points.length - 1) * 1.1);

  if (packet.blockedAt) {
    return (
      <>
        <motion.div
          className="absolute z-10 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full shadow-[0_0_8px_currentColor]"
          style={{ background: packet.color, color: packet.color }}
          animate={{ left, top, opacity: [1, 1, 0] }}
          transition={{ duration, delay, repeat: Infinity, repeatDelay: 0.6, ease: "linear", times: points.map((_, i) => i / (points.length - 1)) }}
        />
      </>
    );
  }

  return (
    <motion.div
      className="absolute z-10 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full shadow-[0_0_8px_currentColor]"
      style={{ background: packet.color, color: packet.color }}
      animate={{ left, top }}
      transition={{ duration, delay, repeat: Infinity, repeatDelay: 0.4, ease: "linear" }}
    />
  );
}

"use client";
import * as React from "react";
import { ExternalLink, Clock } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import type { CertificationPath, CertificationLevel } from "@/lib/certification-paths/paths";
import { useCertificationStore } from "@/store/certification-store";
import { cn } from "@/lib/utils";

const LEVEL_BADGE_VARIANT: Record<CertificationLevel, "info" | "success"> = {
  Associate: "info",
  Professional: "success",
};

interface CertificationPathCardProps {
  path: CertificationPath;
}

export function CertificationPathCard({ path }: CertificationPathCardProps) {
  const completedTopics = useCertificationStore((s) => s.completedTopics);
  const toggleTopic = useCertificationStore((s) => s.toggleTopic);

  const completedCount = path.topics.filter((t) => completedTopics[`${path.id}:${t.id}`]).length;
  const percent = Math.round((completedCount / path.topics.length) * 100);

  return (
    <Card>
      <CardHeader className="gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle>{path.title}</CardTitle>
          <Badge variant={LEVEL_BADGE_VARIANT[path.level]}>{path.level}</Badge>
        </div>
        <CardDescription>{path.description}</CardDescription>
        <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> ~{path.estimatedHours}h estimated
          </span>
          <a
            href={path.officialUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-primary hover:underline"
          >
            Official exam guide <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              {completedCount} of {path.topics.length} topics complete
            </span>
            <span className="font-medium">{percent}%</span>
          </div>
          <Progress value={percent} />
        </div>

        <Accordion type="single" collapsible defaultValue={path.topics.length > 0 ? "topics" : undefined}>
          <AccordionItem value="topics" className="border-none">
            <AccordionTrigger className="py-2 text-sm text-muted-foreground hover:no-underline">
              Study topics ({path.topics.length})
            </AccordionTrigger>
            <AccordionContent>
              <ol className="space-y-1">
                {path.topics.map((topic, index) => {
                  const key = `${path.id}:${topic.id}`;
                  const checked = Boolean(completedTopics[key]);
                  return (
                    <li
                      key={topic.id}
                      className={cn(
                        "flex items-start gap-3 rounded-lg border border-transparent p-2 transition-colors hover:border-border",
                        checked && "opacity-70",
                      )}
                    >
                      <Checkbox
                        id={key}
                        checked={checked}
                        onCheckedChange={() => toggleTopic(path.id, topic.id)}
                        className="mt-0.5"
                      />
                      <label htmlFor={key} className="flex-1 cursor-pointer select-none">
                        <span
                          className={cn(
                            "text-sm font-medium text-foreground",
                            checked && "line-through decoration-muted-foreground/60",
                          )}
                        >
                          {index + 1}. {topic.title}
                        </span>
                        <p className="mt-0.5 text-xs text-muted-foreground">{topic.description}</p>
                      </label>
                    </li>
                  );
                })}
              </ol>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}

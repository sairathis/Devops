import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import type { ArchNode } from "@/store/architecture-store";

function formatConfigValue(value: unknown): string {
  if (Array.isArray(value)) return value.join(", ") || "—";
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
}

export function CanvasNodeCard({ node }: { node: ArchNode }) {
  const def = getResourceDef(node.data.resourceType);
  const configEntries = Object.entries(node.data.config ?? {}).slice(0, 2);

  return (
    <Card className="h-full transition-shadow hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-3 pt-5">
        <div className="flex items-start gap-2.5">
          <ResourceIcon type={node.data.resourceType} color={def?.color ?? "gcp-blue"} size={20} className="h-9 w-9" />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium leading-tight">{node.data.label}</p>
            <p className="text-xs text-muted-foreground">{def?.label ?? node.data.resourceType}</p>
          </div>
        </div>

        {configEntries.length > 0 && (
          <div className="space-y-0.5">
            {configEntries.map(([key, value]) => (
              <p key={key} className="truncate text-[11px] text-muted-foreground">
                <span className="font-medium text-foreground/80">{key}:</span> {formatConfigValue(value)}
              </p>
            ))}
          </div>
        )}

        <Button asChild size="sm" variant="outline" className="mt-auto w-full">
          <Link href="/architecture-builder">
            Open in Architecture Builder <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}

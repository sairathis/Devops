"use client";
import { useRouter } from "next/navigation";
import { FolderOpen, ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useArchitectureStore } from "@/store/architecture-store";

export interface ExplorerProject {
  id: string;
  name: string;
  updatedAt: string;
  nodes: unknown[];
}

export function ProjectCard({ project }: { project: ExplorerProject }) {
  const router = useRouter();
  const loadProject = useArchitectureStore((s) => s.loadProject);

  const handleOpen = () => {
    loadProject(project.id);
    router.push("/architecture-builder");
  };

  return (
    <Card className="h-full transition-shadow hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-3 pt-5">
        <div className="flex items-start gap-2.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gcp-yellow/10 text-gcp-yellow">
            <FolderOpen className="h-[18px] w-[18px]" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium leading-tight">{project.name}</p>
            <p className="text-xs text-muted-foreground">
              Updated {new Date(project.updatedAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        <Badge variant="secondary" className="w-fit text-[10px]">
          {project.nodes.length} resource{project.nodes.length === 1 ? "" : "s"}
        </Badge>

        <Button size="sm" variant="outline" className="mt-auto w-full" onClick={handleOpen}>
          Open <ArrowUpRight className="h-3.5 w-3.5" />
        </Button>
      </CardContent>
    </Card>
  );
}

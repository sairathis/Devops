import type { LucideIcon } from "lucide-react";
import { Boxes, Workflow, FolderOpen } from "lucide-react";
import { cn } from "@/lib/utils";

const STAT_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "text-gcp-blue",
  "gcp-green": "text-gcp-green",
  "gcp-yellow": "text-gcp-yellow",
  "gcp-red": "text-gcp-red",
};

function StatTile({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: LucideIcon;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="glass-panel flex items-center gap-3 rounded-xl px-4 py-3.5">
      <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted", STAT_COLOR_CLASS[color] ?? STAT_COLOR_CLASS["gcp-blue"])}>
        <Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0">
        <div className="text-xl font-semibold leading-none">{value}</div>
        <div className="mt-1 text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

export function StatStrip({
  totalResourceTypes,
  canvasNodeCount,
  savedProjectCount,
}: {
  totalResourceTypes: number;
  canvasNodeCount: number;
  savedProjectCount: number;
}) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      <StatTile icon={Boxes} label="GCP resource types available" value={totalResourceTypes} color="gcp-blue" />
      <StatTile icon={Workflow} label="Resources on your canvas" value={canvasNodeCount} color="gcp-green" />
      <StatTile icon={FolderOpen} label="Saved projects" value={savedProjectCount} color="gcp-yellow" />
    </div>
  );
}

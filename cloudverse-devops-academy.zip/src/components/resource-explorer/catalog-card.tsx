import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { formatCurrency } from "@/lib/utils";
import { CATEGORY_META, type GcpResourceDef } from "@/types/gcp";

export function CatalogCard({ def }: { def: GcpResourceDef }) {
  const monthlyCost = def.estimateMonthlyCost(def.defaultConfig);
  return (
    <Card className="h-full transition-shadow hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-3 pt-5">
        <div className="flex items-start justify-between gap-2">
          <ResourceIcon type={def.type} color={def.color} size={20} className="h-9 w-9" />
          <Badge variant="outline" className="shrink-0 text-[10px]">
            {CATEGORY_META[def.category].label}
          </Badge>
        </div>
        <div>
          <p className="text-sm font-medium leading-tight">{def.label}</p>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{def.description}</p>
        </div>
        <div className="mt-auto flex items-center justify-between pt-1 text-xs">
          <span className="text-muted-foreground">Est. monthly cost</span>
          <span className="font-medium">
            {monthlyCost > 0 ? `~${formatCurrency(monthlyCost)}` : "Free"}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

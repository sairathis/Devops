"use client";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CATEGORY_META, type ResourceCategory } from "@/types/gcp";

const CHIP_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "border-gcp-blue/40 bg-gcp-blue/10 text-gcp-blue",
  "gcp-green": "border-gcp-green/40 bg-gcp-green/10 text-gcp-green",
  "gcp-yellow": "border-gcp-yellow/40 bg-gcp-yellow/10 text-gcp-yellow",
  "gcp-red": "border-gcp-red/40 bg-gcp-red/10 text-gcp-red",
};

export type CategoryFilter = ResourceCategory | "all";

export function SearchControls({
  query,
  onQueryChange,
  category,
  onCategoryChange,
}: {
  query: string;
  onQueryChange: (value: string) => void;
  category: CategoryFilter;
  onCategoryChange: (value: CategoryFilter) => void;
}) {
  return (
    <div className="mb-6 space-y-3">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search GCP resources, canvas nodes, and saved projects…"
          className="h-10 pl-9 pr-9"
        />
        {query.length > 0 && (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => onQueryChange("")}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant={category === "all" ? "default" : "outline"}
          onClick={() => onCategoryChange("all")}
          className="h-7 rounded-full px-3 text-xs"
        >
          All categories
        </Button>
        {(Object.keys(CATEGORY_META) as ResourceCategory[]).map((key) => {
          const meta = CATEGORY_META[key];
          const active = category === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => onCategoryChange(active ? "all" : key)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                active
                  ? (CHIP_COLOR_CLASS[meta.color] ?? CHIP_COLOR_CLASS["gcp-blue"])
                  : "border-border bg-transparent text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              {meta.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

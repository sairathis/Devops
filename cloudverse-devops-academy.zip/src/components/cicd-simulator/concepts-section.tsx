"use client";
import { GitBranch, PackageCheck, Rocket, RefreshCw, Shuffle, GitCompare } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const CI_CD_CONCEPTS = [
  {
    title: "Continuous Integration",
    icon: GitBranch,
    badge: "CI",
    variant: "info" as const,
    body: "Every commit is automatically built and tested against the rest of the codebase. The goal is to catch integration bugs within minutes instead of weeks, so the Build and Unit Tests stages above run on every push.",
  },
  {
    title: "Continuous Delivery",
    icon: PackageCheck,
    badge: "CD",
    variant: "success" as const,
    body: "Every change that passes CI is automatically packaged into a release-ready artifact — like the image pushed to Artifact Registry above — and is always in a deployable state. A human still clicks the button to ship it.",
  },
  {
    title: "Continuous Deployment",
    icon: Rocket,
    badge: "CD",
    variant: "warning" as const,
    body: "The natural extension of delivery: every change that passes all automated checks is deployed to production automatically, with no manual approval gate. The Deploy to GKE and Smoke Test stages above are what that final, unattended step looks like.",
  },
];

const DEPLOYMENT_STRATEGIES = [
  {
    title: "Rolling Update",
    icon: RefreshCw,
    body: "Old pods are replaced with new ones a few at a time, so the service stays up throughout. It is simple and resource-efficient, but a bad rollout is only caught after some traffic has already hit the new version.",
  },
  {
    title: "Blue-Green",
    icon: GitCompare,
    body: "Two full environments run side by side — “blue” (live) and “green” (new). Traffic is switched all at once after the green environment is verified, which makes rollback instant but doubles the infrastructure cost during the switch.",
  },
  {
    title: "Canary",
    icon: Shuffle,
    body: "The new version is released to a small slice of real traffic first — say 5 percent — while metrics are watched closely. If it looks healthy, traffic is gradually shifted over; if not, the blast radius of a bad release stays small.",
  },
];

export function ConceptsSection() {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>CI vs. Continuous Delivery vs. Continuous Deployment</CardTitle>
          <CardDescription>Three related terms that get flattened into &quot;CI/CD&quot; way too often</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {CI_CD_CONCEPTS.map((c) => (
            <div key={c.title} className="flex gap-3 rounded-lg border border-border p-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <c.icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{c.title}</span>
                  <Badge variant={c.variant}>{c.badge}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{c.body}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Deployment strategies</CardTitle>
          <CardDescription>How the &quot;Deploy to GKE&quot; stage could actually ship your change</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {DEPLOYMENT_STRATEGIES.map((s) => (
            <div key={s.title} className="flex gap-3 rounded-lg border border-border p-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gcp-blue/10 text-gcp-blue">
                <s.icon className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <span className="text-sm font-medium">{s.title}</span>
                <p className="mt-1 text-xs text-muted-foreground">{s.body}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

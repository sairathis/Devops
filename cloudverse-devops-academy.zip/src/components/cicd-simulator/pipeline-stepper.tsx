"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Loader2, CheckCircle2, XCircle, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  PIPELINE_STAGES,
  STATUS_CARD_CLASS,
  STATUS_ICON_WRAP_CLASS,
  STATUS_CONNECTOR_CLASS,
  STATUS_LABEL,
  type StageStatus,
} from "./pipeline-config";

function StatusIcon({ status }: { status: StageStatus }) {
  if (status === "running") return <Loader2 className="h-3.5 w-3.5 animate-spin" />;
  if (status === "success") return <CheckCircle2 className="h-3.5 w-3.5" />;
  if (status === "failed") return <XCircle className="h-3.5 w-3.5" />;
  return <Circle className="h-3.5 w-3.5" />;
}

export function PipelineStepper({ statuses }: { statuses: StageStatus[] }) {
  return (
    <div className="flex items-stretch gap-1 overflow-x-auto pb-1 sm:gap-0">
      {PIPELINE_STAGES.map((stage, i) => {
        const status = statuses[i] ?? "pending";
        const Icon = stage.icon;
        return (
          <React.Fragment key={stage.id}>
            <motion.div
              layout
              className={cn(
                "flex min-w-[130px] flex-1 flex-col items-center gap-2 rounded-xl border px-3 py-4 text-center transition-colors",
                STATUS_CARD_CLASS[status],
              )}
            >
              <div className={cn("relative flex h-10 w-10 items-center justify-center rounded-full", STATUS_ICON_WRAP_CLASS[status])}>
                <Icon className="h-5 w-5" />
                <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full border border-card bg-card">
                  <StatusIcon status={status} />
                </span>
              </div>
              <div>
                <p className="text-xs font-medium leading-tight">{stage.label}</p>
                <p className="mt-0.5 text-[10px] text-muted-foreground">{STATUS_LABEL[status]}</p>
              </div>
            </motion.div>
            {i < PIPELINE_STAGES.length - 1 && (
              <div className="flex w-4 shrink-0 items-center sm:w-6">
                <div className={cn("h-0.5 w-full rounded-full transition-colors", STATUS_CONNECTOR_CLASS[status])} />
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

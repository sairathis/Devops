export const CLOUDBUILD_YAML = `# Triggered by: push to "main" (Cloud Build GitHub trigger)
# Mirrors the simulated pipeline: Commit -> Build -> Unit Tests ->
# Push to Artifact Registry -> Deploy to GKE -> Smoke Test

steps:
  # 1. Build the container image
  - id: build
    name: gcr.io/cloud-builders/docker
    args:
      - build
      - -t
      - us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$SHORT_SHA
      - .

  # 2. Run unit tests inside the built image
  - id: unit-tests
    name: us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$SHORT_SHA
    entrypoint: npm
    args: ['test']
    waitFor: ['build']

  # 3. Push the image to Artifact Registry
  - id: push
    name: gcr.io/cloud-builders/docker
    args:
      - push
      - us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$SHORT_SHA
    waitFor: ['unit-tests']

  # 4. Roll out to GKE (rolling update)
  - id: deploy
    name: gcr.io/cloud-builders/gke-deploy
    args:
      - run
      - --filename=k8s/deployment.yaml
      - --image=us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$SHORT_SHA
      - --location=us-central1-a
      - --cluster=payments-cluster
    waitFor: ['push']

  # 5. Smoke test the freshly rolled-out revision
  - id: smoke-test
    name: gcr.io/cloud-builders/curl
    entrypoint: bash
    args:
      - -c
      - |
        curl -sf https://payments-api.cloudverse.dev/healthz || exit 1
    waitFor: ['deploy']

images:
  - us-central1-docker.pkg.dev/$PROJECT_ID/payments-api/app:$SHORT_SHA

options:
  logging: CLOUD_LOGGING_ONLY
  machineType: E2_HIGHCPU_8

timeout: 1200s
`;

import type { LucideIcon } from "lucide-react";
import {
  GitCommitHorizontal,
  Hammer,
  FlaskConical,
  PackageCheck,
  Rocket,
  HeartPulse,
} from "lucide-react";

export type StageStatus = "pending" | "running" | "success" | "failed";

export interface StageDef {
  id: string;
  label: string;
  icon: LucideIcon;
  /** Minimum / maximum simulated "running" duration in ms. */
  minMs: number;
  maxMs: number;
  /** Probability (0..1) that this stage fails when it runs. */
  failChance: number;
  /** Log lines streamed while the stage is running (before the final outcome line). */
  runningLog: string[];
  /** Log line appended when the stage succeeds. */
  successLog: string;
  /** Pool of plausible failure log lines — one is picked at random on failure. */
  failureLogPool: string[];
}

export const PIPELINE_STAGES: StageDef[] = [
  {
    id: "commit",
    label: "Commit",
    icon: GitCommitHorizontal,
    minMs: 700,
    maxMs: 1000,
    failChance: 0,
    runningLog: [
      "Cloning repository github.com/cloudverse/payments-api...",
      "Checked out commit 4f2a9c1 on branch main",
    ],
    successLog: "Commit stage complete — webhook received from Cloud Build trigger.",
    failureLogPool: [],
  },
  {
    id: "build",
    label: "Build",
    icon: Hammer,
    minMs: 1000,
    maxMs: 1500,
    failChance: 0.08,
    runningLog: ["Running `docker build -t app:4f2a9c1 .`...", "Installing dependencies with `npm ci`..."],
    successLog: "Image built successfully (312MB, 4 layers cached).",
    failureLogPool: [
      "FAIL: docker build exited with code 1 — COPY failed: file not found in build context",
      "FAIL: npm ci — could not resolve dependency tree, peer dependency conflict",
    ],
  },
  {
    id: "unit-tests",
    label: "Unit Tests",
    icon: FlaskConical,
    minMs: 900,
    maxMs: 1400,
    failChance: 0.15,
    runningLog: ["Running `npm test`...", "Executing 58 test cases across 11 suites..."],
    successLog: "Tests complete — 58 passed, 0 failed (4.2s).",
    failureLogPool: [
      "FAIL src/tests/auth.test.ts — expected 200, received 500",
      "FAIL src/tests/billing.test.ts — Timeout of 5000ms exceeded waiting for async callback",
      "FAIL src/tests/checkout.test.ts — expected total to equal 42.00, received NaN",
    ],
  },
  {
    id: "push",
    label: "Push to Artifact Registry",
    icon: PackageCheck,
    minMs: 900,
    maxMs: 1300,
    failChance: 0.06,
    runningLog: [
      "Tagging image us-central1-docker.pkg.dev/cloudverse-prod/payments-api/app:4f2a9c1...",
      "Pushing image to us-central1-docker.pkg.dev/cloudverse-prod/payments-api/app:4f2a9c1...",
    ],
    successLog: "Image pushed — digest sha256:8a1c4f...e21b.",
    failureLogPool: [
      "FAIL: denied: Permission 'artifactregistry.repositories.uploadArtifacts' denied on resource",
      "FAIL: unauthorized — token for us-central1-docker.pkg.dev expired mid-push",
    ],
  },
  {
    id: "deploy",
    label: "Deploy to GKE",
    icon: Rocket,
    minMs: 1100,
    maxMs: 1500,
    failChance: 0.1,
    runningLog: [
      "Applying rolling update to gke deployment `payments-api` in cluster `payments-cluster`...",
      "Waiting for 3/3 replicas to report Ready...",
    ],
    successLog: "Rollout complete — deployment/payments-api is healthy (3/3 replicas).",
    failureLogPool: [
      "FAIL: rollout status deployment/payments-api exceeded its progress deadline (600s)",
      "FAIL: ImagePullBackOff — could not pull image from us-central1-docker.pkg.dev",
      "FAIL: CrashLoopBackOff — container exited with code 137 (OOMKilled)",
    ],
  },
  {
    id: "smoke-test",
    label: "Smoke Test",
    icon: HeartPulse,
    minMs: 800,
    maxMs: 1200,
    failChance: 0.08,
    runningLog: ["Sending request GET https://payments-api.cloudverse.dev/healthz..."],
    successLog: "Smoke test: GET /healthz -> 200 OK.",
    failureLogPool: [
      "FAIL: GET /healthz -> 503 Service Unavailable",
      "FAIL: GET /healthz -> connection timed out after 5000ms",
    ],
  },
];

export const STATUS_CARD_CLASS: Record<StageStatus, string> = {
  pending: "border-border bg-muted/30 text-muted-foreground",
  running: "border-info/50 bg-info/10 text-info shadow-[0_0_0_3px_rgba(59,130,246,0.12)] animate-pulse",
  success: "border-success/50 bg-success/10 text-success",
  failed: "border-danger/50 bg-danger/10 text-danger",
};

export const STATUS_ICON_WRAP_CLASS: Record<StageStatus, string> = {
  pending: "bg-muted text-muted-foreground",
  running: "bg-info/15 text-info",
  success: "bg-success/15 text-success",
  failed: "bg-danger/15 text-danger",
};

export const STATUS_CONNECTOR_CLASS: Record<StageStatus, string> = {
  pending: "bg-border",
  running: "bg-border",
  success: "bg-success/60",
  failed: "bg-danger/60",
};

export const STATUS_LABEL: Record<StageStatus, string> = {
  pending: "Pending",
  running: "Running",
  success: "Success",
  failed: "Failed",
};

export const STATUS_BADGE_VARIANT: Record<StageStatus, "secondary" | "info" | "success" | "danger"> = {
  pending: "secondary",
  running: "info",
  success: "success",
  failed: "danger",
};

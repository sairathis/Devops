"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal } from "lucide-react";
import { cn } from "@/lib/utils";

export type LogTone = "muted" | "info" | "success" | "error";

export interface LogEntry {
  id: string;
  text: string;
  tone: LogTone;
}

const TONE_CLASS: Record<LogTone, string> = {
  muted: "text-zinc-500",
  info: "text-zinc-200",
  success: "text-emerald-400",
  error: "text-red-400",
};

const TONE_PREFIX: Record<LogTone, string> = {
  muted: "$",
  info: ">",
  success: "✓",
  error: "✗",
};

export function LogPanel({ entries }: { entries: LogEntry[] }) {
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [entries.length]);

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-zinc-950">
      <div className="flex items-center gap-2 border-b border-white/10 bg-white/5 px-3 py-1.5">
        <Terminal className="h-3.5 w-3.5 text-zinc-400" />
        <span className="font-mono text-xs text-zinc-400">pipeline-run.log</span>
        <div className="ml-auto flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-danger/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-warning/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-success/70" />
        </div>
      </div>
      <div ref={scrollRef} className="h-72 overflow-y-auto px-3 py-3 font-mono text-[12px] leading-relaxed">
        {entries.length === 0 && (
          <p className="text-zinc-600">Press &quot;Run Pipeline&quot; to stream build output here...</p>
        )}
        <AnimatePresence initial={false}>
          {entries.map((entry) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.18 }}
              className={cn("whitespace-pre-wrap break-words", TONE_CLASS[entry.tone])}
            >
              <span className="mr-1.5 select-none text-zinc-600">{TONE_PREFIX[entry.tone]}</span>
              {entry.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

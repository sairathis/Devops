"use client";
import * as React from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark, oneLight } from "react-syntax-highlighter/dist/esm/styles/prism";
import { useTheme } from "next-themes";
import { Check, Copy, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function CodeBlock({
  code,
  language = "hcl",
  filename,
  className,
  maxHeight = "60vh",
}: {
  code: string;
  language?: string;
  filename?: string;
  className?: string;
  maxHeight?: string;
}) {
  const { resolvedTheme } = useTheme();
  const [copied, setCopied] = React.useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const download = () => {
    const blob = new Blob([code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename ?? "output.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={cn("overflow-hidden rounded-xl border border-border", className)}>
      <div className="flex items-center justify-between border-b border-border bg-muted/50 px-3 py-1.5">
        <span className="font-mono text-xs text-muted-foreground">{filename ?? language}</span>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="iconSm" onClick={copy} aria-label="Copy code">
            {copied ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
          <Button variant="ghost" size="iconSm" onClick={download} aria-label="Download file">
            <Download className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
      <div style={{ maxHeight }} className="overflow-auto">
        <SyntaxHighlighter
          language={language}
          style={resolvedTheme === "light" ? oneLight : oneDark}
          customStyle={{ margin: 0, padding: "1rem", fontSize: "12.5px", background: "transparent" }}
          wrapLongLines
        >
          {code || " "}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}

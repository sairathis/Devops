// Deterministic mock telemetry for the Monitoring Academy dashboard.
// IMPORTANT: never use Math.random()/Date.now() here — this runs during
// render on both server and client, and must produce identical output
// every time to avoid SSR/client hydration mismatches.

export interface MetricPoint {
  hour: number;
  label: string;
  latencyMs: number;
  errorRatePct: number;
}

const POINT_COUNT = 24;

/**
 * Generates 24 hourly points of "live-looking" latency + error-rate data
 * using fixed trigonometric formulas so the series is stable across renders.
 */
export function generateMetricSeries(count: number = POINT_COUNT): MetricPoint[] {
  return Array.from({ length: count }, (_, i) => {
    const latencyMs = Math.round(
      150 + Math.sin(i / 3) * 22 + Math.sin(i / 7.5) * 10 + Math.cos(i / 2.3) * 6,
    );
    const errorRatePct = Number(
      Math.max(0.02, 0.4 + Math.sin(i / 4 + 1) * 0.22 + Math.cos(i / 9) * 0.1).toFixed(2),
    );
    return {
      hour: i,
      label: `${String(i).padStart(2, "0")}:00`,
      latencyMs: Math.max(60, latencyMs),
      errorRatePct,
    };
  });
}

export const METRIC_SERIES = generateMetricSeries();

export function getCurrentStats(series: MetricPoint[] = METRIC_SERIES) {
  const latest = series[series.length - 1];
  const p99LatencyMs = Math.max(...series.map((p) => p.latencyMs)) + 38;
  const avgErrorRate = series.reduce((s, p) => s + p.errorRatePct, 0) / series.length;
  return {
    uptimePct: 99.95,
    currentLatencyMs: latest.latencyMs,
    p99LatencyMs,
    currentErrorRatePct: latest.errorRatePct,
    avgErrorRatePct: Number(avgErrorRate.toFixed(2)),
  };
}

// --- SLO / error budget mock state -----------------------------------

export const SLO_DEFINITION = {
  name: "API availability",
  target: 99.9,
  windowDays: 30,
};

export const ERROR_BUDGET = {
  daysElapsed: 19,
  budgetConsumedPct: 34,
};

export function getErrorBudgetProjection() {
  const { daysElapsed, budgetConsumedPct } = ERROR_BUDGET;
  const { windowDays } = SLO_DEFINITION;
  const daysRemainingInWindow = windowDays - daysElapsed;
  const burnRatePerDay = budgetConsumedPct / daysElapsed;
  const projectedConsumedAtWindowEnd = Math.min(999, burnRatePerDay * windowDays);
  const budgetDaysRemainingAtCurrentBurn =
    burnRatePerDay > 0 ? (100 - budgetConsumedPct) / burnRatePerDay : Infinity;
  const onTrack = budgetDaysRemainingAtCurrentBurn >= daysRemainingInWindow;
  return {
    daysRemainingInWindow,
    burnRatePerDay: Number(burnRatePerDay.toFixed(2)),
    projectedConsumedAtWindowEnd: Number(projectedConsumedAtWindowEnd.toFixed(1)),
    budgetDaysRemainingAtCurrentBurn: Number(budgetDaysRemainingAtCurrentBurn.toFixed(1)),
    onTrack,
  };
}

// --- Alerting rules -----------------------------------------------------

export type AlertMetric = "latency" | "error-rate" | "uptime" | "cpu";
export type AlertCondition = ">" | "<";

export interface AlertRule {
  id: string;
  metric: AlertMetric;
  condition: AlertCondition;
  threshold: number;
  duration: string;
  channel: string;
  enabled: boolean;
}

export const METRIC_META: Record<AlertMetric, { label: string; unit: string }> = {
  latency: { label: "Request latency", unit: "ms" },
  "error-rate": { label: "Error rate", unit: "%" },
  uptime: { label: "Uptime", unit: "%" },
  cpu: { label: "CPU utilization", unit: "%" },
};

export const DEFAULT_ALERT_RULES: AlertRule[] = [
  {
    id: "rule-seed-1",
    metric: "latency",
    condition: ">",
    threshold: 500,
    duration: "5m",
    channel: "#sre-alerts",
    enabled: true,
  },
  {
    id: "rule-seed-2",
    metric: "error-rate",
    condition: ">",
    threshold: 2,
    duration: "10m",
    channel: "#sre-alerts",
    enabled: true,
  },
];

"use client";

import { Gauge, Target, FileSignature, Activity, Users, AlertTriangle, HardDrive, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const SIGNAL_ICON_CLASS: Record<string, string> = {
  latency: "bg-gcp-blue/10 text-gcp-blue",
  traffic: "bg-gcp-green/10 text-gcp-green",
  errors: "bg-gcp-red/10 text-gcp-red",
  saturation: "bg-gcp-yellow/10 text-gcp-yellow",
};

const GOLDEN_SIGNALS = [
  {
    id: "latency",
    icon: Activity,
    title: "Latency",
    description:
      "The time it takes to serve a request. Track successful and failed requests separately — a fast error still means something is broken, and mixing them hides real slowdowns.",
  },
  {
    id: "traffic",
    icon: Users,
    title: "Traffic",
    description:
      "The demand on your system, measured in something meaningful to it — requests per second, concurrent sessions, or messages consumed per second.",
  },
  {
    id: "errors",
    icon: AlertTriangle,
    title: "Errors",
    description:
      "The rate of requests that fail, whether explicitly (5xx responses) or implicitly (a 200 response with the wrong content, or a response that is far too slow to be useful).",
  },
  {
    id: "saturation",
    icon: HardDrive,
    title: "Saturation",
    description:
      "How “full” your service is — CPU, memory, disk I/O, or connection pool usage. Saturation trending upward is often the earliest warning sign before latency or errors get bad.",
  },
];

export function ConceptExplainer() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Observability concepts</CardTitle>
        <CardDescription>The vocabulary every on-call engineer needs before looking at a dashboard.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Accordion type="multiple" defaultValue={["sli-slo-sla"]} className="w-full">
          <AccordionItem value="sli-slo-sla">
            <AccordionTrigger>
              <span className="flex items-center gap-2">
                <Gauge className="h-4 w-4 text-gcp-blue" /> SLIs, SLOs &amp; SLAs
              </span>
            </AccordionTrigger>
            <AccordionContent>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="rounded-lg border border-border p-3">
                  <Badge variant="info" className="mb-2">SLI</Badge>
                  <p className="text-xs leading-relaxed">
                    A <span className="font-medium text-foreground">Service Level Indicator</span> is a directly
                    measured metric, like the percentage of requests that succeed or the latency of the 99th
                    percentile request. It is the raw number you actually observe.
                  </p>
                </div>
                <div className="rounded-lg border border-border p-3">
                  <Badge variant="success" className="mb-2">SLO</Badge>
                  <p className="text-xs leading-relaxed">
                    A <span className="font-medium text-foreground">Service Level Objective</span> is the internal
                    target you set for an SLI, e.g. &quot;99.9% of requests succeed over 30 days.&quot; It is a goal
                    your team designs around, not a promise made to customers.
                  </p>
                </div>
                <div className="rounded-lg border border-border p-3">
                  <Badge variant="warning" className="mb-2">SLA</Badge>
                  <p className="text-xs leading-relaxed">
                    A <span className="font-medium text-foreground">Service Level Agreement</span> is an external,
                    often contractual, promise to customers — usually looser than your SLO, with financial or
                    support consequences if missed. You want to breach your SLO long before you&apos;d ever breach
                    an SLA.
                  </p>
                </div>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
                They form a chain: an SLI is measured, an SLO is the internal bar you hold yourself to, and an SLA is
                the external contract built on top with room to spare.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="golden-signals">
            <AccordionTrigger>
              <span className="flex items-center gap-2">
                <Target className="h-4 w-4 text-gcp-green" /> The Four Golden Signals
              </span>
            </AccordionTrigger>
            <AccordionContent>
              <p className="mb-3 text-xs leading-relaxed text-muted-foreground">
                Popularized by Google&apos;s SRE book: if you can only monitor four things about a user-facing
                system, monitor these.
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                {GOLDEN_SIGNALS.map((s) => (
                  <div key={s.id} className="flex gap-3 rounded-lg border border-border p-3">
                    <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${SIGNAL_ICON_CLASS[s.id]}`}>
                      <s.icon className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold">{s.title}</p>
                      <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{s.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="error-budgets">
            <AccordionTrigger>
              <span className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-gcp-yellow" /> Error Budgets
              </span>
            </AccordionTrigger>
            <AccordionContent>
              <p className="text-xs leading-relaxed">
                An <span className="font-medium text-foreground">error budget</span> is simply 100% minus your SLO —
                if the SLO is 99.9% over 30 days, you have a 0.1% budget of allowed failure, downtime, or errors for
                that window. It converts an abstract reliability target into a concrete, spendable quantity.
              </p>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                Error budgets exist to resolve the standing tension between shipping fast and staying reliable: as
                long as budget remains, teams are free to take risks — ship features, roll out changes, try
                risky migrations. Once the budget is exhausted, the team shifts focus to stability work (fixing
                bugs, hardening infrastructure) until the budget recovers. It replaces subjective &quot;should we
                ship?&quot; debates with an objective, shared number.
              </p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="flex items-start gap-2 rounded-lg bg-info/10 px-3 py-2.5 text-xs text-foreground">
          <FileSignature className="mt-0.5 h-3.5 w-3.5 shrink-0 text-info" />
          <span>
            <span className="font-medium">In practice:</span> pick a handful of SLIs from the golden signals, set an
            SLO for each, track the error budget it implies, and let alerting rules fire when you&apos;re burning
            that budget too fast — which is exactly what the rest of this module walks through.
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

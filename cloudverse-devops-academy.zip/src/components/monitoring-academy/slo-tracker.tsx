"use client";

import { Target, Flame, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { SLO_DEFINITION, ERROR_BUDGET, getErrorBudgetProjection } from "./mock-data";

export function SloTracker() {
  const projection = getErrorBudgetProjection();
  const remaining = 100 - ERROR_BUDGET.budgetConsumedPct;

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle className="flex items-center gap-2 text-sm">
            <Target className="h-4 w-4 text-gcp-green" /> SLO tracker
          </CardTitle>
          <CardDescription>
            {SLO_DEFINITION.target}% of requests succeed over {SLO_DEFINITION.windowDays} days
          </CardDescription>
        </div>
        <Badge variant={projection.onTrack ? "success" : "danger"}>
          {projection.onTrack ? "On track" : "At risk"}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="mb-1.5 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Error budget consumed</span>
            <span className="font-medium">{ERROR_BUDGET.budgetConsumedPct}% of budget</span>
          </div>
          <Progress value={ERROR_BUDGET.budgetConsumedPct} className="h-2.5" />
          <p className="mt-1.5 text-[11px] text-muted-foreground">
            {remaining}% of this cycle&apos;s error budget remains, with {projection.daysRemainingInWindow} days left
            in the {SLO_DEFINITION.windowDays}-day window ({ERROR_BUDGET.daysElapsed} days elapsed).
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="flex items-start gap-2 rounded-lg border border-border p-3">
            <Flame className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-yellow" />
            <div>
              <p className="text-xs font-medium">Current burn rate</p>
              <p className="text-[11px] text-muted-foreground">
                ~{projection.burnRatePerDay}% of budget per day. At this pace you&apos;d use{" "}
                {projection.projectedConsumedAtWindowEnd}% of the budget by the end of the window.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-2 rounded-lg border border-border p-3">
            <CheckCircle2 className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${projection.onTrack ? "text-success" : "text-danger"}`} />
            <div>
              <p className="text-xs font-medium">Time remaining at this burn rate</p>
              <p className="text-[11px] text-muted-foreground">
                Roughly {projection.budgetDaysRemainingAtCurrentBurn} days of budget left if the burn rate holds —{" "}
                {projection.onTrack
                  ? "comfortably more than the days remaining in this window."
                  : "less than the days remaining in this window, so this SLO is at risk of breaching."}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

"use client";

import * as React from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Activity, Gauge, ShieldCheck, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { METRIC_SERIES, getCurrentStats } from "./mock-data";

interface SimpleTooltipProps {
  active?: boolean;
  label?: React.ReactNode;
  payload?: readonly { dataKey?: unknown; value?: React.ReactNode }[];
  unit: string;
}

function ChartTooltip({ active, payload, label, unit }: SimpleTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md">
      <p className="mb-1 font-medium text-muted-foreground">{label}</p>
      {payload.map((p, i) => (
        <p key={p.dataKey != null ? String(p.dataKey) : i} className="font-semibold">
          {p.value}
          {unit}
        </p>
      ))}
    </div>
  );
}

export function LiveDashboard() {
  const stats = React.useMemo(() => getCurrentStats(METRIC_SERIES), []);

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-3">
        <StatTile
          icon={ShieldCheck}
          label="Uptime (30d)"
          value={`${stats.uptimePct}%`}
          color="gcp-green"
        />
        <StatTile
          icon={Gauge}
          label="P99 latency"
          value={`${stats.p99LatencyMs} ms`}
          color="gcp-blue"
        />
        <StatTile
          icon={Activity}
          label="Current error rate"
          value={`${stats.currentErrorRatePct}%`}
          color="gcp-yellow"
        />
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-gcp-blue" /> Request latency
            </CardTitle>
            <CardDescription>Last 24 hours, hourly average (ms)</CardDescription>
          </div>
          <Badge variant="info">live</Badge>
        </CardHeader>
        <CardContent>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={METRIC_SERIES} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="label"
                  interval={3}
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={false}
                  tickLine={false}
                  width={40}
                />
                <Tooltip content={(p: object) => <ChartTooltip {...(p as SimpleTooltipProps)} unit=" ms" />} />
                <Line
                  type="monotone"
                  dataKey="latencyMs"
                  stroke="hsl(var(--gcp-blue))"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Activity className="h-4 w-4 text-gcp-red" /> Error rate
            </CardTitle>
            <CardDescription>Last 24 hours, hourly average (%)</CardDescription>
          </div>
          <Badge variant="info">live</Badge>
        </CardHeader>
        <CardContent>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={METRIC_SERIES} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="errorRateFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--gcp-red))" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="hsl(var(--gcp-red))" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="label"
                  interval={3}
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                  axisLine={false}
                  tickLine={false}
                  width={40}
                />
                <Tooltip content={(p: object) => <ChartTooltip {...(p as SimpleTooltipProps)} unit="%" />} />
                <Area
                  type="monotone"
                  dataKey="errorRatePct"
                  stroke="hsl(var(--gcp-red))"
                  strokeWidth={2}
                  fill="url(#errorRateFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

const STAT_TILE_COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "text-gcp-blue bg-gcp-blue/10",
  "gcp-green": "text-gcp-green bg-gcp-green/10",
  "gcp-yellow": "text-gcp-yellow bg-gcp-yellow/10",
  "gcp-red": "text-gcp-red bg-gcp-red/10",
};

function StatTile({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 pt-5">
        <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg", STAT_TILE_COLOR_CLASS[color])}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-xl font-semibold leading-none">{value}</div>
          <div className="mt-1 text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}

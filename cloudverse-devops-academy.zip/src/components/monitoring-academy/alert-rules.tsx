"use client";

import * as React from "react";
import { toast } from "sonner";
import { Plus, Trash2, BellRing } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { randomId } from "@/lib/utils";
import { useProgressStore } from "@/store/progress-store";
import {
  AlertCondition,
  AlertMetric,
  AlertRule,
  DEFAULT_ALERT_RULES,
  METRIC_META,
} from "./mock-data";

const METRIC_OPTIONS: AlertMetric[] = ["latency", "error-rate", "uptime", "cpu"];
const CONDITION_OPTIONS: AlertCondition[] = [">", "<"];

interface FormState {
  metric: AlertMetric;
  condition: AlertCondition;
  threshold: string;
  duration: string;
  channel: string;
}

const DEFAULT_FORM: FormState = {
  metric: "latency",
  condition: ">",
  threshold: "500",
  duration: "5m",
  channel: "#sre-alerts",
};

export function AlertRules() {
  const [rules, setRules] = React.useState<AlertRule[]>(DEFAULT_ALERT_RULES);
  const [form, setForm] = React.useState<FormState>(DEFAULT_FORM);
  const hasAwardedXpRef = React.useRef(false);
  const addXp = useProgressStore((s) => s.addXp);

  const handleAddRule = () => {
    const thresholdNum = Number(form.threshold);
    if (!form.duration.trim() || !form.channel.trim() || Number.isNaN(thresholdNum)) {
      toast.error("Fill in a valid threshold, duration, and notification channel");
      return;
    }

    const newRule: AlertRule = {
      id: randomId("rule"),
      metric: form.metric,
      condition: form.condition,
      threshold: thresholdNum,
      duration: form.duration.trim(),
      channel: form.channel.trim(),
      enabled: true,
    };

    setRules((prev) => [...prev, newRule]);
    setForm(DEFAULT_FORM);

    if (!hasAwardedXpRef.current) {
      hasAwardedXpRef.current = true;
      addXp(10);
      toast.success("Alert rule added — +10 XP");
    } else {
      toast.success("Alert rule added");
    }
  };

  const handleToggle = (id: string) => {
    setRules((prev) => prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));
  };

  const handleDelete = (id: string) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
    toast.success("Alert rule removed");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-sm">
          <BellRing className="h-4 w-4 text-gcp-yellow" /> Alerting rules
        </CardTitle>
        <CardDescription>
          Alert when a metric crosses a threshold for a sustained duration — this is how you turn dashboards into
          pages.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-3 rounded-lg border border-border p-3 sm:grid-cols-2 lg:grid-cols-5">
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Metric</Label>
            <Select value={form.metric} onValueChange={(v) => setForm((f) => ({ ...f, metric: v as AlertMetric }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {METRIC_OPTIONS.map((m) => (
                  <SelectItem key={m} value={m}>{METRIC_META[m].label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Condition</Label>
            <Select value={form.condition} onValueChange={(v) => setForm((f) => ({ ...f, condition: v as AlertCondition }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CONDITION_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c}>{c === ">" ? "greater than" : "less than"}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Threshold ({METRIC_META[form.metric].unit})</Label>
            <Input
              type="number"
              value={form.threshold}
              onChange={(e) => setForm((f) => ({ ...f, threshold: e.target.value }))}
              placeholder="500"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">For duration</Label>
            <Input
              value={form.duration}
              onChange={(e) => setForm((f) => ({ ...f, duration: e.target.value }))}
              placeholder="5m"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Notify</Label>
            <Input
              value={form.channel}
              onChange={(e) => setForm((f) => ({ ...f, channel: e.target.value }))}
              placeholder="#sre-alerts"
            />
          </div>
          <div className="sm:col-span-2 lg:col-span-5">
            <Button size="sm" onClick={handleAddRule}>
              <Plus className="h-3.5 w-3.5" /> Add rule
            </Button>
          </div>
        </div>

        <div className="divide-y divide-border rounded-lg border border-border">
          {rules.length === 0 ? (
            <p className="p-4 text-xs text-muted-foreground">No alerting rules yet — add one above.</p>
          ) : (
            rules.map((rule) => (
              <div key={rule.id} className="flex flex-wrap items-center gap-3 px-3 py-2.5 text-xs">
                <Switch checked={rule.enabled} onCheckedChange={() => handleToggle(rule.id)} />
                <Badge variant={rule.enabled ? "success" : "outline"} className="w-20 justify-center">
                  {rule.enabled ? "Enabled" : "Disabled"}
                </Badge>
                <span className="font-medium">{METRIC_META[rule.metric].label}</span>
                <span className="text-muted-foreground">
                  {rule.condition} {rule.threshold}
                  {METRIC_META[rule.metric].unit}
                </span>
                <span className="text-muted-foreground">for {rule.duration}</span>
                <span className="ml-auto flex items-center gap-1.5 text-muted-foreground">
                  <BellRing className="h-3 w-3" /> {rule.channel}
                </span>
                <Button size="iconSm" variant="ghost" onClick={() => handleDelete(rule.id)}>
                  <Trash2 className="h-3.5 w-3.5 text-danger" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { Play, ListChecks } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { QUIZ_BANK, QUIZ_TOPICS, questionsForTopic } from "@/lib/quiz-bank";
import { ALL_TOPICS_LABEL, QUESTION_COUNT_OPTIONS } from "@/components/quiz-engine/constants";

export function QuizSetup({ onStart }: { onStart: (topic: string, count: number) => void }) {
  const [topic, setTopic] = React.useState<string>(ALL_TOPICS_LABEL);
  const [count, setCount] = React.useState<number>(10);

  const available = topic === ALL_TOPICS_LABEL ? QUIZ_BANK.length : questionsForTopic(topic).length;
  const actualCount = Math.min(count, available);

  return (
    <Card>
      <CardHeader>
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
          <ListChecks className="h-5 w-5 text-primary" />
        </div>
        <CardTitle>Set up your quiz</CardTitle>
        <CardDescription>Pick a topic and how many questions you want to answer.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Topic</label>
            <Select value={topic} onValueChange={setTopic}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_TOPICS_LABEL}>{ALL_TOPICS_LABEL}</SelectItem>
                {QUIZ_TOPICS.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Number of questions</label>
            <Select value={String(count)} onValueChange={(v) => setCount(Number(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {QUESTION_COUNT_OPTIONS.map((c) => (
                  <SelectItem key={c} value={String(c)}>
                    {c} questions
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col gap-3 rounded-lg border border-border bg-muted/40 p-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">{available}</span> question{available === 1 ? "" : "s"}{" "}
            available for <span className="font-medium text-foreground">{topic}</span>
            {count > available && available > 0 ? ` — you'll get all ${actualCount}.` : "."}
          </p>
          <Button onClick={() => onStart(topic, count)} disabled={available === 0} className="shrink-0">
            <Play className="h-4 w-4" /> Start Quiz
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

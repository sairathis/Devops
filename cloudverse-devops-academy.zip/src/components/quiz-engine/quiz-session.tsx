"use client";
import { Progress } from "@/components/ui/progress";
import { QuizCard } from "@/components/quiz-card";
import type { QuizQuestion } from "@/lib/quiz-bank";

export function QuizSession({
  questions,
  index,
  onNext,
}: {
  questions: QuizQuestion[];
  index: number;
  onNext: () => void;
}) {
  const question = questions[index];
  if (!question) return null;

  const percent = Math.round(((index + 1) / questions.length) * 100);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          Question {index + 1} of {questions.length}
        </span>
        <span>{percent}%</span>
      </div>
      <Progress value={percent} />
      {/* key forces a clean remount per question, though QuizCard already resets on question.id change */}
      <QuizCard key={question.id} question={question} onNext={onNext} />
    </div>
  );
}

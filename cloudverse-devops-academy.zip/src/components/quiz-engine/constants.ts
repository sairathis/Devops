// Shared constants for the Quiz Engine module.

/** Sentinel value for "no topic filter" in the setup screen's topic Select. */
export const ALL_TOPICS_LABEL = "All Topics";

/** Selectable question-count options on the setup screen. */
export const QUESTION_COUNT_OPTIONS = [5, 10, 20] as const;

export type ScoreMap = Record<string, { correct: number; total: number }>;

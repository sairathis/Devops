"use client";
import { RotateCcw, Sparkles, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { ScoreMap } from "@/components/quiz-engine/constants";

type Tier = "high" | "mid" | "low";

const TIER_ICON_CLASS: Record<Tier, string> = {
  high: "text-success",
  mid: "text-warning",
  low: "text-danger",
};

const TIER_BADGE_VARIANT: Record<Tier, "success" | "warning" | "danger"> = {
  high: "success",
  mid: "warning",
  low: "danger",
};

const TIER_MESSAGE: Record<Tier, string> = {
  high: "Excellent work — that's mastery-level.",
  mid: "Solid effort — a bit more practice will lock this in.",
  low: "Good start — revisit the explanations and try again.",
};

function tierFor(percent: number): Tier {
  if (percent >= 80) return "high";
  if (percent >= 50) return "mid";
  return "low";
}

export function QuizResults({
  correct,
  total,
  byTopic,
  onRetry,
  onNewQuiz,
}: {
  correct: number;
  total: number;
  byTopic: ScoreMap;
  onRetry: () => void;
  onNewQuiz: () => void;
}) {
  const percent = total > 0 ? Math.round((correct / total) * 100) : 0;
  const tier = tierFor(percent);
  const topics = Object.keys(byTopic);
  const showBreakdown = topics.length > 1;

  return (
    <Card>
      <CardHeader className="items-center text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
          <Trophy className={cn("h-6 w-6", TIER_ICON_CLASS[tier])} />
        </div>
        <CardTitle className="text-xl">
          {correct} / {total} correct
        </CardTitle>
        <CardDescription>{TIER_MESSAGE[tier]}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="flex items-center gap-3">
          <Progress value={percent} className="h-2.5" />
          <Badge variant={TIER_BADGE_VARIANT[tier]} className="shrink-0">
            {percent}%
          </Badge>
        </div>

        {showBreakdown && (
          <div className="space-y-2.5">
            <p className="text-xs font-medium text-muted-foreground">Breakdown by topic</p>
            <div className="space-y-2.5">
              {topics.map((topic) => {
                const t = byTopic[topic];
                const topicPercent = t.total > 0 ? Math.round((t.correct / t.total) * 100) : 0;
                return (
                  <div key={topic}>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="truncate pr-2">{topic}</span>
                      <span className="shrink-0 text-muted-foreground">
                        {t.correct}/{t.total}
                      </span>
                    </div>
                    <Progress value={topicPercent} className="h-1.5" />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2 pt-1">
          <Button variant="outline" onClick={onRetry}>
            <RotateCcw className="h-4 w-4" /> Retry same quiz
          </Button>
          <Button onClick={onNewQuiz}>
            <Sparkles className="h-4 w-4" /> New quiz
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

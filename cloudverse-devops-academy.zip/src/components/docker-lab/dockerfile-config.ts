// Pure types + helpers for the Docker Lab Dockerfile builder.
// No React / browser APIs here — safe to import from both client components and hooks.

export interface CopyRow {
  id: string;
  source: string;
  dest: string;
}

export interface CommandRow {
  id: string;
  command: string;
}

export interface EnvRow {
  id: string;
  key: string;
  value: string;
}

export interface DockerfileConfig {
  baseImage: string;
  workdir: string;
  copyRows: CopyRow[];
  runRows: CommandRow[];
  envRows: EnvRow[];
  exposePort: string;
  cmd: string;
}

export const BASE_IMAGES = [
  "node:20-slim",
  "python:3.12-slim",
  "golang:1.22-alpine",
  "nginx:alpine",
  "debian:bookworm-slim",
  "eclipse-temurin:21-jre",
] as const;

export const DEFAULT_CONFIG: DockerfileConfig = {
  baseImage: "node:20-slim",
  workdir: "/app",
  copyRows: [{ id: "copy-1", source: "package.json", dest: "./" }],
  runRows: [{ id: "run-1", command: "npm install" }],
  envRows: [{ id: "env-1", key: "NODE_ENV", value: "production" }],
  exposePort: "3000",
  cmd: '["node", "server.js"]',
};

export type Instruction = "FROM" | "WORKDIR" | "COPY" | "RUN" | "ENV" | "EXPOSE" | "CMD";

export interface DockerfileLine {
  id: string;
  instruction: Instruction;
  text: string;
}

/** Builds the ordered list of Dockerfile instruction lines from the current config. */
export function buildDockerfileLines(config: DockerfileConfig): DockerfileLine[] {
  const lines: DockerfileLine[] = [];

  lines.push({
    id: "from",
    instruction: "FROM",
    text: `FROM ${config.baseImage.trim() || "node:20-slim"}`,
  });

  if (config.workdir.trim()) {
    lines.push({ id: "workdir", instruction: "WORKDIR", text: `WORKDIR ${config.workdir.trim()}` });
  }

  config.copyRows.forEach((row) => {
    if (!row.source.trim() || !row.dest.trim()) return;
    lines.push({
      id: row.id,
      instruction: "COPY",
      text: `COPY ${row.source.trim()} ${row.dest.trim()}`,
    });
  });

  config.runRows.forEach((row) => {
    if (!row.command.trim()) return;
    lines.push({ id: row.id, instruction: "RUN", text: `RUN ${row.command.trim()}` });
  });

  config.envRows.forEach((row) => {
    if (!row.key.trim()) return;
    lines.push({
      id: row.id,
      instruction: "ENV",
      text: `ENV ${row.key.trim()}=${row.value.trim()}`,
    });
  });

  if (config.exposePort.trim()) {
    lines.push({ id: "expose", instruction: "EXPOSE", text: `EXPOSE ${config.exposePort.trim()}` });
  }

  if (config.cmd.trim()) {
    lines.push({ id: "cmd", instruction: "CMD", text: `CMD ${config.cmd.trim()}` });
  }

  return lines;
}

/** Renders the full Dockerfile text from the current config. */
export function generateDockerfile(config: DockerfileConfig): string {
  return buildDockerfileLines(config)
    .map((line) => line.text)
    .join("\n") + "\n";
}

// Illustrative base-image sizes in MB. These are rough, made-up approximations
// meant to teach the *relative* weight of layers — not measured values.
const BASE_IMAGE_SIZE_MB: Record<string, number> = {
  "node:20-slim": 180,
  "python:3.12-slim": 150,
  "golang:1.22-alpine": 95,
  "nginx:alpine": 45,
  "debian:bookworm-slim": 75,
  "eclipse-temurin:21-jre": 210,
};

/** Rough, illustrative layer size in MB for a given Dockerfile line. Not a real measurement. */
export function estimateLayerSizeMb(line: DockerfileLine, config: DockerfileConfig): number {
  switch (line.instruction) {
    case "FROM":
      return BASE_IMAGE_SIZE_MB[config.baseImage] ?? 120;
    case "COPY":
      return 2;
    case "RUN": {
      const cmd = line.text.toLowerCase();
      if (cmd.includes("npm install") || cmd.includes("npm ci") || cmd.includes("yarn")) return 65;
      if (cmd.includes("pip install")) return 40;
      if (cmd.includes("apt-get") || cmd.includes("apk add")) return 30;
      if (cmd.includes("go build") || cmd.includes("go mod")) return 18;
      if (cmd.includes("mvn") || cmd.includes("gradle")) return 55;
      return 12;
    }
    case "WORKDIR":
    case "ENV":
    case "EXPOSE":
    case "CMD":
    default:
      return 0;
  }
}

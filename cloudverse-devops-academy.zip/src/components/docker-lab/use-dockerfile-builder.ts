import * as React from "react";
import { randomId } from "@/lib/utils";
import {
  DEFAULT_CONFIG,
  type CommandRow,
  type CopyRow,
  type DockerfileConfig,
  type EnvRow,
} from "./dockerfile-config";

/** Encapsulates all Dockerfile builder form state and its row-level mutators. */
export function useDockerfileBuilder() {
  const [config, setConfig] = React.useState<DockerfileConfig>(DEFAULT_CONFIG);

  const setBaseImage = React.useCallback((baseImage: string) => {
    setConfig((c) => ({ ...c, baseImage }));
  }, []);

  const setWorkdir = React.useCallback((workdir: string) => {
    setConfig((c) => ({ ...c, workdir }));
  }, []);

  const setExposePort = React.useCallback((exposePort: string) => {
    setConfig((c) => ({ ...c, exposePort }));
  }, []);

  const setCmd = React.useCallback((cmd: string) => {
    setConfig((c) => ({ ...c, cmd }));
  }, []);

  // COPY rows
  const addCopyRow = React.useCallback(() => {
    setConfig((c) => ({
      ...c,
      copyRows: [...c.copyRows, { id: randomId("copy"), source: "", dest: "" } satisfies CopyRow],
    }));
  }, []);

  const updateCopyRow = React.useCallback((id: string, patch: Partial<CopyRow>) => {
    setConfig((c) => ({
      ...c,
      copyRows: c.copyRows.map((row) => (row.id === id ? { ...row, ...patch } : row)),
    }));
  }, []);

  const removeCopyRow = React.useCallback((id: string) => {
    setConfig((c) => ({ ...c, copyRows: c.copyRows.filter((row) => row.id !== id) }));
  }, []);

  // RUN rows
  const addRunRow = React.useCallback(() => {
    setConfig((c) => ({
      ...c,
      runRows: [...c.runRows, { id: randomId("run"), command: "" } satisfies CommandRow],
    }));
  }, []);

  const updateRunRow = React.useCallback((id: string, command: string) => {
    setConfig((c) => ({
      ...c,
      runRows: c.runRows.map((row) => (row.id === id ? { ...row, command } : row)),
    }));
  }, []);

  const removeRunRow = React.useCallback((id: string) => {
    setConfig((c) => ({ ...c, runRows: c.runRows.filter((row) => row.id !== id) }));
  }, []);

  // ENV rows
  const addEnvRow = React.useCallback(() => {
    setConfig((c) => ({
      ...c,
      envRows: [...c.envRows, { id: randomId("env"), key: "", value: "" } satisfies EnvRow],
    }));
  }, []);

  const updateEnvRow = React.useCallback((id: string, patch: Partial<EnvRow>) => {
    setConfig((c) => ({
      ...c,
      envRows: c.envRows.map((row) => (row.id === id ? { ...row, ...patch } : row)),
    }));
  }, []);

  const removeEnvRow = React.useCallback((id: string) => {
    setConfig((c) => ({ ...c, envRows: c.envRows.filter((row) => row.id !== id) }));
  }, []);

  return {
    config,
    setBaseImage,
    setWorkdir,
    setExposePort,
    setCmd,
    addCopyRow,
    updateCopyRow,
    removeCopyRow,
    addRunRow,
    updateRunRow,
    removeRunRow,
    addEnvRow,
    updateEnvRow,
    removeEnvRow,
  };
}

export type DockerfileBuilder = ReturnType<typeof useDockerfileBuilder>;

"use client";
import * as React from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { BASE_IMAGES } from "./dockerfile-config";
import type { DockerfileBuilder } from "./use-dockerfile-builder";

export function DockerfileForm({ builder }: { builder: DockerfileBuilder }) {
  const { config } = builder;

  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle>Configuration</CardTitle>
        <CardDescription>Shape the Dockerfile — every change regenerates it live.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-1.5">
          <Label htmlFor="base-image">Base image</Label>
          <Select value={config.baseImage} onValueChange={builder.setBaseImage}>
            <SelectTrigger id="base-image">
              <SelectValue placeholder="Select a base image" />
            </SelectTrigger>
            <SelectContent>
              {BASE_IMAGES.map((img) => (
                <SelectItem key={img} value={img}>
                  {img}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="workdir">Working directory</Label>
          <Input
            id="workdir"
            value={config.workdir}
            onChange={(e) => builder.setWorkdir(e.target.value)}
            placeholder="/app"
            spellCheck={false}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>COPY instructions</Label>
            <Button variant="ghost" size="iconSm" onClick={builder.addCopyRow} aria-label="Add COPY row">
              <Plus className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="space-y-2">
            {config.copyRows.map((row) => (
              <div key={row.id} className="flex items-center gap-1.5">
                <Input
                  value={row.source}
                  onChange={(e) => builder.updateCopyRow(row.id, { source: e.target.value })}
                  placeholder="source"
                  spellCheck={false}
                  className="font-mono text-xs"
                />
                <span className="shrink-0 text-xs text-muted-foreground">&rarr;</span>
                <Input
                  value={row.dest}
                  onChange={(e) => builder.updateCopyRow(row.id, { dest: e.target.value })}
                  placeholder="dest"
                  spellCheck={false}
                  className="font-mono text-xs"
                />
                <Button
                  variant="ghost"
                  size="iconSm"
                  onClick={() => builder.removeCopyRow(row.id)}
                  aria-label="Remove COPY row"
                  className="shrink-0"
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
            {config.copyRows.length === 0 && (
              <p className="text-xs text-muted-foreground">No COPY instructions yet.</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>RUN commands</Label>
            <Button variant="ghost" size="iconSm" onClick={builder.addRunRow} aria-label="Add RUN row">
              <Plus className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="space-y-2">
            {config.runRows.map((row) => (
              <div key={row.id} className="flex items-center gap-1.5">
                <Input
                  value={row.command}
                  onChange={(e) => builder.updateRunRow(row.id, e.target.value)}
                  placeholder="npm install"
                  spellCheck={false}
                  className="font-mono text-xs"
                />
                <Button
                  variant="ghost"
                  size="iconSm"
                  onClick={() => builder.removeRunRow(row.id)}
                  aria-label="Remove RUN row"
                  className="shrink-0"
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
            {config.runRows.length === 0 && (
              <p className="text-xs text-muted-foreground">No RUN commands yet.</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>ENV variables</Label>
            <Button variant="ghost" size="iconSm" onClick={builder.addEnvRow} aria-label="Add ENV row">
              <Plus className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="space-y-2">
            {config.envRows.map((row) => (
              <div key={row.id} className="flex items-center gap-1.5">
                <Input
                  value={row.key}
                  onChange={(e) => builder.updateEnvRow(row.id, { key: e.target.value })}
                  placeholder="KEY"
                  spellCheck={false}
                  className="font-mono text-xs"
                />
                <span className="shrink-0 text-xs text-muted-foreground">=</span>
                <Input
                  value={row.value}
                  onChange={(e) => builder.updateEnvRow(row.id, { value: e.target.value })}
                  placeholder="value"
                  spellCheck={false}
                  className="font-mono text-xs"
                />
                <Button
                  variant="ghost"
                  size="iconSm"
                  onClick={() => builder.removeEnvRow(row.id)}
                  aria-label="Remove ENV row"
                  className="shrink-0"
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
            {config.envRows.length === 0 && (
              <p className="text-xs text-muted-foreground">No ENV variables yet.</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="expose-port">EXPOSE port</Label>
            <Input
              id="expose-port"
              type="number"
              min={0}
              max={65535}
              value={config.exposePort}
              onChange={(e) => builder.setExposePort(e.target.value)}
              placeholder="3000"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="cmd">CMD</Label>
          <Input
            id="cmd"
            value={config.cmd}
            onChange={(e) => builder.setCmd(e.target.value)}
            placeholder='["node", "server.js"]'
            spellCheck={false}
            className="font-mono text-xs"
          />
        </div>
      </CardContent>
    </Card>
  );
}

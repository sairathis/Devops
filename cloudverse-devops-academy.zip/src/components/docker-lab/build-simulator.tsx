"use client";
import * as React from "react";
import { Hammer, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { DockerfileLine } from "./dockerfile-config";

const HEX_CHARS = "0123456789abcdef";

function randomHex(length: number): string {
  let out = "";
  for (let i = 0; i < length; i++) {
    out += HEX_CHARS[Math.floor(Math.random() * HEX_CHARS.length)];
  }
  return out;
}

function buildLogLines(lines: DockerfileLine[]): string[] {
  const total = lines.length;
  const entries: string[] = [];

  lines.forEach((line, idx) => {
    entries.push(`Step ${idx + 1}/${total} : ${line.text}`);
    if (line.instruction === "FROM") {
      entries.push(" ---> Using cache");
    } else {
      const containerHash = randomHex(12);
      const layerHash = randomHex(12);
      entries.push(` ---> Running in ${containerHash}`);
      entries.push(` ---> ${layerHash}`);
      entries.push(`Removing intermediate container ${containerHash}`);
    }
  });

  entries.push(`Successfully built ${randomHex(12)}`);
  entries.push("Successfully tagged app:latest");
  return entries;
}

export function BuildSimulator({
  lines,
  onFirstBuild,
}: {
  lines: DockerfileLine[];
  onFirstBuild: () => void;
}) {
  const [log, setLog] = React.useState<string[]>([]);
  const [building, setBuilding] = React.useState(false);
  const timeoutsRef = React.useRef<ReturnType<typeof setTimeout>[]>([]);
  const hasBuiltRef = React.useRef(false);
  const logEndRef = React.useRef<HTMLDivElement | null>(null);

  React.useEffect(() => {
    return () => {
      timeoutsRef.current.forEach(clearTimeout);
    };
  }, []);

  React.useEffect(() => {
    logEndRef.current?.scrollIntoView({ block: "end" });
  }, [log]);

  const runBuild = () => {
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];

    const entries = buildLogLines(lines);
    setLog([]);
    setBuilding(true);

    entries.forEach((text, i) => {
      const t = setTimeout(() => {
        setLog((prev) => [...prev, text]);
        if (i === entries.length - 1) setBuilding(false);
      }, i * 160);
      timeoutsRef.current.push(t);
    });

    if (!hasBuiltRef.current) {
      hasBuiltRef.current = true;
      onFirstBuild();
    }
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle>Simulate build</CardTitle>
          <CardDescription>Replays a fake but realistic `docker build` log for this Dockerfile.</CardDescription>
        </div>
        <Button onClick={runBuild} disabled={building} size="sm">
          {building ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Hammer className="h-3.5 w-3.5" />}
          {building ? "Building..." : "Simulate Build"}
        </Button>
      </CardHeader>
      <CardContent>
        <div className="h-64 overflow-auto rounded-lg border border-border bg-neutral-950 p-3 font-mono text-xs leading-relaxed">
          {log.length === 0 ? (
            <p className="text-neutral-500">Click &quot;Simulate Build&quot; to see fake build output.</p>
          ) : (
            log.map((entry, i) => (
              <div
                key={i}
                className={
                  entry.startsWith("Successfully")
                    ? "text-emerald-400"
                    : entry.startsWith("Step")
                      ? "text-white"
                      : "text-neutral-400"
                }
              >
                {entry}
              </div>
            ))
          )}
          <div ref={logEndRef} />
        </div>
      </CardContent>
    </Card>
  );
}

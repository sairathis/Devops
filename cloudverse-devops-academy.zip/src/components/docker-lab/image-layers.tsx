import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  estimateLayerSizeMb,
  type DockerfileConfig,
  type DockerfileLine,
} from "./dockerfile-config";

const INSTRUCTION_BAR_CLASS: Record<string, string> = {
  FROM: "bg-gcp-blue",
  WORKDIR: "bg-muted-foreground/40",
  COPY: "bg-gcp-green",
  RUN: "bg-gcp-yellow",
  ENV: "bg-gcp-red",
  EXPOSE: "bg-info",
  CMD: "bg-primary",
};

const INSTRUCTION_BADGE_CLASS: Record<string, string> = {
  FROM: "border-transparent bg-gcp-blue/15 text-gcp-blue",
  WORKDIR: "border-transparent bg-muted text-muted-foreground",
  COPY: "border-transparent bg-gcp-green/15 text-gcp-green",
  RUN: "border-transparent bg-gcp-yellow/15 text-gcp-yellow",
  ENV: "border-transparent bg-gcp-red/15 text-gcp-red",
  EXPOSE: "border-transparent bg-info/15 text-info",
  CMD: "border-transparent bg-primary/15 text-primary",
};

export function ImageLayers({
  lines,
  config,
}: {
  lines: DockerfileLine[];
  config: DockerfileConfig;
}) {
  const sized = lines.map((line) => ({ line, sizeMb: estimateLayerSizeMb(line, config) }));
  const totalMb = sized.reduce((sum, s) => sum + s.sizeMb, 0);
  const maxMb = Math.max(...sized.map((s) => s.sizeMb), 1);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Image layers</CardTitle>
        <CardDescription>
          One layer per instruction, stacked in build order &middot; ~{totalMb}MB total (illustrative)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-xs text-muted-foreground">
          Docker caches each layer and reuses it on the next build as long as the instruction and everything above
          it are unchanged. Ordering instructions from least-to-most-frequently-changed &mdash; dependencies before
          application code, for example &mdash; means a source-code edit only invalidates the last few layers
          instead of triggering a full rebuild.
        </p>
        <div className="space-y-2">
          {sized.map(({ line, sizeMb }, idx) => (
            <div key={line.id} className="rounded-lg border border-border p-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="text-xs text-muted-foreground">{idx + 1}</span>
                  <Badge className={cn(INSTRUCTION_BADGE_CLASS[line.instruction])}>{line.instruction}</Badge>
                  <span className="truncate font-mono text-xs text-muted-foreground">{line.text}</span>
                </div>
                <span className="shrink-0 text-xs font-medium tabular-nums">
                  {sizeMb === 0 ? "~0MB" : `~${sizeMb}MB`}
                </span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className={cn("h-full rounded-full", INSTRUCTION_BAR_CLASS[line.instruction])}
                  style={{ width: `${Math.max((sizeMb / maxMb) * 100, sizeMb > 0 ? 4 : 1)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground">
          Sizes are rough, made-up approximations for teaching purposes &mdash; not a real measurement of any built
          image.
        </p>
      </CardContent>
    </Card>
  );
}

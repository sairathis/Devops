"use client";
import * as React from "react";
import { Check, Copy, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

interface CheatsheetEntry {
  cmd: string;
  desc: string;
}

const COMMANDS: CheatsheetEntry[] = [
  { cmd: "docker build -t app:latest .", desc: "Build an image from the Dockerfile in the current directory." },
  { cmd: "docker run -p 3000:3000 app:latest", desc: "Start a container from an image, mapping a host port to it." },
  { cmd: "docker ps", desc: "List currently running containers." },
  { cmd: "docker exec -it <container> sh", desc: "Open an interactive shell inside a running container." },
  { cmd: "docker logs -f <container>", desc: "Stream a container's logs in real time." },
  { cmd: "docker images", desc: "List images cached on this machine." },
  { cmd: "docker rmi <image>", desc: "Remove a local image." },
  { cmd: "docker compose up -d", desc: "Start every service in docker-compose.yml in the background." },
];

export function DockerCheatsheet() {
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  const copy = async (cmd: string, idx: number) => {
    await navigator.clipboard.writeText(cmd);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex((current) => (current === idx ? null : current)), 1500);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-4 w-4 text-muted-foreground" /> CLI cheatsheet
        </CardTitle>
        <CardDescription>The Docker commands you will reach for most often.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        {COMMANDS.map((entry, idx) => (
          <div
            key={entry.cmd}
            className="flex items-center justify-between gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-accent/50"
          >
            <div className="min-w-0">
              <code className="block truncate font-mono text-xs">{entry.cmd}</code>
              <p className="mt-0.5 text-xs text-muted-foreground">{entry.desc}</p>
            </div>
            <Button
              variant="ghost"
              size="iconSm"
              className="shrink-0"
              onClick={() => copy(entry.cmd, idx)}
              aria-label={`Copy ${entry.cmd}`}
            >
              {copiedIndex === idx ? (
                <Check className="h-3.5 w-3.5 text-success" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { LayoutDashboard, ArrowRight } from "lucide-react";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator,
} from "@/components/ui/command";
import { useUiStore } from "@/store/ui-store";
import { MODULES } from "@/lib/modules";
import { GCP_RESOURCES } from "@/lib/gcp";
import { ResourceIcon } from "@/components/gcp/resource-icon";

export function CommandPalette() {
  const router = useRouter();
  const open = useUiStore((s) => s.commandPaletteOpen);
  const setOpen = useUiStore((s) => s.setCommandPaletteOpen);

  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen(!open);
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, setOpen]);

  const go = (href: string) => {
    setOpen(false);
    router.push(href);
  };

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search modules, GCP resources, docs..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Modules">
          {MODULES.map((m) => (
            <CommandItem key={m.id} value={m.label} onSelect={() => go(m.href)}>
              <m.icon className="h-4 w-4 text-muted-foreground" />
              <span>{m.label}</span>
              <ArrowRight className="ml-auto h-3.5 w-3.5 opacity-40" />
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="GCP Resources">
          {GCP_RESOURCES.map((r) => (
            <CommandItem key={r.type} value={r.label} onSelect={() => go(`/gcp-services?focus=${r.type}`)}>
              <ResourceIcon type={r.type} color={r.color} size={14} className="h-6 w-6" />
              <span>{r.label}</span>
              <span className="ml-auto text-xs text-muted-foreground">{r.category}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Quick Actions">
          <CommandItem value="New architecture" onSelect={() => go("/architecture-builder")}>
            <LayoutDashboard className="h-4 w-4 text-muted-foreground" />
            <span>Start a new architecture diagram</span>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { ChevronLeft, Cloud, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { MODULES, MODULE_GROUPS } from "@/lib/modules";
import { useUiStore } from "@/store/ui-store";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { useProgressStore } from "@/store/progress-store";

export function Sidebar() {
  const pathname = usePathname();
  const collapsed = useUiStore((s) => s.sidebarCollapsed);
  const toggleSidebar = useUiStore((s) => s.toggleSidebar);
  const level = useProgressStore((s) => s.level);

  return (
    <motion.aside
      animate={{ width: collapsed ? 72 : 264 }}
      transition={{ type: "spring", stiffness: 300, damping: 32 }}
      className="relative z-30 hidden h-svh shrink-0 flex-col border-r border-sidebar-border bg-sidebar md:flex"
    >
      <div className="flex h-16 items-center gap-2 px-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-gcp-blue via-gcp-green to-gcp-yellow text-white shadow-sm">
          <Cloud className="h-5 w-5" />
        </div>
        {!collapsed && (
          <div className="flex flex-col overflow-hidden">
            <span className="truncate text-sm font-semibold leading-tight">CloudVerse</span>
            <span className="truncate text-[11px] leading-tight text-muted-foreground">DevOps Academy</span>
          </div>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2">
        {MODULE_GROUPS.map((group) => {
          const items = MODULES.filter((m) => m.group === group);
          return (
            <div key={group} className="mb-4">
              {!collapsed && (
                <div className="px-2 pb-1.5 pt-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                  {group}
                </div>
              )}
              <div className="flex flex-col gap-0.5">
                {items.map((m) => {
                  const active = pathname === m.href;
                  const link = (
                    <Link
                      key={m.id}
                      href={m.href}
                      className={cn(
                        "group relative flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm transition-colors",
                        active
                          ? "bg-primary/10 text-primary font-medium"
                          : "text-foreground/80 hover:bg-accent hover:text-foreground",
                      )}
                    >
                      {active && (
                        <motion.span
                          layoutId="active-pill"
                          className="absolute inset-0 rounded-lg bg-primary/10"
                          transition={{ type: "spring", stiffness: 400, damping: 32 }}
                        />
                      )}
                      <m.icon className={cn("relative z-10 h-4 w-4 shrink-0", active && "text-primary")} />
                      {!collapsed && <span className="relative z-10 truncate">{m.label}</span>}
                      {!collapsed && m.badge && (
                        <Badge variant="info" className="relative z-10 ml-auto px-1.5 py-0 text-[9px]">
                          {m.badge}
                        </Badge>
                      )}
                    </Link>
                  );
                  return collapsed ? (
                    <Tooltip key={m.id} delayDuration={200}>
                      <TooltipTrigger asChild>{link}</TooltipTrigger>
                      <TooltipContent side="right">{m.label}</TooltipContent>
                    </Tooltip>
                  ) : (
                    link
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border p-3">
        {!collapsed && (
          <div className="mb-2 flex items-center gap-2 rounded-lg glass px-3 py-2 text-xs">
            <Sparkles className="h-3.5 w-3.5 text-gcp-yellow" />
            <span className="text-muted-foreground">Level {level} Cloud Architect</span>
          </div>
        )}
        <button
          onClick={toggleSidebar}
          className="flex w-full items-center justify-center gap-2 rounded-lg py-1.5 text-xs text-muted-foreground hover:bg-accent"
        >
          <ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
          {!collapsed && "Collapse"}
        </button>
      </div>
    </motion.aside>
  );
}

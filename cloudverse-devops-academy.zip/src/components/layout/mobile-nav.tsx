"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, Cloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { MODULES, MODULE_GROUPS } from "@/lib/modules";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const pathname = usePathname();
  const [open, setOpen] = React.useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 p-0">
        <SheetHeader className="border-b border-border p-4">
          <SheetTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-gcp-blue" /> CloudVerse
          </SheetTitle>
        </SheetHeader>
        <nav className="flex-1 overflow-y-auto p-3">
          {MODULE_GROUPS.map((group) => (
            <div key={group} className="mb-3">
              <div className="px-2 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                {group}
              </div>
              {MODULES.filter((m) => m.group === group).map((m) => (
                <Link
                  key={m.id}
                  href={m.href}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm",
                    pathname === m.href ? "bg-primary/10 text-primary font-medium" : "text-foreground/80 hover:bg-accent",
                  )}
                >
                  <m.icon className="h-4 w-4" />
                  {m.label}
                </Link>
              ))}
            </div>
          ))}
        </nav>
      </SheetContent>
    </Sheet>
  );
}

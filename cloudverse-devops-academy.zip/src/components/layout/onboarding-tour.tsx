"use client";
import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Cloud, Workflow, Network, Trophy, ArrowRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUiStore } from "@/store/ui-store";

const STEPS = [
  {
    icon: Cloud,
    title: "Welcome to CloudVerse DevOps Academy",
    body: "This is your all-in-one hands-on lab for GCP and DevOps — part console, part Terraform generator, part interactive classroom.",
  },
  {
    icon: Workflow,
    title: "Build real architectures",
    body: "Drag GCP resources onto the Architecture Builder canvas. Every resource you add instantly generates Terraform and explains itself.",
  },
  {
    icon: Network,
    title: "See traffic actually flow",
    body: "The Networking Academy animates packets through your topology — inbound, outbound, east-west, NAT, and DNS resolution.",
  },
  {
    icon: Trophy,
    title: "Learn by doing, track your growth",
    body: "Quizzes, troubleshooting scenarios, and certification paths turn every action into XP, streaks, and badges.",
  },
];

export function OnboardingTour() {
  const complete = useUiStore((s) => s.onboardingComplete);
  const completeOnboarding = useUiStore((s) => s.completeOnboarding);
  const [step, setStep] = React.useState(0);
  const [dismissed, setDismissed] = React.useState(false);

  if (complete || dismissed) return null;

  const current = STEPS[step];
  const isLast = step === STEPS.length - 1;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 28 }}
          className="glass-panel relative w-full max-w-md rounded-2xl p-6"
        >
          <button
            onClick={() => setDismissed(true)}
            className="absolute right-4 top-4 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-gcp-blue to-gcp-green text-white">
            <current.icon className="h-6 w-6" />
          </div>
          <h2 className="mb-2 text-lg font-semibold">{current.title}</h2>
          <p className="mb-6 text-sm text-muted-foreground">{current.body}</p>
          <div className="flex items-center justify-between">
            <div className="flex gap-1.5">
              {STEPS.map((_, i) => (
                <span key={i} className={`h-1.5 w-6 rounded-full transition-colors ${i === step ? "bg-primary" : "bg-muted"}`} />
              ))}
            </div>
            <Button
              onClick={() => (isLast ? completeOnboarding() : setStep((s) => s + 1))}
              size="sm"
            >
              {isLast ? "Get started" : "Next"}
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

"use client";

import { GcpResourceDef, CATEGORY_META } from "@/types/gcp";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { cn, formatCurrency } from "@/lib/utils";

const CATEGORY_BADGE_CLASS: Record<string, string> = {
  "gcp-blue": "border-transparent bg-gcp-blue/10 text-gcp-blue",
  "gcp-green": "border-transparent bg-gcp-green/10 text-gcp-green",
  "gcp-yellow": "border-transparent bg-gcp-yellow/10 text-gcp-yellow",
  "gcp-red": "border-transparent bg-gcp-red/10 text-gcp-red",
};

export function ResourceCard({
  def,
  onClick,
}: {
  def: GcpResourceDef;
  onClick: () => void;
}) {
  const categoryMeta = CATEGORY_META[def.category];
  const categoryClass = CATEGORY_BADGE_CLASS[categoryMeta.color] ?? CATEGORY_BADGE_CLASS["gcp-blue"];
  const monthlyCost = def.estimateMonthlyCost(def.defaultConfig);

  return (
    <Card
      role="button"
      tabIndex={0}
      onClick={onClick}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      }}
      className="group cursor-pointer transition-all hover:border-primary/40 hover:shadow-md"
    >
      <CardContent className="flex flex-col gap-3 p-4">
        <div className="flex items-start gap-3">
          <ResourceIcon type={def.type} color={def.color} className="h-9 w-9" size={18} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{def.label}</p>
            <p className="text-xs text-muted-foreground">{def.shortLabel}</p>
          </div>
        </div>
        <p className="line-clamp-2 text-xs text-muted-foreground">{def.description}</p>
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge className={cn("text-[10px]", categoryClass)}>{categoryMeta.label}</Badge>
          <Badge variant="secondary" className="text-[10px]">
            {formatCurrency(monthlyCost)}/mo
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}

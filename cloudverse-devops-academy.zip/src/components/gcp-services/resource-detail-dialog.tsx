"use client";

import * as React from "react";
import { BookOpen, ExternalLink } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { CodeBlock } from "@/components/code-block";
import { QuizCard } from "@/components/quiz-card";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { GcpResourceDef } from "@/types/gcp";
import { QuizQuestion } from "@/lib/quiz-bank";
import { slugify } from "@/lib/utils";

export function ResourceDetailDialog({
  def,
  open,
  onOpenChange,
}: {
  def: GcpResourceDef | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const terraform = React.useMemo(() => {
    if (!def) return "";
    return def.generateTerraform({
      config: def.defaultConfig,
      nodeId: "sample",
      label: def.label,
      slug: slugify(def.label),
      allNodes: [],
      connections: [],
    });
  }, [def]);

  const quizQuestion: QuizQuestion | null = React.useMemo(() => {
    if (!def || def.quiz.length === 0) return null;
    const q = def.quiz[0];
    return {
      id: `${def.type}-0`,
      topic: def.label,
      difficulty: "beginner",
      question: q.question,
      options: q.options,
      answerIndex: q.answerIndex,
      explanation: q.explanation,
    };
  }, [def]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        {def && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-3">
                <ResourceIcon type={def.type} color={def.color} size={22} className="h-11 w-11" />
                <div>
                  <DialogTitle>{def.label}</DialogTitle>
                  <DialogDescription>{def.tooltip}</DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="space-y-5">
              <p className="text-sm text-muted-foreground">{def.description}</p>

              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  <BookOpen className="h-3.5 w-3.5" /> Learning notes
                </p>
                <p className="text-sm leading-relaxed">{def.learningNotes}</p>
              </div>

              <a
                href={def.docsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
              >
                View official documentation <ExternalLink className="h-3.5 w-3.5" />
              </a>

              <div>
                <p className="mb-2 text-sm font-medium">Sample Terraform</p>
                <CodeBlock code={terraform} language="hcl" filename={`${slugify(def.label)}.tf`} />
              </div>

              <div>
                <p className="mb-2 text-sm font-medium">Troubleshooting</p>
                <Accordion type="single" collapsible>
                  {def.troubleshooting.map((t, i) => (
                    <AccordionItem key={i} value={String(i)}>
                      <AccordionTrigger>{t.issue}</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <Badge variant="outline" className="mt-0.5 shrink-0">
                              Cause
                            </Badge>
                            <span>{t.cause}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <Badge variant="success" className="mt-0.5 shrink-0">
                              Fix
                            </Badge>
                            <span>{t.fix}</span>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>

              {quizQuestion && (
                <div>
                  <p className="mb-2 text-sm font-medium">Quick check</p>
                  <QuizCard question={quizQuestion} />
                </div>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

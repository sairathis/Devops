import {
  Network, GitBranch, Server, Layers, Scale, Database, HardDrive, Route, Globe,
  Shield, ShieldCheck, Cable, Boxes, Package, Hammer, Radio, MemoryStick, Router,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

export const RESOURCE_ICONS: Record<string, LucideIcon> = {
  vpc: Network,
  subnet: GitBranch,
  vm: Server,
  mig: Layers,
  lb: Scale,
  cloudsql: Database,
  gcs: HardDrive,
  nat: Route,
  dns: Globe,
  armor: Shield,
  router: Router,
  vpn: ShieldCheck,
  interconnect: Cable,
  gke: Boxes,
  artifact_registry: Package,
  cloud_build: Hammer,
  pubsub: Radio,
  redis: MemoryStick,
};

const COLOR_CLASS: Record<string, string> = {
  "gcp-blue": "text-gcp-blue bg-gcp-blue/10",
  "gcp-red": "text-gcp-red bg-gcp-red/10",
  "gcp-yellow": "text-gcp-yellow bg-gcp-yellow/10",
  "gcp-green": "text-gcp-green bg-gcp-green/10",
};

export function ResourceIcon({
  type,
  color = "gcp-blue",
  className,
  size = 18,
}: {
  type: string;
  color?: string;
  className?: string;
  size?: number;
}) {
  const Icon = RESOURCE_ICONS[type] ?? Network;
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-lg shrink-0",
        COLOR_CLASS[color] ?? COLOR_CLASS["gcp-blue"],
        className,
      )}
    >
      <Icon size={size} strokeWidth={2} />
    </span>
  );
}

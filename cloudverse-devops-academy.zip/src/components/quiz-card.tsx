"use client";
import * as React from "react";
import { toast } from "sonner";
import { Check, X, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useProgressStore } from "@/store/progress-store";
import { QuizQuestion } from "@/lib/quiz-bank";

export function QuizCard({
  question,
  onNext,
  xp = 10,
}: {
  question: QuizQuestion;
  onNext?: () => void;
  xp?: number;
}) {
  const [selected, setSelected] = React.useState<number | null>(null);
  const addXp = useProgressStore((s) => s.addXp);
  const recordQuizResult = useProgressStore((s) => s.recordQuizResult);

  React.useEffect(() => setSelected(null), [question.id]);

  const choose = (i: number) => {
    if (selected !== null) return;
    setSelected(i);
    const correct = i === question.answerIndex;
    recordQuizResult(question.topic, correct ? 1 : 0, 1);
    if (correct) {
      addXp(xp);
      toast.success(`Correct! +${xp} XP`);
    } else {
      toast.error("Not quite.");
    }
  };

  return (
    <div className="rounded-xl border border-border p-4">
      <div className="mb-3 flex items-center gap-2">
        <Badge variant="outline">{question.topic}</Badge>
        <Badge variant="secondary" className="capitalize">{question.difficulty}</Badge>
      </div>
      <p className="mb-3 text-sm font-medium leading-relaxed">{question.question}</p>
      <div className="flex flex-col gap-2">
        {question.options.map((opt, i) => {
          const isCorrect = i === question.answerIndex;
          const showState = selected !== null;
          return (
            <button
              key={i}
              onClick={() => choose(i)}
              className={cn(
                "flex items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition-colors",
                showState && isCorrect && "border-success bg-success/10",
                showState && i === selected && !isCorrect && "border-danger bg-danger/10",
                !showState && "border-border hover:bg-accent",
                showState && i !== selected && !isCorrect && "opacity-50",
              )}
            >
              {opt}
              {showState && isCorrect && <Check className="h-4 w-4 text-success" />}
              {showState && i === selected && !isCorrect && <X className="h-4 w-4 text-danger" />}
            </button>
          );
        })}
      </div>
      {selected !== null && (
        <div className="mt-3 flex items-start justify-between gap-3 rounded-lg bg-muted/50 p-3">
          <p className="text-xs text-muted-foreground">{question.explanation}</p>
          {onNext && (
            <Button size="sm" variant="ghost" onClick={onNext} className="shrink-0">
              Next <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

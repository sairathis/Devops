export interface EnvVar {
  id: string;
  key: string;
  value: string;
}

export type ServiceType = "ClusterIP" | "NodePort" | "LoadBalancer";

export interface DeploymentConfig {
  name: string;
  image: string;
  replicas: number;
  containerPort: number;
  cpuRequest: string;
  cpuLimit: string;
  memoryRequest: string;
  memoryLimit: string;
  envVars: EnvVar[];
}

export interface ServiceConfig {
  type: ServiceType;
  port: number;
  targetPort: number;
}

export interface IngressConfig {
  enabled: boolean;
  host: string;
  path: string;
}

export const DEFAULT_DEPLOYMENT: DeploymentConfig = {
  name: "my-app",
  image: "gcr.io/my-project/app:latest",
  replicas: 3,
  containerPort: 8080,
  cpuRequest: "250m",
  cpuLimit: "500m",
  memoryRequest: "256Mi",
  memoryLimit: "512Mi",
  envVars: [{ id: "env-seed-1", key: "NODE_ENV", value: "production" }],
};

export const DEFAULT_SERVICE: ServiceConfig = {
  type: "ClusterIP",
  port: 80,
  targetPort: 8080,
};

export const DEFAULT_INGRESS: IngressConfig = {
  enabled: false,
  host: "app.example.com",
  path: "/",
};

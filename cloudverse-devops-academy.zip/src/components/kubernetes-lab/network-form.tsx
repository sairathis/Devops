"use client";
import * as React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { ServiceConfig, ServiceType, IngressConfig } from "./types";

const SERVICE_TYPES: ServiceType[] = ["ClusterIP", "NodePort", "LoadBalancer"];

export function NetworkForm({
  service,
  onServiceChange,
  ingress,
  onIngressChange,
}: {
  service: ServiceConfig;
  onServiceChange: (next: ServiceConfig) => void;
  ingress: IngressConfig;
  onIngressChange: (next: IngressConfig) => void;
}) {
  const setService = <K extends keyof ServiceConfig>(key: K, v: ServiceConfig[K]) => {
    onServiceChange({ ...service, [key]: v });
  };
  const setIngress = <K extends keyof IngressConfig>(key: K, v: IngressConfig[K]) => {
    onIngressChange({ ...ingress, [key]: v });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Service &amp; Ingress</CardTitle>
        <CardDescription>Expose the deployment inside the cluster, and optionally to the internet.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Type</Label>
            <Select value={service.type} onValueChange={(v) => setService("type", v as ServiceType)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SERVICE_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="svc-port">Port</Label>
            <Input
              id="svc-port"
              type="number"
              min={1}
              max={65535}
              value={service.port}
              onChange={(e) => setService("port", Number(e.target.value) || 0)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="svc-target-port">Target port</Label>
            <Input
              id="svc-target-port"
              type="number"
              min={1}
              max={65535}
              value={service.targetPort}
              onChange={(e) => setService("targetPort", Number(e.target.value) || 0)}
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg border border-border p-3">
          <div>
            <Label htmlFor="ingress-toggle">Expose with Ingress</Label>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Route external HTTP(S) traffic to the Service via a load balancer.
            </p>
          </div>
          <Switch id="ingress-toggle" checked={ingress.enabled} onCheckedChange={(v) => setIngress("enabled", v)} />
        </div>

        {ingress.enabled && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="ingress-host">Host</Label>
              <Input
                id="ingress-host"
                value={ingress.host}
                onChange={(e) => setIngress("host", e.target.value)}
                placeholder="app.example.com"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ingress-path">Path</Label>
              <Input
                id="ingress-path"
                value={ingress.path}
                onChange={(e) => setIngress("path", e.target.value)}
                placeholder="/"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { CodeBlock } from "@/components/code-block";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export function ManifestViewer({
  deploymentYaml,
  serviceYaml,
  ingressYaml,
}: {
  deploymentYaml: string;
  serviceYaml: string;
  ingressYaml: string | null;
}) {
  const [tab, setTab] = React.useState("deployment");

  React.useEffect(() => {
    if (tab === "ingress" && ingressYaml === null) setTab("deployment");
  }, [tab, ingressYaml]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Generated manifests</CardTitle>
        <CardDescription>Live YAML, generated from the form on the left.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="deployment">Deployment</TabsTrigger>
            <TabsTrigger value="service">Service</TabsTrigger>
            {ingressYaml !== null && <TabsTrigger value="ingress">Ingress</TabsTrigger>}
          </TabsList>
          <TabsContent value="deployment">
            <CodeBlock code={deploymentYaml} language="yaml" filename="deployment.yaml" maxHeight="420px" />
          </TabsContent>
          <TabsContent value="service">
            <CodeBlock code={serviceYaml} language="yaml" filename="service.yaml" maxHeight="420px" />
          </TabsContent>
          {ingressYaml !== null && (
            <TabsContent value="ingress">
              <CodeBlock code={ingressYaml} language="yaml" filename="ingress.yaml" maxHeight="420px" />
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}

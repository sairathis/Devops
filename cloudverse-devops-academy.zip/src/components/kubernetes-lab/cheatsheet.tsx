"use client";
import * as React from "react";
import { Check, Copy, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

interface Command {
  cmd: string;
  desc: string;
}

const COMMANDS: Command[] = [
  { cmd: "kubectl get pods", desc: "List all pods in the current namespace." },
  { cmd: "kubectl describe pod <name>", desc: "Show detailed status, events, and config for one pod." },
  { cmd: "kubectl logs -f <pod>", desc: "Stream logs from a pod in real time." },
  { cmd: "kubectl apply -f manifest.yaml", desc: "Create or update resources from a YAML manifest." },
  { cmd: "kubectl scale deployment <name> --replicas=N", desc: "Change the number of running replicas." },
  { cmd: "kubectl rollout status deployment/<name>", desc: "Watch a deployment rollout until it completes." },
  { cmd: "kubectl exec -it <pod> -- /bin/sh", desc: "Open an interactive shell inside a running pod." },
];

export function Cheatsheet() {
  const [copiedCmd, setCopiedCmd] = React.useState<string | null>(null);

  const copy = async (cmd: string) => {
    await navigator.clipboard.writeText(cmd);
    setCopiedCmd(cmd);
    setTimeout(() => setCopiedCmd((c) => (c === cmd ? null : c)), 1500);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-4 w-4" /> kubectl cheatsheet
        </CardTitle>
        <CardDescription>The commands you&apos;ll reach for most while operating this workload.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        {COMMANDS.map((c) => (
          <div
            key={c.cmd}
            className="flex items-center justify-between gap-3 rounded-lg border border-transparent px-2 py-2 hover:border-border hover:bg-accent/40"
          >
            <div className="min-w-0">
              <code className="block truncate font-mono text-xs">{c.cmd}</code>
              <p className="mt-0.5 text-xs text-muted-foreground">{c.desc}</p>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="iconSm"
              className="shrink-0"
              onClick={() => copy(c.cmd)}
              aria-label={`Copy ${c.cmd}`}
            >
              {copiedCmd === c.cmd ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

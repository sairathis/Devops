import { slugify } from "@/lib/utils";
import type { DeploymentConfig, ServiceConfig, IngressConfig } from "./types";

/** Kubernetes resource names must be lowercase RFC 1123 labels. */
export function k8sName(raw: string): string {
  return slugify(raw) || "my-app";
}

/** Quote a YAML scalar only when it needs it (keeps output readable). */
function yamlScalar(value: string): string {
  if (value === "") return '""';
  if (/^[A-Za-z0-9._-]+$/.test(value)) return value;
  return `"${value.replace(/"/g, '\\"')}"`;
}

export function generateDeploymentYaml(deployment: DeploymentConfig): string {
  const name = k8sName(deployment.name);
  const image = deployment.image.trim() || "gcr.io/my-project/app:latest";
  const envBlock =
    deployment.envVars.length > 0
      ? [
          "          env:",
          ...deployment.envVars
            .filter((e) => e.key.trim() !== "")
            .flatMap((e) => [
              `            - name: ${e.key.trim()}`,
              `              value: ${yamlScalar(e.value)}`,
            ]),
        ].join("\n")
      : "";

  const lines = [
    "apiVersion: apps/v1",
    "kind: Deployment",
    "metadata:",
    `  name: ${name}`,
    "  labels:",
    `    app: ${name}`,
    "spec:",
    `  replicas: ${deployment.replicas}`,
    "  selector:",
    "    matchLabels:",
    `      app: ${name}`,
    "  template:",
    "    metadata:",
    "      labels:",
    `        app: ${name}`,
    "    spec:",
    "      containers:",
    `        - name: ${name}`,
    `          image: ${image}`,
    "          ports:",
    `            - containerPort: ${deployment.containerPort}`,
    ...(envBlock ? [envBlock] : []),
    "          resources:",
    "            requests:",
    `              cpu: ${deployment.cpuRequest}`,
    `              memory: ${deployment.memoryRequest}`,
    "            limits:",
    `              cpu: ${deployment.cpuLimit}`,
    `              memory: ${deployment.memoryLimit}`,
  ];

  return lines.join("\n") + "\n";
}

export function generateServiceYaml(deploymentName: string, service: ServiceConfig): string {
  const name = k8sName(deploymentName);

  const lines = [
    "apiVersion: v1",
    "kind: Service",
    "metadata:",
    `  name: ${name}`,
    "spec:",
    `  type: ${service.type}`,
    "  selector:",
    `    app: ${name}`,
    "  ports:",
    `    - port: ${service.port}`,
    `      targetPort: ${service.targetPort}`,
  ];

  return lines.join("\n") + "\n";
}

export function generateIngressYaml(deploymentName: string, service: ServiceConfig, ingress: IngressConfig): string {
  const name = k8sName(deploymentName);
  const path = ingress.path.trim() || "/";

  const lines = [
    "apiVersion: networking.k8s.io/v1",
    "kind: Ingress",
    "metadata:",
    `  name: ${name}`,
    "  annotations:",
    '    kubernetes.io/ingress.class: "gce"',
    "spec:",
    "  rules:",
    `    - host: ${ingress.host.trim() || "app.example.com"}`,
    "      http:",
    "        paths:",
    `          - path: ${path}`,
    "            pathType: Prefix",
    "            backend:",
    "              service:",
    `                name: ${name}`,
    "                port:",
    `                  number: ${service.port}`,
  ];

  return lines.join("\n") + "\n";
}

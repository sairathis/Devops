"use client";
import * as React from "react";
import { BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface Concept {
  id: string;
  title: string;
  body: string;
}

const CONCEPTS: Concept[] = [
  {
    id: "pods",
    title: "Pods",
    body:
      "A Pod is the smallest deployable unit in Kubernetes — one or more containers that share networking and storage and are always scheduled together. You rarely create Pods directly; a controller like a Deployment creates and manages them for you.",
  },
  {
    id: "deployments",
    title: "Deployments",
    body:
      "A Deployment describes the desired state for a set of identical Pods: which container image to run, how many replicas, and how to roll out changes. It continuously reconciles the actual state to match, replacing failed Pods and handling rolling updates.",
  },
  {
    id: "services",
    title: "Services",
    body:
      "Pods are ephemeral and get new IPs when they restart, so a Service gives them a stable network identity. It load-balances traffic across every Pod matching its label selector. ClusterIP is internal-only, NodePort opens a port on every node, and LoadBalancer provisions an external cloud load balancer.",
  },
  {
    id: "ingress",
    title: "Ingress",
    body:
      "Ingress routes external HTTP(S) traffic to Services based on hostname and path, typically fronted by a single cloud load balancer. It's how you expose multiple Services under one IP address without giving each one its own LoadBalancer Service.",
  },
  {
    id: "configmaps-secrets",
    title: "ConfigMaps & Secrets",
    body:
      "ConfigMaps store non-sensitive configuration — feature flags, URLs, env vars — separately from container images, so you can change config without rebuilding. Secrets hold sensitive values like API keys and passwords the same way, base64-encoded at rest and injected as env vars or mounted files.",
  },
];

export function Concepts() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-4 w-4" /> Core concepts
        </CardTitle>
        <CardDescription>What each piece of this manifest actually does.</CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible defaultValue="pods">
          {CONCEPTS.map((c) => (
            <AccordionItem key={c.id} value={c.id}>
              <AccordionTrigger>{c.title}</AccordionTrigger>
              <AccordionContent>{c.body}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}

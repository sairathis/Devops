"use client";
import * as React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { DeploymentConfig, EnvVar } from "./types";

export function DeploymentForm({
  value,
  onChange,
  onReplicasChange,
}: {
  value: DeploymentConfig;
  onChange: (next: DeploymentConfig) => void;
  onReplicasChange: (replicas: number) => void;
}) {
  const set = <K extends keyof DeploymentConfig>(key: K, v: DeploymentConfig[K]) => {
    onChange({ ...value, [key]: v });
  };

  const addEnvVar = () => {
    const newVar: EnvVar = { id: `env-${Math.random().toString(36).slice(2, 9)}`, key: "", value: "" };
    set("envVars", [...value.envVars, newVar]);
  };

  const updateEnvVar = (id: string, patch: Partial<EnvVar>) => {
    set(
      "envVars",
      value.envVars.map((e) => (e.id === id ? { ...e, ...patch } : e)),
    );
  };

  const removeEnvVar = (id: string) => {
    set("envVars", value.envVars.filter((e) => e.id !== id));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Deployment</CardTitle>
        <CardDescription>Defines the pod template and how many replicas should run.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="deploy-name">Name</Label>
            <Input
              id="deploy-name"
              value={value.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="my-app"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="deploy-image">Container image</Label>
            <Input
              id="deploy-image"
              value={value.image}
              onChange={(e) => set("image", e.target.value)}
              placeholder="gcr.io/my-project/app:latest"
              className="font-mono text-xs"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="deploy-replicas">Replicas</Label>
            <span className="rounded-md bg-muted px-2 py-0.5 font-mono text-xs">{value.replicas}</span>
          </div>
          <Slider
            id="deploy-replicas"
            min={1}
            max={10}
            step={1}
            value={[value.replicas]}
            onValueChange={([v]) => onReplicasChange(v)}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="deploy-port">Container port</Label>
            <Input
              id="deploy-port"
              type="number"
              min={1}
              max={65535}
              value={value.containerPort}
              onChange={(e) => set("containerPort", Number(e.target.value) || 0)}
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">CPU request</Label>
            <Input value={value.cpuRequest} onChange={(e) => set("cpuRequest", e.target.value)} placeholder="250m" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">CPU limit</Label>
            <Input value={value.cpuLimit} onChange={(e) => set("cpuLimit", e.target.value)} placeholder="500m" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Memory request</Label>
            <Input value={value.memoryRequest} onChange={(e) => set("memoryRequest", e.target.value)} placeholder="256Mi" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Memory limit</Label>
            <Input value={value.memoryLimit} onChange={(e) => set("memoryLimit", e.target.value)} placeholder="512Mi" />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Environment variables</Label>
            <Button type="button" variant="outline" size="sm" onClick={addEnvVar}>
              <Plus className="h-3.5 w-3.5" /> Add
            </Button>
          </div>
          {value.envVars.length === 0 ? (
            <p className="text-xs text-muted-foreground">No environment variables yet. Add one above.</p>
          ) : (
            <div className="space-y-2">
              {value.envVars.map((env) => (
                <div key={env.id} className="flex items-center gap-2">
                  <Input
                    value={env.key}
                    onChange={(e) => updateEnvVar(env.id, { key: e.target.value })}
                    placeholder="KEY"
                    className="font-mono text-xs"
                  />
                  <Input
                    value={env.value}
                    onChange={(e) => updateEnvVar(env.id, { value: e.target.value })}
                    placeholder="value"
                    className="font-mono text-xs"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="iconSm"
                    onClick={() => removeEnvVar(env.id)}
                    aria-label="Remove environment variable"
                  >
                    <Trash2 className="h-3.5 w-3.5 text-danger" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

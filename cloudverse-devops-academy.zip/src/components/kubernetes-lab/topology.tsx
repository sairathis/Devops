"use client";
import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Box, Network, Waypoints, Globe } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { IngressConfig, ServiceConfig } from "./types";

const SERVICE_TYPE_LABEL: Record<ServiceConfig["type"], string> = {
  ClusterIP: "Internal (ClusterIP)",
  NodePort: "Node-exposed (NodePort)",
  LoadBalancer: "External (LoadBalancer)",
};

export function Topology({
  name,
  replicas,
  service,
  ingress,
}: {
  name: string;
  replicas: number;
  service: ServiceConfig;
  ingress: IngressConfig;
}) {
  const pods = React.useMemo(() => Array.from({ length: replicas }, (_, i) => `pod-${i}`), [replicas]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Live topology</CardTitle>
        <CardDescription>Updates as you change replicas, Service type, and Ingress settings.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center gap-3">
          {/* Deployment boundary */}
          <div className="w-full rounded-2xl border-2 border-dashed border-gcp-blue/40 bg-gcp-blue/[0.03] p-4">
            <div className="mb-3 flex items-center gap-2 text-xs font-medium text-gcp-blue">
              <Waypoints className="h-3.5 w-3.5" />
              Deployment / {name || "my-app"}
            </div>
            <div className="flex flex-wrap justify-center gap-2.5">
              <AnimatePresence initial={false}>
                {pods.map((id) => (
                  <motion.div
                    key={id}
                    layout
                    initial={{ opacity: 0, scale: 0.6 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.6 }}
                    transition={{ duration: 0.22 }}
                    className="flex h-16 w-16 flex-col items-center justify-center gap-1 rounded-lg border border-border bg-card text-center shadow-sm"
                  >
                    <Box className="h-4 w-4 text-gcp-green" />
                    <span className="text-[9px] text-muted-foreground">Pod</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <Connector />

          {/* Service */}
          <div className="flex w-full max-w-xs flex-col items-center gap-1.5 rounded-xl border border-border bg-card p-3 text-center shadow-sm">
            <Network className="h-4 w-4 text-gcp-yellow" />
            <span className="text-xs font-medium">Service</span>
            <span className="text-[10px] text-muted-foreground">{SERVICE_TYPE_LABEL[service.type]}</span>
            <span className="font-mono text-[10px] text-muted-foreground">
              {service.port} → {service.targetPort}
            </span>
          </div>

          {ingress.enabled && (
            <>
              <Connector />
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex w-full max-w-xs flex-col items-center gap-1.5 rounded-xl border border-border bg-card p-3 text-center shadow-sm"
              >
                <Globe className="h-4 w-4 text-gcp-red" />
                <span className="text-xs font-medium">Ingress / Load Balancer</span>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {ingress.host || "app.example.com"}
                  {ingress.path || "/"}
                </span>
              </motion.div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function Connector() {
  return <div className="h-5 w-px bg-border" aria-hidden />;
}

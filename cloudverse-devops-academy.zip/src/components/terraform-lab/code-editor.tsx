"use client";
import * as React from "react";
import { FileCode2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

export function CodeEditor({ value, onChange, className }: CodeEditorProps) {
  const lineCount = React.useMemo(() => value.split("\n").length, [value]);

  return (
    <div className={cn("flex flex-col overflow-hidden rounded-xl border border-border bg-[#1e1e2e]", className)}>
      <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-3 py-1.5">
        <span className="flex items-center gap-1.5 font-mono text-xs text-white/60">
          <FileCode2 className="h-3.5 w-3.5" /> main.tf
        </span>
        <span className="font-mono text-[10px] text-white/40">{lineCount} lines</span>
      </div>
      <div className="relative flex-1">
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          spellCheck={false}
          wrap="off"
          className="h-full min-h-[420px] w-full resize-none whitespace-pre overflow-auto bg-transparent p-4 font-mono text-[12.5px] leading-relaxed text-[#e4e4f0] outline-none placeholder:text-white/30"
          placeholder='resource "google_storage_bucket" "example" { ... }'
          aria-label="Terraform HCL editor"
        />
      </div>
    </div>
  );
}

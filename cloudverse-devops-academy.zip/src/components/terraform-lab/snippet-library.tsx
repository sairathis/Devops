"use client";
import * as React from "react";
import { FilePlus2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GCP_RESOURCES } from "@/lib/gcp";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";
import { slugify } from "@/lib/utils";

const CATEGORY_BADGE_CLASS: Record<string, string> = {
  "gcp-blue": "bg-gcp-blue/10 text-gcp-blue",
  "gcp-green": "bg-gcp-green/10 text-gcp-green",
  "gcp-yellow": "bg-gcp-yellow/10 text-gcp-yellow",
  "gcp-red": "bg-gcp-red/10 text-gcp-red",
};

interface SnippetLibraryProps {
  onInsert: (code: string, mode: "append" | "replace") => void;
}

const CATEGORY_ORDER: ResourceCategory[] = [
  "networking",
  "compute",
  "storage",
  "database",
  "containers",
  "cicd",
  "security",
  "messaging",
];

export function SnippetLibrary({ onInsert }: SnippetLibraryProps) {
  const grouped = React.useMemo(() => {
    return CATEGORY_ORDER.map((category) => ({
      category,
      resources: GCP_RESOURCES.filter((r) => r.category === category),
    })).filter((g) => g.resources.length > 0);
  }, []);

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-center gap-2 border-b border-border p-4">
        <FilePlus2 className="h-4 w-4 text-primary" />
        <div>
          <p className="text-sm font-semibold leading-none">Snippet library</p>
          <p className="mt-1 text-xs text-muted-foreground">Insert real HCL for any of the 18 resources</p>
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-4 p-3">
          {grouped.map(({ category, resources }) => {
            const meta = CATEGORY_META[category];
            return (
              <div key={category}>
                <span
                  className={`mb-1.5 inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium ${CATEGORY_BADGE_CLASS[meta.color] ?? "bg-muted text-muted-foreground"}`}
                >
                  {meta.label}
                </span>
                <div className="space-y-1">
                  {resources.map((r) => (
                    <button
                      key={r.type}
                      type="button"
                      onClick={() =>
                        onInsert(
                          r.generateTerraform({
                            config: r.defaultConfig,
                            nodeId: "sample",
                            label: r.label,
                            slug: slugify(r.label),
                            allNodes: [],
                            connections: [],
                          }),
                          "append",
                        )
                      }
                      className="group flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left text-xs transition-colors hover:bg-accent"
                      title={r.tooltip}
                    >
                      <span className="min-w-0 flex-1 truncate">{r.label}</span>
                      <Plus className="h-3 w-3 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
      <div className="border-t border-border p-3">
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={() =>
            onInsert("", "replace")
          }
        >
          Clear editor
        </Button>
      </div>
    </div>
  );
}

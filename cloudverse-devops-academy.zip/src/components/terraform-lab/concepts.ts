export interface TerraformConcept {
  id: string;
  title: string;
  summary: string;
  body: string;
}

export const TERRAFORM_CONCEPTS: TerraformConcept[] = [
  {
    id: "providers",
    title: "Providers",
    summary: "Plugins that let Terraform talk to a specific platform, like Google Cloud.",
    body:
      "A provider is a plugin that translates HCL into API calls for a specific platform — the `google` provider knows how to create GCP resources, `aws` knows AWS, and so on. You configure a provider block once (project, region, credentials) and every resource block for that platform reuses it. Most real projects pin a provider version to avoid surprise behavior changes when Terraform updates it.",
  },
  {
    id: "resources",
    title: "Resources",
    summary: "The building blocks — each block declares one piece of real infrastructure.",
    body:
      "A `resource \"type\" \"name\"` block is the core unit of Terraform: it declares one object you want to exist, such as a VM or a storage bucket. The type (e.g. `google_compute_instance`) tells Terraform which API to call, and the local name (e.g. `web`) is how other blocks in your configuration refer back to it, like `google_compute_instance.web.id`. Terraform compares this declared state against reality and creates, updates, or destroys resources to match it.",
  },
  {
    id: "variables-outputs",
    title: "Variables & Outputs",
    summary: "Parameterize configurations going in, and expose useful values coming out.",
    body:
      "`variable` blocks let a configuration accept input instead of hardcoding values — machine type, environment name, or a secret pulled from a secure source rather than typed inline. `output` blocks do the reverse: they surface values (like an instance's IP address) after apply, so other configurations, scripts, or teammates can read them without digging through provider consoles. Together they make a module reusable across environments instead of copy-pasted.",
  },
  {
    id: "state",
    title: "State",
    summary: "Terraform's record of what it believes actually exists.",
    body:
      "Terraform keeps a state file mapping every resource block to the real-world object it created — this is how it knows what to change on the next apply instead of recreating everything from scratch. In solo learning projects the state file sits locally, but real teams store it remotely (e.g. a GCS bucket) with locking, so two people never apply conflicting changes at once. Editing infrastructure outside Terraform causes state to drift from reality, which is a common source of confusing plans.",
  },
  {
    id: "plan-apply",
    title: "Plan & Apply",
    summary: "Preview changes before they happen, then execute them.",
    body:
      "`terraform plan` computes a diff between your configuration and the current state, showing exactly what would be added, changed, or destroyed — without touching anything. `terraform apply` executes that plan for real, calling the provider's API to make the infrastructure match. Reviewing the plan output before applying is the single most effective habit for avoiding accidental deletions, especially for stateful resources like databases.",
  },
  {
    id: "modules",
    title: "Modules",
    summary: "Packaged, reusable groups of resources with their own inputs and outputs.",
    body:
      "A module is just a directory of Terraform files treated as a reusable unit — you call it with `module \"name\" { source = \"...\" }` and pass in variables the way you'd call a function. Modules let a team standardize patterns (like \"a VPC with three subnets and firewall rules\") once and reuse them across projects instead of duplicating HCL. The root configuration that calls modules together is often called the \"root module.\"",
  },
];

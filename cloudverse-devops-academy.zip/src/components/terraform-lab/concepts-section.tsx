"use client";
import * as React from "react";
import { Layers } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { TERRAFORM_CONCEPTS } from "./concepts";

export function ConceptsSection() {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-2 flex items-center gap-2">
        <Layers className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-semibold">Terraform concepts</h2>
      </div>
      <p className="mb-3 text-xs text-muted-foreground">
        The six ideas that show up in almost every Terraform configuration you&apos;ll ever read or write.
      </p>
      <Accordion type="single" collapsible className="w-full">
        {TERRAFORM_CONCEPTS.map((c) => (
          <AccordionItem key={c.id} value={c.id}>
            <AccordionTrigger>
              <span className="flex flex-col items-start text-left">
                <span>{c.title}</span>
                <span className="text-xs font-normal text-muted-foreground">{c.summary}</span>
              </span>
            </AccordionTrigger>
            <AccordionContent>{c.body}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}

"use client";
import * as React from "react";
import { AlertTriangle, CheckCircle2, PlayCircle, ShieldQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface CheckResult {
  id: string;
  message: string;
  ok: boolean;
}

const SECRET_LINE_RE = /\b(password|secret|api[_-]?key|token)\w*\s*=\s*"(?!\$\{)[^"]+"/i;

function runHeuristicChecks(code: string): CheckResult[] {
  const openBraces = (code.match(/\{/g) ?? []).length;
  const closeBraces = (code.match(/\}/g) ?? []).length;
  const hasResourceBlock = /\bresource\s+"[a-z0-9_]+"\s+"[a-zA-Z0-9_]+"\s*\{/.test(code);
  const hasProviderBlock = /\bprovider\s+"[a-z]+"\s*\{/.test(code);
  const suspectLines = code
    .split("\n")
    .map((line, i) => ({ line, i }))
    .filter(({ line }) => SECRET_LINE_RE.test(line));

  return [
    {
      id: "braces",
      ok: openBraces === closeBraces,
      message:
        openBraces === closeBraces
          ? `Braces are balanced (${openBraces} pairs).`
          : `Unbalanced braces: ${openBraces} "{" vs ${closeBraces} "}" — check for a missing or extra brace.`,
    },
    {
      id: "resource",
      ok: hasResourceBlock,
      message: hasResourceBlock
        ? "At least one resource block declares real infrastructure."
        : 'No resource block found. Add one like resource "google_storage_bucket" "example" { ... }.',
    },
    {
      id: "provider",
      ok: hasProviderBlock,
      message: hasProviderBlock
        ? "A provider block is configured."
        : 'No provider block found. Terraform needs one, e.g. provider "google" { project = "..." }.',
    },
    {
      id: "secrets",
      ok: suspectLines.length === 0,
      message:
        suspectLines.length === 0
          ? "No obviously hardcoded secrets detected in quoted literals."
          : `Found ${suspectLines.length} line${suspectLines.length === 1 ? "" : "s"} that look like a hardcoded password/secret/token — use a variable (marked sensitive) or Secret Manager instead.`,
    },
  ];
}

interface ValidationPanelProps {
  code: string;
  onResult?: (allPass: boolean) => void;
}

export function ValidationPanel({ code, onResult }: ValidationPanelProps) {
  const [results, setResults] = React.useState<CheckResult[] | null>(null);

  const handleValidate = () => {
    const next = runHeuristicChecks(code);
    setResults(next);
    onResult?.(next.every((r) => r.ok));
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <ShieldQuestion className="h-4 w-4 text-primary" />
          <div>
            <p className="text-sm font-semibold leading-none">Validate</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Heuristic checks for learning — not a substitute for <code className="font-mono">terraform validate</code>.
            </p>
          </div>
        </div>
        <Button size="sm" onClick={handleValidate}>
          <PlayCircle className="h-3.5 w-3.5" /> Run checks
        </Button>
      </div>

      {results && (
        <ul className="mt-4 space-y-2">
          {results.map((r) => (
            <li key={r.id} className="flex items-start gap-2 text-xs">
              {r.ok ? (
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-success" />
              ) : (
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />
              )}
              <span className={cn(!r.ok && "text-foreground", r.ok && "text-muted-foreground")}>{r.message}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

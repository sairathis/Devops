"use client";
import * as React from "react";
import { BookOpen, ExternalLink, Sparkles } from "lucide-react";
import { GCP_RESOURCES } from "@/lib/gcp";
import { TERRAFORM_CONCEPTS } from "./concepts";

const RESOURCE_TYPE_RE = /resource\s+"([a-z_]+)"\s+"([a-zA-Z0-9_]+)"/g;

interface DetectedBlock {
  terraformResourceType: string;
  blockName: string;
}

function detectResourceBlocks(code: string): DetectedBlock[] {
  const found: DetectedBlock[] = [];
  const seen = new Set<string>();
  const re = new RegExp(RESOURCE_TYPE_RE);
  let match: RegExpExecArray | null;
  while ((match = re.exec(code)) !== null) {
    const key = `${match[1]}::${match[2]}`;
    if (seen.has(key)) continue;
    seen.add(key);
    found.push({ terraformResourceType: match[1], blockName: match[2] });
  }
  return found;
}

export function LiveExplanation({ code }: { code: string }) {
  const detected = React.useMemo(() => detectResourceBlocks(code), [code]);

  const matches = React.useMemo(() => {
    const uniqueTypes = Array.from(new Set(detected.map((d) => d.terraformResourceType)));
    return uniqueTypes
      .map((type) => ({
        type,
        blockNames: detected.filter((d) => d.terraformResourceType === type).map((d) => d.blockName),
        def: GCP_RESOURCES.find((r) => r.terraformResourceType === type),
      }))
      .filter((m) => m.def);
  }, [detected]);

  if (matches.length === 0) {
    return (
      <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card">
        <PanelHeader />
        <div className="flex-1 overflow-auto p-4">
          <p className="mb-3 text-xs text-muted-foreground">
            No recognized GCP resource block yet — here&apos;s a quick primer while you write or insert one from the
            library.
          </p>
          <div className="space-y-3">
            {TERRAFORM_CONCEPTS.slice(0, 4).map((c) => (
              <div key={c.id} className="rounded-lg border border-border p-3">
                <p className="text-xs font-semibold">{c.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{c.summary}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card">
      <PanelHeader count={matches.length} />
      <div className="flex-1 space-y-3 overflow-auto p-4">
        {matches.map(({ type, blockNames, def }) => (
          <div key={type} className="rounded-lg border border-border p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm font-semibold">{def!.label}</span>
              <a
                href={def!.docsUrl}
                target="_blank"
                rel="noreferrer"
                className="flex shrink-0 items-center gap-1 text-[11px] font-medium text-primary hover:underline"
              >
                Docs <ExternalLink className="h-3 w-3" />
              </a>
            </div>
            <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">
              {type} &middot; {blockNames.join(", ")}
            </p>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{def!.learningNotes}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function PanelHeader({ count }: { count?: number }) {
  return (
    <div className="flex items-center gap-2 border-b border-border p-4">
      <Sparkles className="h-4 w-4 text-primary" />
      <div>
        <p className="text-sm font-semibold leading-none">Live explanation</p>
        <p className="mt-1 text-xs text-muted-foreground">
          {count ? `Explaining ${count} recognized resource${count === 1 ? "" : "s"}` : "Updates as you type"}
        </p>
      </div>
      <BookOpen className="ml-auto h-3.5 w-3.5 text-muted-foreground" />
    </div>
  );
}

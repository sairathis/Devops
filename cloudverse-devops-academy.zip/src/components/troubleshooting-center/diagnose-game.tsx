"use client";
import * as React from "react";
import { toast } from "sonner";
import { AlertTriangle, Check, X, Wrench, ArrowRight, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useProgressStore } from "@/store/progress-store";
import { CATEGORY_META } from "@/types/gcp";
import { INCIDENT_BANK, CATEGORY_BADGE_CLASS, type Incident } from "@/lib/troubleshooting-center/incidents";

const DISTRACTOR_COUNT = 3;

function shuffle<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

interface Round {
  incident: Incident;
  options: string[];
}

function buildRound(excludeId?: string): Round {
  const candidates = INCIDENT_BANK.length > 1 ? INCIDENT_BANK.filter((i) => i.id !== excludeId) : INCIDENT_BANK;
  const incident = candidates[Math.floor(Math.random() * candidates.length)];

  const distractorPool = Array.from(
    new Set(
      INCIDENT_BANK.filter((i) => i.id !== incident.id && i.cause !== incident.cause).map((i) => i.cause),
    ),
  );
  const distractors = shuffle(distractorPool).slice(0, DISTRACTOR_COUNT);
  const options = shuffle([incident.cause, ...distractors]);

  return { incident, options };
}

export function DiagnoseGame() {
  const [round, setRound] = React.useState<Round | null>(null);
  const [selected, setSelected] = React.useState<number | null>(null);
  const [score, setScore] = React.useState({ correct: 0, total: 0 });

  const addXp = useProgressStore((s) => s.addXp);
  const recordQuizResult = useProgressStore((s) => s.recordQuizResult);

  // Random selection must never run during initial render (server/client
  // mismatch risk). Populate the first round only after mount.
  React.useEffect(() => {
    setRound(buildRound());
  }, []);

  const choose = (index: number) => {
    if (!round || selected !== null) return;
    setSelected(index);
    const correct = round.options[index] === round.incident.cause;
    recordQuizResult("Troubleshooting", correct ? 1 : 0, 1);
    setScore((s) => ({ correct: s.correct + (correct ? 1 : 0), total: s.total + 1 }));
    if (correct) {
      addXp(10);
      toast.success("Correct diagnosis! +10 XP");
    } else {
      toast.error("Not the root cause — check the fix below.");
    }
  };

  const nextIncident = () => {
    setRound(buildRound(round?.incident.id));
    setSelected(null);
  };

  const accuracy = score.total > 0 ? Math.round((score.correct / score.total) * 100) : 0;

  return (
    <div className="space-y-5">
      <Card className="glass-panel border-none">
        <CardContent className="flex flex-col items-center gap-1 py-5 text-center sm:flex-row sm:justify-between sm:text-left">
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-gcp-blue" />
            <div>
              <p className="text-lg font-semibold leading-none">
                {score.correct} / {score.total} diagnosed correctly
              </p>
              <p className="mt-1 text-xs text-muted-foreground">Running score for this session</p>
            </div>
          </div>
          {score.total > 0 && (
            <Badge variant={accuracy >= 70 ? "success" : accuracy >= 40 ? "warning" : "danger"}>
              {accuracy}% accuracy
            </Badge>
          )}
        </CardContent>
      </Card>

      {!round ? (
        <Card>
          <CardContent className="flex items-center justify-center py-16 text-sm text-muted-foreground">
            Loading an incident…
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="border-danger/30 bg-danger/5">
            <CardHeader>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="danger" className="gap-1">
                  <AlertTriangle className="h-3 w-3" /> Live incident
                </Badge>
                <Badge variant="outline" className={cn(CATEGORY_BADGE_CLASS[CATEGORY_META[round.incident.category].color])}>
                  {CATEGORY_META[round.incident.category].label}
                </Badge>
              </div>
              <CardTitle className="mt-1 text-base">
                🚨 Incident: {round.incident.resourceLabel} — {round.incident.issue}
              </CardTitle>
              <CardDescription>
                On-call page just fired. What is the most likely root cause?
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardContent className="pt-5">
              <p className="mb-3 text-sm font-medium leading-relaxed">What is the most likely root cause?</p>
              <div className="flex flex-col gap-2">
                {round.options.map((option, i) => {
                  const isCorrect = option === round.incident.cause;
                  const showState = selected !== null;
                  return (
                    <button
                      key={i}
                      onClick={() => choose(i)}
                      disabled={showState}
                      className={cn(
                        "flex items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition-colors",
                        showState && isCorrect && "border-success bg-success/10",
                        showState && i === selected && !isCorrect && "border-danger bg-danger/10",
                        !showState && "border-border hover:bg-accent",
                        showState && i !== selected && !isCorrect && "opacity-50",
                      )}
                    >
                      <span>{option}</span>
                      {showState && isCorrect && <Check className="h-4 w-4 shrink-0 text-success" />}
                      {showState && i === selected && !isCorrect && <X className="h-4 w-4 shrink-0 text-danger" />}
                    </button>
                  );
                })}
              </div>

              {selected !== null && (
                <div className="mt-4 space-y-3">
                  <div className="flex items-start gap-2 rounded-lg bg-muted/50 p-3">
                    <Wrench className="mt-0.5 h-4 w-4 shrink-0 text-gcp-green" />
                    <div>
                      <p className="text-xs font-medium text-foreground">The fix</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{round.incident.fix}</p>
                    </div>
                  </div>
                  <Button onClick={nextIncident} className="w-full sm:w-auto">
                    Next incident <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

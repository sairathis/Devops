"use client";
import * as React from "react";
import { Search, AlertTriangle, Wrench, BookOpen } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { CATEGORY_META } from "@/types/gcp";
import { INCIDENT_BANK, getIncidentCategories, CATEGORY_BADGE_CLASS } from "@/lib/troubleshooting-center/incidents";

const CATEGORIES = getIncidentCategories();

export function ReferenceLibrary() {
  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<string>("all");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return INCIDENT_BANK.filter((incident) => {
      const matchesCategory = category === "all" || incident.category === category;
      if (!matchesCategory) return false;
      if (!q) return true;
      return (
        incident.resourceLabel.toLowerCase().includes(q) ||
        incident.issue.toLowerCase().includes(q) ||
        incident.cause.toLowerCase().includes(q) ||
        incident.fix.toLowerCase().includes(q)
      );
    });
  }, [query, category]);

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="flex flex-col gap-3 pt-5 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search incidents by resource, symptom, cause, or fix…"
              className="pl-9"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-full sm:w-56">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {CATEGORY_META[c].label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        {filtered.length} of {INCIDENT_BANK.length} incidents shown
      </p>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center text-sm text-muted-foreground">
            <BookOpen className="h-6 w-6" />
            No incidents match &quot;{query}&quot;. Try a different search or category.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="pt-3">
            <Accordion type="multiple" className="w-full">
              {filtered.map((incident) => (
                <AccordionItem key={incident.id} value={incident.id}>
                  <AccordionTrigger>
                    <div className="flex flex-1 flex-wrap items-center gap-2 pr-3 text-left">
                      <Badge
                        variant="outline"
                        className={cn("shrink-0", CATEGORY_BADGE_CLASS[CATEGORY_META[incident.category].color])}
                      >
                        {incident.resourceLabel}
                      </Badge>
                      <span className="text-sm font-medium">{incident.issue}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 pl-1">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-yellow" />
                        <p>
                          <span className="font-medium text-foreground">Cause: </span>
                          {incident.cause}
                        </p>
                      </div>
                      <div className="flex items-start gap-2">
                        <Wrench className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-green" />
                        <p>
                          <span className="font-medium text-foreground">Fix: </span>
                          {incident.fix}
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

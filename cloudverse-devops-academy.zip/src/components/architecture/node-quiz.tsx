"use client";
import * as React from "react";
import { toast } from "sonner";
import { Check, X, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useProgressStore } from "@/store/progress-store";
import { GcpResourceDef } from "@/types/gcp";

export function NodeQuiz({ def }: { def: GcpResourceDef }) {
  const [index, setIndex] = React.useState(0);
  const [selected, setSelected] = React.useState<number | null>(null);
  const addXp = useProgressStore((s) => s.addXp);
  const recordQuizResult = useProgressStore((s) => s.recordQuizResult);

  const q = def.quiz[index % def.quiz.length];

  const choose = (i: number) => {
    if (selected !== null) return;
    setSelected(i);
    const correct = i === q.answerIndex;
    recordQuizResult(def.type, correct ? 1 : 0, 1);
    if (correct) {
      addXp(10);
      toast.success("Correct! +10 XP", { icon: <Check className="h-4 w-4" /> });
    } else {
      toast.error("Not quite — check the explanation below.");
    }
  };

  const next = () => {
    setSelected(null);
    setIndex((i) => (i + 1) % def.quiz.length);
  };

  return (
    <div className="rounded-xl border border-border p-4">
      <div className="mb-3 flex items-center gap-2 text-xs font-medium text-muted-foreground">
        <HelpCircle className="h-3.5 w-3.5" /> Quick check
      </div>
      <p className="mb-3 text-sm font-medium">{q.question}</p>
      <div className="flex flex-col gap-2">
        {q.options.map((opt, i) => {
          const isCorrect = i === q.answerIndex;
          const showState = selected !== null;
          return (
            <button
              key={i}
              onClick={() => choose(i)}
              className={cn(
                "flex items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition-colors",
                showState && isCorrect && "border-success bg-success/10",
                showState && i === selected && !isCorrect && "border-danger bg-danger/10",
                !showState && "border-border hover:bg-accent",
                showState && i !== selected && !isCorrect && "opacity-50",
              )}
            >
              {opt}
              {showState && isCorrect && <Check className="h-4 w-4 text-success" />}
              {showState && i === selected && !isCorrect && <X className="h-4 w-4 text-danger" />}
            </button>
          );
        })}
      </div>
      {selected !== null && (
        <div className="mt-3 flex items-start justify-between gap-3 rounded-lg bg-muted/50 p-3">
          <p className="text-xs text-muted-foreground">{q.explanation}</p>
          <Button size="sm" variant="ghost" onClick={next} className="shrink-0">
            Next
          </Button>
        </div>
      )}
    </div>
  );
}

"use client";
import * as React from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { GCP_RESOURCES } from "@/lib/gcp";
import { CATEGORY_META, ResourceCategory } from "@/types/gcp";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export function ResourcePalette() {
  const [query, setQuery] = React.useState("");

  const filtered = GCP_RESOURCES.filter(
    (r) => r.label.toLowerCase().includes(query.toLowerCase()) || r.category.includes(query.toLowerCase()),
  );

  const categories = Array.from(new Set(filtered.map((r) => r.category))) as ResourceCategory[];

  const onDragStart = (e: React.DragEvent, resourceType: string) => {
    e.dataTransfer.setData("application/cloudverse-node", resourceType);
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <div className="flex h-full w-64 shrink-0 flex-col border-r border-border bg-card/40">
      <div className="border-b border-border p-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search resources..."
            className="h-8 pl-8 text-xs"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-3">
          {categories.map((cat) => (
            <div key={cat} className="mb-4">
              <p className="mb-1.5 px-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                {CATEGORY_META[cat].label}
              </p>
              <div className="flex flex-col gap-1">
                {filtered
                  .filter((r) => r.category === cat)
                  .map((r) => (
                    <Tooltip key={r.type} delayDuration={400}>
                      <TooltipTrigger asChild>
                        <div
                          draggable
                          onDragStart={(e) => onDragStart(e, r.type)}
                          className="flex cursor-grab items-center gap-2 rounded-lg border border-transparent px-2 py-1.5 text-xs transition-colors hover:border-border hover:bg-accent active:cursor-grabbing"
                        >
                          <ResourceIcon type={r.type} color={r.color} size={14} className="h-6 w-6" />
                          <span className="truncate">{r.label}</span>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="right">{r.tooltip}</TooltipContent>
                    </Tooltip>
                  ))}
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="px-1 py-6 text-center text-xs text-muted-foreground">No resources match &ldquo;{query}&rdquo;</p>
          )}
        </div>
      </ScrollArea>
      <div className="border-t border-border p-3 text-[10px] text-muted-foreground">
        Drag a resource onto the canvas to add it.
      </div>
    </div>
  );
}

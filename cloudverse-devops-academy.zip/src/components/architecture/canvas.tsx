"use client";
import * as React from "react";
import ReactFlow, {
  Background, BackgroundVariant, Controls, MiniMap, applyNodeChanges, applyEdgeChanges,
  type Connection, type NodeChange, type EdgeChange, type Edge, useReactFlow, Panel,
} from "reactflow";
import "reactflow/dist/style.css";
import { toast } from "sonner";
import { useArchitectureStore } from "@/store/architecture-store";
import { GcpNode } from "@/components/architecture/gcp-node";
import { getResourceDef } from "@/lib/gcp";
import { useProgressStore } from "@/store/progress-store";

const nodeTypes = { gcpNode: GcpNode };

export const canvasWrapperId = "architecture-canvas-export-target";

export function ArchitectureCanvas() {
  const nodes = useArchitectureStore((s) => s.nodes);
  const edges = useArchitectureStore((s) => s.edges);
  const setNodes = useArchitectureStore((s) => s.setNodes);
  const setEdges = useArchitectureStore((s) => s.setEdges);
  const addNode = useArchitectureStore((s) => s.addNode);
  const addEdgeToStore = useArchitectureStore((s) => s.addEdge);
  const selectNode = useArchitectureStore((s) => s.selectNode);
  const simulationRunning = useArchitectureStore((s) => s.simulationRunning);
  const addXp = useProgressStore((s) => s.addXp);

  const { project, fitView } = useReactFlow();
  const wrapperRef = React.useRef<HTMLDivElement>(null);

  const onNodesChange = React.useCallback(
    (changes: NodeChange[]) => setNodes(applyNodeChanges(changes, nodes)),
    [nodes, setNodes],
  );
  const onEdgesChange = React.useCallback(
    (changes: EdgeChange[]) => setEdges(applyEdgeChanges(changes, edges)),
    [edges, setEdges],
  );

  const onConnect = React.useCallback(
    (connection: Connection) => {
      if (!connection.source || !connection.target) return;
      const sourceNode = nodes.find((n) => n.id === connection.source);
      const targetNode = nodes.find((n) => n.id === connection.target);
      const sourceDef = sourceNode ? getResourceDef(sourceNode.data.resourceType) : undefined;
      const isRecommended =
        sourceDef?.validConnectionTargets?.includes(targetNode?.data.resourceType ?? "") ?? true;

      const newEdge: Edge = {
        ...connection,
        source: connection.source,
        target: connection.target,
        id: `e-${connection.source}-${connection.target}-${Date.now()}`,
        animated: simulationRunning,
        style: isRecommended ? { strokeWidth: 1.5 } : { strokeWidth: 1.5, strokeDasharray: "4 3", opacity: 0.6 },
      };
      addEdgeToStore(newEdge);
      if (!isRecommended) {
        toast.warning("Unusual connection", {
          description: `${sourceDef?.label ?? "This resource"} doesn't typically connect directly to ${
            targetNode ? getResourceDef(targetNode.data.resourceType)?.label : "that resource"
          }. It'll still show on the diagram.`,
        });
      }
    },
    [nodes, addEdgeToStore, simulationRunning],
  );

  const onDragOver = React.useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = React.useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const resourceType = e.dataTransfer.getData("application/cloudverse-node");
      if (!resourceType || !wrapperRef.current) return;
      const bounds = wrapperRef.current.getBoundingClientRect();
      const position = project({ x: e.clientX - bounds.left, y: e.clientY - bounds.top });
      const wasEmpty = nodes.length === 0;
      addNode(resourceType, position);
      const def = getResourceDef(resourceType);
      addXp(5);
      toast.success(`${def?.label ?? "Resource"} added`, {
        description: "Terraform updated automatically — check the panel on the right.",
      });
      if (wasEmpty) setTimeout(() => fitView({ padding: 0.4, duration: 400 }), 50);
    },
    [project, addNode, nodes.length, fitView, addXp],
  );

  return (
    <div id={canvasWrapperId} ref={wrapperRef} className="relative h-full flex-1 bg-grid">
      <ReactFlow
        nodes={nodes}
        edges={edges.map((e) => (simulationRunning ? { ...e, animated: true } : e))}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeClick={(_, n) => selectNode(n.id)}
        onPaneClick={() => selectNode(null)}
        nodeTypes={nodeTypes}
        fitView
        minZoom={0.2}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
      >
        <Background variant={BackgroundVariant.Dots} gap={22} size={1} className="opacity-60" />
        <Controls showInteractive={false} />
        <MiniMap
          pannable
          zoomable
          className="!bg-card !border !border-border"
          maskColor="transparent"
          nodeColor={() => "hsl(var(--primary) / 0.5)"}
        />
        {nodes.length === 0 && (
          <Panel position="top-center" className="!m-0 mt-24">
            <div className="glass-panel rounded-2xl px-6 py-5 text-center">
              <p className="text-sm font-medium">Drag a resource from the left to get started</p>
              <p className="mt-1 text-xs text-muted-foreground">Or load an example architecture from the toolbar above</p>
            </div>
          </Panel>
        )}
      </ReactFlow>
    </div>
  );
}

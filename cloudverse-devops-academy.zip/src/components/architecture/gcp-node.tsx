"use client";
import * as React from "react";
import { Handle, Position, type NodeProps } from "reactflow";
import { Trash2 } from "lucide-react";
import { ResourceIcon } from "@/components/gcp/resource-icon";
import { getResourceDef } from "@/lib/gcp";
import { useArchitectureStore } from "@/store/architecture-store";
import { CanvasNodeData } from "@/types/gcp";
import { cn } from "@/lib/utils";

const BORDER_COLOR: Record<string, string> = {
  "gcp-blue": "border-t-gcp-blue",
  "gcp-red": "border-t-gcp-red",
  "gcp-yellow": "border-t-gcp-yellow",
  "gcp-green": "border-t-gcp-green",
};

function GcpNodeComponent({ id, data, selected }: NodeProps<CanvasNodeData>) {
  const def = getResourceDef(data.resourceType);
  const removeNode = useArchitectureStore((s) => s.removeNode);
  if (!def) return null;

  const subtitle =
    (data.config.region as string) ||
    (data.config.machineType as string) ||
    (data.config.tier as string) ||
    def.category;

  return (
    <div
      className={cn(
        "group relative w-[200px] rounded-xl border border-t-4 bg-card px-3 py-2.5 shadow-sm transition-all",
        BORDER_COLOR[def.color],
        selected ? "ring-2 ring-primary shadow-lg" : "hover:shadow-md",
      )}
    >
      <Handle type="target" position={Position.Left} className="!h-2.5 !w-2.5 !bg-muted-foreground/50" />
      <Handle type="source" position={Position.Right} className="!h-2.5 !w-2.5 !bg-muted-foreground/50" />

      <button
        onClick={(e) => {
          e.stopPropagation();
          removeNode(id);
        }}
        className="absolute -right-2 -top-2 hidden h-5 w-5 items-center justify-center rounded-full bg-danger text-white shadow group-hover:flex"
        aria-label="Delete resource"
      >
        <Trash2 className="h-3 w-3" />
      </button>

      <div className="flex items-center gap-2">
        <ResourceIcon type={def.type} color={def.color} size={16} className="h-7 w-7" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold leading-tight">{data.label}</p>
          <p className="truncate text-[10px] text-muted-foreground leading-tight">{subtitle}</p>
        </div>
      </div>
    </div>
  );
}

export const GcpNode = React.memo(GcpNodeComponent);

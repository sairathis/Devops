"use client";
import * as React from "react";
import { ConfigField, ResourceConfig } from "@/types/gcp";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export function ConfigForm({
  fields,
  config,
  onChange,
}: {
  fields: ConfigField[];
  config: ResourceConfig;
  onChange: (patch: Partial<ResourceConfig>) => void;
}) {
  return (
    <div className="flex flex-col gap-4">
      {fields.map((field) => (
        <div key={field.key} className="flex flex-col gap-1.5">
          {field.type !== "boolean" && (
            <Label htmlFor={field.key} className="text-xs text-muted-foreground">
              {field.label}
            </Label>
          )}

          {field.type === "text" && (
            <Input
              id={field.key}
              value={(config[field.key] as string) ?? ""}
              placeholder={field.placeholder}
              onChange={(e) => onChange({ [field.key]: e.target.value })}
            />
          )}

          {field.type === "textarea" && (
            <Textarea
              id={field.key}
              value={(config[field.key] as string) ?? ""}
              placeholder={field.placeholder}
              onChange={(e) => onChange({ [field.key]: e.target.value })}
            />
          )}

          {field.type === "number" && (
            <Input
              id={field.key}
              type="number"
              min={field.min}
              max={field.max}
              value={(config[field.key] as number) ?? 0}
              onChange={(e) => onChange({ [field.key]: Number(e.target.value) })}
            />
          )}

          {field.type === "select" && (
            <Select
              value={(config[field.key] as string) ?? ""}
              onValueChange={(v) => onChange({ [field.key]: v })}
            >
              <SelectTrigger id={field.key}>
                <SelectValue placeholder="Select..." />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          {field.type === "boolean" && (
            <div className="flex items-center justify-between rounded-lg border border-border px-3 py-2">
              <Label htmlFor={field.key} className="text-xs">
                {field.label}
              </Label>
              <Switch
                id={field.key}
                checked={Boolean(config[field.key])}
                onCheckedChange={(v) => onChange({ [field.key]: v })}
              />
            </div>
          )}

          {field.type === "slider" && (
            <div className="flex items-center gap-3">
              <Slider
                id={field.key}
                min={field.min}
                max={field.max}
                step={field.step ?? 1}
                value={[(config[field.key] as number) ?? field.min ?? 0]}
                onValueChange={([v]) => onChange({ [field.key]: v })}
              />
              <span className="w-10 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                {config[field.key] as number}
              </span>
            </div>
          )}

          {field.type === "tags" && (
            <Input
              id={field.key}
              value={((config[field.key] as string[]) ?? []).join(", ")}
              placeholder={field.placeholder}
              onChange={(e) =>
                onChange({
                  [field.key]: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                })
              }
            />
          )}

          {field.helpText && <p className="text-[11px] text-muted-foreground">{field.helpText}</p>}
        </div>
      ))}
    </div>
  );
}

export type CertificationLevel = "Associate" | "Professional";

export interface CertificationTopic {
  id: string;
  title: string;
  description: string;
}

export interface CertificationPath {
  id: string;
  title: string;
  level: CertificationLevel;
  estimatedHours: number;
  description: string;
  officialUrl: string;
  topics: CertificationTopic[];
}

export const CERTIFICATION_PATHS: CertificationPath[] = [
  {
    id: "associate-cloud-engineer",
    title: "Associate Cloud Engineer",
    level: "Associate",
    estimatedHours: 45,
    description:
      "The foundational GCP certification for deploying applications, monitoring operations, and managing infrastructure across one or more projects.",
    officialUrl: "https://cloud.google.com/certification/cloud-engineer",
    topics: [
      {
        id: "setting-up-environment",
        title: "Setting up a cloud solution environment",
        description: "Create projects, assign billing accounts, and configure the gcloud CLI, Cloud Shell, and SDK.",
      },
      {
        id: "planning-configuring",
        title: "Planning & configuring a cloud solution",
        description: "Plan and estimate resource usage, and decide between Compute Engine, GKE, and serverless options.",
      },
      {
        id: "deploying-compute",
        title: "Deploying and implementing Compute Engine resources",
        description: "Launch VM instances, manage instance groups, and configure autoscaling and load balancing.",
      },
      {
        id: "deploying-gke",
        title: "Deploying and implementing GKE resources",
        description: "Create clusters, deploy workloads, and manage nodes, pods, and services on Kubernetes Engine.",
      },
      {
        id: "deploying-storage",
        title: "Deploying and implementing Cloud Storage & data solutions",
        description: "Configure storage classes, buckets, IAM permissions, and choose between Cloud SQL, Firestore, and BigQuery.",
      },
      {
        id: "ensuring-operation",
        title: "Ensuring successful operation of a cloud solution",
        description: "Manage resources with Cloud Monitoring and Logging, and configure alerting policies and uptime checks.",
      },
      {
        id: "configuring-access-security",
        title: "Configuring access and security",
        description: "Manage IAM roles, service accounts, and organization policies to enforce least-privilege access.",
      },
      {
        id: "networking-fundamentals",
        title: "Networking fundamentals for compute workloads",
        description: "Configure VPC networks, subnets, firewall rules, and Cloud NAT for outbound-only instances.",
      },
    ],
  },
  {
    id: "professional-cloud-devops-engineer",
    title: "Professional Cloud DevOps Engineer",
    level: "Professional",
    estimatedHours: 60,
    description:
      "Validates the ability to combine software engineering and operations to build and manage the full lifecycle of services running on GCP.",
    officialUrl: "https://cloud.google.com/certification/cloud-devops-engineer",
    topics: [
      {
        id: "applying-sre-principles",
        title: "Applying site reliability engineering principles to a service",
        description: "Define SLIs, SLOs, and error budgets, and use them to drive release and reliability decisions.",
      },
      {
        id: "cicd-pipeline-design",
        title: "Building and implementing CI/CD pipelines",
        description: "Design pipelines with Cloud Build, Artifact Registry, and deployment strategies like canary and blue-green.",
      },
      {
        id: "implementing-service-monitoring",
        title: "Implementing service monitoring strategies",
        description: "Instrument services with Cloud Monitoring, Cloud Trace, and Cloud Profiler for full observability.",
      },
      {
        id: "managing-incident-response",
        title: "Managing incident response",
        description: "Detect, triage, and resolve incidents, then run blameless postmortems to prevent recurrence.",
      },
      {
        id: "optimizing-performance",
        title: "Optimizing performance and managing toil",
        description: "Identify toil, automate repetitive operational work, and tune resource usage for cost and latency.",
      },
      {
        id: "managing-infra-as-code",
        title: "Managing infrastructure as code",
        description: "Use Terraform and Deployment Manager to version, review, and roll out infrastructure changes safely.",
      },
      {
        id: "release-engineering",
        title: "Release engineering and deployment strategies",
        description: "Automate build, test, and rollout stages, and design safe rollback procedures.",
      },
    ],
  },
  {
    id: "professional-cloud-architect",
    title: "Professional Cloud Architect",
    level: "Professional",
    estimatedHours: 70,
    description:
      "Certifies the ability to design, develop, and manage robust, secure, scalable, and dynamic solutions on Google Cloud.",
    officialUrl: "https://cloud.google.com/certification/cloud-architect",
    topics: [
      {
        id: "designing-business-requirements",
        title: "Designing solutions for business requirements",
        description: "Translate business goals, budget constraints, and compliance needs into a cloud solution design.",
      },
      {
        id: "designing-technical-requirements",
        title: "Designing solutions for technical requirements",
        description: "Balance availability, scalability, performance, and cost when choosing services and architecture.",
      },
      {
        id: "designing-network-architecture",
        title: "Designing network, storage, and compute architecture",
        description: "Architect VPCs, hybrid connectivity, storage tiers, and compute platforms that fit the workload.",
      },
      {
        id: "managing-implementation",
        title: "Managing implementation of cloud architecture",
        description: "Advise development teams, oversee provisioning, and coordinate migration and deployment work.",
      },
      {
        id: "ensuring-reliability",
        title: "Ensuring reliability, security, and compliance",
        description: "Design for disaster recovery, apply defense-in-depth security, and meet regulatory requirements.",
      },
      {
        id: "analyzing-optimizing",
        title: "Analyzing and optimizing technical & business processes",
        description: "Assess existing environments and processes to identify cost, performance, and operational improvements.",
      },
      {
        id: "case-study-mapping",
        title: "Mapping case studies to architectural decisions",
        description: "Practice applying the exam's official case studies to real design tradeoffs and recommendations.",
      },
    ],
  },
  {
    id: "professional-cloud-network-engineer",
    title: "Professional Cloud Network Engineer",
    level: "Professional",
    estimatedHours: 55,
    description:
      "Focuses on implementing, managing, and securing network architectures on Google Cloud, including hybrid and multi-cloud connectivity.",
    officialUrl: "https://cloud.google.com/certification/cloud-network-engineer",
    topics: [
      {
        id: "designing-planning-network",
        title: "Designing and planning a GCP network",
        description: "Plan IP address ranges, subnet layouts, and choose between VPC modes and topologies.",
      },
      {
        id: "implementing-vpc-networks",
        title: "Implementing VPC networks",
        description: "Create VPCs, subnets, routes, and firewall rules, and configure VPC peering and Shared VPC.",
      },
      {
        id: "configuring-network-services",
        title: "Configuring network services",
        description: "Set up load balancers, Cloud DNS, and Cloud NAT to route and resolve traffic reliably.",
      },
      {
        id: "implementing-hybrid-connectivity",
        title: "Implementing hybrid connectivity and network peering",
        description: "Connect on-premises networks using Cloud VPN and Cloud Interconnect, and configure Cloud Router.",
      },
      {
        id: "managing-monitoring-networks",
        title: "Managing, monitoring, and optimizing network operations",
        description: "Use Network Intelligence Center, Firewall Insights, and VPC Flow Logs to troubleshoot and tune networks.",
      },
      {
        id: "implementing-network-security",
        title: "Implementing network security",
        description: "Apply Cloud Armor, Identity-Aware Proxy, and hierarchical firewall policies to protect workloads.",
      },
      {
        id: "gke-networking",
        title: "Configuring networking for GKE",
        description: "Design pod and service networking, including VPC-native clusters and network policies.",
      },
    ],
  },
];

export function getCertificationPath(id: string): CertificationPath | undefined {
  return CERTIFICATION_PATHS.find((p) => p.id === id);
}

import { TrafficMode } from "@/store/networking-store";

export const VIEWBOX = { w: 1200, h: 640 };

export interface TopoNode {
  id: string;
  label: string;
  sub?: string;
  icon: "internet" | "dns" | "armor" | "lb" | "vm" | "router" | "nat" | "cloudsql" | "client";
  x: number;
  y: number;
  w: number;
  h: number;
}

export const TOPOLOGY_NODES: TopoNode[] = [
  { id: "internet", label: "Internet", icon: "internet", x: 20, y: 260, w: 90, h: 70 },
  { id: "client", label: "Client", sub: "203.0.113.42", icon: "client", x: 20, y: 40, w: 90, h: 60 },
  { id: "dns", label: "Cloud DNS", sub: "app.example.com", icon: "dns", x: 170, y: 30, w: 110, h: 64 },
  { id: "armor", label: "Cloud Armor", sub: "WAF + DDoS", icon: "armor", x: 170, y: 260, w: 110, h: 64 },
  { id: "lb", label: "Load Balancer", sub: "34.120.10.5", icon: "lb", x: 340, y: 260, w: 110, h: 64 },
  { id: "vm1", label: "web-vm-1", sub: "10.0.1.2", icon: "vm", x: 540, y: 130, w: 100, h: 56 },
  { id: "vm2", label: "web-vm-2", sub: "10.0.1.3", icon: "vm", x: 540, y: 260, w: 100, h: 56 },
  { id: "vm3", label: "web-vm-3", sub: "10.0.1.4", icon: "vm", x: 540, y: 390, w: 100, h: 56 },
  { id: "router", label: "Cloud Router", icon: "router", x: 760, y: 470, w: 100, h: 56 },
  { id: "nat", label: "Cloud NAT", sub: "34.72.9.10", icon: "nat", x: 900, y: 470, w: 100, h: 56 },
  { id: "appvm", label: "app-vm-1", sub: "10.0.2.5", icon: "vm", x: 900, y: 260, w: 100, h: 56 },
  { id: "sqlprimary", label: "Cloud SQL", sub: "primary", icon: "cloudsql", x: 1070, y: 190, w: 110, h: 56 },
  { id: "sqlstandby", label: "Cloud SQL", sub: "standby", icon: "cloudsql", x: 1070, y: 330, w: 110, h: 56 },
];

export const STATIC_EDGES: [string, string][] = [
  ["dns", "lb"],
  ["armor", "lb"],
  ["lb", "vm1"],
  ["lb", "vm2"],
  ["lb", "vm3"],
  ["vm1", "appvm"],
  ["vm2", "appvm"],
  ["vm3", "appvm"],
  ["appvm", "router"],
  ["router", "nat"],
  ["appvm", "sqlprimary"],
  ["sqlprimary", "sqlstandby"],
];

export const SUBNET_BOXES = [
  { label: "Public Subnet — 10.0.1.0/24", x: 500, y: 90, w: 180, h: 380 },
  { label: "Private Subnet — 10.0.2.0/24", x: 860, y: 90, w: 180, h: 380 },
];

export interface PacketSpec {
  path: string[];
  color: string;
  proto: string;
  srcIp: string;
  dstIp: string;
  port: string;
  blockedAt?: string;
}

export interface ModeMeta {
  id: TrafficMode;
  label: string;
  description: string;
  steps: string[];
  packets: (lbCounter: number, blocked: boolean) => PacketSpec[];
}

const VM_ROTATION = ["vm1", "vm2", "vm3"];

export const TRAFFIC_MODES: ModeMeta[] = [
  {
    id: "inbound",
    label: "Inbound Traffic",
    description: "A client on the internet requests your web app over HTTPS. Traffic passes through Cloud Armor for inspection, then the load balancer routes it to a healthy backend VM.",
    steps: [
      "Client sends a TLS request to the load balancer's anycast IP (34.120.10.5:443)",
      "Cloud Armor evaluates the request against WAF rules and rate limits",
      "The external HTTP(S) load balancer terminates TLS and picks a healthy backend",
      "Traffic is forwarded to web-vm-2 inside the public subnet",
    ],
    packets: (_lb, blocked) => [
      {
        path: blocked ? ["internet", "armor"] : ["internet", "armor", "lb", "vm2"],
        color: blocked ? "var(--color-danger)" : "var(--color-gcp-blue)",
        proto: "TCP",
        srcIp: "203.0.113.42",
        dstIp: "34.120.10.5",
        port: "443",
        blockedAt: blocked ? "armor" : undefined,
      },
    ],
  },
  {
    id: "outbound",
    label: "Outbound Traffic",
    description: "A private VM with no public IP needs to call an external API. Cloud NAT translates its internal address to a shared external IP so the connection can leave the VPC.",
    steps: [
      "app-vm-1 (10.0.2.5) opens an outbound TCP connection",
      "Traffic is routed to Cloud Router, which owns the NAT configuration",
      "Cloud NAT performs source NAT, rewriting 10.0.2.5 → 34.72.9.10",
      "The connection reaches the internet — inbound connections to 10.0.2.5 are still impossible",
    ],
    packets: () => [
      {
        path: ["appvm", "router", "nat", "internet"],
        color: "var(--color-gcp-green)",
        proto: "TCP",
        srcIp: "10.0.2.5 → 34.72.9.10",
        dstIp: "pkg.example.com",
        port: "443",
      },
    ],
  },
  {
    id: "eastwest",
    label: "East-West Traffic",
    description: "The web tier calls the internal app tier directly over private IPs — traffic that never leaves the VPC, commonly called east-west traffic.",
    steps: [
      "web-vm-2 in the public subnet needs data from the app tier",
      "It opens a connection directly to app-vm-1's internal IP (10.0.2.5)",
      "Traffic stays entirely inside the VPC, governed by internal firewall rules",
      "No load balancer or NAT is involved — this is service-to-service traffic",
    ],
    packets: () => [
      {
        path: ["vm2", "appvm"],
        color: "var(--color-gcp-yellow)",
        proto: "TCP",
        srcIp: "10.0.1.3",
        dstIp: "10.0.2.5",
        port: "8080",
      },
    ],
  },
  {
    id: "lbrouting",
    label: "LB Routing",
    description: "The load balancer continuously health-checks every backend and distributes new requests round-robin across the healthy ones.",
    steps: [
      "Load balancer sends periodic health check probes to every backend VM",
      "Unhealthy backends (failed checks) are automatically removed from rotation",
      "New requests are distributed round-robin across remaining healthy backends",
      "This request lands on " + "web-vm rotation",
    ],
    packets: (lbCounter) => [
      {
        path: ["internet", "lb", VM_ROTATION[lbCounter % 3]],
        color: "var(--color-gcp-blue)",
        proto: "TCP",
        srcIp: "203.0.113.42",
        dstIp: "34.120.10.5",
        port: "443",
      },
    ],
  },
  {
    id: "nat",
    label: "NAT Translation",
    description: "A close look at exactly how Cloud NAT rewrites packet headers so private instances can reach the internet without a public IP of their own.",
    steps: [
      "Packet leaves app-vm-1 with source 10.0.2.5:51342",
      "Cloud Router forwards it toward the NAT gateway",
      "Cloud NAT allocates a port and rewrites the source to 34.72.9.10:23841",
      "The return packet is translated back to 10.0.2.5:51342 automatically",
    ],
    packets: () => [
      {
        path: ["appvm", "router", "nat"],
        color: "var(--color-gcp-green)",
        proto: "TCP",
        srcIp: "10.0.2.5:51342 ⟶ 34.72.9.10:23841",
        dstIp: "8.8.8.8",
        port: "443",
      },
    ],
  },
  {
    id: "dns",
    label: "DNS Resolution",
    description: "Before any traffic flows, the client must resolve app.example.com to an IP address — Cloud DNS answers that query, then the actual connection begins.",
    steps: [
      "Client queries app.example.com via its resolver",
      "Cloud DNS answers authoritatively with the load balancer's anycast IP",
      "Client now opens the real HTTPS connection to that IP",
      "The load balancer proceeds as in the Inbound Traffic scenario",
    ],
    packets: () => [
      { path: ["client", "dns"], color: "var(--color-gcp-yellow)", proto: "UDP", srcIp: "203.0.113.42", dstIp: "8.8.8.8", port: "53" },
      { path: ["dns", "client"], color: "var(--color-gcp-yellow)", proto: "UDP", srcIp: "Cloud DNS", dstIp: "A record: 34.120.10.5", port: "53" },
      { path: ["client", "lb"], color: "var(--color-gcp-blue)", proto: "TCP", srcIp: "203.0.113.42", dstIp: "34.120.10.5", port: "443" },
    ],
  },
];

export function getNode(id: string): TopoNode {
  const n = TOPOLOGY_NODES.find((n) => n.id === id);
  if (!n) throw new Error(`Unknown topology node: ${id}`);
  return n;
}

export function nodeCenter(id: string) {
  const n = getNode(id);
  return { x: n.x + n.w / 2, y: n.y + n.h / 2 };
}

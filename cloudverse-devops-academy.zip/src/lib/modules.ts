import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard, Workflow, Cloud, FileCode2, Container, Ship, GitMerge,
  Activity, Wrench, Award, HelpCircle, TrendingUp, Compass, Network,
} from "lucide-react";

export interface ModuleDef {
  id: string;
  label: string;
  href: string;
  icon: LucideIcon;
  description: string;
  group: "Learn" | "Build" | "Practice" | "Track";
  badge?: string;
}

export const MODULES: ModuleDef[] = [
  { id: "dashboard", label: "Dashboard", href: "/", icon: LayoutDashboard, description: "Your learning home base", group: "Track" },
  { id: "architecture-builder", label: "Architecture Builder", href: "/architecture-builder", icon: Workflow, description: "Drag-and-drop cloud architecture canvas with live Terraform", group: "Build", badge: "Flagship" },
  { id: "networking-academy", label: "Networking Academy", href: "/networking-academy", icon: Network, description: "VPCs, subnets, firewalls, and animated traffic simulation", group: "Learn", badge: "Flagship" },
  { id: "gcp-services", label: "GCP Services", href: "/gcp-services", icon: Cloud, description: "Browse and learn every supported GCP service", group: "Learn" },
  { id: "terraform-lab", label: "Terraform Lab", href: "/terraform-lab", icon: FileCode2, description: "Write, validate, and understand Terraform HCL", group: "Build" },
  { id: "docker-lab", label: "Docker Lab", href: "/docker-lab", icon: Container, description: "Build images, run containers, inspect layers", group: "Build" },
  { id: "kubernetes-lab", label: "Kubernetes Lab", href: "/kubernetes-lab", icon: Ship, description: "Pods, deployments, services, and manifests", group: "Build" },
  { id: "cicd-simulator", label: "CI/CD Simulator", href: "/cicd-simulator", icon: GitMerge, description: "Visualize a pipeline from commit to production", group: "Practice" },
  { id: "monitoring-academy", label: "Monitoring Academy", href: "/monitoring-academy", icon: Activity, description: "SLOs, dashboards, alerting, and observability", group: "Learn" },
  { id: "troubleshooting-center", label: "Troubleshooting Center", href: "/troubleshooting-center", icon: Wrench, description: "Diagnose realistic production incidents", group: "Practice" },
  { id: "certification-paths", label: "Certification Paths", href: "/certification-paths", icon: Award, description: "Structured tracks toward GCP certifications", group: "Learn" },
  { id: "quiz-engine", label: "Quiz Engine", href: "/quiz-engine", icon: HelpCircle, description: "Test your knowledge across every topic", group: "Practice" },
  { id: "resource-explorer", label: "Resource Explorer", href: "/resource-explorer", icon: Compass, description: "Search and inspect everything you've built", group: "Track" },
  { id: "progress", label: "User Progress", href: "/progress", icon: TrendingUp, description: "XP, streaks, badges, and mastery", group: "Track" },
];

export const MODULE_GROUPS: ModuleDef["group"][] = ["Track", "Build", "Learn", "Practice"];

export function getModule(id: string) {
  return MODULES.find((m) => m.id === id);
}

import type { LucideIcon } from "lucide-react";
import {
  Workflow, FileCode2, Brain, Network, Flame, GraduationCap, Container, Ship, Wrench, Trophy,
} from "lucide-react";

export interface BadgeDef {
  id: string;
  label: string;
  description: string;
  icon: LucideIcon;
}

/**
 * The full catalog of badges a learner can earn across the platform.
 * These are illustrative/aspirational — not every unlock is wired up yet,
 * but any badge actually awarded via `useProgressStore().awardBadge` should
 * use one of these ids so it renders as "earned" here.
 */
export const BADGE_CATALOG: BadgeDef[] = [
  {
    id: "first-architecture",
    label: "First Architecture",
    description: "Build your first diagram in Architecture Builder.",
    icon: Workflow,
  },
  {
    id: "terraform-novice",
    label: "Terraform Novice",
    description: "Generate your first Terraform configuration.",
    icon: FileCode2,
  },
  {
    id: "quiz-whiz",
    label: "Quiz Whiz",
    description: "Score 100% on any quiz.",
    icon: Brain,
  },
  {
    id: "networking-pro",
    label: "Networking Pro",
    description: "Complete every traffic simulation mode in Networking Academy.",
    icon: Network,
  },
  {
    id: "streak-starter",
    label: "Streak Starter",
    description: "Reach a 3-day learning streak.",
    icon: Flame,
  },
  {
    id: "cloud-architect",
    label: "Cloud Architect",
    description: "Reach level 5.",
    icon: GraduationCap,
  },
  {
    id: "container-captain",
    label: "Container Captain",
    description: "Build and run your first container in Docker Lab.",
    icon: Container,
  },
  {
    id: "kubernetes-commander",
    label: "Kubernetes Commander",
    description: "Deploy your first pod in Kubernetes Lab.",
    icon: Ship,
  },
  {
    id: "incident-responder",
    label: "Incident Responder",
    description: "Resolve your first case in the Troubleshooting Center.",
    icon: Wrench,
  },
  {
    id: "full-stack-learner",
    label: "Full-Stack Learner",
    description: "Make progress in every module on the platform.",
    icon: Trophy,
  },
];

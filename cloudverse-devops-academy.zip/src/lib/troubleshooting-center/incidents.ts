import { GCP_RESOURCES } from "@/lib/gcp";
import { ResourceCategory } from "@/types/gcp";

export interface Incident {
  id: string;
  resourceLabel: string;
  resourceType: string;
  category: ResourceCategory;
  issue: string;
  cause: string;
  fix: string;
}

export const INCIDENT_BANK: Incident[] = GCP_RESOURCES.flatMap((resource) =>
  resource.troubleshooting.map((t, i) => ({
    id: `${resource.type}-${i}`,
    resourceLabel: resource.label,
    resourceType: resource.type,
    category: resource.category,
    issue: t.issue,
    cause: t.cause,
    fix: t.fix,
  })),
);

export function getIncidentCategories(): ResourceCategory[] {
  const set = new Set<ResourceCategory>();
  INCIDENT_BANK.forEach((incident) => set.add(incident.category));
  return Array.from(set);
}

// Full literal class strings — never construct Tailwind classes dynamically.
export const CATEGORY_BADGE_CLASS: Record<string, string> = {
  "gcp-blue": "border-gcp-blue/20 bg-gcp-blue/10 text-gcp-blue",
  "gcp-green": "border-gcp-green/20 bg-gcp-green/10 text-gcp-green",
  "gcp-yellow": "border-gcp-yellow/20 bg-gcp-yellow/10 text-gcp-yellow",
  "gcp-red": "border-gcp-red/20 bg-gcp-red/10 text-gcp-red",
};

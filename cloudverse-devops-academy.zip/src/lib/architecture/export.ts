import { toPng, toSvg } from "html-to-image";

async function getBg() {
  const bg = getComputedStyle(document.body).getPropertyValue("--background");
  return bg ? `hsl(${bg})` : "#ffffff";
}

export async function exportCanvasAsPng(el: HTMLElement, filename = "architecture.png") {
  const backgroundColor = await getBg();
  const dataUrl = await toPng(el, { cacheBust: true, backgroundColor, pixelRatio: 2 });
  downloadDataUrl(dataUrl, filename);
  return dataUrl;
}

export async function exportCanvasAsSvg(el: HTMLElement, filename = "architecture.svg") {
  const backgroundColor = await getBg();
  const dataUrl = await toSvg(el, { cacheBust: true, backgroundColor });
  downloadDataUrl(dataUrl, filename);
}

export async function exportCanvasAsPdf(el: HTMLElement, filename = "architecture.pdf") {
  const { jsPDF } = await import("jspdf");
  const backgroundColor = await getBg();
  const dataUrl = await toPng(el, { cacheBust: true, backgroundColor, pixelRatio: 2 });
  const img = new Image();
  img.src = dataUrl;
  await new Promise((resolve) => {
    img.onload = resolve;
  });
  const pdf = new jsPDF({
    orientation: img.width > img.height ? "landscape" : "portrait",
    unit: "px",
    format: [img.width, img.height],
  });
  pdf.addImage(dataUrl, "PNG", 0, 0, img.width, img.height);
  pdf.save(filename);
}

function downloadDataUrl(dataUrl: string, filename: string) {
  const link = document.createElement("a");
  link.download = filename;
  link.href = dataUrl;
  link.click();
}

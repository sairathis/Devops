import type { Edge } from "reactflow";
import type { ArchNode } from "@/store/architecture-store";
import { getResourceDef } from "@/lib/gcp";
import { ResourceConfig } from "@/types/gcp";

function node(id: string, type: string, x: number, y: number, config: Partial<ResourceConfig> = {}): ArchNode {
  const def = getResourceDef(type)!;
  return {
    id,
    type: "gcpNode",
    position: { x, y },
    data: { resourceType: type, label: def.label, config: { ...def.defaultConfig, ...config } as ResourceConfig },
  };
}

function edge(id: string, source: string, target: string, animated = false): Edge {
  return { id, source, target, animated, style: { strokeWidth: 1.5 } };
}

export interface ExampleTemplate {
  id: string;
  label: string;
  description: string;
  nodes: ArchNode[];
  edges: Edge[];
}

const threeTier: ExampleTemplate = {
  id: "three-tier",
  label: "Three-Tier Web App",
  description: "Internet-facing LB, autoscaled web tier, private app VM, and a Cloud SQL backend.",
  nodes: [
    node("vpc-1", "vpc", 40, 260, { name: "prod-vpc" }),
    node("subnet-pub", "subnet", 320, 120, { name: "public-subnet-1", access: "public" }),
    node("subnet-priv", "subnet", 320, 400, { name: "private-subnet-1", access: "private" }),
    node("armor-1", "armor", 600, 20, {}),
    node("lb-1", "lb", 600, 120, { name: "web-lb" }),
    node("mig-1", "mig", 880, 120, { name: "web-mig" }),
    node("router-1", "router", 320, 560, { name: "prod-router" }),
    node("nat-1", "nat", 600, 560, { name: "prod-nat" }),
    node("vm-app", "vm", 880, 400, { name: "app-vm-1", publicIp: false }),
    node("cloudsql-1", "cloudsql", 1160, 400, { name: "prod-db" }),
    node("redis-1", "redis", 1160, 560, { name: "app-cache" }),
  ],
  edges: [
    edge("e1", "vpc-1", "subnet-pub"),
    edge("e2", "vpc-1", "subnet-priv"),
    edge("e3", "armor-1", "lb-1"),
    edge("e4", "lb-1", "mig-1", true),
    edge("e5", "mig-1", "vm-app", true),
    edge("e6", "vm-app", "cloudsql-1", true),
    edge("e7", "vm-app", "redis-1", true),
    edge("e8", "router-1", "nat-1"),
    edge("e9", "subnet-priv", "router-1"),
  ],
};

const privateGke: ExampleTemplate = {
  id: "private-gke",
  label: "Private GKE Platform",
  description: "A private GKE cluster pulling images from Artifact Registry, deployed via Cloud Build.",
  nodes: [
    node("vpc-2", "vpc", 40, 220, { name: "prod-vpc" }),
    node("subnet-gke", "subnet", 320, 220, { name: "private-subnet-1", access: "private" }),
    node("router-2", "router", 320, 420, { name: "prod-router" }),
    node("nat-2", "nat", 600, 420, { name: "prod-nat" }),
    node("gke-1", "gke", 600, 220, { name: "prod-gke" }),
    node("registry-1", "artifact_registry", 880, 100, { name: "app-images" }),
    node("build-1", "cloud_build", 880, 340, { name: "deploy-on-push" }),
    node("cloudsql-2", "cloudsql", 1160, 220, { name: "prod-db" }),
    node("pubsub-1", "pubsub", 1160, 400, { name: "order-events" }),
  ],
  edges: [
    edge("g1", "vpc-2", "subnet-gke"),
    edge("g2", "subnet-gke", "gke-1"),
    edge("g3", "registry-1", "gke-1", true),
    edge("g4", "build-1", "registry-1", true),
    edge("g5", "build-1", "gke-1", true),
    edge("g6", "gke-1", "cloudsql-2", true),
    edge("g7", "gke-1", "pubsub-1", true),
    edge("g8", "router-2", "nat-2"),
  ],
};

const staticSite: ExampleTemplate = {
  id: "static-site",
  label: "Static Site + CDN Storage",
  description: "A globally distributed static website served from a public Cloud Storage bucket behind DNS.",
  nodes: [
    node("dns-1", "dns", 60, 200, { name: "site-zone" }),
    node("lb-2", "lb", 340, 200, { name: "site-lb" }),
    node("gcs-1", "gcs", 620, 200, { name: "site-assets-prod", access: "public" }),
  ],
  edges: [edge("s1", "dns-1", "lb-2"), edge("s2", "lb-2", "gcs-1", true)],
};

export const EXAMPLE_TEMPLATES: ExampleTemplate[] = [threeTier, privateGke, staticSite];

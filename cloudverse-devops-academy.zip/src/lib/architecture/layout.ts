import dagre from "dagre";
import type { Edge } from "reactflow";
import type { ArchNode } from "@/store/architecture-store";

const NODE_WIDTH = 220;
const NODE_HEIGHT = 88;

export function autoArrange(nodes: ArchNode[], edges: Edge[], direction: "LR" | "TB" = "LR"): ArchNode[] {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: direction, nodesep: 60, ranksep: 110 });

  nodes.forEach((n) => g.setNode(n.id, { width: NODE_WIDTH, height: NODE_HEIGHT }));
  edges.forEach((e) => g.setEdge(e.source, e.target));

  dagre.layout(g);

  return nodes.map((n) => {
    const pos = g.node(n.id);
    if (!pos) return n;
    return {
      ...n,
      position: { x: pos.x - NODE_WIDTH / 2, y: pos.y - NODE_HEIGHT / 2 },
    };
  });
}

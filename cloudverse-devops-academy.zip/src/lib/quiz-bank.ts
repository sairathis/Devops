export interface QuizQuestion {
  id: string;
  topic: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

import { GCP_RESOURCES } from "@/lib/gcp";

const resourceQuestions: QuizQuestion[] = GCP_RESOURCES.flatMap((r) =>
  r.quiz.map((q, i) => ({
    id: `${r.type}-${i}`,
    topic: r.label,
    difficulty: "beginner" as const,
    question: q.question,
    options: q.options,
    answerIndex: q.answerIndex,
    explanation: q.explanation,
  })),
);

const networkingQuestions: QuizQuestion[] = [
  {
    id: "net-1", topic: "Networking", difficulty: "beginner",
    question: "What is the primary purpose of Cloud NAT?",
    options: ["Load balancing across regions", "Outbound-only internet access for private instances", "DNS resolution", "Encrypting VPC traffic"],
    answerIndex: 1,
    explanation: "Cloud NAT performs source NAT so private instances can reach the internet without an inbound path.",
  },
  {
    id: "net-2", topic: "Networking", difficulty: "intermediate",
    question: "Traffic between two VMs in the same VPC, across subnets, is typically called:",
    options: ["North-south traffic", "East-west traffic", "Transit traffic", "Egress traffic"],
    answerIndex: 1,
    explanation: "East-west describes traffic flowing between services inside the same network, as opposed to north-south (in/out of the network).",
  },
  {
    id: "net-3", topic: "Networking", difficulty: "beginner",
    question: "Which GCP resource authoritatively answers DNS queries for a domain?",
    options: ["Cloud Router", "Cloud DNS", "Cloud Armor", "Cloud NAT"],
    answerIndex: 1,
    explanation: "Cloud DNS provides managed, authoritative DNS zones for public or private resolution.",
  },
  {
    id: "net-4", topic: "Networking", difficulty: "advanced",
    question: "A Cloud Router is a required prerequisite for which two features?",
    options: ["Cloud Armor and Cloud CDN", "Cloud NAT and dynamic BGP routing over VPN/Interconnect", "IAM and Org Policy", "Cloud Build and Artifact Registry"],
    answerIndex: 1,
    explanation: "Cloud Router provides the BGP control plane both Cloud NAT and dynamic hybrid connectivity rely on.",
  },
  {
    id: "net-5", topic: "Networking", difficulty: "intermediate",
    question: "What happens to a request when every backend behind a load balancer fails its health check?",
    options: ["The LB queues requests indefinitely", "The LB returns a 502/503 error", "Traffic is silently dropped with no error", "The LB automatically creates a new backend"],
    answerIndex: 1,
    explanation: "With no healthy backends, the load balancer cannot forward traffic and returns a 502/503 to the client.",
  },
];

export const QUIZ_BANK: QuizQuestion[] = [...networkingQuestions, ...resourceQuestions];

export function questionsForTopic(topic: string): QuizQuestion[] {
  return QUIZ_BANK.filter((q) => q.topic.toLowerCase() === topic.toLowerCase());
}

export function randomQuestions(count: number, topic?: string): QuizQuestion[] {
  const pool = topic ? questionsForTopic(topic) : QUIZ_BANK;
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

export const QUIZ_TOPICS = Array.from(new Set(QUIZ_BANK.map((q) => q.topic)));

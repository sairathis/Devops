import { GcpResourceDef } from "@/types/gcp";

const MACHINE_COST: Record<string, number> = {
  "e2-micro": 6.5, "e2-small": 13, "e2-medium": 26, "e2-standard-2": 52,
  "e2-standard-4": 104, "n2-standard-2": 71, "n2-standard-4": 142, "c2-standard-4": 168,
};

export const computeResources: GcpResourceDef[] = [
  {
    type: "vm",
    label: "Compute Engine VM",
    shortLabel: "VM",
    category: "compute",
    color: "gcp-green",
    description: "A configurable virtual machine running in a GCP zone, the fundamental building block of Compute Engine.",
    learningNotes:
      "Machine families trade off price vs. performance: E2 for cost-optimized general workloads, N2/N2D for balanced workloads, C2/C3 for compute-intensive tasks, and M-series for memory-optimized. Persistent Disks are network-attached and durable independent of the VM lifecycle. Attaching a public IP exposes the instance directly to the internet — pair with firewall rules and prefer a load balancer + private VM in production.",
    tooltip: "A single virtual machine instance.",
    docsUrl: "https://cloud.google.com/compute/docs/instances",
    terraformResourceType: "google_compute_instance",
    configFields: [
      { key: "name", label: "Instance Name", type: "text", required: true, placeholder: "web-vm-1" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "zone", label: "Zone", type: "select", options: [{ label: "a", value: "-a" }, { label: "b", value: "-b" }, { label: "c", value: "-c" }] },
      { key: "machineFamily", label: "Machine Family", type: "select", options: [{ label: "E2 (cost-optimized)", value: "E2" }, { label: "N2 (balanced)", value: "N2" }, { label: "C2 (compute-optimized)", value: "C2" }] },
      { key: "machineType", label: "Machine Type", type: "select", options: Object.keys(MACHINE_COST).map((m) => ({ label: m, value: m })) },
      { key: "osImage", label: "OS Image", type: "select", options: [
        { label: "Debian 12", value: "debian-cloud/debian-12" }, { label: "Ubuntu 22.04 LTS", value: "ubuntu-os-cloud/ubuntu-2204-lts" },
        { label: "Container-Optimized OS", value: "cos-cloud/cos-stable" }, { label: "Windows Server 2022", value: "windows-cloud/windows-2022" },
      ] },
      { key: "diskSizeGb", label: "Boot Disk Size (GB)", type: "number", min: 10, max: 2000 },
      { key: "diskType", label: "Disk Type", type: "select", options: [{ label: "Standard (pd-standard)", value: "pd-standard" }, { label: "Balanced (pd-balanced)", value: "pd-balanced" }, { label: "SSD (pd-ssd)", value: "pd-ssd" }] },
      { key: "publicIp", label: "Assign Public IP", type: "boolean" },
      { key: "enableSsh", label: "Allow SSH (port 22)", type: "boolean" },
      { key: "tags", label: "Network Tags", type: "tags", placeholder: "web, prod" },
    ],
    defaultConfig: { name: "web-vm-1", region: "us-central1", zone: "-a", machineFamily: "E2", machineType: "e2-medium", osImage: "debian-cloud/debian-12", diskSizeGb: 20, diskType: "pd-balanced", publicIp: true, enableSsh: true, tags: ["web"] },
    generateTerraform: ({ slug, config }) => `resource "google_compute_instance" "${slug}" {
  name         = "${config.name}"
  machine_type = "${config.machineType}"
  zone         = "${config.region}${config.zone}"
  tags         = ${JSON.stringify(config.tags ?? [])}

  boot_disk {
    initialize_params {
      image = "${config.osImage}"
      size  = ${config.diskSizeGb}
      type  = "${config.diskType}"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.public_subnet_1.id
    ${config.publicIp ? "access_config {}" : ""}
  }

  metadata = {
    enable-oslogin = "TRUE"
  }
}`,
    estimateMonthlyCost: (c) => MACHINE_COST[c.machineType as string] ?? 26,
    troubleshooting: [
      { issue: "Cannot SSH into the instance", cause: "Firewall rule missing for tcp:22 or no public IP assigned", fix: "Add a firewall rule allowing tcp:22 from your IP/IAP range, and confirm a public IP or use IAP TCP forwarding." },
      { issue: "Instance stuck in 'Provisioning'", cause: "Insufficient quota or capacity in the selected zone", fix: "Request a quota increase or select a different zone/region." },
    ],
    quiz: [
      { question: "Which machine family is best for cost-optimized, general-purpose workloads?", options: ["C2", "M2", "E2", "A2"], answerIndex: 2, explanation: "E2 instances are GCP's cost-optimized general-purpose family." },
    ],
    validConnectionTargets: ["cloudsql", "redis", "gcs", "pubsub"],
  },
  {
    type: "mig",
    label: "Managed Instance Group",
    shortLabel: "MIG",
    category: "compute",
    color: "gcp-green",
    description: "A group of identical VM instances created from a template, with autoscaling, autohealing, and rolling updates.",
    learningNotes:
      "MIGs are created from an Instance Template (an immutable blueprint of machine type, image, and metadata). Autoscaling policies react to CPU utilization, load balancing capacity, or custom Cloud Monitoring metrics. Autohealing uses a health check to detect and automatically recreate unhealthy instances — a foundational building block for self-healing infrastructure.",
    tooltip: "Auto-scaling, self-healing fleet of identical VMs.",
    docsUrl: "https://cloud.google.com/compute/docs/instance-groups",
    terraformResourceType: "google_compute_instance_group_manager",
    configFields: [
      { key: "name", label: "MIG Name", type: "text", required: true, placeholder: "web-mig" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" }] },
      { key: "minReplicas", label: "Min Instances", type: "number", min: 1, max: 50 },
      { key: "maxReplicas", label: "Max Instances", type: "number", min: 1, max: 200 },
      { key: "targetCpu", label: "Target CPU Utilization (%)", type: "slider", min: 10, max: 100, step: 5 },
      { key: "autoHealing", label: "Enable Autohealing", type: "boolean" },
      { key: "updatePolicy", label: "Update Policy", type: "select", options: [{ label: "Rolling Update", value: "PROACTIVE" }, { label: "Opportunistic", value: "OPPORTUNISTIC" }] },
    ],
    defaultConfig: { name: "web-mig", region: "us-central1", minReplicas: 2, maxReplicas: 10, targetCpu: 60, autoHealing: true, updatePolicy: "PROACTIVE" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_instance_template" "${slug}_template" {
  name_prefix  = "${config.name}-tmpl-"
  machine_type = "e2-medium"
  disk { source_image = "debian-cloud/debian-12" auto_delete = true boot = true }
  network_interface { subnetwork = google_compute_subnetwork.public_subnet_1.id }
  lifecycle { create_before_destroy = true }
}

resource "google_compute_region_instance_group_manager" "${slug}" {
  name               = "${config.name}"
  region             = "${config.region}"
  base_instance_name = "${config.name}"
  version {
    instance_template = google_compute_instance_template.${slug}_template.id
  }
  target_size = ${config.minReplicas}
  ${
    config.autoHealing
      ? `auto_healing_policies {
    health_check      = google_compute_health_check.web_lb_hc.id
    initial_delay_sec = 60
  }`
      : ""
  }
  update_policy {
    type                  = "${config.updatePolicy}"
    minimal_action        = "REPLACE"
    max_surge_fixed       = 3
    max_unavailable_fixed = 0
  }
}

resource "google_compute_region_autoscaler" "${slug}_autoscaler" {
  name   = "${config.name}-autoscaler"
  region = "${config.region}"
  target = google_compute_region_instance_group_manager.${slug}.id
  autoscaling_policy {
    min_replicas    = ${config.minReplicas}
    max_replicas    = ${config.maxReplicas}
    cooldown_period = 60
    cpu_utilization { target = ${Number(config.targetCpu) / 100} }
  }
}`,
    estimateMonthlyCost: (c) => (MACHINE_COST["e2-medium"] ?? 26) * Number(c.minReplicas ?? 2),
    troubleshooting: [
      { issue: "MIG keeps recreating instances in a loop", cause: "Autohealing health check fails immediately after boot (too-short initial delay)", fix: "Increase initial_delay_sec to allow the app to finish starting before health checks begin." },
      { issue: "Scaling doesn't react to load", cause: "Autoscaler target metric doesn't match actual bottleneck", fix: "Switch to a custom Cloud Monitoring metric (e.g. queue depth) that reflects real load." },
    ],
    quiz: [
      { question: "What triggers a Managed Instance Group to automatically recreate an instance?", options: ["Autoscaling policy", "Autohealing health check failure", "Instance template change", "Manual restart"], answerIndex: 1, explanation: "Autohealing detects unhealthy instances via health checks and recreates them." },
    ],
    validConnectionTargets: ["cloudsql", "redis"],
  },
];

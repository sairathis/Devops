import { GcpResourceDef } from "@/types/gcp";

export const securityResources: GcpResourceDef[] = [
  {
    type: "armor",
    label: "Cloud Armor",
    shortLabel: "Armor",
    category: "security",
    color: "gcp-red",
    description: "A web application firewall (WAF) and DDoS protection service attached to your external load balancers.",
    learningNotes:
      "Cloud Armor evaluates security policies (ordered rules) before traffic reaches your backend service. It provides pre-configured WAF rules for OWASP Top 10 threats (SQLi, XSS), rate-limiting, geo-based access control, and always-on L3/L4 DDoS protection for internet-facing services fronted by an external HTTP(S) load balancer.",
    tooltip: "WAF + DDoS protection for your load balancer.",
    docsUrl: "https://cloud.google.com/armor/docs/cloud-armor-overview",
    terraformResourceType: "google_compute_security_policy",
    configFields: [
      { key: "name", label: "Policy Name", type: "text", required: true, placeholder: "cloud-armor-policy" },
      { key: "defaultAction", label: "Default Action", type: "select", options: [{ label: "Allow", value: "allow" }, { label: "Deny (403)", value: "deny(403)" }] },
      { key: "owaspRules", label: "Enable OWASP Top-10 Rules (SQLi/XSS)", type: "boolean" },
      { key: "rateLimitThreshold", label: "Rate Limit (req/min per IP)", type: "number", min: 10, max: 10000 },
      { key: "geoBlockList", label: "Blocked Country Codes", type: "tags", placeholder: "CN, RU" },
    ],
    defaultConfig: { name: "cloud-armor-policy", defaultAction: "allow", owaspRules: true, rateLimitThreshold: 300, geoBlockList: [] },
    generateTerraform: ({ slug, config }) => `resource "google_compute_security_policy" "${slug}" {
  name = "${config.name}"

  rule {
    action   = "${config.defaultAction}"
    priority = 2147483647
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    description = "default rule"
  }
${
  config.owaspRules
    ? `
  rule {
    action   = "deny(403)"
    priority = 1000
    match {
      expr { expression = "evaluatePreconfiguredExpr('sqli-v33-stable')" }
    }
    description = "Block SQL injection (OWASP)"
  }

  rule {
    action   = "deny(403)"
    priority = 1001
    match {
      expr { expression = "evaluatePreconfiguredExpr('xss-v33-stable')" }
    }
    description = "Block XSS (OWASP)"
  }`
    : ""
}

  rule {
    action   = "throttle"
    priority = 2000
    match {
      versioned_expr = "SRC_IPS_V1"
      config { src_ip_ranges = ["*"] }
    }
    rate_limit_options {
      conform_action = "allow"
      exceed_action  = "deny(429)"
      rate_limit_threshold {
        count        = ${config.rateLimitThreshold}
        interval_sec = 60
      }
    }
    description = "Rate limiting"
  }
}`,
    estimateMonthlyCost: () => 5,
    troubleshooting: [
      { issue: "Legitimate traffic getting blocked (false positive)", cause: "OWASP preconfigured rule too aggressive for the app's payloads", fix: "Add an exclusion/sensitivity override for the specific rule ID, or move it to preview mode first." },
      { issue: "Rate limiting triggers too early", cause: "Threshold set too low for legitimate burst traffic", fix: "Raise rateLimitThreshold or use a longer interval to smooth bursts." },
    ],
    quiz: [
      { question: "What must Cloud Armor be attached to in order to filter traffic?", options: ["A VPC", "An external HTTP(S) load balancer backend service", "A Cloud NAT gateway", "A subnet"], answerIndex: 1, explanation: "Cloud Armor policies attach to backend services behind external load balancers." },
    ],
    validConnectionTargets: ["lb"],
  },
];

import { GcpResourceDef } from "@/types/gcp";

export const networkingResources: GcpResourceDef[] = [
  {
    type: "vpc",
    label: "VPC Network",
    shortLabel: "VPC",
    category: "networking",
    color: "gcp-blue",
    description: "A global, software-defined network that provides connectivity for your Compute Engine, GKE, and other resources.",
    learningNotes:
      "A VPC in GCP is global — it can span all regions without needing peering. Subnets, however, are regional. Always design VPCs around the principle of least privilege: separate public and private subnets, and use firewall rules to control east-west and north-south traffic. Custom-mode VPCs (recommended for production) let you control subnet CIDR ranges explicitly, unlike auto-mode VPCs which create a subnet per region automatically.",
    tooltip: "The foundational network container for all your GCP resources.",
    docsUrl: "https://cloud.google.com/vpc/docs/vpc",
    terraformResourceType: "google_compute_network",
    configFields: [
      { key: "name", label: "Network Name", type: "text", required: true, placeholder: "prod-vpc" },
      {
        key: "subnetMode",
        label: "Subnet Creation Mode",
        type: "select",
        options: [
          { label: "Custom (recommended)", value: "CUSTOM" },
          { label: "Auto", value: "AUTO" },
        ],
      },
      { key: "routingMode", label: "Routing Mode", type: "select", options: [{ label: "Regional", value: "REGIONAL" }, { label: "Global", value: "GLOBAL" }] },
      { key: "mtu", label: "MTU", type: "number", min: 1300, max: 8896 },
      { key: "description", label: "Description", type: "textarea" },
    ],
    defaultConfig: { name: "prod-vpc", subnetMode: "CUSTOM", routingMode: "REGIONAL", mtu: 1460, description: "Primary application VPC" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_network" "${slug}" {
  name                    = "${config.name}"
  auto_create_subnetworks = ${config.subnetMode === "AUTO"}
  routing_mode            = "${config.routingMode}"
  mtu                     = ${config.mtu}
  description             = "${config.description ?? ""}"
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "Instances in different subnets can't reach each other", cause: "Missing firewall rule allowing internal ingress", fix: "Add an allow rule for the internal CIDR ranges on the required ports/protocols." },
      { issue: "VPC peering shows INACTIVE", cause: "The peering was only configured on one side", fix: "Create the peering connection symmetrically from both VPCs." },
    ],
    quiz: [
      {
        question: "Are GCP VPC networks regional or global resources?",
        options: ["Regional", "Global", "Zonal", "Multi-regional only in us-central1"],
        answerIndex: 1,
        explanation: "VPC networks are global resources; subnets within them are regional.",
      },
    ],
    validConnectionTargets: ["subnet"],
  },
  {
    type: "subnet",
    label: "Subnet",
    shortLabel: "Subnet",
    category: "networking",
    color: "gcp-blue",
    description: "A regional IP address range within a VPC where resources like VMs get their internal IPs.",
    learningNotes:
      "Subnets are regional — resources in the same subnet can span multiple zones within that region but not other regions. Use separate subnets for public (has a route to an internet gateway) and private (egress only via Cloud NAT) workloads. Enable 'Private Google Access' on private subnets so instances without external IPs can still reach Google APIs.",
    tooltip: "A regional slice of your VPC's IP space.",
    docsUrl: "https://cloud.google.com/vpc/docs/subnets",
    terraformResourceType: "google_compute_subnetwork",
    configFields: [
      { key: "name", label: "Subnet Name", type: "text", required: true, placeholder: "public-subnet-1" },
      { key: "region", label: "Region", type: "select", options: [
        { label: "us-central1", value: "us-central1" }, { label: "us-east1", value: "us-east1" },
        { label: "europe-west1", value: "europe-west1" }, { label: "asia-south1", value: "asia-south1" },
      ] },
      { key: "ipCidrRange", label: "IP CIDR Range", type: "text", placeholder: "10.0.1.0/24" },
      { key: "access", label: "Access Type", type: "select", options: [{ label: "Public", value: "public" }, { label: "Private", value: "private" }] },
      { key: "privateGoogleAccess", label: "Private Google Access", type: "boolean" },
      { key: "flowLogs", label: "Enable VPC Flow Logs", type: "boolean" },
    ],
    defaultConfig: { name: "public-subnet-1", region: "us-central1", ipCidrRange: "10.0.1.0/24", access: "public", privateGoogleAccess: true, flowLogs: false },
    generateTerraform: ({ slug, config }) => `resource "google_compute_subnetwork" "${slug}" {
  name                     = "${config.name}"
  ip_cidr_range            = "${config.ipCidrRange}"
  region                   = "${config.region}"
  network                  = google_compute_network.prod_vpc.id
  private_ip_google_access = ${config.privateGoogleAccess}
  dynamic "log_config" {
    for_each = ${config.flowLogs} ? [1] : []
    content {
      aggregation_interval = "INTERVAL_5_SEC"
      flow_sampling        = 0.5
      metadata             = "INCLUDE_ALL_METADATA"
    }
  }
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "VM has no internet access", cause: "Private subnet with no Cloud NAT attached", fix: "Attach a Cloud NAT gateway to the subnet's region via a Cloud Router." },
      { issue: "Overlapping CIDR error on creation", cause: "IP range collides with another subnet in the VPC", fix: "Pick a non-overlapping CIDR block, e.g. split a /16 into /24s per subnet." },
    ],
    quiz: [
      {
        question: "What lets a VM with no external IP reach Google APIs like Cloud Storage?",
        options: ["Cloud NAT", "Private Google Access", "Cloud Armor", "Cloud Interconnect"],
        answerIndex: 1,
        explanation: "Private Google Access lets internal-only instances reach Google APIs/services without a public IP.",
      },
    ],
    validConnectionTargets: ["vm", "mig", "gke", "cloudsql", "redis"],
  },
  {
    type: "lb",
    label: "Load Balancer",
    shortLabel: "LB",
    category: "networking",
    color: "gcp-blue",
    description: "Distributes incoming traffic across multiple backend instances for scale, availability, and health-checked routing.",
    learningNotes:
      "GCP offers several load balancer types: Global external HTTP(S) for internet-facing web apps (Layer 7, uses Anycast IP), Network/TCP for non-HTTP traffic, and Internal LBs for private, VPC-only traffic between tiers. HTTP(S) LBs integrate natively with Cloud Armor and Cloud CDN. Health checks determine which backends receive traffic — an unhealthy backend is automatically drained.",
    tooltip: "Distributes traffic across backends with health checking.",
    docsUrl: "https://cloud.google.com/load-balancing/docs",
    terraformResourceType: "google_compute_forwarding_rule",
    configFields: [
      { key: "name", label: "Load Balancer Name", type: "text", required: true, placeholder: "web-lb" },
      { key: "lbType", label: "Type", type: "select", options: [
        { label: "HTTP(S) — External", value: "HTTPS" }, { label: "TCP — External", value: "TCP" },
        { label: "Internal HTTP(S)", value: "INTERNAL_HTTPS" }, { label: "Internal TCP/UDP", value: "INTERNAL" },
      ] },
      { key: "protocol", label: "Protocol", type: "select", options: [{ label: "HTTP", value: "HTTP" }, { label: "HTTPS", value: "HTTPS" }, { label: "TCP", value: "TCP" }] },
      { key: "port", label: "Port", type: "number", min: 1, max: 65535 },
      { key: "healthCheckPath", label: "Health Check Path", type: "text", placeholder: "/healthz" },
      { key: "sessionAffinity", label: "Session Affinity", type: "select", options: [{ label: "None", value: "NONE" }, { label: "Client IP", value: "CLIENT_IP" }, { label: "Cookie", value: "GENERATED_COOKIE" }] },
      { key: "cloudArmor", label: "Attach Cloud Armor Policy", type: "boolean" },
    ],
    defaultConfig: { name: "web-lb", lbType: "HTTPS", protocol: "HTTPS", port: 443, healthCheckPath: "/healthz", sessionAffinity: "NONE", cloudArmor: true },
    generateTerraform: ({ slug, config }) => `resource "google_compute_health_check" "${slug}_hc" {
  name               = "${config.name}-hc"
  check_interval_sec = 5
  timeout_sec        = 5
  http_health_check {
    port         = ${config.port}
    request_path = "${config.healthCheckPath}"
  }
}

resource "google_compute_backend_service" "${slug}_backend" {
  name                  = "${config.name}-backend"
  protocol              = "${config.protocol}"
  port_name             = "http"
  load_balancing_scheme = "${String(config.lbType).startsWith("INTERNAL") ? "INTERNAL_MANAGED" : "EXTERNAL_MANAGED"}"
  session_affinity      = "${config.sessionAffinity}"
  health_checks         = [google_compute_health_check.${slug}_hc.id]
  ${config.cloudArmor ? "security_policy       = google_compute_security_policy.cloud_armor_policy.id" : ""}
}

resource "google_compute_global_forwarding_rule" "${slug}" {
  name       = "${config.name}"
  port_range = "${config.port}"
  target     = google_compute_target_http_proxy.${slug}_proxy.id
}`,
    estimateMonthlyCost: () => 18,
    troubleshooting: [
      { issue: "Backend shows UNHEALTHY", cause: "Health check path returns non-200 or firewall blocks the health-check IP ranges", fix: "Allow ingress from 130.211.0.0/22 and 35.191.0.0/16, and verify the app responds 200 on the health check path." },
      { issue: "502 Server Error from the LB", cause: "All backends are unhealthy or backend timeout exceeded", fix: "Check instance health, increase backend timeout, verify the app is listening on the configured port." },
    ],
    quiz: [
      {
        question: "Which GCP firewall source ranges must be allowed for HTTP(S) load balancer health checks?",
        options: ["10.0.0.0/8", "130.211.0.0/22 and 35.191.0.0/16", "0.0.0.0/0", "192.168.0.0/16"],
        answerIndex: 1,
        explanation: "Google's health check probes originate from these two documented ranges.",
      },
    ],
    validConnectionTargets: ["vm", "mig", "gke"],
  },
  {
    type: "router",
    label: "Cloud Router",
    shortLabel: "Router",
    category: "networking",
    color: "gcp-blue",
    description: "A regional, fully-distributed BGP router used for dynamic route exchange with on-prem networks and to power Cloud NAT.",
    learningNotes:
      "Cloud Router is a prerequisite for both Cloud NAT and dynamic routing over VPN/Interconnect. It speaks BGP to exchange routes dynamically rather than requiring static routes to be maintained by hand. One Cloud Router exists per region per VPC.",
    tooltip: "Regional BGP router; required for Cloud NAT and dynamic VPN/Interconnect routing.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/router",
    terraformResourceType: "google_compute_router",
    configFields: [
      { key: "name", label: "Router Name", type: "text", required: true, placeholder: "prod-router" },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "asn", label: "BGP ASN", type: "number", min: 64512, max: 65534 },
    ],
    defaultConfig: { name: "prod-router", region: "us-central1", asn: 64514 },
    generateTerraform: ({ slug, config }) => `resource "google_compute_router" "${slug}" {
  name    = "${config.name}"
  region  = "${config.region}"
  network = google_compute_network.prod_vpc.id
  bgp {
    asn = ${config.asn}
  }
}`,
    estimateMonthlyCost: () => 0,
    troubleshooting: [
      { issue: "BGP session not established", cause: "ASN mismatch or interface/peer misconfiguration", fix: "Verify ASN pairing and BGP peer IP addresses on both sides of the session." },
    ],
    quiz: [
      { question: "What protocol does Cloud Router use to exchange routes?", options: ["OSPF", "BGP", "RIP", "EIGRP"], answerIndex: 1, explanation: "Cloud Router is a fully managed BGP speaker." },
    ],
    validConnectionTargets: ["nat", "vpn", "interconnect"],
  },
  {
    type: "nat",
    label: "Cloud NAT",
    shortLabel: "NAT",
    category: "networking",
    color: "gcp-blue",
    description: "Provides outbound-only internet access for instances without external IPs, without exposing them to inbound connections.",
    learningNotes:
      "Cloud NAT is regional and requires a Cloud Router in the same region/VPC. It performs source NAT (SNAT) only — there's no way to initiate inbound connections through it, which is exactly why it's the recommended pattern for private-subnet workloads that need outbound package downloads or API calls.",
    tooltip: "Outbound-only internet access for private instances.",
    docsUrl: "https://cloud.google.com/nat/docs/overview",
    terraformResourceType: "google_compute_router_nat",
    configFields: [
      { key: "name", label: "NAT Gateway Name", type: "text", required: true, placeholder: "prod-nat" },
      { key: "natIpAllocation", label: "IP Allocation", type: "select", options: [{ label: "Auto-allocate", value: "AUTO_ONLY" }, { label: "Manual (reserved IPs)", value: "MANUAL_ONLY" }] },
      { key: "minPortsPerVm", label: "Min Ports Per VM", type: "number", min: 32, max: 65536 },
      { key: "loggingFilter", label: "Logging", type: "select", options: [{ label: "Off", value: "OFF" }, { label: "Errors Only", value: "ERRORS_ONLY" }, { label: "All", value: "ALL" }] },
    ],
    defaultConfig: { name: "prod-nat", natIpAllocation: "AUTO_ONLY", minPortsPerVm: 64, loggingFilter: "ERRORS_ONLY" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_router_nat" "${slug}" {
  name                               = "${config.name}"
  router                             = google_compute_router.prod_router.name
  region                             = google_compute_router.prod_router.region
  nat_ip_allocate_option             = "${config.natIpAllocation}"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  min_ports_per_vm                   = ${config.minPortsPerVm}
  log_config {
    enable = ${config.loggingFilter !== "OFF"}
    filter = "${config.loggingFilter}"
  }
}`,
    estimateMonthlyCost: (c) => 32 + Number(c.minPortsPerVm ?? 64) * 0.01,
    troubleshooting: [
      { issue: "Outbound connections fail intermittently", cause: "NAT port exhaustion under high connection concurrency", fix: "Increase minPortsPerVm or switch to dynamic port allocation." },
      { issue: "New VM in subnet still has no internet", cause: "NAT source range doesn't include that subnet", fix: "Set NAT to cover ALL_SUBNETWORKS_ALL_IP_RANGES or explicitly add the subnet." },
    ],
    quiz: [
      { question: "Can Cloud NAT be used to allow inbound connections to a private instance?", options: ["Yes, symmetric NAT", "No, it is outbound-only", "Only for TCP", "Only with a static IP"], answerIndex: 1, explanation: "Cloud NAT only performs source NAT for outbound traffic." },
    ],
    validConnectionTargets: [],
  },
  {
    type: "dns",
    label: "Cloud DNS",
    shortLabel: "DNS",
    category: "networking",
    color: "gcp-blue",
    description: "A scalable, reliable, managed authoritative DNS service running on Google's infrastructure.",
    learningNotes:
      "Cloud DNS supports public managed zones (resolvable from the internet) and private managed zones (resolvable only from specified VPCs). 100% uptime SLA is backed by Google's global anycast network. DNSSEC can be enabled per zone to prevent spoofing/cache poisoning.",
    tooltip: "Managed, authoritative DNS for public or private zones.",
    docsUrl: "https://cloud.google.com/dns/docs/overview",
    terraformResourceType: "google_dns_managed_zone",
    configFields: [
      { key: "name", label: "Zone Name", type: "text", required: true, placeholder: "prod-zone" },
      { key: "dnsName", label: "DNS Name (FQDN)", type: "text", placeholder: "example.com." },
      { key: "visibility", label: "Visibility", type: "select", options: [{ label: "Public", value: "public" }, { label: "Private", value: "private" }] },
      { key: "dnssec", label: "Enable DNSSEC", type: "boolean" },
    ],
    defaultConfig: { name: "prod-zone", dnsName: "example.com.", visibility: "public", dnssec: true },
    generateTerraform: ({ slug, config }) => `resource "google_dns_managed_zone" "${slug}" {
  name       = "${config.name}"
  dns_name   = "${config.dnsName}"
  visibility = "${config.visibility}"
  dnssec_config {
    state = "${config.dnssec ? "on" : "off"}"
  }
}`,
    estimateMonthlyCost: () => 0.4,
    troubleshooting: [
      { issue: "Domain doesn't resolve", cause: "Registrar's nameservers not updated to Cloud DNS NS records", fix: "Copy the zone's NS records into your domain registrar's nameserver settings." },
    ],
    quiz: [
      { question: "What determines whether a Cloud DNS zone is resolvable only within your VPCs?", options: ["Zone TTL", "Visibility setting (private vs public)", "DNSSEC", "Record type"], answerIndex: 1, explanation: "Private zones resolve only within specified VPC networks." },
    ],
    validConnectionTargets: ["lb"],
  },
  {
    type: "vpn",
    label: "Cloud VPN",
    shortLabel: "VPN",
    category: "networking",
    color: "gcp-blue",
    description: "Securely connects your on-premises network to your VPC through an IPsec VPN tunnel over the public internet.",
    learningNotes:
      "HA VPN provides a 99.99% SLA when configured with two interfaces/tunnels to a peer. Classic VPN (single tunnel, single external IP) only offers 99.9%. Cloud VPN encrypts traffic but rides over the public internet, unlike Interconnect which uses private connectivity.",
    tooltip: "Encrypted IPsec tunnel to on-prem or another cloud.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/vpn",
    terraformResourceType: "google_compute_vpn_gateway",
    configFields: [
      { key: "name", label: "Gateway Name", type: "text", required: true, placeholder: "prod-vpn" },
      { key: "vpnType", label: "Type", type: "select", options: [{ label: "HA VPN (99.99% SLA)", value: "HA" }, { label: "Classic VPN (99.9% SLA)", value: "CLASSIC" }] },
      { key: "peerIp", label: "Peer Gateway IP", type: "text", placeholder: "203.0.113.1" },
      { key: "sharedSecret", label: "Shared Secret", type: "text", placeholder: "••••••••" },
    ],
    defaultConfig: { name: "prod-vpn", vpnType: "HA", peerIp: "203.0.113.1", sharedSecret: "" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_ha_vpn_gateway" "${slug}" {
  name    = "${config.name}"
  network = google_compute_network.prod_vpc.id
}

resource "google_compute_external_vpn_gateway" "${slug}_peer" {
  name            = "${config.name}-peer"
  redundancy_type = "SINGLE_IP_INTERNALLY_REDUNDANT"
  interface {
    id         = 0
    ip_address = "${config.peerIp}"
  }
}`,
    estimateMonthlyCost: () => 36,
    troubleshooting: [
      { issue: "Tunnel status stuck at 'FIRST_HANDSHAKE'", cause: "Shared secret or peer IP mismatch", fix: "Verify identical pre-shared keys and correct peer gateway IP on both ends." },
    ],
    quiz: [
      { question: "Which Cloud VPN mode offers a 99.99% availability SLA?", options: ["Classic VPN", "HA VPN with two tunnels", "Any VPN with a static route", "Cloud NAT"], answerIndex: 1, explanation: "HA VPN with redundant tunnels/interfaces provides the 99.99% SLA." },
    ],
    validConnectionTargets: ["router"],
  },
  {
    type: "interconnect",
    label: "Dedicated Interconnect",
    shortLabel: "Interconnect",
    category: "networking",
    color: "gcp-blue",
    description: "A private, physical connection between your on-premises network and Google's network — bypassing the public internet entirely.",
    learningNotes:
      "Interconnect offers higher throughput (10/100 Gbps circuits) and lower, more predictable latency than VPN since it never traverses the public internet. Partner Interconnect is available when a direct physical presence in a colocation facility isn't feasible. Combine with Cloud Router for dynamic BGP routing across the link.",
    tooltip: "Private physical link to Google's network, bypassing the internet.",
    docsUrl: "https://cloud.google.com/network-connectivity/docs/interconnect",
    terraformResourceType: "google_compute_interconnect_attachment",
    configFields: [
      { key: "name", label: "Attachment Name", type: "text", required: true, placeholder: "prod-interconnect" },
      { key: "type", label: "Type", type: "select", options: [{ label: "Dedicated", value: "DEDICATED" }, { label: "Partner", value: "PARTNER" }] },
      { key: "bandwidth", label: "Bandwidth", type: "select", options: [{ label: "10 Gbps", value: "BPS_10G" }, { label: "50 Gbps", value: "BPS_50G" }, { label: "100 Gbps", value: "BPS_100G" }] },
    ],
    defaultConfig: { name: "prod-interconnect", type: "DEDICATED", bandwidth: "BPS_10G" },
    generateTerraform: ({ slug, config }) => `resource "google_compute_interconnect_attachment" "${slug}" {
  name                     = "${config.name}"
  type                     = "${config.type}"
  router                   = google_compute_router.prod_router.id
  bandwidth                = "${config.bandwidth}"
}`,
    estimateMonthlyCost: () => 1700,
    troubleshooting: [
      { issue: "Attachment stuck PENDING_CUSTOMER", cause: "LOA-CFA not completed with the colocation provider", fix: "Complete the Letter of Authorization / Connecting Facility Assignment with your provider." },
    ],
    quiz: [
      { question: "What is the main advantage of Dedicated Interconnect over Cloud VPN?", options: ["Cheaper for low bandwidth", "Bypasses the public internet with dedicated bandwidth", "No need for a Cloud Router", "Works over Wi-Fi"], answerIndex: 1, explanation: "Interconnect is a private physical link, avoiding public internet transit." },
    ],
    validConnectionTargets: ["router"],
  },
];

import { GcpResourceDef } from "@/types/gcp";

export const storageResources: GcpResourceDef[] = [
  {
    type: "gcs",
    label: "Cloud Storage",
    shortLabel: "GCS",
    category: "storage",
    color: "gcp-yellow",
    description: "Unified object storage for unstructured data — from serving static websites to storing backups and ML training data.",
    learningNotes:
      "Storage classes trade access frequency for price: Standard for hot data, Nearline (30-day minimum) for monthly access, Coldline (90-day) for quarterly, and Archive (365-day) for long-term retention. Lifecycle rules automate transitions between classes or deletion. Uniform bucket-level access (recommended) applies IAM consistently instead of mixing in legacy ACLs. Versioning protects against accidental overwrite/delete.",
    tooltip: "Object storage bucket for files, backups, and static assets.",
    docsUrl: "https://cloud.google.com/storage/docs/introduction",
    terraformResourceType: "google_storage_bucket",
    configFields: [
      { key: "name", label: "Bucket Name (globally unique)", type: "text", required: true, placeholder: "my-app-assets-prod" },
      { key: "location", label: "Location", type: "select", options: [{ label: "US (multi-region)", value: "US" }, { label: "EU (multi-region)", value: "EU" }, { label: "us-central1", value: "us-central1" }, { label: "asia-south1", value: "asia-south1" }] },
      { key: "storageClass", label: "Storage Class", type: "select", options: [{ label: "Standard", value: "STANDARD" }, { label: "Nearline", value: "NEARLINE" }, { label: "Coldline", value: "COLDLINE" }, { label: "Archive", value: "ARCHIVE" }] },
      { key: "access", label: "Access", type: "select", options: [{ label: "Private", value: "private" }, { label: "Public Read", value: "public" }] },
      { key: "versioning", label: "Enable Versioning", type: "boolean" },
      { key: "lifecycleDays", label: "Delete Objects After (days, 0 = never)", type: "number", min: 0, max: 3650 },
      { key: "uniformAccess", label: "Uniform Bucket-Level Access", type: "boolean" },
    ],
    defaultConfig: { name: "my-app-assets-prod", location: "US", storageClass: "STANDARD", access: "private", versioning: true, lifecycleDays: 365, uniformAccess: true },
    generateTerraform: ({ slug, config }) => `resource "google_storage_bucket" "${slug}" {
  name                        = "${config.name}"
  location                    = "${config.location}"
  storage_class               = "${config.storageClass}"
  uniform_bucket_level_access = ${config.uniformAccess}

  versioning {
    enabled = ${config.versioning}
  }

  ${
    Number(config.lifecycleDays) > 0
      ? `lifecycle_rule {
    condition { age = ${config.lifecycleDays} }
    action    { type = "Delete" }
  }`
      : ""
  }
}
${
  config.access === "public"
    ? `
resource "google_storage_bucket_iam_member" "${slug}_public" {
  bucket = google_storage_bucket.${slug}.name
  role   = "roles/storage.objectViewer"
  member = "allUsers"
}`
    : ""
}`,
    estimateMonthlyCost: () => 2.3,
    troubleshooting: [
      { issue: "403 Forbidden when downloading a public asset", cause: "Bucket/object still private, or org policy blocks public access", fix: "Grant roles/storage.objectViewer to allUsers, and check the domain-restricted-sharing org policy." },
      { issue: "Old data won't delete automatically", cause: "No lifecycle rule configured", fix: "Add a lifecycle rule with an age condition and a Delete or SetStorageClass action." },
    ],
    quiz: [
      { question: "Which storage class is cheapest for data accessed roughly once a year?", options: ["Standard", "Nearline", "Coldline", "Archive"], answerIndex: 3, explanation: "Archive class is optimized for data touched less than once a year, with the lowest storage price and a 365-day minimum." },
    ],
    validConnectionTargets: [],
  },
];

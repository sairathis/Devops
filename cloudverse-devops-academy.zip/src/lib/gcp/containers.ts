import { GcpResourceDef } from "@/types/gcp";

export const containerResources: GcpResourceDef[] = [
  {
    type: "gke",
    label: "GKE Cluster",
    shortLabel: "GKE",
    category: "containers",
    color: "gcp-green",
    description: "A managed Kubernetes cluster for deploying, managing, and scaling containerized applications.",
    learningNotes:
      "Autopilot mode manages nodes for you (pay per pod resource requests) and is recommended for most teams; Standard mode gives full node-pool control. Private clusters keep node IPs internal-only, reducing attack surface — access the control plane via an authorized network or a bastion. Workload Identity is the recommended way for pods to authenticate to GCP APIs, replacing node-level service account keys.",
    tooltip: "Managed Kubernetes for container workloads.",
    docsUrl: "https://cloud.google.com/kubernetes-engine/docs/concepts/kubernetes-engine-overview",
    terraformResourceType: "google_container_cluster",
    configFields: [
      { key: "name", label: "Cluster Name", type: "text", required: true, placeholder: "prod-gke" },
      { key: "mode", label: "Mode", type: "select", options: [{ label: "Autopilot (recommended)", value: "autopilot" }, { label: "Standard", value: "standard" }] },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "nodeCount", label: "Nodes per Zone (Standard only)", type: "number", min: 1, max: 20 },
      { key: "privateCluster", label: "Private Cluster", type: "boolean" },
      { key: "workloadIdentity", label: "Enable Workload Identity", type: "boolean" },
      { key: "release_channel", label: "Release Channel", type: "select", options: [{ label: "Rapid", value: "RAPID" }, { label: "Regular", value: "REGULAR" }, { label: "Stable", value: "STABLE" }] },
    ],
    defaultConfig: { name: "prod-gke", mode: "autopilot", region: "us-central1", nodeCount: 3, privateCluster: true, workloadIdentity: true, release_channel: "REGULAR" },
    generateTerraform: ({ slug, config }) => `resource "google_container_cluster" "${slug}" {
  name             = "${config.name}"
  location         = "${config.region}"
  enable_autopilot = ${config.mode === "autopilot"}
  ${config.mode !== "autopilot" ? `initial_node_count       = ${config.nodeCount}\n  remove_default_node_pool = true` : ""}

  release_channel {
    channel = "${config.release_channel}"
  }

  ${
    config.privateCluster
      ? `private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }`
      : ""
  }

  ${config.workloadIdentity ? `workload_identity_config {\n    workload_pool = "\${var.project_id}.svc.id.goog"\n  }` : ""}

  network    = google_compute_network.prod_vpc.id
  subnetwork = google_compute_subnetwork.public_subnet_1.id
}`,
    estimateMonthlyCost: (c) => (c.mode === "autopilot" ? 74 : 74 + Number(c.nodeCount ?? 3) * 24),
    troubleshooting: [
      { issue: "kubectl can't reach the cluster", cause: "Private cluster endpoint not authorized for your source IP", fix: "Add your IP to the cluster's master authorized networks, or connect via a bastion/Cloud Shell." },
      { issue: "Pods stuck in Pending", cause: "Insufficient node capacity or unsatisfiable resource requests", fix: "Scale the node pool, or, on Autopilot, adjust the pod's resource requests to a supported compute class." },
    ],
    quiz: [
      { question: "Which GKE feature lets pods authenticate to Google Cloud APIs without node-level service account keys?", options: ["Cloud IAP", "Workload Identity", "Cloud Armor", "Binary Authorization"], answerIndex: 1, explanation: "Workload Identity maps Kubernetes service accounts to IAM service accounts securely." },
    ],
    validConnectionTargets: ["cloudsql", "redis", "artifact_registry", "pubsub"],
  },
];

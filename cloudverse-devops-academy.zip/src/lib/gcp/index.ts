import { GcpResourceDef, ResourceCategory } from "@/types/gcp";
import { networkingResources } from "./networking";
import { securityResources } from "./security";
import { computeResources } from "./compute";
import { containerResources } from "./containers";
import { storageResources } from "./storage";
import { databaseResources } from "./database";
import { cicdResources } from "./cicd";
import { messagingResources } from "./messaging";

export const GCP_RESOURCES: GcpResourceDef[] = [
  ...networkingResources,
  ...securityResources,
  ...computeResources,
  ...containerResources,
  ...storageResources,
  ...databaseResources,
  ...cicdResources,
  ...messagingResources,
];

export const GCP_RESOURCE_MAP: Record<string, GcpResourceDef> = Object.fromEntries(
  GCP_RESOURCES.map((r) => [r.type, r]),
);

export function getResourceDef(type: string): GcpResourceDef | undefined {
  return GCP_RESOURCE_MAP[type];
}

export function resourcesByCategory(category: ResourceCategory): GcpResourceDef[] {
  return GCP_RESOURCES.filter((r) => r.category === category);
}

export * from "./networking";
export * from "./security";
export * from "./compute";
export * from "./containers";
export * from "./storage";
export * from "./database";
export * from "./cicd";
export * from "./messaging";

import { GcpResourceDef } from "@/types/gcp";

export const messagingResources: GcpResourceDef[] = [
  {
    type: "pubsub",
    label: "Pub/Sub",
    shortLabel: "Pub/Sub",
    category: "messaging",
    color: "gcp-yellow",
    description: "A fully managed, asynchronous messaging service for decoupling producers and consumers at global scale.",
    learningNotes:
      "Pub/Sub decouples services: producers publish to a topic without knowing who (or how many) subscribers exist. Push subscriptions deliver to an HTTP(S) endpoint (e.g. Cloud Run); pull subscriptions let a consumer fetch messages at its own pace. Set an appropriate acknowledgement deadline and dead-letter topic to handle poison messages gracefully.",
    tooltip: "Asynchronous, decoupled messaging between services.",
    docsUrl: "https://cloud.google.com/pubsub/docs/overview",
    terraformResourceType: "google_pubsub_topic",
    configFields: [
      { key: "name", label: "Topic Name", type: "text", required: true, placeholder: "order-events" },
      { key: "subscriptionType", label: "Subscription Type", type: "select", options: [{ label: "Pull", value: "pull" }, { label: "Push", value: "push" }] },
      { key: "ackDeadlineSeconds", label: "Ack Deadline (seconds)", type: "number", min: 10, max: 600 },
      { key: "messageRetentionDays", label: "Message Retention (days)", type: "number", min: 1, max: 31 },
      { key: "deadLetterEnabled", label: "Enable Dead-Letter Topic", type: "boolean" },
    ],
    defaultConfig: { name: "order-events", subscriptionType: "pull", ackDeadlineSeconds: 30, messageRetentionDays: 7, deadLetterEnabled: true },
    generateTerraform: ({ slug, config }) => `resource "google_pubsub_topic" "${slug}" {
  name                       = "${config.name}"
  message_retention_duration = "${Number(config.messageRetentionDays) * 86400}s"
}

resource "google_pubsub_subscription" "${slug}_sub" {
  name  = "${config.name}-sub"
  topic = google_pubsub_topic.${slug}.name

  ack_deadline_seconds = ${config.ackDeadlineSeconds}

  ${
    config.subscriptionType === "push"
      ? `push_config {
    push_endpoint = "https://example.com/pubsub/push"
  }`
      : ""
  }

  ${
    config.deadLetterEnabled
      ? `dead_letter_policy {
    dead_letter_topic     = google_pubsub_topic.${slug}_dlq.id
    max_delivery_attempts = 5
  }`
      : ""
  }
}
${config.deadLetterEnabled ? `\nresource "google_pubsub_topic" "${slug}_dlq" {\n  name = "${config.name}-dlq"\n}` : ""}`,
    estimateMonthlyCost: () => 4,
    troubleshooting: [
      { issue: "Messages redelivered repeatedly", cause: "Consumer doesn't ack within the deadline (too short for processing time)", fix: "Increase ackDeadlineSeconds or use ack extension (modifyAckDeadline) during long processing." },
      { issue: "Push subscription gets no traffic", cause: "Push endpoint unreachable or missing OIDC auth token verification", fix: "Verify the endpoint is publicly reachable and configure push auth with a service account." },
    ],
    quiz: [
      { question: "What is the purpose of a dead-letter topic in Pub/Sub?", options: ["To store all messages permanently", "To capture messages that repeatedly fail delivery", "To increase throughput", "To encrypt messages"], answerIndex: 1, explanation: "Dead-letter topics catch messages that exceed max delivery attempts, preventing infinite redelivery loops." },
    ],
    validConnectionTargets: ["vm", "mig", "gke", "cloud_build"],
  },
];

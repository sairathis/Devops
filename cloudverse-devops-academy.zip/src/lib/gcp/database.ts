import { GcpResourceDef } from "@/types/gcp";

const TIER_COST: Record<string, number> = {
  "db-f1-micro": 9, "db-g1-small": 27, "db-custom-2-8192": 130, "db-custom-4-16384": 260,
};

export const databaseResources: GcpResourceDef[] = [
  {
    type: "cloudsql",
    label: "Cloud SQL",
    shortLabel: "Cloud SQL",
    category: "database",
    color: "gcp-red",
    description: "Fully managed relational database service for PostgreSQL, MySQL, and SQL Server with automated backups and failover.",
    learningNotes:
      "Enabling high availability creates a synchronously-replicated standby in a different zone; on failure, GCP automatically fails over and repoints the instance's IP. Read replicas (asynchronous) scale read-heavy workloads but are not a substitute for HA. Always require SSL/mTLS for connections and prefer Private Service Connect / private IP over exposing a public IP.",
    tooltip: "Managed PostgreSQL, MySQL, or SQL Server.",
    docsUrl: "https://cloud.google.com/sql/docs/introduction",
    terraformResourceType: "google_sql_database_instance",
    configFields: [
      { key: "name", label: "Instance Name", type: "text", required: true, placeholder: "prod-db" },
      { key: "engine", label: "Database Engine", type: "select", options: [{ label: "PostgreSQL 15", value: "POSTGRES_15" }, { label: "MySQL 8.0", value: "MYSQL_8_0" }, { label: "SQL Server 2022", value: "SQLSERVER_2022_STANDARD" }] },
      { key: "tier", label: "Machine Tier", type: "select", options: Object.keys(TIER_COST).map((t) => ({ label: t, value: t })) },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "highAvailability", label: "Enable High Availability (standby)", type: "boolean" },
      { key: "backupEnabled", label: "Automated Backups", type: "boolean" },
      { key: "publicIp", label: "Assign Public IP", type: "boolean" },
      { key: "storageGb", label: "Storage (GB)", type: "number", min: 10, max: 65536 },
    ],
    defaultConfig: { name: "prod-db", engine: "POSTGRES_15", tier: "db-custom-2-8192", region: "us-central1", highAvailability: true, backupEnabled: true, publicIp: false, storageGb: 100 },
    generateTerraform: ({ slug, config }) => `resource "google_sql_database_instance" "${slug}" {
  name             = "${config.name}"
  database_version = "${config.engine}"
  region           = "${config.region}"

  settings {
    tier              = "${config.tier}"
    availability_type = "${config.highAvailability ? "REGIONAL" : "ZONAL"}"
    disk_size         = ${config.storageGb}
    disk_autoresize   = true

    backup_configuration {
      enabled                        = ${config.backupEnabled}
      point_in_time_recovery_enabled = ${config.backupEnabled}
    }

    ip_configuration {
      ipv4_enabled    = ${config.publicIp}
      private_network = google_compute_network.prod_vpc.id
      require_ssl     = true
    }
  }

  deletion_protection = true
}`,
    estimateMonthlyCost: (c) => (TIER_COST[c.tier as string] ?? 130) * (c.highAvailability ? 2 : 1),
    troubleshooting: [
      { issue: "Application can't connect to the database", cause: "Missing private services access / VPC peering for private IP, or SSL required but not configured client-side", fix: "Set up Service Networking peering for private IP and configure the client to use SSL certs." },
      { issue: "Failover takes longer than expected", cause: "Instance is ZONAL, not REGIONAL (HA)", fix: "Set availability_type to REGIONAL to enable automatic failover to a standby." },
    ],
    quiz: [
      { question: "What does enabling High Availability actually create in Cloud SQL?", options: ["A read replica in another region", "A synchronous standby in a different zone", "An automatic backup every hour", "A CDN cache layer"], answerIndex: 1, explanation: "HA (REGIONAL availability) provisions a synchronously replicated standby for automatic failover." },
    ],
    validConnectionTargets: [],
  },
  {
    type: "redis",
    label: "Memorystore (Redis)",
    shortLabel: "Redis",
    category: "database",
    color: "gcp-red",
    description: "A fully managed, in-memory Redis service for caching, session storage, and low-latency data access.",
    learningNotes:
      "Basic tier Memorystore runs a single node with no failover — good for caches that can be rebuilt. Standard tier adds a replica with automatic failover for higher availability. Memorystore instances live inside your VPC via private service access, so they're never reachable from the public internet.",
    tooltip: "Managed in-memory Redis cache.",
    docsUrl: "https://cloud.google.com/memorystore/docs/redis/redis-overview",
    terraformResourceType: "google_redis_instance",
    configFields: [
      { key: "name", label: "Instance Name", type: "text", required: true, placeholder: "app-cache" },
      { key: "tier", label: "Tier", type: "select", options: [{ label: "Basic", value: "BASIC" }, { label: "Standard HA", value: "STANDARD_HA" }] },
      { key: "memorySizeGb", label: "Memory (GB)", type: "number", min: 1, max: 300 },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "redisVersion", label: "Redis Version", type: "select", options: [{ label: "7.2", value: "REDIS_7_2" }, { label: "6.x", value: "REDIS_6_X" }] },
    ],
    defaultConfig: { name: "app-cache", tier: "STANDARD_HA", memorySizeGb: 4, region: "us-central1", redisVersion: "REDIS_7_2" },
    generateTerraform: ({ slug, config }) => `resource "google_redis_instance" "${slug}" {
  name           = "${config.name}"
  tier           = "${config.tier}"
  memory_size_gb = ${config.memorySizeGb}
  region         = "${config.region}"
  redis_version  = "${config.redisVersion}"
  authorized_network = google_compute_network.prod_vpc.id
}`,
    estimateMonthlyCost: (c) => Number(c.memorySizeGb ?? 4) * (c.tier === "STANDARD_HA" ? 49 : 27),
    troubleshooting: [
      { issue: "Cache misses spike after a deploy", cause: "Instance restarted/failed over and lost in-memory data", fix: "Treat Redis as a cache, not a source of truth; ensure the app can rebuild cache entries on miss." },
      { issue: "App can't connect to Memorystore", cause: "App running outside the VPC/region, or missing VPC connector (serverless)", fix: "Use a Serverless VPC Access connector or run the app inside the same VPC." },
    ],
    quiz: [
      { question: "Why is Memorystore for Redis never reachable from the public internet?", options: ["It uses IAM auth", "It's only accessible via private IP inside your VPC", "It requires a VPN always", "It's a REST API"], answerIndex: 1, explanation: "Memorystore instances are provisioned with a private IP inside your authorized VPC network only." },
    ],
    validConnectionTargets: [],
  },
];

import { GcpResourceDef } from "@/types/gcp";

export const cicdResources: GcpResourceDef[] = [
  {
    type: "artifact_registry",
    label: "Artifact Registry",
    shortLabel: "Registry",
    category: "cicd",
    color: "gcp-blue",
    description: "A universal package manager for container images, language packages, and other build artifacts.",
    learningNotes:
      "Artifact Registry is the successor to Container Registry and supports multiple formats (Docker, Maven, npm, Python, Go) in a single service, with per-repository IAM and optional vulnerability scanning. Regional repositories reduce pull latency and egress cost for GKE clusters in the same region.",
    tooltip: "Managed registry for container images and packages.",
    docsUrl: "https://cloud.google.com/artifact-registry/docs/overview",
    terraformResourceType: "google_artifact_registry_repository",
    configFields: [
      { key: "name", label: "Repository Name", type: "text", required: true, placeholder: "app-images" },
      { key: "format", label: "Format", type: "select", options: [{ label: "Docker", value: "DOCKER" }, { label: "npm", value: "NPM" }, { label: "Maven", value: "MAVEN" }, { label: "Python", value: "PYTHON" }] },
      { key: "region", label: "Region", type: "select", options: [{ label: "us-central1", value: "us-central1" }, { label: "europe-west1", value: "europe-west1" }] },
      { key: "vulnerabilityScanning", label: "Enable Vulnerability Scanning", type: "boolean" },
      { key: "immutableTags", label: "Immutable Tags", type: "boolean" },
    ],
    defaultConfig: { name: "app-images", format: "DOCKER", region: "us-central1", vulnerabilityScanning: true, immutableTags: true },
    generateTerraform: ({ slug, config }) => `resource "google_artifact_registry_repository" "${slug}" {
  location      = "${config.region}"
  repository_id = "${config.name}"
  format        = "${config.format}"
  docker_config {
    immutable_tags = ${config.immutableTags}
  }
}`,
    estimateMonthlyCost: () => 5,
    troubleshooting: [
      { issue: "docker push denied: permission error", cause: "Missing roles/artifactregistry.writer on the CI service account", fix: "Grant the CI/CD service account the Artifact Registry Writer role on the repository." },
    ],
    quiz: [
      { question: "What did Artifact Registry replace?", options: ["Cloud Source Repositories", "Container Registry (GCR)", "Cloud Build", "Cloud Storage"], answerIndex: 1, explanation: "Artifact Registry is Google's next-gen replacement for the older Container Registry." },
    ],
    validConnectionTargets: ["gke", "mig"],
  },
  {
    type: "cloud_build",
    label: "Cloud Build",
    shortLabel: "Build",
    category: "cicd",
    color: "gcp-blue",
    description: "A serverless CI/CD platform that executes builds as a series of containerized steps, triggered by source changes.",
    learningNotes:
      "Cloud Build triggers can fire on a push, pull request, or tag to a connected repo (GitHub, GitLab, Cloud Source Repositories). Each build step runs in its own container, chaining together via a shared workspace volume — enabling build, test, containerize, and deploy in one pipeline defined in cloudbuild.yaml.",
    tooltip: "Serverless CI/CD pipeline runner.",
    docsUrl: "https://cloud.google.com/build/docs/overview",
    terraformResourceType: "google_cloudbuild_trigger",
    configFields: [
      { key: "name", label: "Trigger Name", type: "text", required: true, placeholder: "deploy-on-push" },
      { key: "repoOwner", label: "Repository Owner", type: "text", placeholder: "my-org" },
      { key: "repoName", label: "Repository Name", type: "text", placeholder: "my-app" },
      { key: "branchPattern", label: "Branch Pattern", type: "text", placeholder: "^main$" },
      { key: "deployTarget", label: "Deploy Target", type: "select", options: [{ label: "GKE", value: "gke" }, { label: "Cloud Run", value: "cloud_run" }, { label: "MIG (rolling update)", value: "mig" }] },
    ],
    defaultConfig: { name: "deploy-on-push", repoOwner: "my-org", repoName: "my-app", branchPattern: "^main$", deployTarget: "gke" },
    generateTerraform: ({ slug, config }) => `resource "google_cloudbuild_trigger" "${slug}" {
  name = "${config.name}"

  github {
    owner = "${config.repoOwner}"
    name  = "${config.repoName}"
    push {
      branch = "${config.branchPattern}"
    }
  }

  filename = "cloudbuild.yaml"
}`,
    estimateMonthlyCost: () => 3,
    troubleshooting: [
      { issue: "Trigger doesn't fire on push", cause: "GitHub app not installed/authorized for the repo, or branch pattern mismatch", fix: "Reconnect the repository via the Cloud Build GitHub App and verify the regex branch pattern." },
      { issue: "Build fails at the deploy step", cause: "Cloud Build service account lacks IAM permissions on the target (e.g. GKE)", fix: "Grant roles/container.developer (or equivalent) to the Cloud Build service account." },
    ],
    quiz: [
      { question: "How are Cloud Build pipeline steps typically defined?", options: ["A Jenkinsfile", "cloudbuild.yaml with containerized steps", "A Dockerfile only", "A Terraform module"], answerIndex: 1, explanation: "Cloud Build pipelines are defined in cloudbuild.yaml, with each step running in its own container." },
    ],
    validConnectionTargets: ["artifact_registry", "gke", "mig"],
  },
];

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface ModuleProgress {
  moduleId: string;
  percent: number;
  xp: number;
  lastVisited: string;
}

export interface Badge {
  id: string;
  label: string;
  description: string;
  icon: string;
  earnedAt: string;
}

interface ProgressState {
  modules: Record<string, ModuleProgress>;
  totalXp: number;
  level: number;
  badges: Badge[];
  streakDays: number;
  lastActiveDate: string | null;
  quizScores: Record<string, { correct: number; total: number }>;
  setModuleProgress: (moduleId: string, percent: number) => void;
  addXp: (amount: number) => void;
  awardBadge: (badge: Omit<Badge, "earnedAt">) => void;
  recordQuizResult: (topic: string, correct: number, total: number) => void;
  touchStreak: () => void;
  resetProgress: () => void;
}

const LEVEL_XP = 500;

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      modules: {},
      totalXp: 0,
      level: 1,
      badges: [],
      streakDays: 1,
      lastActiveDate: null,
      quizScores: {},

      setModuleProgress: (moduleId, percent) => {
        set({
          modules: {
            ...get().modules,
            [moduleId]: {
              moduleId,
              percent: Math.max(percent, get().modules[moduleId]?.percent ?? 0),
              xp: get().modules[moduleId]?.xp ?? 0,
              lastVisited: new Date().toISOString(),
            },
          },
        });
      },

      addXp: (amount) => {
        const newXp = get().totalXp + amount;
        set({ totalXp: newXp, level: Math.max(1, Math.floor(newXp / LEVEL_XP) + 1) });
      },

      awardBadge: (badge) => {
        if (get().badges.some((b) => b.id === badge.id)) return;
        set({ badges: [...get().badges, { ...badge, earnedAt: new Date().toISOString() }] });
      },

      recordQuizResult: (topic, correct, total) => {
        const prev = get().quizScores[topic] ?? { correct: 0, total: 0 };
        set({
          quizScores: {
            ...get().quizScores,
            [topic]: { correct: prev.correct + correct, total: prev.total + total },
          },
        });
      },

      touchStreak: () => {
        const today = new Date().toDateString();
        const last = get().lastActiveDate;
        if (last === today) return;
        const yesterday = new Date(Date.now() - 86400000).toDateString();
        set({
          streakDays: last === yesterday ? get().streakDays + 1 : 1,
          lastActiveDate: today,
        });
      },

      resetProgress: () =>
        set({ modules: {}, totalXp: 0, level: 1, badges: [], streakDays: 1, lastActiveDate: null, quizScores: {} }),
    }),
    { name: "cloudverse-progress-store" },
  ),
);

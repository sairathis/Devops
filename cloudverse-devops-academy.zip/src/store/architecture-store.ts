import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Edge, Node } from "reactflow";
import { CanvasNodeData, ResourceConfig } from "@/types/gcp";
import { getResourceDef } from "@/lib/gcp";
import { randomId, slugify } from "@/lib/utils";

export type ArchNode = Node<CanvasNodeData>;

interface Project {
  id: string;
  name: string;
  updatedAt: string;
  nodes: ArchNode[];
  edges: Edge[];
}

interface ArchitectureState {
  projects: Project[];
  activeProjectId: string;
  nodes: ArchNode[];
  edges: Edge[];
  selectedNodeId: string | null;
  simulationRunning: boolean;
  addNode: (resourceType: string, position: { x: number; y: number }) => string;
  updateNodeConfig: (nodeId: string, config: Partial<ResourceConfig>) => void;
  removeNode: (nodeId: string) => void;
  setNodes: (nodes: ArchNode[]) => void;
  setEdges: (edges: Edge[]) => void;
  addEdge: (edge: Edge) => void;
  selectNode: (nodeId: string | null) => void;
  clearCanvas: () => void;
  loadExample: (nodes: ArchNode[], edges: Edge[]) => void;
  setSimulationRunning: (running: boolean) => void;
  saveProject: (name: string) => void;
  loadProject: (id: string) => void;
  deleteProject: (id: string) => void;
}

export const useArchitectureStore = create<ArchitectureState>()(
  persist(
    (set, get) => ({
      projects: [],
      activeProjectId: "draft",
      nodes: [],
      edges: [],
      selectedNodeId: null,
      simulationRunning: false,

      addNode: (resourceType, position) => {
        const def = getResourceDef(resourceType);
        if (!def) return "";
        const existingCount = get().nodes.filter((n) => n.data.resourceType === resourceType).length;
        const id = randomId(slugify(resourceType));
        const label = existingCount > 0 ? `${def.label} ${existingCount + 1}` : def.label;
        const node: ArchNode = {
          id,
          type: "gcpNode",
          position,
          data: { resourceType, label, config: { ...def.defaultConfig, name: slugify(label) } },
        };
        set({ nodes: [...get().nodes, node], selectedNodeId: id });
        return id;
      },

      updateNodeConfig: (nodeId, config) => {
        set({
          nodes: get().nodes.map((n) =>
            n.id === nodeId
            ? { ...n, data: { ...n.data, config: { ...n.data.config, ...config } as ResourceConfig } }
            : n,
          ),
        });
      },

      removeNode: (nodeId) => {
        set({
          nodes: get().nodes.filter((n) => n.id !== nodeId),
          edges: get().edges.filter((e) => e.source !== nodeId && e.target !== nodeId),
          selectedNodeId: get().selectedNodeId === nodeId ? null : get().selectedNodeId,
        });
      },

      setNodes: (nodes) => set({ nodes }),
      setEdges: (edges) => set({ edges }),
      addEdge: (edge) => set({ edges: [...get().edges, edge] }),
      selectNode: (nodeId) => set({ selectedNodeId: nodeId }),
      clearCanvas: () => set({ nodes: [], edges: [], selectedNodeId: null }),
      loadExample: (nodes, edges) => set({ nodes, edges, selectedNodeId: null }),
      setSimulationRunning: (running) => set({ simulationRunning: running }),

      saveProject: (name) => {
        const { nodes, edges, projects } = get();
        const id = randomId("project");
        const project: Project = { id, name, updatedAt: new Date().toISOString(), nodes, edges };
        set({ projects: [...projects, project], activeProjectId: id });
      },

      loadProject: (id) => {
        const project = get().projects.find((p) => p.id === id);
        if (project) set({ nodes: project.nodes, edges: project.edges, activeProjectId: id });
      },

      deleteProject: (id) => {
        set({ projects: get().projects.filter((p) => p.id !== id) });
      },
    }),
    { name: "cloudverse-architecture-store" },
  ),
);

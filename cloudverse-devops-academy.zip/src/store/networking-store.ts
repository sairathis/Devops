import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";

export type TrafficMode = "inbound" | "outbound" | "eastwest" | "lbrouting" | "nat" | "dns";

export interface FirewallRule {
  id: string;
  name: string;
  direction: "INGRESS" | "EGRESS";
  action: "ALLOW" | "DENY";
  protocol: string;
  ports: string;
  range: string;
  priority: number;
  enabled: boolean;
}

const DEFAULT_RULES: FirewallRule[] = [
  { id: "fw-1", name: "allow-https-lb", direction: "INGRESS", action: "ALLOW", protocol: "TCP", ports: "443", range: "0.0.0.0/0", priority: 1000, enabled: true },
  { id: "fw-2", name: "allow-health-checks", direction: "INGRESS", action: "ALLOW", protocol: "TCP", ports: "80,443", range: "130.211.0.0/22,35.191.0.0/16", priority: 1000, enabled: true },
  { id: "fw-3", name: "allow-internal", direction: "INGRESS", action: "ALLOW", protocol: "TCP,UDP,ICMP", ports: "all", range: "10.0.0.0/16", priority: 1000, enabled: true },
  { id: "fw-4", name: "deny-all-ingress", direction: "INGRESS", action: "DENY", protocol: "all", ports: "all", range: "0.0.0.0/0", priority: 65534, enabled: true },
];

interface NetworkingState {
  mode: TrafficMode;
  simulationRunning: boolean;
  speed: number;
  rules: FirewallRule[];
  lbCounter: number;
  setMode: (mode: TrafficMode) => void;
  setSimulationRunning: (running: boolean) => void;
  setSpeed: (speed: number) => void;
  addRule: (rule: Omit<FirewallRule, "id">) => void;
  removeRule: (id: string) => void;
  toggleRule: (id: string) => void;
  resetRules: () => void;
  bumpLbCounter: () => void;
}

export const useNetworkingStore = create<NetworkingState>()(
  persist(
    (set, get) => ({
      mode: "inbound",
      simulationRunning: true,
      speed: 1,
      rules: DEFAULT_RULES,
      lbCounter: 0,
      setMode: (mode) => set({ mode }),
      setSimulationRunning: (running) => set({ simulationRunning: running }),
      setSpeed: (speed) => set({ speed }),
      addRule: (rule) => set({ rules: [...get().rules, { ...rule, id: randomId("fw") }] }),
      removeRule: (id) => set({ rules: get().rules.filter((r) => r.id !== id) }),
      toggleRule: (id) => set({ rules: get().rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)) }),
      resetRules: () => set({ rules: DEFAULT_RULES }),
      bumpLbCounter: () => set({ lbCounter: get().lbCounter + 1 }),
    }),
    { name: "cloudverse-networking-store" },
  ),
);

export function isInboundHttpsAllowed(rules: FirewallRule[]): boolean {
  const sorted = [...rules].filter((r) => r.enabled && r.direction === "INGRESS").sort((a, b) => a.priority - b.priority);
  for (const rule of sorted) {
    const portMatch = rule.ports === "all" || rule.ports.split(",").map((p) => p.trim()).includes("443");
    const protoMatch = rule.protocol === "all" || rule.protocol.toUpperCase().includes("TCP");
    const rangeMatch = rule.range.includes("0.0.0.0/0");
    if (portMatch && protoMatch && rangeMatch) {
      return rule.action === "ALLOW";
    }
  }
  return false;
}

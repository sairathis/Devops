import { create } from "zustand";
import { persist } from "zustand/middleware";

function topicKey(pathId: string, topicId: string): string {
  return `${pathId}:${topicId}`;
}

interface CertificationState {
  completedTopics: Record<string, boolean>;
  toggleTopic: (pathId: string, topicId: string) => void;
  isTopicCompleted: (pathId: string, topicId: string) => boolean;
  resetPath: (pathId: string) => void;
}

export const useCertificationStore = create<CertificationState>()(
  persist(
    (set, get) => ({
      completedTopics: {},

      toggleTopic: (pathId, topicId) => {
        const key = topicKey(pathId, topicId);
        const current = get().completedTopics;
        set({
          completedTopics: {
            ...current,
            [key]: !current[key],
          },
        });
      },

      isTopicCompleted: (pathId, topicId) => {
        return Boolean(get().completedTopics[topicKey(pathId, topicId)]);
      },

      resetPath: (pathId) => {
        const prefix = `${pathId}:`;
        const next: Record<string, boolean> = {};
        for (const [key, value] of Object.entries(get().completedTopics)) {
          if (!key.startsWith(prefix)) next[key] = value;
        }
        set({ completedTopics: next });
      },
    }),
    { name: "cloudverse-certification-store" },
  ),
);

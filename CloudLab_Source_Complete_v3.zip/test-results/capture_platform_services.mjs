// Captures a clean, focused set of console screenshots showing each of the
// nine Milestone-15 GCP Platform/DevOps services (Service Account, Instance
// Template, Managed Instance Group, NAT Gateway, VPC Peering, Shared VPC,
// BigQuery dataset, Composer environment, Cloud Run service) actually
// created and reaching real READY status in CloudLab's own web console --
// for the platform-services detailed report, distinct from (and not mixed
// into) capture_core_services.mjs's own core-services screenshot set.
//
// Usage: node test-results/capture_platform_services.mjs
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { mkdirSync } from "node:fs";

const SHOT_DIR = "/home/claude/cloudlab/test-results/screenshots-platform";
mkdirSync(SHOT_DIR, { recursive: true });

const stamp = Date.now();
const email = `platform-report-${stamp}@cloudlab.dev`;
const password = "password123";
const octet = 70 + (stamp % 170);

const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
// Two buttons in this console genuinely use window.alert() (service-account
// key reveal, Cloud Run invoke) -- auto-accept so a real alert dialog never
// blocks the capture run.
page.on("dialog", (d) => d.accept());

// This console's layout is a fixed-height flex shell with an independently
// scrolling `.main` content pane (see styles.css: `.main{overflow-y:auto}`)
// -- so `document.body`'s own height never grows past one viewport, and
// Playwright's `fullPage: true` (which measures body height) silently
// crops anything below the fold once a tab's cards exceed 900px, exactly
// what happened to the NAT & Peering tab's third (Shared VPC) card. Resize
// the real viewport to the `.main` pane's actual scrollHeight first so the
// whole tab is on-screen, then capture normally.
async function shot(name) {
  // The architecture tab's own diagram wrapper (.arch-svg-wrap) additionally
  // scrolls horizontally for a wide graph, which the height-only fix above
  // doesn't touch -- widen the viewport too whenever something on the page
  // needs more width than the default.
  const { contentHeight, contentWidth } = await page.evaluate(() => {
    const main = document.querySelector(".main");
    const topbar = document.querySelector(".topbar");
    const archWrap = document.querySelector(".arch-svg-wrap");
    return {
      contentHeight: (topbar?.offsetHeight ?? 0) + (main?.scrollHeight ?? 0) + 40,
      contentWidth: 210 /* nav sidebar */ + Math.max(main?.scrollWidth ?? 0, archWrap?.scrollWidth ?? 0) + 40,
    };
  });
  await page.setViewportSize({ width: Math.max(1440, Math.min(contentWidth, 3600)), height: Math.max(900, Math.min(contentHeight, 4000)) });
  await page.waitForTimeout(150); // let layout settle after the resize
  await page.screenshot({ path: `${SHOT_DIR}/${name}.png`, fullPage: true });
  console.log(`captured ${name}.png`);
}

async function callApi(method, path, body, token) {
  const result = await page.evaluate(
    async ({ method, path, body, token }) => {
      const res = await fetch(`/api/v1${path}`, {
        method,
        headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      const text = await res.text();
      return { status: res.status, body: text ? JSON.parse(text) : null };
    },
    { method, path, body, token },
  );
  if (!result.body || (result.status >= 400 && result.status !== 404)) {
    console.error(`callApi ${method} ${path} -> ${result.status}: ${JSON.stringify(result.body)}`);
  }
  return result;
}

// Selects assembled from readyTemplates/readyNetworks/readyPipelines only
// carry an option once refreshTabData()'s GET has actually returned that
// resource as READY -- waiting for the option to exist (rather than just
// the <select> element itself) avoids a race against that fetch. Scoped to
// #main-content because the header itself has two <select>s of its own
// (the org and project switchers), which would otherwise shift every
// index in this file off by two.
async function selectByLabel(nth, label) {
  const select = page.locator("#main-content select").nth(nth);
  await select.locator(`option:has-text("${label}")`).first().waitFor({ timeout: 15000, state: "attached" });
  await select.selectOption({ label });
}

async function waitReady(path, id, token, maxSeconds = 60) {
  for (let i = 0; i < maxSeconds * 2; i++) {
    const { body } = await callApi("GET", path, undefined, token);
    const row = body.find((r) => r.id === id);
    if (row?.status === "READY" || row?.status === "FAILED") return row;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`${path}/${id} did not reach READY in time`);
}

try {
  await page.goto("http://localhost:4000/");
  await page.click("text=Register");
  await page.fill('input[name="name"]', "Platform Services Report");
  await page.fill('input[name="email"]', email);
  await page.fill('input[name="password"]', password);
  await page.click('button:has-text("Create account")');
  await page.waitForSelector('input[placeholder="Organization name"]', { timeout: 10000 });
  await page.fill('input[placeholder="Organization name"]', "Platform Services Report Org");
  await page.click('button:has-text("Create")');
  await page.waitForSelector('input[placeholder="Project name"]', { timeout: 10000 });
  await page.fill('input[placeholder="Project name"]', "platform-services-report-project");
  await page.click('button:has-text("Create")');
  await page.waitForSelector("text=Networking", { timeout: 10000 });
  await page.waitForTimeout(500); // let localStorage's token/project writes settle before reading them

  const token = await page.evaluate(() => localStorage.getItem("cloudlab_token"));
  const projectId = await page.evaluate(() => localStorage.getItem("cloudlab_project"));
  if (!token || !projectId) throw new Error(`missing token/projectId after project creation: token=${token} projectId=${projectId}`);

  // ---- Prerequisite networks (created via the real API, same pattern the
  // core-services capture uses for non-showcased setup resources) ----
  const netARes = await callApi("POST", `/projects/${projectId}/networks`, { name: "vpc-platform-a", cidr: `10.${octet}.0.0/24` }, token);
  const netAId = netARes.body.resource.id;
  await waitReady(`/projects/${projectId}/networks`, netAId, token);
  const netBRes = await callApi("POST", `/projects/${projectId}/networks`, { name: "vpc-platform-b", cidr: `10.${octet}.1.0/24` }, token);
  const netBId = netBRes.body.resource.id;
  await waitReady(`/projects/${projectId}/networks`, netBId, token);

  // ---- 1. Service Account (via the console's own create form) ----
  await page.click("text=Service Accounts");
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="CI Runner"]', "Deploy Bot");
  await page.fill('input[placeholder="ci-runner-sa"]', "deploy-bot-sa");
  await page.click('button:has-text("Create service account")');
  await page.waitForSelector("td:has-text('Deploy Bot')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("01_service_account_created");

  // ---- 2. Instance Template + Managed Instance Group (via console forms) ----
  await page.click("text=Instance Groups");
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="web-template"]', "web-template");
  await page.click('button:has-text("Create template")');
  await page.waitForSelector("td:has-text('web-template')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  // The MIG form's network/template <select>s only populate once
  // refreshTabData() has pulled the just-created READY template into
  // state -- reload the tab to pick it up, exactly like the core-services
  // capture reloads after creating prerequisites via direct API calls.
  await page.reload();
  await page.click("text=Instance Groups");
  await page.waitForTimeout(500);
  await page.fill('input[placeholder="web-mig"]', "web-mig");
  await selectByLabel(0, "web-template");
  await selectByLabel(1, "vpc-platform-a");
  await page.click('button:has-text("Create group")');
  await page.waitForSelector("td:has-text('web-mig')");
  await page.waitForFunction(() => document.body.innerText.includes("live"), { timeout: 30000 });
  await page.waitForTimeout(2000); // let the 10s reconciler's first tick land so "2 / 2 live" shows, not "0 / 2"
  await page.reload();
  await page.click("text=Instance Groups");
  await page.waitForTimeout(500);
  await shot("02_instance_template_and_mig_created");

  // ---- 3 & 4. NAT Gateway + VPC Peering + Shared VPC (via console forms, one tab) ----
  await page.click("text=NAT & Peering");
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="nat-default"]', "nat-platform-a");
  await selectByLabel(0, "vpc-platform-a");
  await page.click('button:has-text("Create NAT gateway")');
  await page.waitForSelector("td:has-text('nat-platform-a')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("03_nat_gateway_created");

  await page.fill('input[placeholder="peer-a-b"]', "peer-a-b");
  await selectByLabel(1, "vpc-platform-a");
  await selectByLabel(2, "vpc-platform-b");
  await page.click('button:has-text("Create peering")');
  await page.waitForSelector("td:has-text('peer-a-b')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("04_vpc_peering_created");

  // Real second project to be the Shared VPC's service project -- proves
  // the id typed into the form is a genuine cross-project reference.
  const svcProjRes = await callApi("POST", "/projects", { orgId: (await callApi("GET", "/organizations", undefined, token)).body[0].id, name: `svc-project-${stamp}` }, token);
  const svcProjectId = svcProjRes.body.id;
  await page.fill('input[placeholder="attach-service-project"]', "shared-with-svc-project");
  await page.fill('input[placeholder="service project id"]', svcProjectId);
  await selectByLabel(3, "vpc-platform-a");
  await page.click('button:has-text("Grant attachment")');
  await page.waitForSelector("td:has-text('shared-with-svc-project')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("05_shared_vpc_granted");

  // ---- 6. BigQuery dataset (via console form, then a real query) ----
  await page.click("text=BigQuery");
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="analytics-ds"]', "analytics-ds");
  await page.fill('input[placeholder="analytics (optional)"]', "analytics");
  await page.click('button:has-text("Create dataset")');
  await page.waitForSelector("td:has-text('analytics-ds')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 40000 });
  // handleWsMessage's operation.update handler keeps the pending-steps
  // panel mounted for 4s after an operation reaches SUCCEEDED before
  // clearing it (see app.js), and that clear is itself a renderMain() that
  // rebuilds every element in the tab -- including the very <input> this
  // step is about to fill. Outlasting that 4s window before touching the
  // form keeps the fill from landing on a node that's about to be replaced.
  await page.waitForTimeout(4500);
  await page.fill('input[placeholder="SELECT 1"]', "SELECT 1 AS one, 'cloudlab' AS engine, now() AS server_time");
  await page.click('button:has-text("Run query")');
  await page.waitForTimeout(1500);
  await shot("06_bigquery_dataset_and_query");

  // ---- 7. Composer environment (needs a real READY pipeline first) ----
  const pipeRes = await callApi("POST", `/projects/${projectId}/pipelines`, { name: "nightly-etl-pipeline", stages: [{ name: "extract", command: "echo extracting" }, { name: "load", command: "echo loading" }] }, token);
  await waitReady(`/projects/${projectId}/pipelines`, pipeRes.body.resource.id, token);
  await page.reload();
  await page.click("text=Composer");
  await page.waitForTimeout(500);
  await page.fill('input[placeholder="nightly-etl"]', "nightly-etl-env");
  await selectByLabel(0, "nightly-etl-pipeline");
  await page.click('button:has-text("Create environment")');
  await page.waitForSelector("td:has-text('nightly-etl-env')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("07_composer_environment_created");

  // ---- 8. Cloud Run service (create, then genuinely cold-start via Invoke) ----
  await page.click("text=Cloud Run");
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="hello-service"]', "hello-service");
  await selectByLabel(0, "vpc-platform-a");
  await page.click('button:has-text("Create service")');
  await page.waitForSelector("td:has-text('hello-service')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("08_cloud_run_service_idle");

  await page.click('button:has-text("Invoke")');
  await page.waitForTimeout(1500); // real cold start: a container genuinely comes up
  await shot("09_cloud_run_service_invoked_running");

  // ---- Architecture view showing every platform service connected ----
  await page.click("text=Architecture");
  await page.waitForTimeout(1200);
  await shot("10_architecture_all_platform_services");

  console.log("\nAll platform-service screenshots captured successfully.");
} catch (err) {
  console.error("FATAL:", err);
  await shot("fatal_error");
  process.exitCode = 1;
} finally {
  await browser.close();
}

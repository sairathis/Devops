#!/usr/bin/env python3
"""Builds "CloudLab -- GCP Platform & DevOps Services: Mapping, Provisioning
Methods & Test Report" (Milestone 15) as a single PDF.

Reads test-results/platform-services-results.json (written by
scripts/platform-services-test.mjs), the screenshots in
test-results/screenshots-platform/, and the real captured CLI transcripts in
test-results/transcripts/*-platform.txt, and renders one self-contained
HTML document that wkhtmltopdf turns into the final PDF.

This is the Milestone-15 companion to build_services_report.py -- that
report covers the seven original "core services"; this one covers the nine
new GCP Platform/DevOps Architect services (Service Account, Instance
Template, Managed Instance Group, NAT Gateway, VPC Peering, Shared VPC,
BigQuery dataset, Composer environment, Cloud Run service) plus the
GCP-service-to-CloudLab-resource mapping table and per-service, per-method
creation and testing guide the user explicitly asked for.
"""
import base64
import html
import json
import os
import subprocess
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(HERE, "screenshots-platform")
TRANSCRIPTS = os.path.join(HERE, "transcripts")

with open(os.path.join(HERE, "platform-services-results.json")) as f:
    PS = json.load(f)


def esc(s):
    return html.escape(str(s), quote=False)


def b64_img(name):
    path = os.path.join(SHOTS, f"{name}.png")
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


def read_transcript(name):
    with open(os.path.join(TRANSCRIPTS, name)) as f:
        return f.read()


run_date = datetime.now(timezone.utc).strftime("%B %d, %Y at %H:%M UTC")

# ---------------------------------------------------------------------------
# 1. GCP service -> CloudLab resource mapping table
# ---------------------------------------------------------------------------
MAPPING = [
    ("Cloud VPC Network", "network", "A real Docker bridge network with a real, host-wide-collision-checked CIDR.", "Full"),
    ("Cloud NAT", "nat_gateway", "Real host-level iptables MASQUERADE + ip_forward on the network's bridge -- egress genuinely toggles on/off.", "Full"),
    ("VPC Network Peering", "vpc_peering", "Real bidirectional iptables FORWARD ACCEPT rules opened between the two networks' bridges.", "Full"),
    ("Shared VPC", "shared_vpc_attachment", "A real, narrowly-scoped grant record: names one host network and one service project; enforced on every cross-project attach call, not a label.", "Full"),
    ("IAM Service Account", "service_account", "A real 2048-bit RSA keypair generated on create; the private key is AES-256-GCM encrypted at rest and only decrypted on an explicit, audited reveal call.", "Full"),
    ("Compute Engine Instance Template", "instance_template", "A stored blueprint (image, command, publish flag) -- no infrastructure of its own, exactly like GCP's own template.", "Full"),
    ("Compute Engine Managed Instance Group", "managed_instance_group", "Real containers stamped from a template; a reconciler tick (10s) keeps the live count pinned to target size and restarts crashed members -- genuine self-healing.", "Full"),
    ("Cloud Load Balancing", "load_balancer", "A real reverse-proxy container; its backend pool can point at a fixed instance list OR a Managed Instance Group's live, changing membership.", "Full (pre-existing, extended)"),
    ("Cloud SQL", "database", "CloudLab's pre-existing managed database type -- a dedicated real Postgres container per instance. No new resource type needed: Cloud SQL and this report's \"Managed database\" are the same relational-database-as-a-service concept, so the mapping is a documentation decision, not new code.", "Full (pre-existing)"),
    ("BigQuery", "bigquery_dataset", "Honest substitute: a genuinely dedicated real PostgreSQL 16 server per dataset with a real ad-hoc SQL query endpoint -- not BigQuery's actual distributed columnar/analytical engine, but every query genuinely executes against real data and returns real errors on bad SQL.", "Honest substitute (documented)"),
    ("Cloud Composer", "composer_environment", "Wraps a real CI/CD pipeline (Milestone 8) with a real 5-field UTC cron schedule; a scheduler loop (60s tick) genuinely triggers real pipeline runs on schedule -- not Airflow's actual DAG engine, but the trigger-on-schedule behavior is genuine.", "Honest substitute (documented)"),
    ("Cloud Run", "cloud_run_service", "Real scale-to-zero: no container exists until the first real Invoke request cold-starts one; an idle checker (15s tick) genuinely stops it again after the configured idle timeout.", "Full"),
    ("Docker / container runtime", "-- (engine, not a service)", "Not a GCP-mappable \"service\" at all -- it's the underlying engine every compute-shaped resource above (instances, MIG members, databases, BigQuery datasets, Cloud Run containers) is actually implemented with. See §2.1.", "N/A -- infrastructure layer"),
]
mapping_rows = "".join(
    f"""<tr><td><strong>{esc(gcp)}</strong></td><td class="mono">{esc(rtype)}</td><td>{desc}</td><td>{esc(fid)}</td></tr>"""
    for gcp, rtype, desc, fid in MAPPING
)

# ---------------------------------------------------------------------------
# 2. Per-service, per-method creation + testing guide
# ---------------------------------------------------------------------------
# Each entry: (service, gcp_equiv, demo_name, manual_steps, cicd_snippet, cloudshell_cmd, terraform_block, test_steps)
SERVICES_GUIDE = [
    dict(
        name="Service Account",
        gcp="IAM Service Account",
        demo="deploy-bot-sa",
        manual='Console -> <strong>Service Accounts</strong> -> fill Name <span class="mono">Deploy Bot</span>, Account ID <span class="mono">deploy-bot-sa</span> -> <strong>Create service account</strong>. Click <strong>Download key</strong> once READY to reveal the real decrypted RSA private key (audited).',
        cicd='<span class="mono">create service-accounts \'{"name":"deploy-bot-sa","accountId":"deploy-bot-sa"}\'</span> (see <span class="mono">cicd-lab/pipeline-platform-services.json</span>, stage <span class="mono">service-account</span>)',
        cloudshell='npx tsx gcloud-lab/gcloud.ts iam service-accounts create deploy-bot-sa --account-id=deploy-bot-sa\nnpx tsx gcloud-lab/gcloud.ts iam service-accounts keys create deploy-bot-sa   # reveals the real key',
        terraform='resource "cloudlab_service_account" "deploy_bot" {\n  account_id = "deploy-bot-sa"\n}',
        test='<span class="mono">GET .../service-accounts</span> -&gt; READY with a real <span class="mono">metadata.email</span>. <span class="mono">GET .../service-accounts/:id/key</span> returns a real, freshly-decrypted PEM private key -- confirm it is a genuine 2048-bit RSA key (<span class="mono">openssl rsa -in key.pem -check</span>) and that the ciphertext stored in Postgres is unrecoverable without this endpoint.',
    ),
    dict(
        name="Instance Template",
        gcp="Compute Engine Instance Template",
        demo="web-template",
        manual='Console -> <strong>Instance Groups</strong> -> "Create an instance template" -> Name <span class="mono">web-template</span> -> <strong>Create template</strong>.',
        cicd='<span class="mono">create instance-templates \'{"name":"web-template","image":"cloudlab/guest:latest"}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts compute instance-templates create web-template --image=cloudlab/guest:latest',
        terraform='resource "cloudlab_instance_template" "web_template" {\n  image = "cloudlab/guest:latest"\n}',
        test='<span class="mono">GET .../instance-templates</span> -&gt; READY immediately (it stores a blueprint only -- no infrastructure to provision). Confirm <span class="mono">spec.image</span> matches what you asked for, then create a Managed Instance Group that references its id and confirm real containers come up using that image.',
    ),
    dict(
        name="Managed Instance Group",
        gcp="Compute Engine Managed Instance Group",
        demo="web-mig",
        manual='Console -> <strong>Instance Groups</strong> -> "Create a managed instance group" -> Name <span class="mono">web-mig</span>, pick the template and a network, Target size <span class="mono">2</span> -> <strong>Create group</strong>. Try <strong>Resize</strong> to 3 and watch "Members" update within ~10s.',
        cicd='<span class="mono">create managed-instance-groups \'{"name":"web-mig","instanceTemplateId":"&lt;id&gt;","networkId":"&lt;id&gt;","targetSize":2}\' 60</span> (longer poll timeout -- real containers take longer than a network to start)',
        cloudshell='npx tsx gcloud-lab/gcloud.ts compute instance-groups managed create web-mig --template=web-template --network=vpc-main --size=2\nnpx tsx gcloud-lab/gcloud.ts compute instance-groups managed resize web-mig --size=3',
        terraform='resource "cloudlab_managed_instance_group" "web_group" {\n  instance_template_id = cloudlab_instance_template.web_template.id\n  network_id            = cloudlab_network.vpc_main.id\n  target_size           = 2\n}',
        test='<span class="mono">GET .../managed-instance-groups</span> -&gt; <span class="mono">metadata.liveCount</span> should equal <span class="mono">spec.targetSize</span> within ~10s of any change (create, resize, or a manually killed member). Kill one of its real containers directly (<span class="mono">docker kill &lt;container&gt;</span>) and confirm the next reconciler tick (10s) replaces it -- this is the self-healing test, and it only passes because the containers are real.',
    ),
    dict(
        name="NAT Gateway",
        gcp="Cloud NAT",
        demo="nat-default",
        manual='Console -> <strong>NAT & Peering</strong> -> "Create a NAT gateway" -> Name <span class="mono">nat-default</span>, pick a READY network -> <strong>Create NAT gateway</strong>.',
        cicd='<span class="mono">create nat-gateways \'{"name":"nat-default","networkResourceId":"&lt;id&gt;"}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts compute nat-gateways create nat-default --network=vpc-main',
        terraform='resource "cloudlab_nat_gateway" "nat_main" {\n  network_resource_id = cloudlab_network.vpc_main.id\n}',
        test='<span class="mono">GET .../nat-gateways</span> -&gt; READY. Verify the real iptables rule from the environment shell: <span class="mono">iptables -t nat -L POSTROUTING -n | grep MASQUERADE</span> should show a rule tagged <span class="mono">cloudlab:nat:&lt;id&gt;</span> on the network\'s real bridge interface, and <span class="mono">sysctl net.ipv4.ip_forward</span> should read <span class="mono">1</span>.',
    ),
    dict(
        name="VPC Peering",
        gcp="VPC Network Peering",
        demo="peer-a-b",
        manual='Console -> <strong>NAT & Peering</strong> -> "Create a VPC peering" -> Name <span class="mono">peer-a-b</span>, pick two different READY networks -> <strong>Create peering</strong>.',
        cicd='<span class="mono">create vpc-peerings \'{"name":"peer-a-b","networkAId":"&lt;idA&gt;","networkBId":"&lt;idB&gt;"}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts compute networks peerings create peer-a-b --network=vpc-a --peer-network=vpc-b',
        terraform='resource "cloudlab_vpc_peering" "peer_a_b" {\n  network_a_id = cloudlab_network.vpc_a.id\n  network_b_id = cloudlab_network.vpc_b.id\n}',
        test='<span class="mono">GET .../vpc-peerings</span> -&gt; READY. Verify real routing: from a container on network A, ping/connect to a container\'s address on network B and confirm it succeeds -- then delete the peering and confirm the same connection now fails. Negative test: POST the same network id as both <span class="mono">networkAId</span> and <span class="mono">networkBId</span> and confirm a real 400 ("must be different networks").',
    ),
    dict(
        name="Shared VPC",
        gcp="Shared VPC",
        demo="attach-service-project",
        manual='Console -> <strong>NAT & Peering</strong> -> "Grant a Shared VPC attachment" -> Name, a real other project\'s id, and a READY network from this (host) project -> <strong>Grant attachment</strong>.',
        cicd='Not included in the CI/CD demo pipeline (it inherently needs a second, already-existing project id) -- create it as any other resource: <span class="mono">create shared-vpc-attachments \'{"name":"...","serviceProjectId":"&lt;other-project-id&gt;","networkResourceId":"&lt;id&gt;"}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts compute shared-vpc create attach-svc --network=vpc-main --service-project=<other-project-id>',
        terraform='resource "cloudlab_shared_vpc_attachment" "attach_svc" {\n  network_resource_id = cloudlab_network.vpc_main.id\n  service_project_id  = "<other-project-id>"  # a literal id -- not a $ref, since it names a resource in a DIFFERENT project\n}',
        test='<span class="mono">GET .../shared-vpc-attachments</span> -&gt; READY. The real test is the enforcement, not the record: from the SERVICE project, <span class="mono">POST /projects/&lt;service-project&gt;/instances</span> with <span class="mono">networkId</span> set to the host network\'s id -- expect a real <span class="mono">404</span> before the grant exists, and a real <span class="mono">202</span> (then a genuine READY instance on the host\'s network bridge) once it does. Also confirm a THIRD, uninvolved project is still denied -- the grant names one service project, not "anyone".',
    ),
    dict(
        name="BigQuery Dataset",
        gcp="BigQuery",
        demo="analytics-ds",
        manual='Console -> <strong>BigQuery</strong> -> "Create a dataset" -> Name <span class="mono">analytics-ds</span>, Dataset id <span class="mono">analytics</span> -> <strong>Create dataset</strong>. Once READY, type SQL into the row\'s query box and click <strong>Run query</strong> to see a real result set.',
        cicd='<span class="mono">create bigquery-datasets \'{"name":"analytics-ds","datasetId":"analytics"}\' 60</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts bq datasets create analytics-ds --dataset-id=analytics\nnpx tsx gcloud-lab/gcloud.ts bq query --dataset=analytics-ds "SELECT 1 AS one"',
        terraform='resource "cloudlab_bigquery_dataset" "analytics" {\n  dataset_id = "analytics"\n}',
        test='<span class="mono">GET .../bigquery-datasets</span> -&gt; READY (allow extra time -- a real Postgres 16 server has to initialize). <span class="mono">POST .../bigquery-datasets/:id/query</span> with real SQL (e.g. <span class="mono">CREATE TABLE t(x int); INSERT INTO t VALUES (1),(2); SELECT sum(x) FROM t</span> as separate calls) and confirm the numbers are genuinely computed, not canned -- then send deliberately broken SQL and confirm a real Postgres error message comes back, not a swallowed success.',
    ),
    dict(
        name="Composer Environment",
        gcp="Cloud Composer",
        demo="nightly-etl-env",
        manual='First create a READY pipeline under <strong>CI/CD</strong> (Composer needs a real target). Then Console -> <strong>Composer</strong> -> Name <span class="mono">nightly-etl-env</span>, pick the pipeline, Schedule <span class="mono">*/5 * * * *</span> -> <strong>Create environment</strong>.',
        cicd='Not included in the demo pipeline (a pipeline scheduling another pipeline is circular for a flat demo) -- create it the same way as any resource once a target pipeline exists: <span class="mono">create composer-environments \'{"name":"...","pipelineId":"&lt;id&gt;","schedule":"*/5 * * * *"}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts composer environments create nightly-etl-env --pipeline=nightly-etl-pipeline --schedule="*/5 * * * *"',
        terraform='# This HCL subset supports strings/numbers/bools/arrays/refs but not\n# object-literal attributes, and a pipeline\'s `stages` is an array of\n# objects -- so hardcode an already-existing pipeline\'s real id as a string:\nresource "cloudlab_composer_environment" "scheduled" {\n  pipeline_id = "<existing-pipeline-id>"\n  schedule    = "*/10 * * * *"\n}',
        test='<span class="mono">GET .../composer-environments</span> -&gt; READY. Wait for a minute boundary matching the cron expression and confirm <span class="mono">metadata.triggerCount</span> increments and a new row appears under <span class="mono">GET .../pipeline-runs</span> for the wrapped pipeline -- a real trigger, not a static schedule string. Negative test: POST an invalid cron (e.g. <span class="mono">"not a cron"</span>) and confirm a real 400 naming the field.',
    ),
    dict(
        name="Cloud Run Service",
        gcp="Cloud Run",
        demo="hello-service",
        manual='Console -> <strong>Cloud Run</strong> -> Name <span class="mono">hello-service</span>, pick a READY network, Idle timeout <span class="mono">60</span> -> <strong>Create service</strong>. Click <strong>Invoke</strong> once READY and watch STATE flip IDLE -&gt; RUNNING.',
        cicd='<span class="mono">create cloud-run-services \'{"name":"hello-service","networkId":"&lt;id&gt;","idleTimeoutSeconds":60}\'</span>',
        cloudshell='npx tsx gcloud-lab/gcloud.ts run services create hello-service --network=vpc-main --idle-timeout=60\nnpx tsx gcloud-lab/gcloud.ts run services invoke hello-service   # genuine cold start',
        terraform='resource "cloudlab_cloud_run_service" "hello_service" {\n  network_id           = cloudlab_network.vpc_main.id\n  idle_timeout_seconds = 60\n}',
        test='<span class="mono">GET .../cloud-run-services</span> -&gt; READY with <span class="mono">metadata.state = "IDLE"</span> and no backing container yet (<span class="mono">docker ps</span> shows nothing for it). <span class="mono">POST .../:id/invoke</span> -&gt; a real container cold-starts (confirm with <span class="mono">docker ps</span>), <span class="mono">metadata.state</span> flips to <span class="mono">RUNNING</span>. Wait past the idle timeout with no further invokes and confirm the idle checker (15s tick) genuinely stops the container and flips state back to <span class="mono">IDLE</span> -- watch <span class="mono">docker ps</span> during the wait to see it disappear on its own.',
    ),
]

def service_guide_block(s):
    return f"""
    <div class="svc-block">
      <h3>{esc(s['name'])} <span class="gcp-tag">GCP: {esc(s['gcp'])}</span></h3>
      <table class="method-table">
        <tr><td class="method-lbl">Manual (console)</td><td>demo name <span class="mono">{esc(s['demo'])}</span> &mdash; {s['manual']}</td></tr>
        <tr><td class="method-lbl">CI/CD pipeline</td><td>{s['cicd']}</td></tr>
        <tr><td class="method-lbl">Cloud Shell (gcloud-lab)</td><td><pre class="cmd">{esc(s['cloudshell'])}</pre></td></tr>
        <tr><td class="method-lbl">Terraform (.tf)</td><td><pre class="cmd">{esc(s['terraform'])}</pre></td></tr>
        <tr><td class="method-lbl">How to test</td><td>{s['test']}</td></tr>
      </table>
    </div>
    """

services_guide_html = "".join(service_guide_block(s) for s in SERVICES_GUIDE)

# ---------------------------------------------------------------------------
# 3. Test results table, grouped by method
# ---------------------------------------------------------------------------
METHOD_ORDER = ["JSON-CLI", "Terraform-lab", "gcloud-CLI", "CI/CD-pipeline", "Shared-VPC-IAM"]
METHOD_LABEL = {
    "JSON-CLI": "Method: JSON CLI (scripts/cloudlab-cli.ts)",
    "Terraform-lab": "Method: Terraform-lab (real .tf syntax)",
    "gcloud-CLI": "Method: gcloud-style CLI (Cloud Shell lab)",
    "CI/CD-pipeline": "Method: CI/CD pipeline",
    "Shared-VPC-IAM": "Cross-cutting: Shared VPC's real cross-project IAM enforcement",
}
by_method = {m: [] for m in METHOD_ORDER}
for r in PS["results"]:
    by_method.setdefault(r["method"], []).append(r)

ps_sections = []
for m in METHOD_ORDER:
    rows = by_method.get(m, [])
    p = sum(1 for r in rows if r["status"] == "PASS")
    trs = "".join(
        f"""<tr><td class="mono">{esc(r['id'])}</td><td>{esc(r['description'])}</td>
        <td><span class="pill {'pass' if r['status']=='PASS' else 'fail'}">{r['status']}</span></td>
        <td class="mono small">{esc(r['details'][:130])}</td></tr>"""
        for r in rows
    )
    ps_sections.append(f"""
    <h3>{esc(METHOD_LABEL[m])} &mdash; {p}/{len(rows)} passed</h3>
    <table class="overview">
    <tr><th>Case</th><th>What it verifies</th><th>Result</th><th>Evidence</th></tr>
    {trs}
    </table>
    """)

total_pass, total_fail, total_all = PS["pass"], PS["fail"], PS["total"]

# ---------------------------------------------------------------------------
# 4. Real captured terminal transcripts
# ---------------------------------------------------------------------------
def transcript_block(title, filename, note):
    body = esc(read_transcript(filename)).rstrip()
    return f"""<div class="transcript-block">
      <h3>{esc(title)}</h3>
      <p class="note">{note}</p>
      <pre class="term">{body}</pre>
    </div>"""


transcripts_html = "".join([
    transcript_block(
        "JSON CLI -- all 9 new services in one plan",
        "json-cli-platform.txt",
        "scripts/cloudlab-cli.ts apply/plan/destroy against a real running project, using $-reference resolution across service_account, instance_template, managed_instance_group, nat_gateway, vpc_peering, bigquery_dataset and cloud_run_service.",
    ),
    transcript_block(
        "Terraform-lab -- real .tf syntax",
        "terraform-lab-platform.txt",
        "terraform-lab/configs/platform-services.tf applied/planned/destroyed unmodified (CIDRs substituted only to dodge this long-lived sandbox's real host-wide collision check).",
    ),
    transcript_block(
        "gcloud-style CLI -- Cloud Shell lab",
        "gcloud-cli-platform.txt",
        "A full session: init, all 9 services created (a real CIDR collision and retry included, unedited), special verbs (key reveal -- redacted, resize, bq query, invoke), and a real negative (Shared VPC to your own project).",
    ),
    transcript_block(
        "CI/CD pipeline -- cicd-lab/pipeline-platform-services.json",
        "cicd-pipeline-platform.txt",
        "cicd-lab/run-platform-services-lab.mjs: a real pipeline run whose shell stages call back into CloudLab's own REST API, provisioning 7 of the 9 new services as a side effect of a CI job.",
    ),
])

# ---------------------------------------------------------------------------
# 5. Console screenshot gallery
# ---------------------------------------------------------------------------
SCREENS = [
    ("01_service_account_created", "A Service Account reaching READY with a real generated email -- the private key is downloadable (and audited) once ready."),
    ("02_instance_template_and_mig_created", "An Instance Template and a Managed Instance Group sized to 2, showing \"2 / 2 live\" -- a real reconciler tick confirmed the count."),
    ("03_nat_gateway_created", "A NAT Gateway reaching READY, with its provisioning steps showing the real iptables MASQUERADE + ip_forward work performed."),
    ("04_vpc_peering_created", "A VPC Peering reaching READY -- real bidirectional iptables FORWARD ACCEPT rules opened between the two networks' bridges."),
    ("05_shared_vpc_granted", "A Shared VPC attachment reaching READY, naming a real second project id as the service project -- this exact grant is what Section 6's cross-cutting IAM tests exercise."),
    ("06_bigquery_dataset_and_query", "A BigQuery dataset with a genuine ad-hoc SQL query executed against its own real dedicated Postgres server -- the JSON result shown is real, not canned."),
    ("07_composer_environment_created", "A Composer environment wrapping a real pipeline on a real 5-field UTC cron schedule."),
    ("08_cloud_run_service_idle", "A Cloud Run service just created -- STATE is IDLE because, true to GCP's own model, no container exists yet."),
    ("09_cloud_run_service_invoked_running", "The same service immediately after a real Invoke -- STATE flips to RUNNING because a real container genuinely cold-started."),
    ("10_architecture_all_platform_services", "The architecture graph, computed fresh from the database, showing all 9 new platform services and their real relationships alongside the networks and pipeline that support them."),
]
screens_html = "".join(
    f"""<div class="shot-card">
      <img class="shot" src="data:image/png;base64,{b64_img(name)}">
      <p class="cap">{cap}</p>
    </div>"""
    for name, cap in SCREENS
)

neg_count = sum(1 for r in PS["results"] if "(negative)" in r["id"])

HTML = f"""<!doctype html>
<html><head><meta charset="utf-8">
<style>
  @page {{ margin: 20mm 16mm 18mm 16mm; }}
  * {{ box-sizing: border-box; }}
  body {{ font-family: 'DejaVu Sans', Arial, Helvetica, sans-serif; color: #16233f; font-size: 10.3pt; line-height: 1.5; }}
  h1 {{ font-size: 22pt; margin: 0 0 4px; }}
  h2 {{ font-size: 15pt; margin: 26px 0 10px; padding-bottom: 6px; border-bottom: 2px solid #1d4ed8; color: #0f2a5c; }}
  h3 {{ font-size: 11.5pt; margin: 18px 0 8px; color: #14336b; }}
  p {{ margin: 6px 0; }}
  .cover {{ text-align: center; padding-top: 20mm; page-break-after: always; }}
  .cover .brand {{ font-size: 30pt; font-weight: 700; color: #0f2a5c; }}
  .cover .brand .dot {{ color: #1d4ed8; }}
  .cover .subtitle {{ font-size: 14pt; color: #33415c; margin-top: 6px; }}
  .cover .meta {{ margin-top: 30px; font-size: 10.5pt; color: #4b5a78; }}
  .cover .meta div {{ margin: 3px 0; }}
  .cover .summary-box {{ display: inline-block; margin-top: 30px; padding: 16px 30px; border: 1px solid #cfe0fb; border-radius: 10px; background: #eef4ff; }}
  .cover .summary-box .big {{ font-size: 28pt; font-weight: 700; color: #1d4ed8; }}
  .cover .summary-box .lbl {{ font-size: 9.5pt; color: #4b5a78; text-transform: uppercase; letter-spacing: .04em; }}
  .cover .method-badges {{ margin-top: 22px; }}
  .cover .method-badges span {{ display: inline-block; margin: 3px; padding: 5px 12px; background: #0f2a5c; color: #fff; border-radius: 999px; font-size: 9pt; }}
  .cover .svc-badges {{ margin-top: 14px; }}
  .cover .svc-badges span {{ display: inline-block; margin: 2px; padding: 4px 10px; background: #fff; border: 1px solid #cfe0fb; color: #14336b; border-radius: 999px; font-size: 8.3pt; }}
  .section {{ page-break-before: always; }}
  .section:first-of-type {{ page-break-before: auto; }}
  ol, ul {{ margin: 6px 0; padding-left: 22px; }}
  li {{ margin: 4px 0; }}
  code, .mono {{ font-family: 'DejaVu Sans Mono', monospace; font-size: 9.3pt; }}
  .small {{ font-size: 8.3pt; color: #555; }}
  .callout {{ background: #eef4ff; border-left: 3px solid #1d4ed8; padding: 8px 12px; margin: 10px 0; font-size: 10pt; }}
  .callout.warn {{ background: #fdf1de; border-left-color: #a8681c; }}
  table.overview {{ width: 100%; border-collapse: collapse; margin-top: 8px; margin-bottom: 14px; font-size: 9.3pt; }}
  table.overview th {{ text-align: left; background: #0f2a5c; color: #fff; padding: 6px 8px; font-size: 8.8pt; text-transform: uppercase; letter-spacing: .03em; }}
  table.overview td {{ padding: 6px 8px; border-bottom: 1px solid #dbe4f3; vertical-align: top; }}
  table.overview tr:nth-child(even) td {{ background: #f5f8fd; }}
  .pill {{ display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 8.5pt; font-weight: 700; letter-spacing: .03em; }}
  .pill.pass {{ background: #d9f0e6; color: #12664f; }}
  .pill.fail {{ background: #fbe1de; color: #9c2c20; }}
  .transcript-block {{ margin: 14px 0; page-break-inside: avoid; }}
  .transcript-block .note {{ font-size: 9pt; color: #4b5a78; margin: 2px 0 6px; }}
  pre.term {{ background: #0f2a5c; color: #dce8ff; padding: 12px 14px; border-radius: 8px; font-family: 'DejaVu Sans Mono', monospace; font-size: 7.6pt; line-height: 1.4; white-space: pre-wrap; word-wrap: break-word; }}
  .shot-card {{ margin: 0 0 18px; page-break-inside: avoid; }}
  img.shot {{ width: 100%; border: 1px solid #cfe0fb; border-radius: 6px; display: block; }}
  .shot-card .cap {{ font-size: 9pt; color: #4b5a78; margin-top: 5px; }}
  .footer-note {{ margin-top: 24px; font-size: 8.5pt; color: #6b7690; border-top: 1px solid #dbe4f3; padding-top: 8px; }}
  .known-limits li {{ margin: 6px 0; }}
  .svc-block {{ margin: 6px 0 22px; page-break-inside: avoid; }}
  .gcp-tag {{ font-size: 8pt; font-weight: 400; background: #eef4ff; color: #14336b; padding: 2px 9px; border-radius: 999px; margin-left: 8px; }}
  table.method-table {{ width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 9.2pt; }}
  table.method-table td {{ padding: 6px 8px; border-bottom: 1px solid #eaeff8; vertical-align: top; }}
  table.method-table td.method-lbl {{ width: 130px; font-weight: 700; color: #0f2a5c; font-size: 8.6pt; text-transform: uppercase; letter-spacing: .02em; }}
  pre.cmd {{ background: #f5f8fd; border: 1px solid #dbe4f3; border-radius: 6px; padding: 8px 10px; font-family: 'DejaVu Sans Mono', monospace; font-size: 8.6pt; white-space: pre-wrap; word-wrap: break-word; margin: 0; }}
</style></head>
<body>

<div class="cover">
  <div class="brand">Cloud<span class="dot">Lab</span></div>
  <div class="subtitle">GCP Platform &amp; DevOps Services &mdash; Mapping, Provisioning Methods &amp; Test Report</div>
  <div class="meta">
    <div>Milestone 15: NAT Gateway, Shared VPC, Cloud SQL, BigQuery, Composer, Cloud Run, VPC Peering, Service Accounts, Instance Templates &amp; Managed Instance Groups</div>
    <div>Report generated: {run_date}</div>
  </div>
  <div class="summary-box">
    <div class="big">{total_pass} / {total_all}</div>
    <div class="lbl">Test cases passed across 4 methods + cross-cutting IAM</div>
  </div>
  <div class="method-badges">
    <span>Console (manual)</span><span>JSON CLI</span><span>Terraform-lab</span><span>gcloud-style CLI</span><span>CI/CD pipeline</span>
  </div>
  <div class="svc-badges">
    <span>Service Account</span><span>Instance Template</span><span>Managed Instance Group</span><span>NAT Gateway</span><span>VPC Peering</span><span>Shared VPC</span><span>BigQuery</span><span>Composer</span><span>Cloud Run</span>
  </div>
</div>

<div class="section">
<h2>1. What this report covers</h2>
<p>The previous services report covered CloudLab's seven original "core services." This report is the Milestone 15 companion: thinking as a GCP Platform/DevOps Architect would, it adds the networking, identity, fleet-management and managed-data-and-compute services a real GCP landing zone needs beyond those seven &mdash; <strong>NAT Gateway, Shared VPC, Cloud SQL, BigQuery, Cloud Composer, Cloud Run, VPC Peering, Service Accounts, Instance Templates,</strong> and <strong>Managed Instance Groups</strong> &mdash; and extends the existing Load Balancer to target a Managed Instance Group's live membership.</p>
<p>Every one of these is backed by genuinely real infrastructure on this host: real iptables rules for NAT and peering, a real narrowly-scoped and enforced cross-project grant for Shared VPC, a real RSA-2048 keypair per service account with AES-256-GCM encryption at rest, real self-healing containers for Managed Instance Groups, a real dedicated Postgres server per BigQuery dataset, a real cron-driven scheduler for Composer, and real cold-start/scale-to-zero container lifecycle for Cloud Run. Two of these (BigQuery, Composer) are documented, honest substitutes for engines (a distributed columnar warehouse; a DAG scheduler) that cannot be reproduced in this environment &mdash; every other behavior in this report is the real thing, not a simulated status.</p>
<p>This document gives, for <strong>every</strong> service: what it maps to in real GCP (§2), how to create it by hand in the console with a concrete demo name (§3), how to create it from a CI/CD pipeline stage, from the gcloud-style Cloud Shell CLI, and from a Terraform-style <span class="mono">.tf</span> file (§3), and exactly how to independently test that it is real (§3) &mdash; plus real captured terminal transcripts (§4), real console screenshots (§5), and a full automated test run's results (§6).</p>

<h3>1.1 Docker's role -- explicitly not a "service"</h3>
<p>Docker is not added here as a tenth GCP-mappable service because it isn't one in GCP's own model either: it's the underlying container engine every compute-shaped resource in CloudLab is actually implemented with, from a plain <span class="mono">instance</span> to a Managed Instance Group's members to a Cloud Run service's cold-started container. Every "real container" claim in this report means a genuine <span class="mono">docker run</span>/<span class="mono">docker network</span>/<span class="mono">docker exec</span> call happened, checkable with <span class="mono">docker ps</span>/<span class="mono">docker inspect</span> against this environment's real Docker Engine at any point in this document's test steps.</p>
</div>

<div class="section">
<h2>2. GCP service &rarr; CloudLab resource mapping</h2>
<table class="overview">
<tr><th>GCP service</th><th>CloudLab resource type</th><th>What actually runs behind it</th><th>Fidelity</th></tr>
{mapping_rows}
</table>
<p class="callout">"Fidelity" follows the same honesty standard as the rest of this project: <strong>Full</strong> means the real underlying mechanism GCP itself relies on (iptables, a real keypair, a real container engine, a real relational database) is genuinely present and checkable from outside CloudLab's own API. <strong>Honest substitute</strong> means the surface behavior (a scheduled trigger, a SQL query endpoint) is real, but the engine underneath is deliberately simpler than GCP's own (a single Postgres server standing in for BigQuery's distributed columnar engine; a cron-driven pipeline trigger standing in for Airflow's DAG scheduler) -- documented here and in ROADMAP.md rather than glossed over.</p>
</div>

<div class="section">
<h2>3. Every new service: create it 4 ways, then test it</h2>
<p>For each service below: a concrete demo resource name, how to create it by hand in the console, from a CI/CD pipeline stage, from the gcloud-style Cloud Shell CLI, and from a Terraform-style <span class="mono">.tf</span> file &mdash; and how to independently verify it is genuinely real, not just trust its status badge.</p>
{services_guide_html}
<p class="callout">General pattern for every resource above, exactly as with the seven core services: <span class="mono">POST</span> returns <span class="mono">{{ resource, operationId }}</span> immediately with status <span class="mono">CREATING</span>; poll <span class="mono">GET /projects/:id/operations/:operationId</span> until <span class="mono">SUCCEEDED</span>/<span class="mono">FAILED</span>; then re-<span class="mono">GET</span> the resource for its final real status. Every transcript, screenshot and test case in this report follows exactly this discipline.</p>
</div>

<div class="section">
<h2>4. Real, captured terminal transcripts</h2>
<p>Every transcript below is the real, unedited stdout of an actual run against this running CloudLab instance in this environment (the service-account private key is redacted for this document; everything else, including a genuine CIDR collision and its retry in the gcloud-CLI session, is shown exactly as it happened).</p>
{transcripts_html}
</div>

<div class="section">
<h2>5. Console screenshots</h2>
<p>All nine new services created by hand through CloudLab's own console, each reaching a real READY status (or, for Cloud Run, genuinely transitioning IDLE &rarr; RUNNING on invoke):</p>
{screens_html}
</div>

<div class="section">
<h2>6. Automated test results</h2>
<p>A dedicated test suite (<span class="mono">scripts/platform-services-test.mjs</span>) exercises create, independent-GET verification, and delete-and-confirm-gone for all nine new services across the JSON CLI, Terraform-lab, gcloud-style CLI and CI/CD pipeline methods, plus {neg_count} negative/edge cases (self-peering rejected, a malformed service-account id rejected, an invalid cron schedule rejected, sharing a network with your own project rejected, a missing required CLI flag caught before ever calling the API, and more) and a dedicated cross-cutting section proving Shared VPC's cross-project grant is genuinely enforced: denied with no grant, allowed once one exists, and still denied for a third, uninvolved project.</p>
<div class="callout"><strong>{total_pass} of {total_all} test cases passed.</strong> One real app bug was found and fixed in the course of building this report: the console's live WebSocket status updates only ever patched the Networks and Instances tables (a leftover from before Milestone 15), silently leaving all nine new services' tables to update only on a manual refresh; the fix (a type-to-state-key map in <span class="mono">handleWsMessage</span>) now live-updates every resource type's table, the same way Networks and Instances always did. A second, related bug -- a BigQuery query's result flashing and then vanishing immediately, because it lived only on a local DOM reference that the app's own post-action re-render then discarded -- was fixed by moving query results into application state. Both fixes are reflected in the screenshots in §5.</div>
{"".join(ps_sections)}
</div>

<div class="section">
<h2>7. Summary</h2>
<p>All nine new GCP Platform/DevOps services requested for Milestone 15 -- Service Accounts, Instance Templates, Managed Instance Groups, NAT Gateway, VPC Peering, Shared VPC, BigQuery, Composer, and Cloud Run -- are backed by genuinely real infrastructure (or an honestly documented substitute where the real GCP engine cannot be reproduced here), map cleanly onto their real GCP counterparts, and can each be created, verified and deleted through the same four independent, cross-checked methods as CloudLab's original seven core services: the console by hand, a declarative JSON CLI, a real <span class="mono">.tf</span>-syntax Terraform-lab, a gcloud-style Cloud Shell CLI, and a CI/CD pipeline calling the platform's own API. {total_pass} of {total_all} automated test cases passed, including a dedicated cross-project IAM enforcement suite for Shared VPC, and the existing core-services and full-regression QA suites remain fully passing alongside this work.</p>
<div class="footer-note">Generated from real captured CLI transcripts, real console screenshots, and a real automated test run against this running CloudLab instance. No output in this report was hand-written or simulated.</div>
</div>

</body></html>
"""

out_path = os.path.join(HERE, "cloudlab_platform_services_report.html")
with open(out_path, "w") as f:
    f.write(HTML)
print("wrote", out_path, len(HTML), "bytes")

pdf_path = os.path.join(HERE, "CloudLab_Platform_Services_Report.pdf")
subprocess.run(
    ["wkhtmltopdf", "--enable-local-file-access", "--print-media-type", out_path, pdf_path],
    check=True,
)
print("wrote", pdf_path)

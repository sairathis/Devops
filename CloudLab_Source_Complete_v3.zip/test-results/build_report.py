#!/usr/bin/env python3
"""Builds the CloudLab Usage Guide & QA Test Report as a single PDF.

Reads test-results/results.json (written by scripts/qa-run.mjs) and the
screenshots in test-results/screenshots/, combines them with formal test
case specifications and a usage guide, and renders one self-contained HTML
document that wkhtmltopdf turns into the final PDF.
"""
import base64
import json
import os
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(HERE, "screenshots")
with open(os.path.join(HERE, "results.json")) as f:
    RUN = json.load(f)

RESULTS_BY_ID = {r["id"]: r for r in RUN["results"]}

def b64_img(name):
    path = os.path.join(SHOTS, f"{name}.png")
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")

# ---------------------------------------------------------------------------
# Formal test case specifications (independent of the run -- this is what
# a tester would follow by hand; the run just proves it was executed).
# ---------------------------------------------------------------------------
TEST_CASES = [
    dict(id="TC-01", title="User registration", area="Auth",
         pre="The console is open at the login screen with no active session.",
         steps="1. Click “Register”.\n2. Enter a name, a unique email, and a password (8+ chars).\n3. Click “Create account”.",
         expected="Account is created, a session token is issued, and the screen advances to organization creation.",
         shot="tc01_registered"),
    dict(id="TC-02", title="Invalid login is rejected", area="Auth",
         pre="The console is open at the login screen.",
         steps="1. Enter an email/password combination that does not match a real account.\n2. Click “Log in”.",
         expected="Login is rejected; a visible error banner explains the failure. No session is created.",
         shot="tc02_invalid_login"),
    dict(id="TC-03", title="Organization creation", area="Orgs & Projects",
         pre="User is logged in with no organization yet.",
         steps="1. Enter an organization name.\n2. Click “Create”.",
         expected="The organization is created, the user becomes its Owner, and the screen advances to project creation.",
         shot="tc03_org_created"),
    dict(id="TC-04", title="Project creation", area="Orgs & Projects",
         pre="User belongs to an organization with no project yet.",
         steps="1. Enter a project name.\n2. Click “Create”.",
         expected="The project is created and the main console (Dashboard, side navigation) loads.",
         shot="tc04_dashboard"),
    dict(id="TC-05", title="VPC network creation", area="Networking",
         pre="An active project exists.",
         steps="1. Open the Networking tab.\n2. Enter a network name and CIDR.\n3. Click “Create network”.",
         expected="A resource row appears in status CREATING, then a real Docker bridge network is provisioned and the badge turns READY.",
         shot="tc05_network_ready"),
    dict(id="TC-06", title="Compute instance creation", area="Compute",
         pre="A network in status READY exists.",
         steps="1. Open the Compute tab.\n2. Choose the READY network.\n3. Enter an instance name.\n4. Click “Create instance”.",
         expected="A real container is started on the chosen network, passes its health check, and the badge turns READY with a working public URL.",
         shot="tc06_instance_ready"),
    dict(id="TC-07", title="Remote command execution (exec panel)", area="Compute",
         pre="An instance in status READY exists.",
         steps="1. Open the instance's detail page.\n2. Enter a command (e.g. “hostname”) in the “Run a command” box.\n3. Click “Run”.",
         expected="The real command runs inside the container and its real output is displayed.",
         shot="tc07_exec_command"),
    dict(id="TC-08", title="Interactive terminal session", area="Compute",
         pre="An instance in status READY exists and its detail page is open.",
         steps="1. Wait for the terminal panel to connect.\n2. Type a command (e.g. “id”) and press Enter.",
         expected="A real, Tty-attached shell session inside the container executes the command and streams its real output back.",
         shot="tc08_terminal"),
    dict(id="TC-09", title="Auto-derived architecture graph", area="Observability",
         pre="A project has at least one network and one connected instance.",
         steps="1. Open the Architecture tab.",
         expected="The graph shows a node for the project and every resource, plus a real “connects_to” edge between the instance and its network — computed fresh from the database, never hand-drawn.",
         shot="tc09_architecture"),
    dict(id="TC-10", title="Activity timeline", area="Observability",
         pre="At least one action has been performed in the project.",
         steps="1. Open the Activity tab.",
         expected="A human-readable, chronological feed of what happened in the project is shown.",
         shot="tc10_activity"),
    dict(id="TC-11", title="Audit log", area="Observability",
         pre="At least one API call has been made in the project.",
         steps="1. Open the Audit Log tab.",
         expected="Every API call is listed with its outcome, timestamp, endpoint, and request id — including calls the specific route never explicitly annotated.",
         shot="tc11_audit"),
    dict(id="TC-12", title="IAM role definitions are visible", area="IAM",
         pre="An active project exists.",
         steps="1. Open the IAM tab.",
         expected="The four built-in roles (Owner, Admin, Developer, Viewer) are listed with their allow/deny permission rules.",
         shot="tc12_iam_roles"),
    dict(id="TC-13", title="Viewer role is enforced (read-only)", area="IAM",
         pre="A second user has been bound to the project with the Viewer role.",
         steps="1. As the Viewer, request the resource list (expect success).\n2. As the Viewer, attempt to create a resource (expect denial).\n3. As the project Owner, check the Audit Log.",
         expected="The Viewer can list resources (200) but is blocked from creating them (403 PERMISSION_DENIED); the denied attempt itself appears in the project's audit trail.",
         shot="tc13_viewer_denied_audit_trail"),
    dict(id="TC-14", title="Unauthorized project access is hidden (404, not 403)", area="IAM",
         pre="A user exists with no organization or project membership whatsoever.",
         steps="1. As that user, request a resource list for a project they do not belong to.",
         expected="The API returns 404 Not Found, not 403 — existence of the project is not revealed to users with no visibility into it.",
         shot=None),
    dict(id="TC-15", title="Delete is blocked by a live dependency", area="Lifecycle",
         pre="A network has a non-deleted instance attached to it.",
         steps="1. Attempt to delete the network while the instance is still live.",
         expected="The delete is refused with a clear “DEPENDENCY_EXISTS” error naming the blocking resource; nothing is deleted.",
         shot="tc15_delete_blocked"),
    dict(id="TC-16", title="Instance deletion", area="Lifecycle",
         pre="An instance in status READY exists.",
         steps="1. Click “Delete” on the instance.",
         expected="The instance is torn down, its real container is removed from the Docker daemon, and it disappears from the list.",
         shot="tc16_instance_deleted"),
    dict(id="TC-17", title="Network deletion after dependency is cleared", area="Lifecycle",
         pre="The network's only dependent instance has just been deleted.",
         steps="1. Click “Delete” on the network.",
         expected="The network is torn down, its real Docker network is removed, and it disappears from the list.",
         shot="tc17_network_deleted"),
    # -- Milestone 2: networking upgrades ------------------------------------
    dict(id="TC-19", title="Subnet creation allocates a real sub-range", area="Networking",
         pre="A VPC network in status READY exists.",
         steps="1. Open Networking.\n2. Create a subnet inside the network, giving it a CIDR that is a sub-range of the network's own CIDR.\n3. Wait for it to reach READY.",
         expected="The subnet reaches READY holding the requested sub-range CIDR, which the compute layer later allocates real static IPs from.",
         shot=None),
    dict(id="TC-20", title="Firewall rule installs a real iptables rule", area="Networking",
         pre="A network in status READY exists.",
         steps="1. Open Firewall.\n2. Add an ingress ALLOW rule for a port range and source CIDR.\n3. Wait for it to reach READY.",
         expected="The rule reaches READY, and a matching real iptables rule exists on the network's Docker bridge (not just a database row).",
         shot="tc20_firewall"),
    dict(id="TC-21", title="DNS record is served by a real resolver", area="Networking",
         pre="A network in status READY exists.",
         steps="1. Create a DNS record mapping a hostname to an IP on the network.\n2. Wait for it to reach READY.",
         expected="A real DNS resolver container on the network answers queries for that hostname with the configured IP.",
         shot=None),
    dict(id="TC-22", title="Load balancer fronts real backend instances", area="Networking",
         pre="A READY network and at least one READY backend instance exist.",
         steps="1. Create a load balancer, selecting the backend instance(s).\n2. Wait for it to reach READY.",
         expected="A real reverse-proxy container starts, routing traffic to the chosen backend instance(s).",
         shot="tc22_loadbalancer"),

    # -- Milestone 3: compute upgrades ----------------------------------------
    dict(id="TC-23", title="Disk creation provisions a real Docker volume", area="Compute",
         pre="An active project exists.",
         steps="1. Open Disks.\n2. Create a disk with a chosen size.\n3. Wait for it to reach READY.",
         expected="The disk reaches READY and a real Docker volume of that size backs it, mountable by an instance.",
         shot="tc23_disks"),
    dict(id="TC-24", title="Instance stats reflect real container.stats()", area="Compute",
         pre="An instance in status READY exists.",
         steps="1. Call the instance's stats endpoint.",
         expected="CPU percent, memory usage/limit, and network RX/TX bytes are returned from a genuine live Docker `container.stats()` read, not synthetic placeholder numbers.",
         shot=None),

    # -- Milestone 4: container registry / images -----------------------------
    dict(id="TC-25", title="Registry creation runs a real private registry", area="CI/CD & Images",
         pre="An active project exists.",
         steps="1. Open Registry.\n2. Create a registry.\n3. Wait for it to reach READY.",
         expected="A real private container-image registry service starts and reaches READY.",
         shot="tc25_registry"),
    dict(id="TC-26", title="Image build runs a genuine `docker build`", area="CI/CD & Images",
         pre="A registry in status READY exists.",
         steps="1. Submit a Dockerfile (based on the platform's own guest image) to build an image against that registry.\n2. Wait for it to reach READY.",
         expected="A real `docker build` executes the given Dockerfile and the resulting image reaches READY with a real tag.",
         shot=None),

    # -- Milestone 5: storage, databases, secrets ------------------------------
    dict(id="TC-27", title="Object storage serves real PUT/GET/LIST", area="Storage & Data",
         pre="A bucket in status READY exists.",
         steps="1. PUT an object to the bucket's own HTTP endpoint.\n2. LIST the bucket.\n3. GET the object back.",
         expected="The object is genuinely stored and retrieved byte-for-byte through the bucket's own real HTTP object protocol; it also appears in a real LIST response.",
         shot="tc27_storage"),
    dict(id="TC-28", title="Managed database runs a real Postgres container", area="Storage & Data",
         pre="An active project exists.",
         steps="1. Open Databases.\n2. Create a managed database.\n3. Wait for it to reach READY.",
         expected="A real, dedicated Postgres container is provisioned for the database resource and reaches READY.",
         shot="tc28_databases"),
    dict(id="TC-29", title="Secrets are genuinely encrypted at rest", area="Storage & Data",
         pre="An active project exists.",
         steps="1. Create a secret with a plaintext value.\n2. Inspect what is stored at rest and what the list/get API returns.\n3. Call the dedicated reveal endpoint.",
         expected="The value is stored as real AES-256-GCM ciphertext (verified directly against the database), the ordinary list/get API never exposes it, and only the reveal endpoint (its own separate permission) recovers the exact original plaintext.",
         shot="tc29_secrets"),

    # -- Milestone 6: Kubernetes ------------------------------------------------
    dict(id="TC-30", title="Kubernetes cluster runs real node containers", area="Kubernetes",
         pre="An active project exists.",
         steps="1. Create a Kubernetes cluster with a chosen node count.\n2. Wait for it to reach READY.",
         expected="Real containers are started as cluster nodes on a real, dedicated Docker network, one per requested node.",
         shot="tc30_k8s_cluster"),
    dict(id="TC-31", title="Deployment runs real pod containers", area="Kubernetes",
         pre="A Kubernetes cluster in status READY exists.",
         steps="1. Create a deployment on that cluster with a chosen replica count.\n2. Wait for it to reach READY.",
         expected="A real container is started for each requested replica.",
         shot=None),
    dict(id="TC-32", title="Scaling a deployment adds/removes real pods", area="Kubernetes",
         pre="A deployment in status READY exists.",
         steps="1. Scale the deployment to a higher replica count.\n2. Wait for it to reach READY again.",
         expected="The real number of running pod containers changes to match the new replica count exactly.",
         shot="tc32_k8s_scale"),

    # -- Milestone 8: CI/CD -------------------------------------------------
    dict(id="TC-33", title="Pipeline run executes real sequential stages", area="CI/CD & Images",
         pre="A pipeline with two or more stages exists in status READY.",
         steps="1. Trigger a pipeline run.\n2. Wait for it to finish.",
         expected="A real, ephemeral CI-runner container executes every stage's command in order inside a shared workspace volume, and each stage's real exit code/output/duration is recorded.",
         shot="tc33_cicd"),

    # -- Milestone 9: Observability -------------------------------------------
    dict(id="TC-34", title="Metrics are sampled and stored as a time series", area="Observability",
         pre="A READY instance exists and has been running for at least one metrics-collector cycle.",
         steps="1. Wait roughly 15+ seconds for the background collector to sample.\n2. Query the instance's metrics endpoint for a time range.",
         expected="One or more real `container.stats()` samples, persisted on a genuine interval, are returned as a time series.",
         shot=None),
    dict(id="TC-35", title="A real fault triggers a genuine CRITICAL alert", area="Observability",
         pre="A READY instance exists.",
         steps="1. Inject a real crash fault on the instance.\n2. Wait for the instance to reach FAILED.\n3. Check the Alerts list.",
         expected="A CRITICAL alert is opened, derived from the instance's real observed status (not a simulated event).",
         shot="tc35_alert_open"),
    dict(id="TC-36", title="Recovery genuinely resolves the alert", area="Observability",
         pre="An OPEN alert exists for a crashed instance (from TC-35).",
         steps="1. Start the instance again and wait for it to reach READY.\n2. Resolve the alert.\n3. Re-check the alert's status.",
         expected="The alert's status genuinely transitions to RESOLVED in the database (not just hidden from the UI).",
         shot="tc36_alert_resolved"),
    dict(id="TC-37", title="Request tracing correlates audit + operation by request id", area="Observability",
         pre="A recent action's audit entry and its async operation both exist.",
         steps="1. Find the action's row in the Audit Log.\n2. Look up its trace by the shared request id.",
         expected="The trace endpoint returns the same request's real audit record and async-operation history, correlated purely by the shared request id.",
         shot=None),

    # -- Milestone 10: architecture diagram -------------------------------------
    dict(id="TC-38", title="Architecture renders a real SVG node-link diagram", area="Observability",
         pre="A project has many resources of different types.",
         steps="1. Open the Architecture tab.\n2. Click a node.",
         expected="A layered SVG diagram (one column per resource tier) renders every resource as its own node with real dependency edges; clicking a node highlights it and its direct neighbors.",
         shot="tc38_architecture_svg"),

    # -- Milestone 11: fault injection & troubleshooting -------------------------
    dict(id="TC-39", title="Network fault genuinely blackholes traffic", area="Fault Injection",
         pre="A network in status READY exists.",
         steps="1. Inject a timed blackhole fault on the network.",
         expected="Real iptables DROP rules are installed on the network's bridge and the resource reports DEGRADED with the fault's real expiry recorded.",
         shot="tc39_network_blackhole"),
    dict(id="TC-40", title="A timed fault self-reverts via a real delayed job", area="Fault Injection",
         pre="A blackhole fault is active on a network (from TC-39).",
         steps="1. Wait for the fault's configured duration to elapse.",
         expected="A real scheduled delayed job removes the iptables rules and the network returns to READY on its own, with no manual intervention.",
         shot=None),
    dict(id="TC-41", title="Troubleshoot panel combines history with a live read", area="Fault Injection",
         pre="An instance with some operational history exists.",
         steps="1. Open the instance's detail page.\n2. Click “Run diagnostics”.",
         expected="The panel's response combines the resource's real recorded history with a live, on-demand Docker inspect of its current state.",
         shot="tc41_troubleshoot"),

    # -- Milestone 12: learning system --------------------------------------
    dict(id="TC-42", title="Scenario steps are graded live against real state", area="Learning",
         pre="A project's resources already satisfy every step of the “Networking Fundamentals” scenario.",
         steps="1. Open Learning.\n2. View the scenario's step-by-step progress.",
         expected="Each step is independently re-evaluated server-side against real project state on every view (a READY network, a READY subnet, a READY instance with a real subnet-assigned IP, a READY firewall rule) -- nothing is client-trusted.",
         shot="tc42_learning_progress"),
    dict(id="TC-43", title="Claiming completion re-verifies server-side", area="Learning",
         pre="A scenario's steps all genuinely pass (from TC-42).",
         steps="1. Click “Claim completion”.",
         expected="The server re-checks every step fresh before accepting the claim, and records a real, immutable first-completion timestamp.",
         shot="tc43_learning_claimed"),

    # -- Milestone 13: production hardening -----------------------------------
    dict(id="TC-44", title="CIDR collisions are rejected synchronously", area="Hardening",
         pre="A network already exists with a given CIDR.",
         steps="1. Attempt to create a second network with the exact same CIDR.",
         expected="The request is rejected with 400 before any provisioning operation is even created, naming the specific network it collides with.",
         shot=None),
    dict(id="TC-45", title="Repeated failed logins lock the account", area="Hardening",
         pre="A real user account exists.",
         steps="1. Submit five wrong-password login attempts in a row for the same account.\n2. Submit a sixth attempt.",
         expected="After five genuine failures the account is locked (423), independent of which IP address the attempts came from -- a real, per-account, database-tracked lockout, not just a per-IP throttle.",
         shot="tc45_account_lockout"),
    dict(id="TC-46", title="A request burst hits the real rate limiter", area="Hardening",
         pre="The API is reachable.",
         steps="1. Fire a burst of concurrent login requests well past the per-route limit.",
         expected="Once the configured limit is exceeded, further requests genuinely receive 429 RATE_LIMITED from the real Redis-backed limiter (shared across processes, not an in-memory counter).",
         shot=None),
    dict(id="TC-47", title="The health check pings real dependencies", area="Hardening",
         pre="The API is running.",
         steps="1. Call the health endpoint.",
         expected="The response reflects a genuine live ping of both Postgres and Redis, not a hardcoded “HEALTHY”.",
         shot=None),
    dict(id="TC-48", title="Activity/Audit pagination is real LIMIT/OFFSET", area="Hardening",
         pre="A project has more audit rows than one page holds.",
         steps="1. Request page 1 of the audit log at a small page size.\n2. Request page 2.",
         expected="The two pages return disjoint rows backed by a real Postgres `LIMIT`/`OFFSET` query, with an accurate total count and `hasMore` flag.",
         shot="tc48_pagination"),

    dict(id="TC-18", title="No unexpected UI errors during the full run", area="Regression",
         pre="TC-01 through TC-48 have just been executed back-to-back in one session.",
         steps="1. Monitor the browser console throughout the entire run above.",
         expected="No uncaught JavaScript exceptions and no application-raised console errors occur (expected 4xx/5xx network log lines from the deliberate negative-path tests above are not counted).",
         shot=None),
]

def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))

def nl2br(s):
    return "<br>".join(esc(line) for line in s.split("\n"))

run_date = datetime.fromisoformat(RUN["runAt"].replace("Z", "+00:00")).strftime("%B %d, %Y at %H:%M UTC")
total = len(TEST_CASES)
passed = sum(1 for tc in TEST_CASES if RESULTS_BY_ID[tc["id"]]["status"] == "PASS")

rows_html = []
cards_html = []
for tc in TEST_CASES:
    res = RESULTS_BY_ID[tc["id"]]
    status = res["status"]
    status_class = "pass" if status == "PASS" else "fail"
    rows_html.append(f"""
    <tr>
      <td class="mono">{tc['id']}</td>
      <td>{esc(tc['title'])}</td>
      <td>{esc(tc['area'])}</td>
      <td><span class="pill {status_class}">{status}</span></td>
    </tr>""")

    shot_html = ""
    if tc["shot"]:
        img = b64_img(tc["shot"])
        shot_html = f'<img class="shot" src="data:image/png;base64,{img}">'
    notes = res.get("notes") or ""
    notes_html = f'<div class="notes"><strong>Observed:</strong> {esc(notes)}</div>' if notes else ""

    cards_html.append(f"""
    <div class="case">
      <div class="case-head">
        <div>
          <span class="mono case-id">{tc['id']}</span>
          <span class="case-title">{esc(tc['title'])}</span>
          <span class="area-tag">{esc(tc['area'])}</span>
        </div>
        <span class="pill {status_class}">{status}</span>
      </div>
      <table class="spec">
        <tr><th>Preconditions</th><td>{nl2br(tc['pre'])}</td></tr>
        <tr><th>Steps</th><td>{nl2br(tc['steps'])}</td></tr>
        <tr><th>Expected result</th><td>{nl2br(tc['expected'])}</td></tr>
      </table>
      {notes_html}
      {shot_html}
    </div>""")

HTML = f"""<!doctype html>
<html><head><meta charset="utf-8">
<style>
  @page {{ margin: 20mm 16mm 18mm 16mm; }}
  * {{ box-sizing: border-box; }}
  body {{ font-family: 'DejaVu Sans', Arial, Helvetica, sans-serif; color: #17212b; font-size: 10.5pt; line-height: 1.5; }}
  h1 {{ font-size: 22pt; margin: 0 0 4px; }}
  h2 {{ font-size: 15pt; margin: 26px 0 10px; padding-bottom: 6px; border-bottom: 2px solid #1f6f5c; color: #124b3d; }}
  h3 {{ font-size: 12pt; margin: 16px 0 6px; }}
  p {{ margin: 6px 0; }}
  .cover {{ text-align: center; padding-top: 26mm; page-break-after: always; }}
  .cover .brand {{ font-size: 30pt; font-weight: 700; color: #124b3d; }}
  .cover .brand .dot {{ color: #1f6f5c; }}
  .cover .subtitle {{ font-size: 14pt; color: #444; margin-top: 6px; }}
  .cover .meta {{ margin-top: 40px; font-size: 10.5pt; color: #555; }}
  .cover .meta div {{ margin: 3px 0; }}
  .cover .summary-box {{ display: inline-block; margin-top: 40px; padding: 18px 34px; border: 1px solid #dde3e1; border-radius: 10px; background: #f3f8f6; }}
  .cover .summary-box .big {{ font-size: 30pt; font-weight: 700; color: #1f6f5c; }}
  .cover .summary-box .lbl {{ font-size: 10pt; color: #555; text-transform: uppercase; letter-spacing: .04em; }}
  .section {{ page-break-before: always; }}
  .section:first-of-type {{ page-break-before: auto; }}
  ol, ul {{ margin: 6px 0; padding-left: 22px; }}
  li {{ margin: 4px 0; }}
  code, .mono {{ font-family: 'DejaVu Sans Mono', monospace; font-size: 9.5pt; }}
  .callout {{ background: #f3f8f6; border-left: 3px solid #1f6f5c; padding: 8px 12px; margin: 10px 0; font-size: 10pt; }}
  .callout.warn {{ background: #fbeedd; border-left-color: #a8681c; }}
  table.overview {{ width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 9.5pt; }}
  table.overview th {{ text-align: left; background: #124b3d; color: #fff; padding: 6px 8px; font-size: 9pt; text-transform: uppercase; letter-spacing: .03em; }}
  table.overview td {{ padding: 6px 8px; border-bottom: 1px solid #dde3e1; vertical-align: top; }}
  table.overview tr:nth-child(even) td {{ background: #f7f9f8; }}
  .pill {{ display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 8.5pt; font-weight: 700; letter-spacing: .03em; }}
  .pill.pass {{ background: #d9f0e6; color: #12664f; }}
  .pill.fail {{ background: #fbe1de; color: #9c2c20; }}
  .case {{ border: 1px solid #dde3e1; border-radius: 8px; padding: 12px 14px; margin: 14px 0; page-break-inside: avoid; }}
  .case-head {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }}
  .case-id {{ background: #124b3d; color: #fff; padding: 2px 7px; border-radius: 4px; margin-right: 8px; }}
  .case-title {{ font-weight: 700; font-size: 11pt; }}
  .area-tag {{ margin-left: 10px; font-size: 8.5pt; color: #777; border: 1px solid #dde3e1; border-radius: 999px; padding: 1px 8px; }}
  table.spec {{ width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 8px; }}
  table.spec th {{ width: 130px; text-align: left; vertical-align: top; color: #555; padding: 4px 8px 4px 0; font-weight: 600; }}
  table.spec td {{ padding: 4px 0; vertical-align: top; }}
  .notes {{ background: #eef6ff; border-left: 3px solid #1f5c8f; padding: 6px 10px; font-size: 9.5pt; margin-bottom: 8px; }}
  img.shot {{ width: 100%; border: 1px solid #dde3e1; border-radius: 6px; display: block; }}
  .footer-note {{ margin-top: 30px; font-size: 8.5pt; color: #888; border-top: 1px solid #dde3e1; padding-top: 8px; }}
  .defect {{ border: 1px solid #f0d9a8; background: #fdf6e8; border-radius: 8px; padding: 10px 14px; margin: 12px 0; }}
  .defect h3 {{ margin: 0 0 6px; color: #8a5a10; }}
  .badge-sev {{ font-size: 8.5pt; padding: 1px 8px; border-radius: 999px; margin-left: 8px; }}
  .sev-medium {{ background: #fbeedd; color: #a8681c; }}
  .sev-fixed {{ background: #d9f0e6; color: #12664f; }}
</style></head>
<body>

<div class="cover">
  <div class="brand">Cloud<span class="dot">Lab</span></div>
  <div class="subtitle">Usage Guide &amp; QA Test Report</div>
  <div class="meta">
    <div>A GCP-like console backed by real infrastructure</div>
    <div>Report generated: {run_date}</div>
    <div>Test account used: <span class="mono">{esc(RUN['email'])}</span></div>
  </div>
  <div class="summary-box">
    <div class="big">{passed} / {total}</div>
    <div class="lbl">Test cases passed</div>
  </div>
</div>

<div class="section">
<h2>1. How to Use CloudLab</h2>

<p>CloudLab is a small cloud-platform console that provisions <strong>real</strong>
local infrastructure &mdash; real Docker networks, real containers, a real
interactive terminal &mdash; behind a GCP-like web UI, REST API, IAM system,
and audit log. Nothing shown as &ldquo;running&rdquo; is simulated.</p>

<h3>1.1 First-time setup</h3>
<ol>
  <li>Open the console (default: <span class="mono">http://localhost:4000</span>).</li>
  <li>Click <strong>Register</strong>, enter a name, email, and password (8+ characters), and click <strong>Create account</strong>.</li>
  <li>Create an <strong>Organization</strong> &mdash; this is the top-level container for your projects; you become its Owner automatically.</li>
  <li>Create a <strong>Project</strong> inside that organization. This is where all resources (networks, instances) live.</li>
</ol>

<h3>1.2 Building something</h3>
<ol>
  <li>Open <strong>Networking</strong> and create a VPC network (give it a name; a CIDR is suggested for you). Wait for its status badge to turn from <span class="mono">CREATING</span> to <span class="mono">READY</span> &mdash; this is a real Docker bridge network being created live.</li>
  <li>Open <strong>Compute</strong>, pick the READY network, name an instance, and create it. It provisions a real container, waits for a real health check, and turns READY with a clickable public URL.</li>
  <li>Click into the instance to open its detail page: run one-off commands in the <strong>exec panel</strong>, tail its real logs, or use the <strong>live terminal</strong> for a genuine interactive shell session inside the container.</li>
</ol>

<h3>1.3 Seeing what you built</h3>
<ul>
  <li><strong>Architecture</strong> &mdash; a graph of every resource and how they connect, computed fresh from the database on every visit (never hand-drawn).</li>
  <li><strong>Activity</strong> &mdash; a human-readable timeline of everything that has happened in the project.</li>
  <li><strong>Audit Log</strong> &mdash; every single API call, who made it, and its outcome &mdash; recorded automatically, with no way to opt out.</li>
  <li><strong>IAM</strong> &mdash; the built-in roles (Owner, Admin, Developer, Viewer) and their permission rules, plus who is bound to this project.</li>
</ul>

<h3>1.4 Cleaning up</h3>
<p>Use the <strong>Delete</strong> button on an instance or network row. Deleting a network that still has a live instance attached to it is refused with a clear error &mdash; delete the instance first, then the network.</p>

<h3>1.5 Beyond the basics</h3>
<p>The tabs above cover the essentials; every other tab in the console is backed by the same &ldquo;real infrastructure, never simulated&rdquo; principle:</p>
<ul>
  <li><strong>Subnets, Firewall, DNS, Load Balancers</strong> &mdash; carve a subnet's real sub-range out of a network's CIDR, install real iptables rules, resolve hostnames through a real DNS container, and front instances with a real reverse proxy.</li>
  <li><strong>Disks, Registry &amp; Images</strong> &mdash; attach real Docker-volume-backed disks to an instance, and build container images with a genuine <span class="mono">docker build</span> against your own Dockerfile.</li>
  <li><strong>Storage, Databases, Secrets</strong> &mdash; an object-storage bucket with its own real HTTP PUT/GET/LIST endpoint, a dedicated Postgres container per managed database, and secrets encrypted with real AES-256-GCM that only a dedicated reveal endpoint can decrypt.</li>
  <li><strong>Kubernetes &amp; CI/CD</strong> &mdash; a cluster of real node containers, deployments whose replica count maps to real running pod containers, and pipeline runs that execute each stage's command sequentially inside a real ephemeral CI-runner container.</li>
  <li><strong>Observability &amp; Fault Injection</strong> &mdash; live container metrics on a real collector interval, a real alert lifecycle (open/resolve) driven off actual resource status, request tracing by shared request id, and fault injection (instance crash, network blackhole) that does real damage and, where configured, genuinely self-heals.</li>
  <li><strong>Learning</strong> &mdash; guided scenarios whose steps are graded live, server-side, against your project's real state &mdash; nothing is client-trusted, and claiming completion re-verifies everything first.</li>
</ul>

<div class="callout">Every account starts with the <strong>Owner</strong> role on anything it creates, which can do everything. Additional users can be granted <strong>Admin</strong>, <strong>Developer</strong>, or read-only <strong>Viewer</strong> access to a specific project via the IAM API. Repeated failed logins genuinely lock an account for 15 minutes, and the API itself is protected by a real Redis-backed rate limit.</div>
</div>

<div class="section">
<h2>2. Test Strategy</h2>
<p>Forty-eight test cases were designed to exercise every user-facing capability of CloudLab end to end, across all thirteen build milestones: account creation and authentication (including account lockout and API rate limiting), organization/project setup, real network and compute provisioning (VPCs, subnets, firewall rules, DNS, load balancers, disks), the exec panel and live terminal, container registries and genuine image builds, object storage/managed databases/encrypted secrets, Kubernetes clusters and deployments, a real sequential CI/CD pipeline runner, observability (live metrics, the real alert lifecycle, request tracing), the derived architecture graph, fault injection and self-healing (instance crash, network blackhole with auto-revert), the server-verified learning/scenario system, and IAM role enforcement (including a negative/security case and an access-hiding case).</p>
<p>All forty-eight were executed against the actual running application &mdash; a real PostgreSQL database, a real Redis-backed job queue and rate limiter, a real Docker daemon, and the real worker process &mdash; driven through a headless browser and, where a check is more naturally expressed as a direct API call (e.g. verifying encryption at rest, or a burst of concurrent requests), the same real HTTP endpoints a client would use. A screenshot was captured at each test case's key verification point as evidence; a handful of purely backend checks (e.g. the shape of a health-check response) have no corresponding screen and are marked accordingly.</p>
<p class="callout">Two full-coverage projects are used across the run: the original vertical slice (TC-01&ndash;TC-18) exercises the UI end to end on one project, and a second project (TC-19&ndash;TC-48) is created purely through the API to cover every remaining milestone without re-typing the same UI forms forty more times &mdash; every one of its resources is still verified against genuine backend/infrastructure state, and it is torn down through the real delete API at the end of the run.</p>

<h3>2.1 Results overview</h3>
<table class="overview">
<tr><th>ID</th><th>Test case</th><th>Area</th><th>Result</th></tr>
{''.join(rows_html)}
</table>
</div>

<div class="section">
<h2>3. Test Cases &amp; Execution Evidence</h2>
{''.join(cards_html)}
</div>

<div class="section">
<h2>4. Defects Found During Testing</h2>
<p>Testing across all thirteen milestones surfaced four real application defects, all fixed and re-verified before this report was generated, plus one known UI limitation and one known pagination trade-off left open by design.</p>

<div class="defect">
  <h3>Errors were silently swallowed inside the main console <span class="badge-sev sev-fixed">FIXED</span></h3>
  <p>Every action in the app already captured a failure's message, but the banner used to display it only existed on the pre-login and org/project-picker screens. Once inside a project, a permission denial, a blocked delete, or a failed command produced <em>no visible feedback at all</em> &mdash; the screen looked exactly as if nothing had happened. Found by TC-15. Fixed by showing the same error banner inside the main console layout.</p>
</div>

<div class="defect">
  <h3>Running an exec command erased its own output and reset the live terminal <span class="badge-sev sev-fixed">FIXED</span></h3>
  <p>The exec panel's &ldquo;Run&rdquo; button triggered a full page rebuild on success, which silently discarded the output it had just displayed and reconnected the live terminal's connection underneath the user. Found by TC-07. Fixed by having the exec panel manage its own result display without forcing a page-wide rebuild.</p>
</div>

<div class="defect">
  <h3>A real 429 from the rate limiter came back to clients as a 500 <span class="badge-sev sev-fixed">FIXED</span></h3>
  <p>The Redis-backed rate limiter (Milestone 13) throws a plain object carrying its own <span class="mono">statusCode</span> when a client goes over its limit, rather than the application's own error class. The console's global error handler only recognized that internal error class and coerced everything else to a generic 500 &mdash; so a real, correctly-detected rate-limit violation was reaching the client as an opaque server error instead of 429 RATE_LIMITED. Found by TC-46 (a burst of 62 concurrent login attempts against the per-route limit returned 0 real 429s). Fixed by having the error handler honor a thrown error's own status code for 4xx cases.</p>
</div>

<div class="defect">
  <h3>Launching an instance into a subnet could collide with an existing container's IP <span class="badge-sev sev-fixed">FIXED</span></h3>
  <p>A subnet's address range is carved out of its parent network's own CIDR. The static-IP allocator for a subnet-scoped instance only checked for collisions against <em>other subnet-scoped</em> instances, so a plain instance created directly on the network (letting Docker's own allocator pick anywhere in the network's range) could already be sitting on an address inside the subnet &mdash; and the next subnet-scoped instance's real <span class="mono">docker run</span> then genuinely failed with &ldquo;address already in use&rdquo;. Found by TC-19/TC-42 (the Networking Fundamentals learning scenario's subnet-instance step). Fixed by having the allocator also treat any instance on the same network whose real assigned IP falls inside the subnet's range as taken.</p>
</div>

<div class="defect">
  <h3>Project-only role bindings have no navigation path in the console <span class="badge-sev sev-medium">KNOWN LIMITATION</span></h3>
  <p>The org/project picker only lists projects reached through an organization membership. A user granted access to a single project directly (without also belonging to its organization) &mdash; a binding shape the IAM system fully supports &mdash; currently has no way to browse to that project from the console UI, even though the API serves them correctly (verified in TC-13). Not fixed in this pass; the natural fix is a &ldquo;projects shared with me&rdquo; list once an invite/join flow exists.</p>
</div>

<div class="defect">
  <h3>Offset-based pagination can shift under concurrent writes <span class="badge-sev sev-medium">KNOWN TRADE-OFF</span></h3>
  <p>Activity/Audit pagination (Milestone 13) uses a real Postgres <span class="mono">LIMIT</span>/<span class="mono">OFFSET</span> query rather than a cursor. This is simple and correct for a stable result set, but if new rows are written between reading page 1 and page 2 of the same query, the offset window can shift and a row can appear on both pages (or be skipped). Documented in ROADMAP.md as a deliberate scope simplification rather than fixed with cursor-based pagination in this pass.</p>
</div>
</div>

<div class="section">
<h2>5. Summary</h2>
<p><strong>{passed} of {total} test cases passed</strong> on the final run, after the four defects above were fixed and re-verified with two consecutive clean full-suite runs. No further defects are open other than the known limitations noted above. The application's core promise &mdash; that everything the console shows is backed by real, verifiable infrastructure &mdash; held up under this testing across all thirteen milestones: every &ldquo;READY&rdquo; status corresponded to a genuine running Docker resource (container, network, volume, or service), every blocked action was a genuine, correctly-enforced rule, every encrypted value was genuinely unrecoverable without the reveal endpoint, every fault injected was a real iptables rule or a real killed process, and no failure was ever silently reported as a success.</p>
<div class="footer-note">Generated automatically from a live Playwright-driven test run (scripts/qa-run.mjs) against CloudLab. Screenshots are unedited, full-page captures taken at each test case's assertion point.</div>
</div>

</body></html>
"""

out_path = os.path.join(HERE, "cloudlab_report.html")
with open(out_path, "w") as f:
    f.write(HTML)
print("wrote", out_path, len(HTML), "bytes")

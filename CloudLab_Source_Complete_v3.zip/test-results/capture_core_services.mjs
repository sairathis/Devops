// Captures a clean, focused set of console screenshots showing each of the
// seven "core services" this cross-method lab covers (network, subnet,
// firewall rule, instance, disk, bucket, database) actually created and
// showing real READY status in CloudLab's own web console -- for the
// Services + Creation Methods + Testing report, distinct from (and not
// mixed into) qa-run.mjs's own numbered TC-* screenshot set.
//
// Usage: node test-results/capture_core_services.mjs
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { mkdirSync } from "node:fs";

const SHOT_DIR = "/home/claude/cloudlab/test-results/screenshots-services";
mkdirSync(SHOT_DIR, { recursive: true });

const stamp = Date.now();
const email = `services-report-${stamp}@cloudlab.dev`;
const password = "password123";
const octet = 60 + (stamp % 190);

const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome", args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

async function shot(name) {
  await page.screenshot({ path: `${SHOT_DIR}/${name}.png`, fullPage: true });
  console.log(`captured ${name}.png`);
}

async function callApi(method, path, body, token) {
  return page.evaluate(
    async ({ method, path, body, token }) => {
      const res = await fetch(`/api/v1${path}`, {
        method,
        headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      const text = await res.text();
      return { status: res.status, body: text ? JSON.parse(text) : null };
    },
    { method, path, body, token },
  );
}

async function waitReady(path, id, token, maxSeconds = 60) {
  for (let i = 0; i < maxSeconds * 2; i++) {
    const { body } = await callApi("GET", path, undefined, token);
    const row = body.find((r) => r.id === id);
    if (row?.status === "READY" || row?.status === "FAILED") return row;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`${path}/${id} did not reach READY in time`);
}

try {
  await page.goto("http://localhost:4000/");
  await page.click("text=Register");
  await page.fill('input[name="name"]', "Services Report");
  await page.fill('input[name="email"]', email);
  await page.fill('input[name="password"]', password);
  await page.click('button:has-text("Create account")');
  await page.waitForSelector('input[placeholder="Organization name"]', { timeout: 10000 });
  await page.fill('input[placeholder="Organization name"]', "Services Report Org");
  await page.click('button:has-text("Create")');
  await page.waitForSelector('input[placeholder="Project name"]', { timeout: 10000 });
  await page.fill('input[placeholder="Project name"]', "services-report-project");
  await page.click('button:has-text("Create")');
  await page.waitForSelector("text=Networking", { timeout: 10000 });
  await shot("00_dashboard");

  const token = await page.evaluate(() => localStorage.getItem("cloudlab_token"));
  const projectId = await page.evaluate(() => localStorage.getItem("cloudlab_project"));

  // ---- Network (via the console's own create form) ----
  await page.click("text=Networking");
  await page.fill('input[placeholder="vpc-main"]', "vpc-core-services");
  await page.click('button:has-text("Create network")');
  await page.waitForSelector("td:has-text('vpc-core-services')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 20000 });
  await shot("01_network_created");

  const netRows = (await callApi("GET", `/projects/${projectId}/networks`, undefined, token)).body;
  const networkRow = netRows.find((r) => r.name === "vpc-core-services");
  const networkId = networkRow.id;
  // The console's create-network form takes only a name -- the network's
  // real CIDR is whatever the API assigned by default (Milestone 13's
  // collision check picks a free 172.30.x.0/24), so the subnet must be
  // derived from that real CIDR, not assumed to be some fixed 10.x block.
  const networkCidr = networkRow.spec.cidr; // e.g. "172.30.177.0/24"
  const subnetCidr = networkCidr.replace("/24", "/25"); // first half of the same block

  // ---- Subnet (created via the real API, same session, then shown in-console) ----
  const subnetRes = await callApi("POST", `/projects/${projectId}/subnets`, { name: "subnet-core-services", networkId, cidr: subnetCidr }, token);
  await waitReady(`/projects/${projectId}/subnets`, subnetRes.body.resource.id, token);
  await page.reload();
  await page.click("text=Networking");
  await page.waitForTimeout(500);
  await shot("02_subnet_created");

  // ---- Firewall rule ----
  const fwRes = await callApi(
    "POST",
    `/projects/${projectId}/firewall-rules`,
    { name: "fw-core-services", networkResourceId: networkId, direction: "ingress", action: "ALLOW", protocol: "tcp", portRange: "80", cidr: "0.0.0.0/0" },
    token,
  );
  await waitReady(`/projects/${projectId}/firewall-rules`, fwRes.body.resource.id, token);
  await page.reload();
  await page.click("text=Networking");
  await page.waitForTimeout(500);
  await shot("03_firewall_created");

  // ---- Instance (via console form, attached to the network) ----
  await page.click("text=Compute");
  await page.fill('input[placeholder="web-01"]', "web-core-services");
  await page.click('button:has-text("Create instance")');
  await page.waitForSelector("a:has-text('web-core-services')");
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 30000 });
  await shot("04_instance_created");

  // ---- Disk ----
  const diskRes = await callApi("POST", `/projects/${projectId}/disks`, { name: "disk-core-services", sizeGb: 10 }, token);
  await waitReady(`/projects/${projectId}/disks`, diskRes.body.resource.id, token);
  await page.click("text=Disks");
  await page.waitForTimeout(500);
  await shot("05_disk_created");

  // ---- Bucket ----
  const bucketRes = await callApi("POST", `/projects/${projectId}/buckets`, { name: "bucket-core-services" }, token);
  await waitReady(`/projects/${projectId}/buckets`, bucketRes.body.resource.id, token);
  await page.reload();
  await page.click("text=Storage");
  await page.waitForSelector("td:has-text('bucket-core-services')", { timeout: 10000 });
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 10000 });
  await shot("06_bucket_created");

  // ---- Database ----
  const dbRes = await callApi("POST", `/projects/${projectId}/databases`, { name: "database-core-services" }, token);
  await waitReady(`/projects/${projectId}/databases`, dbRes.body.resource.id, token, 90);
  await page.reload();
  await page.click("text=Databases");
  await page.waitForSelector("td:has-text('database-core-services')", { timeout: 10000 });
  await page.waitForFunction(() => document.body.innerText.includes("READY"), { timeout: 10000 });
  await shot("07_database_created");

  // ---- Architecture view showing all 7 resources connected ----
  await page.click("text=Architecture");
  await page.waitForTimeout(1000);
  await shot("08_architecture_all_services");

  console.log("\nAll core-service screenshots captured successfully.");
} catch (err) {
  console.error("FATAL:", err);
  await shot("fatal_error");
  process.exitCode = 1;
} finally {
  await browser.close();
}

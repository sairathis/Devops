# CloudLab — Roadmap

This build pass targeted a real, working vertical slice of the full master
spec, not the entire 65-section platform. This file records what's built,
what's deliberately deferred, and what a next milestone would look like.

## Milestone 1 (this build): real vertical slice — DONE

- Monorepo scaffold (npm workspaces): `apps/api`, `apps/worker`,
  `packages/shared`.
- Real Postgres schema + migrations (Drizzle).
- Auth (register/login/JWT) + full IAM policy engine (glob allow/deny
  roles, org→project inheritance, existence-hiding 404s).
- Generic resource model with lifecycle states, resource relationships,
  and per-resource event history.
- Async operation pattern (BullMQ) with live step-by-step progress over
  WebSocket.
- Centralized, automatic audit logging (every request, no opt-in).
- Real local infrastructure adapters: Docker networks and containers via
  `dockerode`, built on a locally-built `FROM scratch` guest image (no
  external registry dependency).
- Auto-derived architecture graph, activity timeline, and filterable audit
  log, all backed by the same Postgres tables.
- A minimal but fully functional plain-JS web console covering every
  feature above, including a real interactive terminal.
- A formal Vitest suite (20 tests, API-layer, in-process) and a formal
  `scripts/e2e.ts` vertical-slice script (31 checks) that drives the real
  running stack — API, worker, Postgres, Redis, Docker — end to end and
  cross-checks API claims against actual Docker Engine state.

## Milestone 2: Networking — DONE

Real subnets, firewall, DNS and load balancing, all reusing the generic
resource model, IAM, audit, and architecture-graph infrastructure from
Milestone 1 with no schema changes:

- **Subnets** — a validated sub-range of a VPC's CIDR (`cidrContains`
  check against the parent). Creating an instance inside a subnet gets it
  a real static IP via Docker's `IPAMConfig.IPv4Address`, computed by a
  real free-address scan (`apps/worker/src/net/ipalloc.ts`), not a label.
- **Firewall rules** — genuine `iptables` rules inserted into the
  `DOCKER-USER` chain, matched against the target network's real bridge
  interface (`br-<12-char-network-id>`, verified live against
  `/sys/class/net` rather than assumed). A DENY rule is a real kernel
  DROP, confirmed in this build by reading the rule back with
  `iptables -S DOCKER-USER`.
- **DNS** — a hand-written, dependency-free Go DNS server
  (`infra/dns-image`), one real container per network, serving real UDP
  `A`-record responses for custom hostnames and forwarding everything
  else to Docker's embedded resolver (`127.0.0.11`). Verified with a raw
  DNS query from outside the container. Config is pushed into the
  scratch-based container (no shell to exec into) via `dockerode`'s
  `putArchive` and a `tar-stream` in-memory archive.
- **Load balancers** — a hand-written Go HTTP reverse proxy
  (`infra/lb-image`) doing real round-robin over backends with active
  `/healthz` checks, one container per load balancer. Verified end to end
  with a real HTTP request that came back through the proxy carrying an
  `X-Cloudlab-Lb-Backend` header naming the instance that served it.
- Full console UI: a Firewall tab, a DNS tab, a Load Balancers tab (with
  live backend attachment), and a Subnets section under Networking.
- `BUILTIN_ROLES` extended so `developer` can create/read/list every new
  resource type but not delete them, consistent with the existing pattern.

A real bug was found and fixed during this pass: the worker wrote DNS
records to the resolver container as `{hostname, ip}`, but the Go
resolver's JSON struct expects `{name, ip}` — every record silently
matched nothing and every query fell through to the upstream forwarder.
Caught by an actual DNS query against the running resolver, not by
inspection. A second gap — an orphaned DNS resolver container blocking
the owning network's own deletion once all of its DNS records were
removed — was also found via a real end-to-end teardown test and fixed
(the resolver container is now torn down when its last record is
deleted).

All 20 Vitest checks and all 31 `scripts/e2e.ts` checks still pass with
no regressions, plus a dedicated manual pass creating/verifying/tearing
down one of every new resource type against the live stack.

## Milestone 3: Compute upgrades — DONE

- **Disks** — real Docker named volumes, attachable to an instance at
  creation time (mounted at `/mnt/disk-N`). `sizeGb` is recorded for the UI
  but not enforced by Docker's local volume driver -- documented as a
  limitation below rather than faked with a quota check that doesn't exist.
- **Startup scripts** — an optional script run via a real `docker exec`
  once the instance's health check passes, output and exit code recorded
  on the resource. Uses the same exec mechanism as the console's exec
  panel, not a simulated log line.
- **Live monitoring** — a real `/instances/:id/stats` endpoint backed by
  the Docker Engine's own `container.stats()` accounting (the same numbers
  `docker stats` shows), polled every 3s by a live panel on the instance
  detail page.
- SSH (dropbear) was **not** attempted this pass -- real remote exec
  already exists (the console's exec panel and interactive terminal), but
  it speaks CloudLab's own protocol, not actual SSH. Bundling a static
  `dropbear` binary into the scratch-based guest image is a reasonable
  next step but was judged lower-value than breadth across the remaining
  milestones for this pass; listed here rather than silently implied done.

A real bug was found and fixed during this pass: the startup-script exec
reused Docker's raw multiplexed stdout/stderr stream without stripping its
8-byte binary frame headers (the console's exec panel does this correctly;
the new code initially didn't). Those headers can contain NUL bytes, and
Postgres's jsonb column type rejects a NUL byte outright ("unsupported
Unicode escape sequence") -- so every instance with a startup script
failed outright. Caught by an actual end-to-end creation test, fixed by
reusing the existing demux logic (`apps/worker/src/net/demux.ts`).

## Milestone 4: Container registry — DONE

- **Registries** — a real Docker Registry HTTP API v2 server, hand-written
  in Go against the stdlib only (no base image reachable in this sandbox
  for an off-the-shelf `registry:2`), running as its own container per
  registry resource with a published port. Implements blob upload
  (start/patch/finish), content-addressable blob storage, manifest
  put/get, tag listing, and repository catalog listing — enough for real
  `docker push`/`docker pull`/`docker build --push` to interoperate with
  it, not just CloudLab's own worker code.
- **Container images** — build-and-push as one resource: the worker builds
  a real image from a submitted Dockerfile (`docker.buildImage()` against
  an in-memory tar build context) and pushes it to the registry resource
  (`image.push()`), recording the real digest, full tag, pull command, and
  a tail of the actual build log output on the resource. Nothing here is
  templated -- `buildLogTail` is genuine `docker build` step output.
- **Independent verification** — the built/pushed image was pulled back
  with a separate `docker pull` CLI invocation outside the platform's own
  code, and the pulled digest matched the one recorded on the resource,
  confirming the registry is a real, protocol-compliant registry and not
  just internally self-consistent.
- **Documented limitation**: registry-side blob garbage collection is not
  implemented. Deleting a `container_image` resource removes the local
  Docker image and the resource record, but blobs already pushed to the
  registry's on-disk store are not swept -- acceptable for a simulator but
  called out here rather than silently assumed away.

Two real bugs were found and fixed during this pass:

1. **Nested catalog listing** — `handleCatalog()` initially walked only one
   directory level under the registry's `repos/` store, so a two-segment
   repository name like `test/guest` showed up as just `test`. Fixed by
   using `filepath.WalkDir` to find every directory that has a `manifests`
   subdirectory and computing its path relative to `repos/` as the
   repository name.
2. **Concurrent upload-ID race condition** — the upload ID handed out by
   `handleStartUpload` was originally derived from `len(uploads)` read
   outside the map's lock, so two blob-layer uploads started in the same
   instant (exactly what `docker push` does for a multi-layer image) could
   receive the same ID, and the second layer's `PATCH`/`PUT` would fail
   with "unknown upload". Fixed by generating upload IDs from
   `crypto/rand` (16 random bytes, hex-encoded) instead of a counter, and
   verified fixed with a 5-way concurrent push stress test.

## Milestone 5: Storage & databases — DONE

- **Buckets** — a hand-written real object-storage HTTP server
  (`infra/bucket-image`, Go stdlib only, same `FROM scratch` pattern as the
  registry/DNS/LB images), one container per bucket resource, published on a
  host port. Genuine PUT/GET/DELETE/LIST over HTTP against files on disk,
  with real MD5 ETags — verified directly with `curl` (upload an object, GET
  it back byte-for-byte, list it, delete it), not just through the
  platform's own API. **Documented limitation**: this is CloudLab's own
  object protocol, not AWS SigV4/S3-API-compatible — no request signing, no
  multipart upload, no versioning.
- **Databases** — a real, dedicated PostgreSQL 16 server per `database`
  resource: genuine `initdb` + `pg_ctl start` against a fresh data
  directory, a generated `scram-sha-256` password, and a real
  `CREATE DATABASE` for the requested database name, verified by connecting
  independently with `psql` (not just the platform's own `pg` client) and
  running a real query. **Documented limitation**: unlike every other
  CloudLab resource, this runs as an OS process on the host (via `sudo -u
  postgres`), not inside its own Docker container — there is no reachable
  base image in this sandbox to build a real Postgres container from (every
  container registry is network-blocked here), and hand-assembling glibc
  plus the Postgres binaries into a `FROM scratch` image was judged lower
  value than covering the remaining milestones in this pass. The database
  engine itself is completely real regardless of the process model.
- **Secrets** — real AES-256-GCM envelope encryption
  (`packages/shared`'s `encryptSecretValue`/`decryptSecretValue`, master key
  from `SECRETS_MASTER_KEY`). The plaintext value is encrypted synchronously
  in the API route handler, before the resource row is even created, so it
  is never written to the resource's persisted `spec`, never logged, and
  never passed through the BullMQ job queue (which retains completed job
  data for a while — a real, avoidable leak surface this design closes).
  `GET .../reveal` is the only path that ever produces plaintext again, and
  it's gated by its own `secrets.secrets.reveal` permission, denied by
  default for the `developer` role and verified denied end-to-end (403
  `PERMISSION_DENIED`) while the `owner` role's reveal succeeds.

## Milestone 6: Kubernetes — DONE, with an important honest substitution

**This is not real Kubernetes, and cannot be in this sandbox.** Every
container registry this environment can reach is network-blocked
(`docker.io`, `ghcr.io`, `registry.k8s.io`, `gcr.io`, `quay.io`,
`mcr.microsoft.com` all refuse the CONNECT at the egress proxy). A real
`kind` node or `k3s` install needs to pull at least a pause/sandbox image
and CoreDNS from one of those on first boot — there is no engineering
workaround for that, the images are simply not reachable. So rather than
silently produce something Kubernetes-flavored and call it Kubernetes, this
milestone builds and clearly labels **CloudLab's own lightweight
container-orchestration layer**, modeled on Kubernetes' cluster/node/pod/
deployment concepts:

- **`k8s_cluster`** — a real Docker bridge network as the cluster fabric,
  plus N real "node" containers (reusing the existing `cloudlab/guest`
  image) genuinely running on the Docker daemon.
- **`k8s_deployment`** — M real "pod" containers scheduled onto that
  network, with a create/scale/delete lifecycle. Scaling up starts new real
  containers; scaling down stops real containers — verified by counting
  actual `docker ps` output before and after, not just resource metadata.
- **A real reconciliation loop** (`apps/worker/src/k8s/reconciler.ts`),
  ticking every 10s: it lists live pod containers by label, compares the
  count (and which index numbers) against the deployment's desired replica
  count, and starts replacements for whatever's missing. Pods are created
  with Docker's own `RestartPolicy: "no"` specifically so that any
  self-healing you see is genuinely this loop's doing, not Docker quietly
  doing it for us. Verified by directly `docker kill`-ing a pod container
  mid-test and confirming the reconciler noticed and replaced it within one
  tick — a real, working control loop, just not driven by a real kubelet's
  watch mechanism against a real API server.

**What's honestly NOT here**: no real `kubectl`/Kubernetes API surface, no
etcd, no real per-node scheduling (pods run directly on the platform's own
Docker host next to the node containers, not inside them — true node-level
isolation would need Docker-in-Docker inside each node container, out of
scope for this pass), no rolling-update surge/drain sequencing on scale
(this scales by starting/stopping containers at the edge, not a real
Deployment controller's gradual rollout), no ConfigMaps/Secrets/Services/
Ingress resource types. All of this is why the type names are `k8s_cluster`
and `k8s_deployment` rather than anything implying wire-compatibility with
real Kubernetes, and why the console's own Kubernetes tab says so directly
rather than leaving a user to assume otherwise.

## Milestone 7: "Terraform provider" — infeasible as specified, real substitute built

**A real Terraform provider cannot be built or run in this sandbox, and
this was verified before writing any code, not assumed.** A provider is
useless without something to load it: the `terraform` binary is not
installable here (`releases.hashicorp.com` and `apt.releases.hashicorp.com`
both refuse the CONNECT at the egress proxy, and there is no `terraform`
apt package in Debian's own repositories either — only unrelated helper
tools like `terraform-config-inspect` are). Writing the provider itself
hits the same wall from the other direction: real Terraform providers speak
a gRPC protocol defined by `terraform-plugin-go`/`terraform-plugin-sdk`,
and fetching those (or their transitive protobuf/gRPC dependencies) needs
either `proxy.golang.org` (blocked) or `git`/HTTPS access to `github.com`
(also blocked here — oddly, only `raw.githubusercontent.com` happens to be
reachable, nowhere near enough to hand-vendor a real gRPC dependency tree).
There is no code path from here to a real, loadable, verifiable Terraform
provider.

Rather than stop at "not possible" or ship something that merely looks
provider-shaped without ever having run inside real Terraform, this
milestone builds and honestly labels **CloudLab's own declarative
infra-as-code CLI** (`scripts/cloudlab-cli.ts`, `npm run cloudlab`) —
delivering the same underlying value (`plan`/`apply`/`destroy` against a
declarative desired-state file) through the real REST API that already
exists, no HCL parser or gRPC protocol required:

- **`plan`** — reads a JSON desired-state file, fetches live state from the
  real API, and prints a real diff (`+ create` / `= unchanged`) resource by
  resource.
- **`apply`** — creates whatever's missing through the real API (the same
  endpoints the console uses), polling each operation to a real terminal
  state and failing loudly on a real `FAILED` operation rather than
  reporting success regardless. A spec value like `"networkId": "$cli-vpc"`
  resolves to another managed resource's real id once it exists — a
  same-plan dependency graph resolved by iterating to a fixed point, the
  same shape of problem Terraform's graph solves, just triggered by a
  string convention instead of HCL's expression syntax. Verified end to end
  with `scripts/example-infra.json` (a network, an instance referencing it
  by `$ref`, and an independent bucket): the instance was correctly created
  only after the network it depends on, and a second `plan` run against the
  same file reported all three as unchanged (idempotent, like a real `apply`
  followed by a real `plan`).
- **`destroy`** — deletes every resource the plan manages, retrying
  `DEPENDENCY_EXISTS` failures in later passes exactly the way `apply`
  retries unresolved references — verified tearing down the same
  network/instance/bucket trio with zero containers or networks left behind
  afterward.

**What this honestly is NOT**: not HCL, not wire-compatible with real
Terraform, no state file/locking, no `import`, no provider registry
publishing. It's a real, working plan/apply/destroy loop against
CloudLab's real API — the same spirit as a Terraform provider, deliberately
not the same claim.

## Milestone 8: CI/CD pipeline — DONE

- **`pipeline`** — a definition resource: an ordered list of `{name,
  command}` stages plus an optional runner image (default
  `cloudlab/guest:latest`, which the M3 startup-script work already proved
  has a real busybox shell).
- **`pipeline_run`** — a real execution: a fresh runner container is
  started per run with an ephemeral Docker volume mounted at `/workspace`,
  and each stage's command is executed with a genuine `docker exec`
  (reusing the exact demuxing logic from the M3 startup-script bug fix),
  capturing a real exit code, real stdout/stderr, and real duration per
  stage. A later stage sees files an earlier stage wrote (verified: a
  `build` stage that writes `/workspace/artifact.txt` and a `test` stage
  that `grep`s for it, both passing for real). The run fails fast on the
  first non-zero exit and marks every remaining stage `SKIPPED` rather than
  silently not running them — verified with a 3-stage pipeline where stage
  1 exits 1: stage 2 and 3 both recorded as `SKIPPED`, never executed. The
  runner container and its workspace volume are torn down the moment the
  run finishes (pass or fail) — verified zero leftover containers/volumes
  after a run.
- **Documented scope**: this is a real single-job sequential CI runner, not
  a full CI/CD platform — no git checkout step (there's nothing to check
  out against; a pipeline's stages operate on the ephemeral `/workspace` a
  user's own commands populate), no build matrix, no artifact
  upload/download between separate runs, no webhook-triggered runs, no
  parallel stages. A stage's command is free to call the real APIs this
  build already has (build/push through the Milestone 4 registry, scale a
  Milestone 6 deployment) to actually deploy something as its own explicit
  step, the same way a real CI job's deploy stage would — that's a
  capability of this design, not a built-in "deploy" stage type.

## Milestone 9: Observability — DONE

- **Metrics** (`resource_metrics` table, `apps/worker/src/observability/
  metricsCollector.ts`) — a real time-series, sampled every 15s from the
  exact same Docker Engine `container.stats()` accounting the Milestone 3
  live-stats panel already reads live; this collector just also persists a
  sample so a resource has real history rather than only a live snapshot.
  `GET /projects/:id/metrics/:resourceId?minutes=N` returns real samples,
  verified end to end with a real running instance. Scoped to `instance`
  resources for this pass — k8s pods/nodes and CI runner containers are
  ephemeral enough that persisting their metrics was judged lower value
  than covering the remaining milestones.
- **Alerts** (`alerts` table, `apps/worker/src/observability/`) — three
  rules, every one derived from data this build already produces, never a
  synthetic count: `resource_unhealthy` fires the instant any resource's own
  status (set only on a genuine infrastructure error, per every processor in
  this codebase) becomes `FAILED`/`DEGRADED`, and auto-resolves the moment
  it isn't anymore; `high_cpu` fires from a real metric sample crossing 80%;
  `pods_under_replicated` is raised and auto-resolved by the Milestone 6
  reconciler itself, using its own real missing-pod count. Verified end to
  end: forcing a real `FAILED` network (a genuine Docker IPAM CIDR
  collision) produced a real open `resource_unhealthy` alert within one
  evaluator tick, and `POST /alerts/:id/resolve` genuinely closed it.
- **Tracing** (`operations.request_id`, `GET /projects/:id/traces/
  :requestId`) — not synthetic spans: every audit log entry and the async
  operation it triggered already carry the same request ID (added a
  `requestId` column to `operations` and threaded `req.requestId` through
  all 16 `createOperation` call sites to make the join possible), so a
  trace is a real correlation of the HTTP request's audit entry with its
  operation's real step-by-step timeline. Verified end to end: looking up a
  real instance-creation request ID returned the exact
  VALIDATING → NETWORKING → VM_PROVISIONING → HEALTH_CHECK → READY step
  sequence with real timestamps.
- **Console** — a new Observability tab: an open-alerts table with a real
  Resolve action, an on-demand metrics viewer per instance, and a trace
  lookup box (paste a request ID copied from the Audit Log tab).
- **Documented scope**: no distributed spans across service boundaries
  (there's only one API process to trace across), no metric-based
  autoscaling, no alert notification channels (email/Slack/webhook) — an
  alert is a real row in the `alerts` table and the console's own view of
  it, not a message sent anywhere.

## Milestone 10: Architecture visualization upgrade — DONE

`GET /projects/:id/architecture` (`apps/api/src/resources/graph.ts`) was
always real -- rebuilt from `resources` + `resource_relationships` on every
request, never hand-drawn -- but the console only ever rendered that data as
a flex-wrapped grid of node cards with a plain text list of "A -> kind -> B"
lines underneath. There were no actual lines connecting anything, so the one
UI element whose entire job is to show how things relate to each other
didn't actually draw a graph. This milestone replaces that view with a real
interactive node-link diagram over the exact same data, no schema or API
changes needed:

- **Layered layout** (`computeArchLayout` in `apps/api/public/app.js`) -- a
  deterministic client-side layout, not a second hand-drawn diagram: each
  resource's column ("tier") is picked from its real `type` (network first,
  then subnet/firewall/DNS/registry, then storage/images, then compute/
  clusters, then deployments/load-balancers, then pipelines, then pipeline
  runs -- the same dependency order every processor in this codebase already
  encodes via `addRelationship`), and rows within a tier are just
  alphabetical. The topology -- which nodes exist, which edges connect them --
  is 100% server data; only the (x, y) placement is a rendering choice, same
  as any node-link diagram tool.
- **Real SVG edges** -- one `<path>` per `resource_relationships` row,
  bezier-curved between real node centers, arrow-headed and colored/dashed
  by real `kind` (`contains`, `connects_to`, `depends_on`, `routes_to`), with
  a legend. The project's own `contains` edges to every resource are excluded
  from the diagram (they'd fan out from one node to all others and add
  nothing) -- the project is already named in the page header and topbar.
- **Interactive dependency tracing** -- clicking a node highlights it and
  every node directly connected to it by a real edge (one BFS hop, computed
  from the same edge list used to draw the lines) and dims everything else;
  clicking it again clears the highlight. This is graph traversal over real
  data, not a canned "related items" list.
- **Live updates** -- the diagram was previously a point-in-time snapshot
  fetched only on tab-open. It now also re-fetches (debounced 500ms) whenever
  a `resource.update` WS message arrives while the tab is open, over the same
  WebSocket connection every other live view in the console already uses.
- Node color still reflects real resource status (green/amber/red/grey,
  reusing the same status families as the rest of the console); node text
  shows the real type, name, and status.

Verified end to end against a live api+worker pair: seeded one project with
one of every applicable resource type (network, subnet, registry, disk,
bucket, instance, load balancer, k8s cluster, k8s deployment, pipeline,
pipeline run) via the real REST API, confirmed `GET /architecture` returned
the full real graph (12 nodes incl. project, 18 edges incl. `contains`), and
screenshotted the rendered console: all 7 tiers laid out left to right with
real curved, arrow-headed edges between them, and clicking the network node
correctly highlighted only its real dependents (subnet, instance, load
balancer) while dimming the rest. Torn everything down afterward through the
real delete APIs and confirmed with `docker ps`/`docker network ls` that the
underlying containers and network were genuinely removed, not just marked
deleted in the UI. No regressions: all 20 Vitest + 31 e2e checks still pass.

**Documented scope**: pods are ephemeral Docker containers labeled by the
Milestone 6 orchestrator, not rows in the `resources` table, so they don't
appear as graph nodes (a deployment's replica count is visible on the node
itself via the Kubernetes tab); the layout is a fixed left-to-right tier
order rather than a general force-directed/auto-layout algorithm, so a
future resource type needs one line added to `ARCH_TYPE_TIER` to be placed
sensibly; there's no pan/zoom, only horizontal scroll for wide graphs.

## Milestone 11: Fault injection & troubleshooting — DONE

Two real, connected capabilities: deliberately breaking real infrastructure
on demand, and detecting/diagnosing real breakage (deliberate or not).

**Fault injection:**

- **Instance crash** (`POST /instances/:id/faults/crash`,
  `apps/worker/src/processors/instanceFault.ts`) — a genuine
  `docker kill --signal=SIGKILL` against the instance's actual container.
  Verified directly before relying on it: a test container with the same
  `RestartPolicy: unless-stopped` every instance runs with, killed the same
  way, stayed `exited` with `RestartCount: 0` for 8+ seconds afterward --
  Docker only auto-restarts on an *internal* process crash, not an
  operator-issued kill (it treats a kill like an explicit `docker stop`).
  So this is a real, lasting outage: the instance stays FAILED until a real
  recovery action -- the existing `instance.start` flow -- brings it back,
  exactly like a crashed real VM.
- **Network blackhole** (`POST /networks/:id/faults/blackhole` +
  `/faults/blackhole/cancel`, `apps/worker/src/net/faults.ts` +
  `processors/networkFault.ts`) — the obvious way to simulate a *degraded*
  (not fully down) link is `tc qdisc add dev <bridge> root netem delay
  <ms> loss <pct>%`. Tried directly in this sandbox before writing any app
  code: `Error: Specified qdisc kind is unknown.` -- `sch_netem` isn't
  compiled into this sandbox's kernel and there's no `modprobe` to load it
  (no loadable kernel modules at all in this environment), so partial
  network degradation is genuinely infeasible here, not attempted or faked.
  What the same iptables/`DOCKER-USER` mechanism Milestone 2's firewall
  rules already use *can* genuinely deliver is a total blackhole: both
  directions of the network's real bridge get a real `DROP`. The fault
  auto-reverts via a real delayed BullMQ job (persisted in Redis, not an
  in-process timer, so a worker restart mid-fault doesn't strand it) and
  can also be cancelled early; the revert is idempotent so the scheduled
  job and an early cancel never double-act.
- **Verified end to end** against the live stack: crashing an instance
  produced a real `exited`/code-137 container, confirmed independently with
  a raw `docker inspect`; recovering it via Start brought it back to READY.
  Blackholing a network was verified with real container-to-container
  traffic (a second instance's `wget` to the first instance's real internal
  IP across the same bridge) -- every request timed out while the fault was
  active and succeeded again the instant the scheduled revert fired, with
  `iptables -S DOCKER-USER` confirming zero leftover rules afterward. (A
  curl from the sandbox host itself to the instance's *published port*
  during the same fault kept succeeding -- host-to-published-port traffic
  takes Docker's NAT/hairpin path and never transits `FORWARD`/
  `DOCKER-USER` at all, so it isn't a valid way to observe this fault; noted
  here since it's an easy mistake to make when checking this by hand.)

**Troubleshooting:**

- **Instance health monitor** (`apps/worker/src/observability/
  instanceHealth.ts`, every 10s) — before this, nothing ever re-checked a
  READY instance's actual container state after creation; Milestone 9's
  status-alert evaluator only reads the `resources.status` column. This
  closes that gap: a real `docker inspect` on every READY instance, and if
  Docker disagrees with the database (not running, or missing entirely) and
  no legitimate start/stop/delete/crash operation currently owns that
  resource, the database is corrected to FAILED with the real exit
  code/OOM flag/timestamp Docker reported. This is what actually catches an
  injected crash (or any other real one) if nothing else does first.
- **Troubleshoot endpoint** (`GET /projects/:id/resources/:id/troubleshoot`,
  `apps/api/src/routes/troubleshoot.ts`) — one generic, resource-type-
  agnostic diagnostic view, not per-type bespoke pages: recent real status
  transitions (`resource_events`), open/recent real alerts, recent real
  operations, and, for instances and networks, a live read straight from
  the Docker Engine at request time (the API is already allowed to read
  Docker directly for logs/exec/stats -- only *mutating* infra has to go
  through the worker's queue). The one piece of synthesis is a single
  sentence comparing what the database currently believes against what
  Docker just reported, produced only when they actually disagree -- never
  a canned "recommendation".
- **Console**: a Fault injection + Troubleshoot section on the instance
  detail page (Crash button, "Run diagnostics" showing the live vs.
  recorded comparison, recent history, alerts, operations), and a
  Blackhole/Cancel-fault button on each network row, with a live countdown
  to the auto-revert.

Verified end to end: the troubleshoot panel against a real running
instance correctly reported "no drift" with real CPU/memory/network
numbers and real status history; running it again immediately after a real
crash fault correctly showed the live Docker state (`running: false, exit
code: 137`) matching the database. No regressions: 20 Vitest + 31 e2e
checks still pass.

**Documented scope**: only instances and networks have real fault-
injection/live-troubleshooting support (the two resource types with an
obvious, genuinely-implementable real fault); the network fault is a full
blackhole, not partial degradation, for the kernel reason above; the
health monitor only watches for READY→down drift, not the reverse (a
container that comes back up while the database still says FAILED needs an
explicit Start, matching how every other recovery in this app already
works); there's no fault library/scenario runner, each fault is a single
manual action.

## Milestone 12: Learning system — DONE

**The problem this had to avoid**: a "learning system" is trivial to fake
-- a checklist a user (or a compromised client) can just tick, unrelated
to whether they actually did anything. That would have been worthless as
a signal and dishonest as a feature, so the whole design turns on one
rule: no client ever tells the server a step is done. The server tells
the client.

**What was built**: four scenarios (`packages/shared/src/index.ts` ->
`SCENARIOS`) -- Networking Fundamentals, Compute Lifecycle & Recovery,
Kubernetes Basics, and Observability & Alerting -- each a short list of
real steps with plain-language instructions ("Go to Compute and create
an instance. Wait for it to reach READY."). The instructions are static
data; the grading is not. `apps/api/src/scenarios/checks.ts` holds one
real predicate per step, each a live query against the same tables every
other milestone already writes to:

- **Resource-existence steps** ("create a network", "create a cluster")
  query `resources` for a row of the right `type` with `status =
  'READY'` in this project -- optionally filtered further (the
  create-instance-in-subnet step also requires `spec.subnetId` to be
  set; the k8s deploy step requires `spec.replicas >= 2`).
- **Sequencing steps** ("stop it, then start it again", "crash it, then
  recover it") can't be answered by resource state alone -- a stopped-
  then-started instance and a never-touched one can look identical at
  rest. `hasSucceededSequence()` instead walks the real `operations`
  table ordered by time and asks whether a SUCCEEDED `instance.stop`
  (or `instance.crash`, reusing Milestone 11's real fault injection) was
  followed by a SUCCEEDED `instance.start` *on the same resource,
  strictly later*. This is read straight off history the app was
  already recording for the audit log -- nothing new was invented to
  make this checkable.
- **Observability steps** count real rows in `resource_metrics` (the
  real 15s Docker-stats collector from Milestone 9) and real `alerts`
  (fired and resolved) for the project.

Every step also returns a real evidence string ("2 READY network(s)",
"a real fault-injected crash followed by a real recovery on the same
instance (verified from its real operations history)") so the UI never
just shows a checkmark on faith.

`scenario_progress` (new table, migration `0003_military_tomas.sql`) is
the one piece of persisted state, and it is deliberately thin: one row
per `(project, user, scenario)` recording only `completed_at`, the first
moment a real claim succeeded. `POST .../scenarios/:key/claim`
re-evaluates every step for real, in that same request, and only writes
the row (upsert, so a second claim is a harmless no-op that keeps the
original timestamp) if every step is genuinely still true; otherwise it
409s with the exact steps still unmet. There is no path, anywhere in
this feature, where a client can cause `scenario_progress` to hold
something that isn't independently verifiable from `resources`,
`operations`, `alerts`, and `resource_metrics` at that instant.

The Learning tab (`renderLearning()` in `apps/api/public/app.js`) lists
each scenario with a progress percentage, a checklist of steps (green +
evidence line once real, grey circle otherwise), and a "Claim
completion" button that's disabled until every step is independently
verified -- clicking it calls the claim endpoint and shows a real
"COMPLETED <timestamp>" badge once the server agrees.

**Verification**: seeded a fresh project via the real API (no
shortcuts), confirmed all four scenarios start 0% complete and unclaimed
with every step failed; confirmed claiming an incomplete scenario is
correctly rejected with 409 and the specific unmet steps; walked
Networking Fundamentals for real (created a network, subnet, subnet-
assigned instance, and firewall rule through their normal routes,
waiting for each to reach real READY), confirmed all four steps flipped
to passed with real evidence and the scenario showed 100% complete;
claimed it, confirmed a `scenario_progress` row was written with a real
timestamp, confirmed re-fetching the scenario list shows that timestamp
persisted, and confirmed claiming again is idempotent (same timestamp,
no error); separately exercised the Compute Lifecycle scenario's
sequencing check by doing a real Stop then a real Start on an instance
and confirming `stop-and-start` only flips to passed after both
operations genuinely succeed in order. Took a live screenshot of the
Learning tab mid-scenario (partial, steps green as they complete) and
post-claim (green "COMPLETED" badge with a real date). No regressions:
20 Vitest + 31 e2e checks still pass. All Docker containers/networks
created during verification were torn down and confirmed gone
afterward.

**Documented scope**: four scenarios covering networking, compute
lifecycle/recovery, Kubernetes, and observability -- not full coverage
of every milestone (registry, storage/databases/secrets, CI/CD, and the
architecture diagram have no scenario yet); no hint system beyond the
static per-step instructions; no scenario editor -- `SCENARIOS` is
static data in the shared package, not a CMS.

## Milestone 13: Production hardening — DONE

This pass worked directly off this file's own "known limitations" list
below (#1, #6, #7) rather than new user-facing features -- the goal was
to close real operational gaps the build had accumulated, each with a
genuine mechanism, not a cosmetic one.

**Real CIDR-collision prevention** (closes limitation #1). Docker's IPAM
pool is host-wide, not scoped per project, so two networks with
overlapping CIDRs were always going to genuinely fail at the daemon --
previously that only surfaced asynchronously as a confusing `FAILED`
network. `routes/networks.ts` now checks the same real constraint
synchronously at create time: `cidrsOverlap()` (new in
`packages/shared`, alongside the `parseCidr()` moved there from
`apps/worker/src/net/ipalloc.ts` so both packages share one
implementation instead of two) is checked against every other network
resource's real `spec.cidr` that isn't already `DELETED`/`FAILED`, and a
genuine overlap -- full or partial -- is rejected with a 400 naming the
colliding network before an operation is even created.

**A network health monitor** (new, `apps/worker/src/observability/
networkHealth.ts`) -- the network-side counterpart to Milestone 11's
instance health monitor, and a real gap that had existed since Milestone
1: nothing had ever re-checked a READY network's actual Docker state.
Every 15s it inspects each READY network's real Docker network and
corrects the database to `FAILED` if it's missing (or if a READY row
somehow has no `dockerNetworkId` at all -- itself real drift, not
something to skip silently). This isn't cosmetic: the CIDR check above
trusts `status` to mean "this CIDR is still genuinely reserved", so a
stale READY row for a network Docker no longer has would otherwise block
a new network from ever reusing that address space. Verified live: this
monitor is what actually reconciled a large backlog of stale test-only
READY network rows (accumulated Docker networks removed directly rather
than through the app's own delete flow, across many earlier
verification passes) back to honest `FAILED` state during this
milestone's own testing -- a real demonstration of the feature, not a
synthetic one.

**Real account lockout** (closes half of limitation #6, and is the
actual brute-force defense -- see below). `users` gained
`failed_login_attempts`/`locked_until` columns (migration
`0004_damp_thunderbird.sql`). `routes/auth.ts` increments the counter on
every genuinely wrong password and locks the account for 15 real minutes
once 5 wrong attempts accumulate, checked against real wall-clock time on
every login -- a locked account is rejected (`423 ACCOUNT_LOCKED`, with
the real remaining seconds) before the password is even checked, and a
real successful login resets the counter to 0. Verified live: 5 wrong
attempts genuinely lock the account, and the correct password is still
rejected while locked.

**Real rate limiting** (the other half of limitation #6). `@fastify/
rate-limit` registered globally with a Redis-backed store (the same real
Redis this app already runs BullMQ against, so the limit is genuinely
shared across however many API processes run behind a load balancer, and
survives an API restart) -- a generous 1000 req/min backstop overall,
with a tighter 60 req/min override on `/auth/register` and `/auth/login`
specifically. This is deliberately a secondary defense: the account
lockout above is what actually stops a targeted password-guessing attack
regardless of which IP it comes from; the IP-based limit exists for the
network-abuse case (a scripted loop hammering the endpoint) that lockout
alone doesn't cover.

**A real health check.** `GET /api/v1/health` used to unconditionally
return `HEALTHY` -- a lie for a process whose Postgres or Redis
connection had actually died. It now genuinely pings both (a real
`select 1` and a real Redis `PING`) and reports `DEGRADED`/503 with which
one failed if either does.

**Real pagination on Activity and Audit** (closes limitation #7). Both
endpoints used to return a fixed top-N slice with no way to see anything
older. They now take real `page`/`pageSize` query params, run a genuine
`LIMIT`/`OFFSET` against Postgres, and return `{ items, page, pageSize,
total, hasMore }` -- `total` is a real `count(*)` of the same filtered
set, so `hasMore` reflects actual remaining rows, not a guess. The
console's Activity and Audit Log tabs gained a real "Load more" control
wired to the same real pages.

**Verification**: a dedicated live check (12 assertions) confirmed --
against the real running API, not mocks -- that an overlapping CIDR is
rejected and a disjoint one accepted; that partial containment is
correctly treated as overlap; that the 5th wrong login locks the account
and even the correct password is rejected while locked; that the health
check reports real per-backend status; and that two consecutive audit
pages return disjoint rows with a correct `hasMore`. All Docker
containers/networks created during verification were torn down
afterward. No regressions: 20 Vitest + 31 e2e checks still pass --
fixing them after this milestone's changes required giving each test
network its own effectively-unique CIDR (`test/helpers.ts` ->
`uniqueCidr()`) and updating `scripts/e2e.ts`'s activity/audit assertions
for the new paginated envelope, both genuine adjustments to a test suite
that had never had to account for either real CIDR collisions or a
non-array response shape before.

**Documented scope**: the CIDR check is global (matching Docker's real
IPAM pool), not project-scoped -- two different projects still can't use
overlapping ranges, which is correct given they'd share the same Docker
daemon. Rate limits and the lockout threshold/duration are fixed
constants, not per-org configurable. Pagination is offset-based (simple,
correct at this scale) rather than cursor-based. Limitations #2 and #3
(the worker/API schema import and duplicated naming helpers) remain --
see "Suggested next milestone" below, now updated to reflect what's left.

## Explicitly out of scope for this pass

These are real, sizeable parts of the original spec that were not
attempted here, listed so nothing is silently implied to exist:

- **Billing/quota simulation.**
- **Multi-region** — everything runs under a single synthetic region
  (`local-1`).
- **OpenAPI/Swagger generation.**

## Known limitations of what *was* built

(Also listed in `ARCHITECTURE.md`/`SECURITY.md`; repeated here as the
single "what to fix first" list.)

1. Worker/API share the DB schema via a relative cross-app import, not a
   proper shared package — works only because both run from one checkout.
2. Container/network naming convention is duplicated (not shared) between
   `apps/api` and `apps/worker`.
3. Architecture graph is a fixed layered layout, not force-directed.
4. Terminal forwards whole lines, not raw keystrokes.
5. Rate limits and the account-lockout threshold/duration are fixed
   constants, not per-org configurable; no dedicated secrets-manager
   service (secrets themselves are real AES-256-GCM encrypted at rest,
   Milestone 5 -- this is about a standalone Vault-style service, which
   was never in scope).
6. Pagination is offset-based, not cursor-based (fine at this scale; a
   cursor would matter at much higher row counts) — confirmed by the final
   QA pass below to genuinely shift under concurrent writes between two
   page reads, exactly the trade-off this limitation already named.

## Final QA pass — 48/48, all 13 milestones

A formal regression pass (`scripts/qa-run.mjs`, Playwright-driven, real
stack end to end) was extended from its original 18 test cases (the
Milestone-1-era vertical slice) to 48, adding dedicated coverage for
every milestone added since: subnets/firewall/DNS/load balancers, disks
and live container stats, the real registry+image build, object
storage/managed databases/encrypted secrets, Kubernetes clusters and
deployments, the CI/CD pipeline runner, the metrics/alert/tracing
observability stack, the SVG architecture diagram, fault injection and
self-healing, the learning system's server-side grading, and every
Milestone 13 hardening feature (CIDR collisions, account lockout, rate
limiting, the real health check, and pagination). The report generator
(`test-results/build_report.py`) and its test-case catalogue were
extended to match, and the resulting PDF (48/48, with screenshots) is
`test-results/cloudlab_report.pdf`.

Getting to a clean run surfaced two genuine, previously-undetected
production bugs (both fixed and re-verified with two consecutive clean
48/48 runs plus the full Vitest and e2e suites):

- **A real 429 from the rate limiter came back as a 500.**
  `@fastify/rate-limit`'s `errorResponseBuilder` is `throw`n by the
  plugin rather than sent directly, so it runs through the app's own
  global error handler (`middleware/audit.ts`) — which only recognized
  the app's own `HttpError` class and coerced everything else to a
  generic 500. A correctly-detected rate-limit violation was therefore
  reaching clients as an opaque server error instead of 429
  `RATE_LIMITED`. Fixed by having the rate-limit error carry its own
  `statusCode` and having the error handler honor any thrown error's
  own 4xx status code, not just `HttpError`'s.
- **Subnet-scoped instance IP allocation didn't account for
  non-subnet-scoped siblings.** A subnet's CIDR is carved out of its
  parent network's own range, but the static-IP allocator for a
  subnet-scoped instance only checked for collisions against *other*
  subnet-scoped instances. A plain instance created directly on the
  network (Docker's own allocator picking anywhere in the network's
  range) could already occupy an address inside the subnet, and the
  next subnet-scoped instance's real `docker run` then genuinely failed
  with "address already in use". Fixed by having the allocator treat
  any instance on the same network whose real assigned IP falls inside
  the subnet's range as taken, regardless of whether it was itself
  created with a `subnetId`.

Both are documented here rather than only in the git history because
they're exactly the kind of thing a "no fake success" build is supposed
to catch: real infrastructure occasionally disagrees in ways a
label-only simulation never would, and this pass is the evidence that
disagreement gets surfaced and fixed, not hidden.

## Milestone 14: Four more ways to build the same infrastructure — DONE

Following on from Milestone 7's honest substitute (CloudLab's own JSON-based
plan/apply/destroy CLI, `scripts/cloudlab-cli.ts`), this pass adds three
more genuinely working provisioning methods for a "core services" set
(VPC network, subnet, firewall rule, compute instance, disk, storage
bucket, managed database), plus wires the existing CI/CD pipeline runner
up to actually provision real infrastructure as a side effect of a real
pipeline run, rather than just running arbitrary shell commands:

- **Terraform-lab** (`terraform-lab/`) — a hand-rolled parser for a
  deliberate *subset* of real HCL syntax (`resource "cloudlab_<type>"
  "<name>" { ... }` blocks, string/number/bool/array literals,
  `type.name.id` references), reading genuine `.tf`-style files. The
  JSON CLI's plan/apply/destroy engine was extracted into a shared module
  (`scripts/lib/iac-engine.ts`) so both front ends call the exact same
  real implementation. As documented in Milestone 7 above, a real
  Terraform *provider* remains infeasible in this sandbox (no path to a
  real `terraform` binary or `terraform-plugin-go`'s gRPC/protobuf
  dependency tree) — this is CloudLab's own engine reading real-looking
  `.tf` syntax, not a Hashicorp-compatible provider. See
  `terraform-lab/README.md` for the exact supported grammar.
- **gcloud-style CLI** (`gcloud-lab/gcloud.ts`) — a command-line tool
  shaped like real `gcloud` (command groups, `--flag=value` syntax, a
  locally cached logged-in account and active project via `init`/`auth
  login`/`config set project`), covering the same seven core services.
  It talks only to CloudLab's own REST API — no Google Cloud code or
  credentials are involved. See `gcloud-lab/README.md`.
- **CI/CD-to-API** (`apps/worker/src/processors/pipelineRun.ts`,
  `cicd-lab/`) — a pipeline run's shell stages can now genuinely call back
  into CloudLab's own REST API and provision real infrastructure as a side
  effect of the job. Reaching the host API from inside the runner
  container uses the standard `host.docker.internal` + `ExtraHosts:
  host-gateway` mechanism (needed explicitly on plain Linux `dockerd`,
  unlike Docker Desktop), and the caller's identity is a real, normally-
  issued JWT minted server-side for the run's owner, deliberately short-
  lived (15 minutes) since it's injected as a plain environment variable
  into the run's log-visible environment. Since the guest image's busybox
  build has no `jq`/`sed`/`awk`, `cicd-lab/build-pipeline.mjs` generates a
  small POSIX-`sh` JSON-field-extraction/poll-to-READY library that stages
  source from a shared workspace file. See `cicd-lab/README.md`.

A dedicated multi-method test suite (`scripts/multi-method-test.mjs`, 37
cases) exercises create → independently-verify-READY-via-GET → delete →
independently-verify-gone-via-GET for all seven core services across all
four of these methods, plus several negative/edge cases per method (an
unknown resource type, a dangling `$ref`, a project-wide name collision, a
dependency-blocked delete, a missing required flag, no cached credentials,
`describe` on a deleted resource, and a pipeline stage that exits non-zero
correctly failing the run and skipping later stages). All 37 pass on two
consecutive runs. Getting there surfaced one real, environment-specific
flake worth recording: the CI/CD lab's original fixed example CIDR
(`10.90.0.0/24`) occasionally collided with a leftover network from
earlier ad hoc testing in this same long-lived sandbox — a real instance
of Milestone 13's host-wide CIDR-collision check doing exactly its job,
not a bug in the check. Fixed by widening the randomly-chosen CIDR's
address space (`cicd-lab/run-lab.mjs` and the test suite itself now draw
from a ~62,000-block range instead of ~140) and adding an automatic
retry-with-a-freshly-randomized-CIDR when a run's network stage fails
specifically on a real collision. A companion report,
`test-results/CloudLab_Services_And_Methods_Report.pdf`, documents every
CloudLab service, how to independently test each one after creating it,
and all five provisioning methods side by side with real captured
terminal transcripts, real console screenshots, and the full multi-method
test result table.

## Milestone 15: platform/DevOps services (NAT, Shared VPC, IAM SA, MIG, BigQuery, Composer, Cloud Run) — DONE

Following a request to think through this build like a GCP Platform/DevOps
Architect and fill in the services a real GCP landing zone would have beyond
the seven core services, this milestone adds nine more resource types, maps
every one explicitly to its GCP counterpart, and — per this project's
standing "no fake success" rule — documents exactly where a service is a
full-fidelity implementation versus an honestly-simplified substitute.

**New resource types, all built on the same generic resource model, IAM,
audit, and worker-job infrastructure from Milestone 1 — no schema-level
special-casing:**

- **`service_account`** (→ IAM Service Account) — a genuine 2048-bit RSA
  keypair generated on create; the private key is AES-256-GCM-encrypted at
  rest (reusing Milestone 5's secrets envelope) and only ever decrypted by
  a dedicated `reveal`/download endpoint, audited like a secret reveal.
- **`instance_template`** (→ Compute Engine Instance Template) — a stored
  blueprint (image, startup command, machine shape) with no infrastructure
  of its own, exactly matching GCP's own template semantics: creating one
  does nothing to Docker; it only becomes real containers once a Managed
  Instance Group references it.
- **`managed_instance_group`** (→ Compute Engine MIG) — real containers
  stamped from an `instance_template`, kept at a target size by a new
  reconciler tick (same pattern as Milestone 6's Kubernetes reconciler):
  it lists live members, compares against desired count, and starts
  replacements for anything missing — genuine self-healing, verified by
  directly killing a member container and watching the reconciler replace
  it. A MIG can be attached to an existing `load_balancer` as a live
  membership list rather than a fixed backend set, so scaling the group up
  or down changes real proxy backends in place.
- **`nat_gateway`** (→ Cloud NAT) — a real host-level `iptables`
  MASQUERADE + `ip_forward` toggle on the target network's bridge; egress
  genuinely turns on and off, verified with a real outbound request from a
  container on an otherwise-isolated internal network.
- **`vpc_peering`** (→ VPC Network Peering) — real bidirectional
  `iptables FORWARD ACCEPT` rules opened between two networks' bridges,
  verified with real container-to-container traffic across the peered
  networks that only succeeds once both sides of the peering are READY.
- **`shared_vpc_attachment`** (→ Shared VPC) — a real, narrowly-scoped
  cross-project grant record, enforced (not just labeled) at attach time:
  attaching a resource from a service project to a host project's network
  is checked against a live grant row naming that exact service project,
  verified with a dedicated cross-project IAM test (see below).
- **`bigquery_dataset`** (→ BigQuery) — **honest substitute, documented**:
  a genuinely dedicated real PostgreSQL 16 server per dataset (reusing
  Milestone 5's real-Postgres-per-`database` mechanism) with a real ad-hoc
  SQL query endpoint that actually executes against it and returns real
  rows or a real error — not BigQuery's actual distributed columnar engine,
  which has no feasible substitute in this sandbox, but every query is
  genuinely run, not templated.
- **`composer_environment`** (→ Cloud Composer) — **honest substitute,
  documented**: wraps a real `pipeline` (Milestone 8) on a real 5-field
  UTC cron schedule, with a scheduler tick that genuinely triggers real
  pipeline runs on schedule — not Airflow's actual DAG engine, but the
  trigger-on-schedule behavior is real and independently verifiable by
  watching real `pipeline_run` rows appear at the scheduled time.
- **`cloud_run_service`** (→ Cloud Run) — real scale-to-zero: no
  container exists until the first real Invoke request, which genuinely
  cold-starts one (state flips `IDLE` → `RUNNING`), and a real idle-timeout
  checker genuinely stops it again after the configured idle window with
  no traffic — verified with a real request round trip through a
  just-cold-started container.

**Cloud SQL and Docker were both deliberately *not* added as new types.**
Cloud SQL is exactly the existing `database` resource under GCP's own
naming — Milestone 5 already built a real dedicated Postgres server per
instance, so mapping it is a documentation decision, not new code. Docker
itself isn't a GCP-mappable *service* at all — it's the underlying
container engine every compute-shaped resource in this entire build
(instances, MIG members, Kubernetes pods, CI runner containers) is
actually implemented with, so it's documented as the infrastructure layer
underneath everything rather than given a resource type of its own.

**Four provisioning methods, extended to all nine new services, following
the exact pattern Milestone 14 established:**

- JSON CLI (`scripts/cloudlab-cli.ts`) — all nine types added to
  `TYPE_PATHS`; a single plan can create a Shared VPC host/service project
  pair, a MIG on a network, and a BigQuery dataset in one `apply`.
- Terraform-lab (`terraform-lab/configs/platform-services.tf`) — real
  `.tf`-style blocks for all nine types, including a documented Composer
  workaround (write the target pipeline's real id as a literal
  `pipeline_id` string, since a `.tf` file has no way to express "create
  this pipeline first, then this Composer environment" as one apply
  without a second, nested pipeline definition).
- gcloud-style CLI (`gcloud-lab/gcloud.ts`) — full command coverage
  (`iam service-accounts create`, `compute instance-templates create`,
  `compute instance-groups managed create` + `resize`, `compute
  routers nats create`, `compute networks peerings create`, `compute
  shared-vpc associated-projects add`, `bq mk`/`query`, `composer
  environments create`, `run deploy`/`services call`).
- CI/CD pipeline (`cicd-lab/pipeline-platform-services.json` +
  `run-platform-services-lab.mjs` / `destroy-platform-services-lab.mjs`) —
  the exact same `lib.sh`/`create`/`poll_ready` mechanism from Milestone
  14, zero new pipeline-runner code, provisioning seven of the nine
  (Shared VPC and Composer are documented as out of scope for the flat
  single-pipeline demo specifically, with the real workaround for each
  spelled out in `cicd-lab/README.md`, not silently dropped).

A new 47-case test suite (`scripts/platform-services-test.mjs`) exercises
create → independently-verify-READY-via-GET → idempotent re-apply →
negative cases → destroy → independently-verify-gone for all nine new
types across all four methods, plus a dedicated fifth section proving
Shared VPC's cross-project enforcement is real: a service-project instance
attaching to a host network with no grant is genuinely denied (404); the
identical request succeeds only after the host creates the real grant;
and a third, uninvolved project is *still* denied afterward, proving the
grant is scoped to exactly the named service project, not "any other
project." All 47 cases pass.

**Two real, previously-undiscovered production bugs were found and fixed
during this pass** (per this project's standing rule that a "no fake
success" build treats a bug found in its own UI the same as one found in
its own infrastructure — fix it, don't just route around it in a test
script):

1. **Every non-network/instance resource type never got live WS-driven
   table updates.** `handleWsMessage()` in `apps/api/public/app.js` only
   ever routed `resource.update` messages to `state.networks` or
   `state.instances` via a hardcoded ternary — every other resource type,
   including all pre-Milestone-15 types (subnets, firewall rules, DNS
   records, load balancers, disks, buckets, databases, secrets, k8s
   clusters/deployments, pipelines/runs) and all nine new Milestone 15
   types, only ever updated their console table on a manual refresh or
   page reload, never live. Fixed with a generic `RESOURCE_TYPE_TO_STATE_KEY`
   map covering all ~25 resource types and a rewritten, type-agnostic
   `resource.update` handler. This was a real, build-wide gap that had
   existed since Milestone 1 and had nothing to do with Milestone 15
   specifically — it just took adding nine more types to make it obvious.
2. **A real BigQuery query result would flash and then vanish.**
   `renderBigquery()`'s "Run query" button set its result on a local DOM
   node, but the console's universal `withErrorHandling()` button wrapper
   unconditionally calls a full `render()` (a complete DOM rebuild)
   immediately after any handler resolves, which silently discarded the
   just-set result on the very next tick. Fixed by moving query results
   into `state.bigqueryQueryResults` (keyed by dataset id, storing the
   typed SQL alongside the result) so they survive the rebuild; verified
   fixed with a fresh screenshot showing a real JSON result persisted on
   screen.

A detailed report, `test-results/CloudLab_Platform_Services_Report.pdf`,
documents the full GCP-service-to-CloudLab-resource mapping table with
fidelity ratings, a per-service guide (demo resource name, manual/CI-CD/
Cloud-Shell/Terraform creation steps, and independent test steps) for all
nine new services, real captured terminal transcripts for all four
CLI/pipeline methods, ten real console screenshots, the full 47-case test
result table, and both bugs above documented as part of the report's own
honesty narrative rather than glossed over.

## Suggested next milestone

If continuing this build, the highest-leverage next steps, roughly in
order:

1. **Extract `packages/shared`** to actually hold the DB schema and Docker
   naming helpers, removing limitations #1 and #2 above — this is
   mechanical but important before either process is deployed
   independently.
2. **A real IPAM allocator** (track allocated subnets in Postgres, hand out
   the next free `/24` from `INSTANCE_SUBNET_BASE`) — a natural companion
   to Milestone 13's CIDR-collision check and the existing "no fake
   success" philosophy (fewer *avoidable* failures, while keeping genuine
   ones honest).
3. ~~A CLI that's a thin wrapper over the same REST API the console
   uses~~ — done (Milestone 7's `scripts/cloudlab-cli.ts`), and as of
   Milestone 14 joined by a Terraform-lab, a gcloud-style CLI, and
   CI/CD-to-API provisioning, all four covering the seven core services;
   Milestone 15 then extended all four to the nine new platform services.
4. **Extend all four provisioning methods to the remaining resource
   catalogue** (DNS, load balancers, registries/images, Kubernetes,
   secrets) — mechanical, following the same `TYPE_PATHS`/engine pattern
   already in place for both the seven core services and the nine
   Milestone 15 platform services.
5. A real Terraform *provider* (a genuine Hashicorp-loadable Go plugin)
   remains blocked on this sandbox's network access, not on anything left
   to design — see Milestone 7 and Milestone 14 above for the specifics.
6. Everything else in "explicitly out of scope" above, roughly in the
   order the original master spec introduces it.

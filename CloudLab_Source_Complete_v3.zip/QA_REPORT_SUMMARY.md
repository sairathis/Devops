# CloudLab — QA Test Report Summary (Final)

Three separate QA passes now cover this build: the original 48-case console regression pass, a follow-on 37-case multi-method provisioning test suite added for Milestone 14, and a third 47-case suite added for Milestone 15's platform/DevOps services.

## Pass 1 — 48-case console regression (all 13 milestones)

A formal 48-test-case QA pass was run against the live console (real Postgres/Redis/Docker), covering all 13 build milestones end to end, each case verified with a screenshot or a direct API-level check. Full report delivered to the user as a PDF (`cloudlab_report.pdf`, 42 pages): usage guide (including a "beyond the basics" tour of every milestone's features) + test case specs + execution evidence + defects found.

**Result:** 48/48 passed, confirmed with two consecutive clean full-suite runs, plus the existing 20 Vitest tests and the 31-check e2e vertical slice all still green.

This pass supersedes the earlier 18-test-case pass (Milestone 1 only) — its two fixed defects are carried forward below, plus two more found while extending coverage to Milestones 2–13.

### Defects found and fixed
1. **Silent error banner** (18-case pass) — `state.error` was captured on every failed action but the `<div class="error-banner">` only existed on the pre-login/org-picker/project-picker screens. Any error inside the actual console (permission denied, blocked delete, failed exec) produced zero visible feedback. Fixed by rendering the banner in the main layout too.
2. **Exec panel self-destructed on success** (18-case pass) — the "Run" button's success path always triggered a full `render()`, wiping its own just-displayed output and silently reconnecting the live terminal's WebSocket. Fixed by giving the exec button its own scoped try/catch, no page-wide rebuild.
3. **A real 429 from the rate limiter came back as a 500** (48-case pass) — `@fastify/rate-limit` throws its error object rather than sending it directly, so it ran through the app's own global error handler, which only recognized the app's own `HttpError` class and coerced everything else to 500. Found by a 62-request burst test expecting 429s and getting none. Fixed by having the error handler honor a thrown error's own status code.
4. **Subnet IP allocation could collide with a sibling instance's Docker-assigned IP** (48-case pass) — the subnet allocator only checked for collisions against other subnet-scoped instances, missing that a plain network-scoped instance's Docker-auto-assigned address can also fall inside the subnet's range. Found via the Learning system's networking-fundamentals scenario. Fixed by considering every instance on the same network, not just subnet-scoped ones.

### Known limitations (not fixed, documented as scope)
- Project-only IAM role bindings (no org membership) have no navigation path in the console — the org/project picker only lists projects reached via an org membership, even though the API/IAM engine fully supports project-only access. Natural fix is a "projects shared with me" list once an invite/join flow exists.
- Offset-based Activity/Audit pagination can shift under concurrent writes between reading page 1 and page 2 (a real, known LIMIT/OFFSET trade-off, not a bug) — a cursor would fix this but wasn't in scope for Milestone 13.

### Artifacts
- `scripts/qa-run.mjs` — the 48-case Playwright + API-level script (repeatable)
- `test-results/results.json`, `test-results/screenshots/*.png` — raw run output
- `test-results/build_report.py` — regenerates the PDF from the above
- `ROADMAP.md`'s "Final QA pass" section — the full writeup of the two new defects

## Pass 2 — 37-case multi-method provisioning suite (Milestone 14)

A second test suite (`scripts/multi-method-test.mjs`) covers the four provisioning methods added in Milestone 14 (JSON CLI, Terraform-lab, gcloud-style CLI, CI/CD-to-API), each with: create all seven core services, independently verify each is READY via a fresh `GET` (never trusting a CLI's own stdout), delete all seven, and independently verify each is gone — plus per-method negative/edge cases. Full report delivered to the user as `test-results/CloudLab_Services_And_Methods_Report.pdf` (16 pages): every CloudLab service explained, how to test each after creating it, all five provisioning methods compared side by side with real terminal transcripts, real console screenshots of all seven core services reaching READY, and the full test result table.

**Result:** 37/37 passed, confirmed with two consecutive clean full-suite runs.

### Negative/edge cases covered (by method)
- **JSON CLI**: unknown resource type, dangling `$ref`, project-wide name collision (409).
- **Terraform-lab**: non-`cloudlab_` resource type, a rejected `name` attribute (the label IS the name), a dangling reference absent from the file.
- **gcloud-style CLI**: missing required flag, delete blocked by a live dependency (409), no cached credentials, `describe` on an already-deleted resource (404).
- **CI/CD pipeline**: a stage that exits non-zero correctly fails the run and marks later stages `SKIPPED` rather than running them anyway.

### Issue found and fixed
- **CI/CD lab's fixed example CIDR occasionally collided with a leftover network.** `cicd-lab/`'s original example pipeline hardcoded `10.90.0.0/24`, substituted with a narrow time-derived octet range for repeat runs; in this long-lived sandbox that range occasionally landed on a network left over from earlier ad hoc testing, correctly triggering Milestone 13's real host-wide CIDR-collision check (not a bug in the check itself). Fixed by widening the randomly-chosen CIDR to a ~62,000-block range in both `cicd-lab/run-lab.mjs` and the test suite, and adding an automatic retry-with-a-fresh-random-CIDR specifically when a run's network stage fails on a real collision.

### Artifacts
- `scripts/multi-method-test.mjs` — the 37-case suite (repeatable)
- `test-results/multi-method-results.json` — raw run output
- `test-results/screenshots-services/*.png`, `test-results/transcripts/*.txt` — screenshots and real captured CLI transcripts used in the report
- `test-results/build_services_report.py` — regenerates the PDF from the above
- `terraform-lab/README.md`, `gcloud-lab/README.md`, `cicd-lab/README.md` — per-method scope and usage documentation

## Pass 3 — 47-case platform-services suite (Milestone 15)

A third test suite (`scripts/platform-services-test.mjs`) covers the nine new resource types added in Milestone 15 (service accounts, instance templates, managed instance groups, NAT gateways, VPC peering, Shared VPC, BigQuery datasets, Composer environments, Cloud Run services) across the same four provisioning methods, plus a dedicated cross-project Shared VPC IAM enforcement section: create → independently-verify-READY-via-GET → idempotent re-apply → negative cases → destroy → independently-verify-gone. Full report delivered to the user as `test-results/CloudLab_Platform_Services_Report.pdf`: the full GCP-service-to-CloudLab-resource mapping table with fidelity ratings, a per-service creation-and-test guide (manual/CI-CD/Cloud-Shell/Terraform, each followed by independent test steps), real captured terminal transcripts, ten real console screenshots, and the full 47-case test result table.

**Result:** 47/47 passed.

### Negative/edge cases and dedicated coverage
- **JSON CLI**: self-peering rejection, a bad service-account id reference, an invalid cron schedule, a shared-VPC-to-self rejection.
- **Terraform-lab**: the documented Composer workaround (a real pipeline id hardcoded as a Terraform string literal) proven to actually work end to end, not just described.
- **gcloud-style CLI**: full lifecycle for all nine types including special verbs (service-account key reveal, MIG resize, BigQuery query, Cloud Run invoke), a shared-VPC-to-own-project negative, a missing-required-flag negative.
- **CI/CD pipeline**: a hand-built pipeline stage that feeds a wrong-type resource id into a NAT gateway creation call, asserting the run correctly fails and skips later stages.
- **Shared VPC cross-project IAM (dedicated section)**: an unauthorized cross-project attach is denied with a real 404; the identical request succeeds only after the host project creates a real grant naming that exact service project; a third, uninvolved project is still denied afterward, proving the grant's scope is exact, not "any other project."

### Issues found and fixed
Both are real, previously-undiscovered bugs in the running application (`apps/api/public/app.js`), not test-script issues, and both were fixed rather than worked around:

1. **The console's WebSocket resource-update dispatcher was hardcoded to two resource types.** `handleWsMessage()` only ever routed live `resource.update` events to the networks or instances table — every other resource type, including nine pre-existing ones (subnets, firewall rules, DNS records, load balancers, disks, buckets, databases, secrets, Kubernetes clusters/deployments, pipelines/runs) as well as all nine new Milestone 15 types, only updated on a manual refresh. This is a build-wide gap dating back to Milestone 1, surfaced by adding nine more types. Fixed with a generic type-to-state-key map covering all ~25 resource types.
2. **A real BigQuery query result would flash and then vanish.** The "Run query" button's result was written to a local DOM node, which the console's universal post-click full-page re-render then immediately discarded. A real user's query result would appear and disappear within the same second. Fixed by persisting query results (and the typed SQL) in application state so they survive the re-render; verified fixed with a fresh screenshot showing a real JSON result staying on screen.

### Artifacts
- `scripts/platform-services-test.mjs` — the 47-case suite (repeatable)
- `test-results/platform-services-results.json` — raw run output
- `test-results/screenshots-platform/*.png`, `test-results/transcripts/*-platform.txt` — screenshots and real captured CLI/pipeline transcripts used in the report
- `test-results/build_platform_services_report.py` — regenerates the PDF from the above
- `cicd-lab/README.md`'s "Milestone 15" section — the CI/CD demo's exact scope and the documented Shared-VPC/Composer workarounds

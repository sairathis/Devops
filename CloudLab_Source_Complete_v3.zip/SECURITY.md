# CloudLab — Security

This is a local learning/demo platform, not a production system, but the
security-relevant pieces of the spec (IAM, audit, honest error handling)
were built for real rather than stubbed out.

## Authentication

- Passwords are hashed with `bcryptjs` (pure JS — avoids native-binary
  builds, which the sandboxed build environment couldn't fetch from most
  registries anyway). Never stored or logged in plaintext.
- Sessions are stateless JWTs (`jsonwebtoken`), signed with `JWT_SECRET`
  from `.env`, default expiry 12h (`JWT_EXPIRES_IN`). The token embeds
  `{userId, email}`.
- **`JWT_SECRET` ships with a placeholder default
  (`"change-me-in-production"`) in `config.ts` — this is fine for local use
  but must be overridden via `.env` before this is ever exposed beyond
  localhost.**
- There's no refresh-token flow, no password reset, no email verification,
  no MFA. Login is register → get a token → use it until it expires.

## Authorization (IAM)

- Every mutating and most read routes call
  `requireProjectPermission(userId, projectId, action)`
  (`apps/api/src/iam/policy.ts`) before doing anything.
- A user's effective role is resolved as: explicit `project_memberships`
  binding first, falling back to their `org_memberships` role if no
  project-level binding exists ("role inheritance"). If neither exists, the
  user has no visibility into the project at all.
- Roles are glob-pattern allow/deny lists (`packages/shared/src/index.ts`,
  `BUILTIN_ROLES`): `owner` (`allow: ["*"]`), `admin`
  (`projects.*`, `compute.*`, `network.*`, `iam.roles.read`, `iam.bindings.*`,
  explicitly denying `organizations.delete`), `developer` (can create/read/
  start/stop/exec compute and create/read networks, but is denied deleting
  either and denied all `iam.*`), `viewer` (`allow: ["*.get", "*.list"]`,
  deny everything else). **Deny always overrides allow.**
- `matchesPattern()` treats `*` as a true glob spanning any number of
  `.`-separated segments — `*.list` matches `compute.instances.list` just
  as much as `projects.list`. (An earlier implementation required equal
  segment counts and silently broke every wildcard suffix rule; see
  `TESTING.md` for the regression test that pins this down.)
- **No visibility into a project → `404`, not `403`.** This intentionally
  mirrors real cloud provider behavior: a stranger can't tell the
  difference between "doesn't exist" and "exists but you can't see it."

## Audit logging

- `apps/api/src/middleware/audit.ts` registers a global `onRequest` hook
  (assigns a `requestId` and start time to every request) and a global
  `onResponse` hook that unconditionally writes an `audit_logs` row —
  whether the specific route annotated `req.audit` with a meaningful
  action/resource, or not (in which case a generic `method:path` action is
  recorded). **There is no code path through this server that skips the
  audit write.** If the audit insert itself fails, the failure is logged
  loudly but never blocks the actual API response.
- Audit logs record who (`userId`, `ip`, `userAgent`), what (`action`,
  `resourceType/Id/Name`, `previousState`/`newState`), when
  (`createdAt`, `durationMs`), how (`apiEndpoint`, `httpMethod`,
  `authMethod`, `source`), and the outcome (`status`, `error`).
- There is no PATCH or DELETE route for `audit_logs` — by design, audit
  history is immutable from the API surface.

## Honest failure ("no fake success")

- Resource status transitions are driven entirely by what the worker
  actually observes from the Docker Engine API. A Docker error (e.g. a
  genuine IPAM subnet-pool overlap) is written back as `status: FAILED`
  with the real Docker error message in `metadata`/`operations.error` — it
  is never silently retried, swallowed, or reported as success.
- `assertDeletable()` blocks a delete when a live (non-`DELETED`) dependent
  resource still references it, returning `409 DEPENDENCY_EXISTS` with the
  exact list of blocking resources — never a false "deleted" that leaves
  dangling infra.

## Transport & environment

- No TLS is configured; this runs over plain HTTP on localhost by design.
  Anything beyond local/demo use needs a reverse proxy terminating TLS.
- CORS is wide open (`origin: true`) — appropriate for a local dev console,
  not for a multi-tenant deployment.
- The Docker socket (`DOCKER_SOCKET`, default `/var/run/docker.sock`) is
  used directly by both the API (for exec/logs) and the worker (for
  provisioning). Anyone who can reach this API with a valid token can, via
  the app's own semantics, run arbitrary commands inside any instance they
  have `compute.instances.exec` access to — this is a feature (it's what
  makes the terminal real), but it means container isolation, not the
  CloudLab authorization layer, is the actual security boundary between
  tenants' workloads.

## Known gaps

- No rate limiting on `/auth/register` or `/auth/login`.
- No account lockout after repeated failed logins.
- No secrets management beyond `.env` (fine for local dev; not fine as-is
  for any shared or hosted deployment).
- No dependency/SCA scanning wired into this build pass.

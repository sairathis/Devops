import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { createServer } from "node:net";
import { randomBytes } from "node:crypto";
import { mkdir, writeFile, rm } from "node:fs/promises";
import { Client } from "pg";

const execFileAsync = promisify(execFile);

// Real, dedicated PostgreSQL 16 server per `database` resource -- genuine
// initdb + postmaster process, not a logical database carved out of
// CloudLab's own shared Postgres. Documented simplification (ROADMAP.md):
// each instance is an OS process on this host, not a Docker container like
// every other CloudLab resource, because there is no reachable base image in
// this sandbox to build a real Postgres container from (all registries are
// network-blocked, and hand-assembling glibc + the postgres binaries into a
// FROM-scratch image was judged lower value than breadth across the
// remaining milestones) -- but the database engine itself is completely
// real: real data directory, real WAL, a real `psql`/`pg` client can connect
// to it and run arbitrary SQL.
const PG_BIN = process.env.PG_BIN ?? "/usr/lib/postgresql/16/bin";
const PG_OS_USER = process.env.PG_OS_USER ?? "postgres";
export const DATABASES_ROOT = process.env.CLOUDLAB_DATABASES_ROOT ?? "/var/lib/cloudlab/databases";

async function runAsPostgres(bin: string, args: string[]) {
  return execFileAsync("sudo", ["-u", PG_OS_USER, bin, ...args]);
}

export async function findFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const srv = createServer();
    srv.unref();
    srv.on("error", reject);
    srv.listen(0, "127.0.0.1", () => {
      const address = srv.address();
      const port = typeof address === "object" && address ? address.port : 0;
      srv.close(() => resolve(port));
    });
  });
}

export function generatePassword(): string {
  return randomBytes(18).toString("base64url");
}

export interface ProvisionedDatabase {
  host: string;
  port: number;
  username: string;
  password: string;
  databaseName: string;
  dataDir: string;
}

export async function provisionPostgres(resourceId: string, databaseName: string): Promise<ProvisionedDatabase> {
  const dataDir = `${DATABASES_ROOT}/${resourceId}`;
  const username = "cloudlab";
  const password = generatePassword();
  const port = await findFreePort();

  // Created as root (this worker process's own user), then handed to the
  // postgres OS user -- the earlier approach of having postgres itself
  // `mkdir -p` its data directory failed because the parent
  // DATABASES_ROOT is root-owned, so postgres had no write access to create
  // a subdirectory in it at all.
  await mkdir(dataDir, { recursive: true });
  await execFileAsync("chown", ["-R", `${PG_OS_USER}:${PG_OS_USER}`, dataDir]);

  const pwFile = `/tmp/cloudlab-pgpw-${resourceId}`;
  await writeFile(pwFile, password, { mode: 0o600 });
  await execFileAsync("chown", [`${PG_OS_USER}:${PG_OS_USER}`, pwFile]);

  await runAsPostgres(`${PG_BIN}/initdb`, ["-D", dataDir, "-U", username, `--pwfile=${pwFile}`, "--auth=scram-sha-256"]);
  await rm(pwFile, { force: true });

  // Inside dataDir, not next to it -- dataDir is postgres-owned, its parent
  // (DATABASES_ROOT) is not, and pg_ctl runs as the postgres OS user.
  const logFile = `${dataDir}/server.log`;
  await runAsPostgres(`${PG_BIN}/pg_ctl`, [
    "-D",
    dataDir,
    "-o",
    `-p ${port} -c listen_addresses='127.0.0.1'`,
    "-l",
    logFile,
    "start",
  ]);

  await waitForReady({ host: "127.0.0.1", port, username, password, database: "postgres" });

  if (databaseName && databaseName !== "postgres") {
    const admin = new Client({ host: "127.0.0.1", port, user: username, password, database: "postgres" });
    await admin.connect();
    try {
      // Database names come from user input elsewhere (validated to be a
      // plain identifier before reaching here) -- still quoted defensively.
      await admin.query(`CREATE DATABASE "${databaseName.replace(/"/g, '""')}"`);
    } finally {
      await admin.end();
    }
  }

  return { host: "127.0.0.1", port, username, password, databaseName: databaseName || "postgres", dataDir };
}

async function waitForReady(opts: { host: string; port: number; username: string; password: string; database: string }, attempts = 30) {
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      const client = new Client({ host: opts.host, port: opts.port, user: opts.username, password: opts.password, database: opts.database });
      await client.connect();
      await client.query("SELECT 1");
      await client.end();
      return;
    } catch (err) {
      lastErr = err;
      await new Promise((r) => setTimeout(r, 300));
    }
  }
  throw new Error(`Postgres on port ${opts.port} did not become ready: ${(lastErr as Error)?.message}`);
}

export async function teardownPostgres(resourceId: string) {
  const dataDir = `${DATABASES_ROOT}/${resourceId}`;
  try {
    await runAsPostgres(`${PG_BIN}/pg_ctl`, ["-D", dataDir, "-m", "fast", "stop"]);
  } catch (err) {
    // Already stopped, or data dir never fully came up -- fall through to
    // removing whatever is on disk rather than leaving it orphaned.
    if (!/is not running|no server running|does not exist/i.test((err as Error).message)) throw err;
  }
  await execFileAsync("rm", ["-rf", dataDir, `${dataDir}.log`]);
}

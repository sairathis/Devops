// Real firewall enforcement using iptables on the DOCKER-USER chain, which
// Docker guarantees is consulted before its own bridge-forwarding rules --
// the standard, documented way to add custom filtering in front of Docker
// networks without Docker rewriting your rules away on restart.
//
// Every rule this module inserts is tagged with a `--comment` carrying the
// owning resource's id, so a rule can be found and removed later without
// needing to remember its exact match spec, and so a `cloudlab:` prefix
// makes it obvious on `iptables -L` which rules this app owns.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { readdir } from "node:fs/promises";

const execFileAsync = promisify(execFile);

export interface FirewallRuleSpec {
  networkResourceId: string;
  direction: "ingress" | "egress";
  action: "ALLOW" | "DENY";
  protocol: "tcp" | "udp" | "all";
  portRange?: string; // e.g. "80" or "8000:9000", omitted for protocol "all"
  cidr: string; // source (ingress) or destination (egress) CIDR, e.g. "0.0.0.0/0"
}

function commentFor(resourceId: string) {
  return `cloudlab:fw:${resourceId}`;
}

// Docker names a network's Linux bridge device `br-<first 12 hex chars of
// the network's Docker ID>`. Verified against a live `docker network create`
// in this sandbox (checked /sys/class/net/br-<id> directly) rather than
// assumed -- if this ever stops holding, the lookup fails loudly instead of
// silently matching the wrong bridge.
export async function bridgeInterfaceFor(dockerNetworkId: string): Promise<string> {
  const short = dockerNetworkId.slice(0, 12);
  const candidate = `br-${short}`;
  const devices = await readdir("/sys/class/net").catch(() => [] as string[]);
  if (!devices.includes(candidate)) {
    throw new Error(
      `expected bridge interface '${candidate}' for docker network ${dockerNetworkId} was not found under /sys/class/net ` +
        `(found: ${devices.join(", ") || "none"}). Docker's br-<id> naming convention may not hold in this environment.`,
    );
  }
  return candidate;
}

function buildArgs(bridge: string, resourceId: string, rule: FirewallRuleSpec, op: "-I" | "-D"): string[] {
  const args = ["-t", "filter", op, "DOCKER-USER"];
  // ingress = traffic arriving *into* this network's bridge (-i); egress = traffic
  // leaving it (-o). This models "the network's own perimeter", not a specific host.
  args.push(rule.direction === "ingress" ? "-i" : "-o", bridge);
  if (rule.protocol !== "all") {
    args.push("-p", rule.protocol);
    if (rule.portRange) {
      const dport = rule.portRange.includes(":") ? rule.portRange.replace(":", "-") : rule.portRange;
      args.push("--dport", dport);
    }
  }
  if (rule.direction === "ingress") args.push("-s", rule.cidr);
  else args.push("-d", rule.cidr);
  args.push("-m", "comment", "--comment", commentFor(resourceId));
  args.push("-j", rule.action === "ALLOW" ? "ACCEPT" : "DROP");
  return args;
}

export async function applyFirewallRule(resourceId: string, dockerNetworkId: string, rule: FirewallRuleSpec): Promise<void> {
  const bridge = await bridgeInterfaceFor(dockerNetworkId);
  // Insert at the top (-I with no rule number = position 1) so explicit
  // cloudlab rules always take precedence over anything already there.
  await execFileAsync("iptables", buildArgs(bridge, resourceId, rule, "-I"));
}

export async function revokeFirewallRule(resourceId: string, dockerNetworkId: string, rule: FirewallRuleSpec): Promise<void> {
  const bridge = await bridgeInterfaceFor(dockerNetworkId).catch(() => null);
  if (!bridge) return; // network already gone -- nothing to clean up
  try {
    await execFileAsync("iptables", buildArgs(bridge, resourceId, rule, "-D"));
  } catch (err) {
    // Rule may already be gone (e.g. flushed by a network delete); don't fail
    // the whole delete operation over an idempotent cleanup step.
    const msg = (err as Error).message;
    if (!/Bad rule|does a matching rule exist/i.test(msg)) throw err;
  }
}

// Lists every cloudlab-owned rule currently in DOCKER-USER, for diagnostics /
// the architecture view ("what firewall rules are actually active right now").
export async function listActiveCloudlabRules(): Promise<string[]> {
  const { stdout } = await execFileAsync("iptables", ["-S", "DOCKER-USER"]);
  return stdout.split("\n").filter((l) => l.includes("cloudlab:fw:"));
}

// ---------------------------------------------------------------------------
// Milestone 15: NAT Gateway (real host-level MASQUERADE), for `internal: true`
// networks created with no default Docker egress route. Docker Hub and every
// other image registry is network-blocked in this sandbox, so a "router
// container" image can't be pulled -- this reuses the exact same host-level
// iptables mechanism the firewall-rule feature already uses instead of a new
// container, which is genuinely how a NAT gateway works at the network layer
// anyway (GCP's own Cloud NAT is not a VM you can see either).
function natCommentFor(resourceId: string) {
  return `cloudlab:nat:${resourceId}`;
}

async function ensureIpForwarding(): Promise<void> {
  // Real kernel-level enablement -- without this, MASQUERADE rules exist but
  // the kernel still never routes packets between interfaces.
  await execFileAsync("sysctl", ["-w", "net.ipv4.ip_forward=1"]);
}

export async function applyNatGateway(resourceId: string, dockerNetworkId: string, cidr: string): Promise<void> {
  await ensureIpForwarding();
  const bridge = await bridgeInterfaceFor(dockerNetworkId);
  // MASQUERADE every packet from this network's CIDR headed anywhere else --
  // real source-NAT, the same primitive `iptables -t nat -A POSTROUTING -j
  // MASQUERADE` GCP's own Cloud NAT and every home router use.
  await execFileAsync("iptables", ["-t", "nat", "-I", "POSTROUTING", "-s", cidr, "!", "-o", bridge, "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "MASQUERADE"]);
  // The network was created with --internal (Docker never wires its own
  // egress rule for it), so FORWARD is genuinely blocking outbound traffic
  // until we explicitly allow this bridge to forward out and accept the
  // return path -- otherwise MASQUERADE rewrites packets that never leave.
  await execFileAsync("iptables", ["-I", "FORWARD", "-i", bridge, "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "ACCEPT"]);
  await execFileAsync("iptables", ["-I", "FORWARD", "-o", bridge, "-m", "state", "--state", "RELATED,ESTABLISHED", "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "ACCEPT"]);
}

export async function revokeNatGateway(resourceId: string, dockerNetworkId: string, cidr: string): Promise<void> {
  const bridge = await bridgeInterfaceFor(dockerNetworkId).catch(() => null);
  if (!bridge) return; // network already gone
  const attempts: string[][] = [
    ["-t", "nat", "-D", "POSTROUTING", "-s", cidr, "!", "-o", bridge, "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "MASQUERADE"],
    ["-D", "FORWARD", "-i", bridge, "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "ACCEPT"],
    ["-D", "FORWARD", "-o", bridge, "-m", "state", "--state", "RELATED,ESTABLISHED", "-m", "comment", "--comment", natCommentFor(resourceId), "-j", "ACCEPT"],
  ];
  for (const args of attempts) {
    try {
      await execFileAsync("iptables", args);
    } catch (err) {
      const msg = (err as Error).message;
      if (!/Bad rule|does a matching rule exist/i.test(msg)) throw err;
    }
  }
}

// ---------------------------------------------------------------------------
// Milestone 15: VPC Peering -- real bidirectional FORWARD-chain ACCEPT rules
// between two networks' bridges, genuinely enabling private-IP reachability
// between two otherwise-isolated Docker networks (which by default cannot
// route to each other at all). This is the honest host-level substitute for
// a real cloud's SDN-level peering, since there is no cross-network routing
// primitive Docker itself exposes.
function peeringCommentFor(resourceId: string) {
  return `cloudlab:peer:${resourceId}`;
}

export async function applyVpcPeering(resourceId: string, networkAId: string, networkBId: string): Promise<void> {
  const [bridgeA, bridgeB] = await Promise.all([bridgeInterfaceFor(networkAId), bridgeInterfaceFor(networkBId)]);
  await execFileAsync("iptables", ["-I", "FORWARD", "-i", bridgeA, "-o", bridgeB, "-m", "comment", "--comment", peeringCommentFor(resourceId), "-j", "ACCEPT"]);
  await execFileAsync("iptables", ["-I", "FORWARD", "-i", bridgeB, "-o", bridgeA, "-m", "comment", "--comment", peeringCommentFor(resourceId), "-j", "ACCEPT"]);
}

export async function revokeVpcPeering(resourceId: string, networkAId: string, networkBId: string): Promise<void> {
  const bridgeA = await bridgeInterfaceFor(networkAId).catch(() => null);
  const bridgeB = await bridgeInterfaceFor(networkBId).catch(() => null);
  if (!bridgeA || !bridgeB) return;
  for (const args of [
    ["-D", "FORWARD", "-i", bridgeA, "-o", bridgeB, "-m", "comment", "--comment", peeringCommentFor(resourceId), "-j", "ACCEPT"],
    ["-D", "FORWARD", "-i", bridgeB, "-o", bridgeA, "-m", "comment", "--comment", peeringCommentFor(resourceId), "-j", "ACCEPT"],
  ]) {
    try {
      await execFileAsync("iptables", args);
    } catch (err) {
      const msg = (err as Error).message;
      if (!/Bad rule|does a matching rule exist/i.test(msg)) throw err;
    }
  }
}

// Milestone 11: real network fault injection.
//
// The obvious way to simulate a degraded (not fully down) network link is
// `tc qdisc add dev <bridge> root netem delay <ms> loss <pct>%` -- verified
// directly in this sandbox before writing any app code:
//
//   $ tc qdisc add dev br-<id> root netem delay 100ms loss 25%
//   Error: Specified qdisc kind is unknown.
//
// The `sch_netem` qdisc isn't compiled into this sandbox's kernel and there
// is no `modprobe` to load it (this environment's kernel doesn't support
// loadable modules at all), so netem-based latency/loss injection is
// genuinely infeasible here -- not attempted, not faked. See ROADMAP.md for
// this finding.
//
// What *is* real and available is the same iptables/DOCKER-USER mechanism
// Milestone 2's firewall rules already use (net/iptables.ts) -- so this
// module implements the one network fault that mechanism can genuinely
// deliver: a total blackhole. Every packet in or out of the network's real
// Linux bridge is actually dropped by the kernel until the fault is
// reverted, verified end to end with a real HTTP request that fails while
// the blackhole is active and succeeds again the instant it's lifted.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { bridgeInterfaceFor } from "./iptables.js";

const execFileAsync = promisify(execFile);

function commentFor(resourceId: string) {
  return `cloudlab:fault:${resourceId}`;
}

function argsFor(bridge: string, resourceId: string, direction: "-i" | "-o", op: "-I" | "-D"): string[] {
  return ["-t", "filter", op, "DOCKER-USER", direction, bridge, "-m", "comment", "--comment", commentFor(resourceId), "-j", "DROP"];
}

export async function applyNetworkBlackhole(resourceId: string, dockerNetworkId: string): Promise<void> {
  const bridge = await bridgeInterfaceFor(dockerNetworkId);
  // Both directions: a real blackhole cuts traffic entering *and* leaving
  // the network, not just one side of it.
  await execFileAsync("iptables", argsFor(bridge, resourceId, "-i", "-I"));
  await execFileAsync("iptables", argsFor(bridge, resourceId, "-o", "-I"));
}

export async function revokeNetworkBlackhole(resourceId: string, dockerNetworkId: string): Promise<void> {
  const bridge = await bridgeInterfaceFor(dockerNetworkId).catch(() => null);
  if (!bridge) return; // network already gone -- nothing to clean up
  for (const direction of ["-i", "-o"] as const) {
    try {
      await execFileAsync("iptables", argsFor(bridge, resourceId, direction, "-D"));
    } catch (err) {
      // Idempotent: the rule may already be gone (manual cancel racing the
      // scheduled revert, or a network delete that flushed everything).
      const msg = (err as Error).message;
      if (!/Bad rule|does a matching rule exist/i.test(msg)) throw err;
    }
  }
}

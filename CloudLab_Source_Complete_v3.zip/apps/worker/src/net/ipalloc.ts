// Subnet-containment and static-IP allocation helpers. CIDR parsing itself
// (parseCidr) moved to packages/shared as of Milestone 13, so the API can
// do the same real overlap arithmetic synchronously at network-create time
// -- both packages now agree on exactly one implementation of it.
import { parseCidr } from "@cloudlab/shared";
export { parseCidr };

function intToIp(n: number): string {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join(".");
}

// True if `inner` (e.g. a subnet) is fully contained within `outer` (e.g. its
// parent network/VPC's range).
export function cidrContains(outer: string, inner: string): boolean {
  const o = parseCidr(outer);
  const i = parseCidr(inner);
  return i.prefix >= o.prefix && i.base >= o.base && i.base + i.size <= o.base + o.size;
}

// True if a single dotted-quad address falls within `cidr`'s range.
export function ipInCidr(ip: string, cidr: string): boolean {
  const { base, size } = parseCidr(cidr);
  const { base: ipBase } = parseCidr(`${ip}/32`);
  return ipBase >= base && ipBase < base + size;
}

// Picks the first address in `cidr` not already in `used`, skipping the
// network address, the broadcast address, and .1 (reserved for the bridge
// gateway Docker itself assigns).
export function firstFreeIp(cidr: string, used: string[]): string {
  const { base, size } = parseCidr(cidr);
  const usedSet = new Set(used);
  for (let offset = 2; offset < size - 1; offset++) {
    const candidate = intToIp(base + offset);
    if (!usedSet.has(candidate)) return candidate;
  }
  throw new Error(`no free IP addresses remaining in ${cidr}`);
}

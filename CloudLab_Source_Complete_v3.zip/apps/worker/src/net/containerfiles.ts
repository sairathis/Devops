// Writes a single file into a running container via the Docker Engine API's
// putArchive (PUT /containers/{id}/archive). Used for the dns-resolver and
// lb-proxy images, which are built FROM scratch and have no shell -- so
// `docker exec` is not an option; a tar stream over the archive endpoint is
// the only way to update their config files after they've started.
import tarStream from "tar-stream";
import type Docker from "dockerode";

export async function writeFileToContainer(
  container: Docker.Container,
  destDir: string,
  fileName: string,
  contents: string,
): Promise<void> {
  const pack = tarStream.pack();
  pack.entry({ name: fileName, mode: 0o644 }, contents);
  pack.finalize();
  await container.putArchive(pack, { path: destDir });
}

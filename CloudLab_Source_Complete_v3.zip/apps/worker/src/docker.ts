import Docker from "dockerode";

const socketPath = process.env.DOCKER_SOCKET ?? "/var/run/docker.sock";
export const docker = new Docker({ socketPath });

// Naming scheme MUST match apps/api/src/adapters/docker/client.ts exactly --
// the API execs/logs against containers/networks the worker creates by name.
export function containerNameFor(instanceResourceId: string) {
  return `cloudlab-vm-${instanceResourceId}`;
}
export function networkNameFor(networkResourceId: string) {
  return `cloudlab-net-${networkResourceId}`;
}
// DNS resolvers and load balancers are singleton containers per network
// resource -- one dns-resolver serves every dns_record in that network, one
// lb-proxy container per load_balancer resource.
export function dnsResolverNameFor(networkResourceId: string) {
  return `cloudlab-dns-${networkResourceId}`;
}
export function lbProxyNameFor(lbResourceId: string) {
  return `cloudlab-lb-${lbResourceId}`;
}
export function diskVolumeNameFor(diskResourceId: string) {
  return `cloudlab-disk-${diskResourceId}`;
}
export function registryNameFor(registryResourceId: string) {
  return `cloudlab-registry-${registryResourceId}`;
}
export function bucketNameFor(bucketResourceId: string) {
  return `cloudlab-bucket-${bucketResourceId}`;
}
export function k8sClusterNetworkNameFor(clusterResourceId: string) {
  return `cloudlab-k8s-net-${clusterResourceId}`;
}
export function k8sNodeNameFor(clusterResourceId: string, index: number) {
  return `cloudlab-k8s-node-${clusterResourceId}-${index}`;
}
export function k8sPodNameFor(deploymentResourceId: string, index: number) {
  return `cloudlab-k8s-pod-${deploymentResourceId}-${index}`;
}
export function pipelineRunnerNameFor(pipelineRunResourceId: string) {
  return `cloudlab-ci-run-${pipelineRunResourceId}`;
}
// Milestone 15
export function migMemberNameFor(migResourceId: string, index: number) {
  return `cloudlab-mig-${migResourceId}-${index}`;
}
export function cloudRunContainerNameFor(serviceResourceId: string) {
  return `cloudlab-run-${serviceResourceId}`;
}

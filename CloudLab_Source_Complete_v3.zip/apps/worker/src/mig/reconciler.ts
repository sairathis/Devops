import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { networkNameFor } from "../docker.js";
import { listLiveMembers, createMember, removeMember, type InstanceTemplateSpec } from "./members.js";
import { publishResourceUpdate } from "../events.js";
import { refreshLoadBalancerForMig } from "../processors/loadbalancer.js";
import { openOrRefreshAlert, resolveAlert } from "../observability/alerts.js";

const RECONCILE_INTERVAL_MS = 10_000;

interface MigSpec {
  instanceTemplateId: string;
  networkId: string;
  targetSize: number;
}

// GCP Managed Instance Group equivalent of the k8s deployment reconciler
// (apps/worker/src/k8s/reconciler.ts) -- ticks every 10s, notices a member
// container is missing (crashed, `docker kill`-ed, manually removed) and
// starts a real replacement, unprompted. Also keeps any load balancer
// pointed at this MIG (load_balancer.spec.managedInstanceGroupId) hot-reloaded
// with the current live backend set, so autoscaling/self-healing is visible
// end-to-end through the load balancer too, not just in the MIG's own count.
export async function reconcileMigsOnce() {
  const groups = await db.select().from(resources).where(eq(resources.type, "managed_instance_group"));
  for (const mig of groups) {
    if (mig.status !== "READY") continue;
    try {
      const spec = mig.spec as MigSpec;
      const desired = Math.max(1, Math.min(10, spec.targetSize ?? 1));
      const live = await listLiveMembers(mig.id);
      const liveIndices = new Set(
        live.map((c) => c.Labels?.["cloudlab.migIndex"]).filter((v): v is string => v !== undefined).map(Number),
      );

      const missing: number[] = [];
      for (let i = 0; i < desired; i++) if (!liveIndices.has(i)) missing.push(i);
      const excess = [...liveIndices].filter((i) => i >= desired);

      if (missing.length === 0 && excess.length === 0) {
        await resolveAlert(mig.id, "mig_under_replicated");
        continue;
      }

      if (missing.length > 0) {
        await openOrRefreshAlert({
          projectId: mig.projectId,
          resourceId: mig.id,
          ruleKey: "mig_under_replicated",
          severity: "WARNING",
          message: `${missing.length}/${desired} member(s) missing, reconciler is restarting them`,
        });
        const [template] = await db.select().from(resources).where(eq(resources.id, spec.instanceTemplateId)).limit(1);
        if (template) {
          const networkName = networkNameFor(spec.networkId);
          const templateSpec = template.spec as InstanceTemplateSpec;
          for (const index of missing) {
            await createMember({ migResourceId: mig.id, projectId: mig.projectId, index, networkName, template: templateSpec });
          }
        }
      }
      for (const index of excess) await removeMember(mig.id, index);

      const liveCount = desired - missing.length + missing.length; // after healing, == desired (best-effort)
      await setResourceStatus(mig.id, "READY", missing.length ? `Reconciler restarted ${missing.length} missing member(s)` : `Reconciler removed ${excess.length} excess member(s)`, { liveCount });
      await publishResourceUpdate(mig.projectId, mig.id);
      if (missing.length === 0) await resolveAlert(mig.id, "mig_under_replicated");
      console.log(`mig reconciler: reconciled group ${mig.name} (${mig.id}) -- +${missing.length}/-${excess.length}`);

      // Refresh any load balancer dynamically targeting this MIG.
      const lbs = await db.select().from(resources).where(eq(resources.type, "load_balancer"));
      for (const lb of lbs) {
        if (lb.status !== "READY") continue;
        const lbSpec = lb.spec as { managedInstanceGroupId?: string; networkId: string; backendInstanceIds: string[] };
        if (lbSpec.managedInstanceGroupId === mig.id) {
          await refreshLoadBalancerForMig(lb.id, lbSpec).catch((err) => console.error(`mig reconciler: failed to refresh lb ${lb.id}:`, (err as Error).message));
        }
      }
    } catch (err) {
      console.error(`mig reconciler: failed to reconcile group ${mig.id}:`, (err as Error).message);
    }
  }
}

export function startMigReconciler() {
  const timer = setInterval(() => {
    reconcileMigsOnce().catch((err) => console.error("mig reconciler tick failed:", err));
  }, RECONCILE_INTERVAL_MS);
  timer.unref();
  console.log(`mig reconciler started (every ${RECONCILE_INTERVAL_MS / 1000}s)`);
}

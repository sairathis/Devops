import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { docker, networkNameFor } from "../docker.js";
import { listLiveMembers } from "./members.js";

// Shared by the MIG reconciler and the load-balancer processor: "what are
// this Managed Instance Group's real, currently-live backend IPs right now"
// -- computed fresh from `docker inspect`, never cached, so a load balancer
// pointed at a MIG (spec.managedInstanceGroupId) always reflects genuine
// container state, the same way GCP's own managed-instance-group backend
// service does.
export async function computeMigBackends(migResourceId: string): Promise<{ name: string; ip: string }[]> {
  const [mig] = await db.select().from(resources).where(eq(resources.id, migResourceId)).limit(1);
  if (!mig) return [];
  const spec = mig.spec as { networkId: string };
  const networkName = networkNameFor(spec.networkId);
  const live = await listLiveMembers(migResourceId);
  const backends: { name: string; ip: string }[] = [];
  for (const c of live) {
    const info = await docker.getContainer(c.Id).inspect();
    const ip = info.NetworkSettings.Networks[networkName]?.IPAddress;
    if (ip) backends.push({ name: info.Name.replace(/^\//, ""), ip });
  }
  return backends;
}

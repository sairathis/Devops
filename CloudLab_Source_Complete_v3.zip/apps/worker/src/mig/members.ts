import { docker, migMemberNameFor } from "../docker.js";
import { config } from "../../../api/src/config.js";

// GCP Managed Instance Group members. Modeled directly on
// apps/worker/src/k8s/pods.ts's real pod-container pattern: each member is a
// genuine `docker run` container (not a row pretending to be one) started
// straight from an instance template's blueprint, labeled so the reconciler
// (mig/reconciler.ts) can find "how many are actually alive right now" the
// same honest way the k8s reconciler does for pods.
export interface InstanceTemplateSpec {
  image?: string;
  command?: string[];
  publish?: boolean;
}

export async function listLiveMembers(migResourceId: string) {
  return docker.listContainers({
    all: false,
    filters: JSON.stringify({ label: [`cloudlab.migId=${migResourceId}`] }),
  });
}

export async function createMember(opts: {
  migResourceId: string;
  projectId: string;
  index: number;
  networkName: string;
  template: InstanceTemplateSpec;
}) {
  const name = migMemberNameFor(opts.migResourceId, opts.index);
  try {
    await docker.getContainer(name).remove({ force: true });
  } catch {
    // didn't exist -- fine
  }
  const image = opts.template.image || config.guestImage;
  const publish = opts.template.publish === true;
  const container = await docker.createContainer({
    name,
    Image: image,
    Cmd: opts.template.command,
    ExposedPorts: publish ? { "8080/tcp": {} } : undefined,
    Labels: {
      "cloudlab.resourceId": opts.migResourceId,
      "cloudlab.projectId": opts.projectId,
      "cloudlab.migId": opts.migResourceId,
      "cloudlab.migIndex": String(opts.index),
    },
    HostConfig: {
      NetworkMode: opts.networkName,
      PortBindings: publish ? { "8080/tcp": [{ HostPort: "" }] } : undefined,
      RestartPolicy: { Name: "no" },
    },
  });
  await container.start();
  return container.inspect();
}

export async function removeMember(migResourceId: string, index: number) {
  try {
    await docker.getContainer(migMemberNameFor(migResourceId, index)).remove({ force: true });
  } catch (err) {
    if ((err as { statusCode?: number }).statusCode !== 404) throw err;
  }
}

export async function removeAllMembers(migResourceId: string) {
  const containers = await docker.listContainers({
    all: true,
    filters: JSON.stringify({ label: [`cloudlab.migId=${migResourceId}`] }),
  });
  for (const c of containers) {
    try {
      await docker.getContainer(c.Id).remove({ force: true });
    } catch {
      // already gone
    }
  }
}

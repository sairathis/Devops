// See apps/api/src/config.ts for why both the default cwd-relative load AND
// an explicit monorepo-root load happen here -- this process is started
// with cwd=apps/worker, so `dotenv/config`'s default path never found the
// real .env at the repo root, and every process ended up minting its own
// random SECRETS_MASTER_KEY fallback instead of sharing one.
import dotenv from "dotenv";
import { fileURLToPath } from "node:url";
dotenv.config();
dotenv.config({ path: fileURLToPath(new URL("../../../.env", import.meta.url)) });
import { Worker } from "bullmq";
import { Redis } from "ioredis";
import { OPERATIONS_QUEUE, type OperationJobData } from "./queue.js";
import { processNetworkCreate, processNetworkDelete } from "./processors/network.js";
import { processInstanceCreate, processInstanceStart, processInstanceStop, processInstanceDelete } from "./processors/instance.js";
import { processSubnetCreate, processSubnetDelete } from "./processors/subnet.js";
import { processFirewallRuleCreate, processFirewallRuleDelete } from "./processors/firewall.js";
import { processDnsRecordCreate, processDnsRecordUpdate, processDnsRecordDelete } from "./processors/dns.js";
import { processLoadBalancerCreate, processLoadBalancerUpdate, processLoadBalancerDelete } from "./processors/loadbalancer.js";
import { processDiskCreate, processDiskDelete } from "./processors/disk.js";
import { processRegistryCreate, processRegistryDelete } from "./processors/registry.js";
import { processContainerImageCreate, processContainerImageDelete } from "./processors/image.js";
import { processBucketCreate, processBucketDelete } from "./processors/bucket.js";
import { processDatabaseCreate, processDatabaseDelete } from "./processors/database.js";
import { processSecretCreate, processSecretDelete } from "./processors/secret.js";
import { processK8sClusterCreate, processK8sClusterDelete } from "./processors/k8sCluster.js";
import { processK8sDeploymentCreate, processK8sDeploymentDelete, processK8sDeploymentScale } from "./processors/k8sDeployment.js";
import { startReconciler } from "./k8s/reconciler.js";
import { processPipelineCreate, processPipelineDelete } from "./processors/pipeline.js";
import { processPipelineRunCreate, processPipelineRunDelete } from "./processors/pipelineRun.js";
import { startMetricsCollector } from "./observability/metricsCollector.js";
import { startStatusAlertEvaluator } from "./observability/statusAlerts.js";
import { processInstanceCrash } from "./processors/instanceFault.js";
import { processNetworkFaultBlackhole, processNetworkFaultRevert } from "./processors/networkFault.js";
import { startInstanceHealthMonitor } from "./observability/instanceHealth.js";
import { startNetworkHealthMonitor } from "./observability/networkHealth.js";
// Milestone 15
import { processServiceAccountCreate, processServiceAccountDelete } from "./processors/serviceAccount.js";
import { processInstanceTemplateCreate, processInstanceTemplateDelete } from "./processors/instanceTemplate.js";
import { processManagedInstanceGroupCreate, processManagedInstanceGroupDelete, processManagedInstanceGroupResize } from "./processors/managedInstanceGroup.js";
import { processNatGatewayCreate, processNatGatewayDelete } from "./processors/natGateway.js";
import { processVpcPeeringCreate, processVpcPeeringDelete } from "./processors/vpcPeering.js";
import { processSharedVpcAttachmentCreate, processSharedVpcAttachmentDelete } from "./processors/sharedVpc.js";
import { processBigqueryDatasetCreate, processBigqueryDatasetDelete } from "./processors/bigqueryDataset.js";
import { processComposerEnvironmentCreate, processComposerEnvironmentDelete } from "./processors/composerEnvironment.js";
import { processCloudRunServiceCreate, processCloudRunServiceDelete } from "./processors/cloudRunService.js";
import { startMigReconciler } from "./mig/reconciler.js";
import { startComposerScheduler } from "./composer/scheduler.js";
import { startCloudRunIdleChecker } from "./cloudrun/idleChecker.js";

const connection = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", { maxRetriesPerRequest: null });

const handlers: Record<OperationJobData["type"], (job: OperationJobData) => Promise<void>> = {
  "network.create": processNetworkCreate,
  "network.delete": processNetworkDelete,
  "instance.create": processInstanceCreate,
  "instance.start": processInstanceStart,
  "instance.stop": processInstanceStop,
  "instance.delete": processInstanceDelete,
  "subnet.create": processSubnetCreate,
  "subnet.delete": processSubnetDelete,
  "firewall_rule.create": processFirewallRuleCreate,
  "firewall_rule.delete": processFirewallRuleDelete,
  "dns_record.create": processDnsRecordCreate,
  "dns_record.update": processDnsRecordUpdate,
  "dns_record.delete": processDnsRecordDelete,
  "load_balancer.create": processLoadBalancerCreate,
  "load_balancer.update": processLoadBalancerUpdate,
  "load_balancer.delete": processLoadBalancerDelete,
  "disk.create": processDiskCreate,
  "disk.delete": processDiskDelete,
  "registry.create": processRegistryCreate,
  "registry.delete": processRegistryDelete,
  "container_image.create": processContainerImageCreate,
  "container_image.delete": processContainerImageDelete,
  "bucket.create": processBucketCreate,
  "bucket.delete": processBucketDelete,
  "database.create": processDatabaseCreate,
  "database.delete": processDatabaseDelete,
  "secret.create": processSecretCreate,
  "secret.delete": processSecretDelete,
  "k8s_cluster.create": processK8sClusterCreate,
  "k8s_cluster.delete": processK8sClusterDelete,
  "k8s_deployment.create": processK8sDeploymentCreate,
  "k8s_deployment.delete": processK8sDeploymentDelete,
  "k8s_deployment.scale": processK8sDeploymentScale,
  "pipeline.create": processPipelineCreate,
  "pipeline.delete": processPipelineDelete,
  "pipeline_run.create": processPipelineRunCreate,
  "pipeline_run.delete": processPipelineRunDelete,
  "instance.crash": processInstanceCrash,
  "network.fault_blackhole": processNetworkFaultBlackhole,
  "network.fault_revert": processNetworkFaultRevert,
  "service_account.create": processServiceAccountCreate,
  "service_account.delete": processServiceAccountDelete,
  "instance_template.create": processInstanceTemplateCreate,
  "instance_template.delete": processInstanceTemplateDelete,
  "managed_instance_group.create": processManagedInstanceGroupCreate,
  "managed_instance_group.delete": processManagedInstanceGroupDelete,
  "managed_instance_group.resize": processManagedInstanceGroupResize,
  "nat_gateway.create": processNatGatewayCreate,
  "nat_gateway.delete": processNatGatewayDelete,
  "vpc_peering.create": processVpcPeeringCreate,
  "vpc_peering.delete": processVpcPeeringDelete,
  "shared_vpc_attachment.create": processSharedVpcAttachmentCreate,
  "shared_vpc_attachment.delete": processSharedVpcAttachmentDelete,
  "bigquery_dataset.create": processBigqueryDatasetCreate,
  "bigquery_dataset.delete": processBigqueryDatasetDelete,
  "composer_environment.create": processComposerEnvironmentCreate,
  "composer_environment.delete": processComposerEnvironmentDelete,
  "cloud_run_service.create": processCloudRunServiceCreate,
  "cloud_run_service.delete": processCloudRunServiceDelete,
};

const worker = new Worker<OperationJobData>(
  OPERATIONS_QUEUE,
  async (job) => {
    const handler = handlers[job.data.type];
    if (!handler) throw new Error(`no handler for job type ${job.data.type}`);
    await handler(job.data);
  },
  { connection, concurrency: 4 },
);

worker.on("ready", () => {
  console.log("cloudlab-worker ready, waiting for operations...");
  startReconciler();
  startMetricsCollector();
  startStatusAlertEvaluator();
  startInstanceHealthMonitor();
  startNetworkHealthMonitor();
  startMigReconciler();
  startComposerScheduler();
  startCloudRunIdleChecker();
});
worker.on("failed", (job, err) => console.error(`job ${job?.id} (${job?.name}) failed:`, err.message));
worker.on("completed", (job) => console.log(`job ${job.id} (${job.name}) completed`));

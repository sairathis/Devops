import { docker } from "../docker.js";
import { config } from "../../../api/src/config.js";

// Shared pod-container helpers used by both the deployment processor
// (create/scale/delete) and the reconciliation loop (reconciler.ts), so
// "what counts as a live pod for this deployment" is defined in exactly one
// place.
export function podContainerName(deploymentResourceId: string, index: number) {
  return `cloudlab-k8s-pod-${deploymentResourceId}-${index}`;
}

export async function listLivePods(deploymentResourceId: string) {
  const containers = await docker.listContainers({
    all: false, // running only -- an exited pod is not "live" and should be replaced
    filters: JSON.stringify({ label: [`cloudlab.k8sDeploymentId=${deploymentResourceId}`] }),
  });
  return containers;
}

export async function createPod(opts: {
  deploymentResourceId: string;
  projectId: string;
  index: number;
  clusterNetworkName: string;
  image: string;
  command?: string[];
}) {
  const name = podContainerName(opts.deploymentResourceId, opts.index);
  // A previous pod at this index may still exist in a stopped/errored state
  // (e.g. a crashed replacement) -- clear it before recreating so the name
  // doesn't collide.
  try {
    await docker.getContainer(name).remove({ force: true });
  } catch {
    // didn't exist -- fine
  }
  const container = await docker.createContainer({
    name,
    Image: opts.image,
    Cmd: opts.command,
    Labels: {
      "cloudlab.resourceId": opts.deploymentResourceId,
      "cloudlab.projectId": opts.projectId,
      "cloudlab.k8sRole": "pod",
      "cloudlab.k8sDeploymentId": opts.deploymentResourceId,
      "cloudlab.k8sPodIndex": String(opts.index),
    },
    HostConfig: { NetworkMode: opts.clusterNetworkName, RestartPolicy: { Name: "no" } },
  });
  await container.start();
  const info = await container.inspect();
  return info;
}

export function defaultPodImage() {
  return config.guestImage;
}

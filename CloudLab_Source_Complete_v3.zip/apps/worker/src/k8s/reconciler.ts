import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { k8sClusterNetworkNameFor } from "../docker.js";
import { createPod, listLivePods, defaultPodImage } from "./pods.js";
import { publishResourceUpdate } from "../events.js";
import { openOrRefreshAlert, resolveAlert } from "../observability/alerts.js";

const RECONCILE_INTERVAL_MS = 10_000;

interface DeploymentSpec {
  clusterId: string;
  image?: string;
  replicas?: number;
  command?: string[];
}

// The one piece of Kubernetes behavior this milestone set out to actually
// demonstrate, not just describe: a real controller loop that notices a pod
// is gone and starts a replacement, unprompted. This is intentionally
// separate from any Docker RestartPolicy (pods are created with
// RestartPolicy: "no" -- see k8s/pods.ts) so the self-healing you see is
// genuinely this loop's doing, verifiable by `docker kill`-ing a pod
// container directly and watching a replacement appear within one tick.
export async function reconcileOnce() {
  const deployments = await db.select().from(resources).where(eq(resources.type, "k8s_deployment"));
  for (const deployment of deployments) {
    if (deployment.status !== "READY") continue;
    try {
      const spec = deployment.spec as DeploymentSpec;
      const desired = Math.max(1, Math.min(20, spec.replicas ?? 1));
      const live = await listLivePods(deployment.id);
      const liveIndices = new Set(
        live
          .map((c) => c.Labels?.["cloudlab.k8sPodIndex"])
          .filter((v): v is string => v !== undefined)
          .map((v) => Number(v)),
      );
      const missing: number[] = [];
      for (let i = 0; i < desired; i++) if (!liveIndices.has(i)) missing.push(i);
      if (missing.length === 0) {
        await resolveAlert(deployment.id, "pods_under_replicated");
        continue;
      }
      await openOrRefreshAlert({
        projectId: deployment.projectId,
        resourceId: deployment.id,
        ruleKey: "pods_under_replicated",
        severity: "WARNING",
        message: `${missing.length}/${desired} pod(s) missing, reconciler is restarting them`,
      });

      const [cluster] = await db.select().from(resources).where(eq(resources.id, spec.clusterId)).limit(1);
      if (!cluster || cluster.status !== "READY") continue; // nothing to schedule onto
      const networkName = k8sClusterNetworkNameFor(cluster.id);
      const image = spec.image || defaultPodImage();

      for (const index of missing) {
        await createPod({ deploymentResourceId: deployment.id, projectId: deployment.projectId, index, clusterNetworkName: networkName, image, command: spec.command });
      }
      await setResourceStatus(deployment.id, "READY", `Reconciler restarted ${missing.length} missing pod(s): index ${missing.join(", ")}`);
      await publishResourceUpdate(deployment.projectId, deployment.id);
      await resolveAlert(deployment.id, "pods_under_replicated");
      console.log(`k8s reconciler: healed deployment ${deployment.name} (${deployment.id}), restarted pod index ${missing.join(", ")}`);
    } catch (err) {
      console.error(`k8s reconciler: failed to reconcile deployment ${deployment.id}:`, (err as Error).message);
    }
  }
}

export function startReconciler() {
  const timer = setInterval(() => {
    reconcileOnce().catch((err) => console.error("k8s reconciler tick failed:", err));
  }, RECONCILE_INTERVAL_MS);
  timer.unref();
  console.log(`k8s reconciler started (every ${RECONCILE_INTERVAL_MS / 1000}s)`);
}

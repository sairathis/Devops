import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources, resourceMetrics } from "../../../api/src/db/schema.js";
import { docker, containerNameFor } from "../docker.js";
import { openOrRefreshAlert, resolveAlert } from "./alerts.js";

const COLLECT_INTERVAL_MS = 15_000;
const HIGH_CPU_THRESHOLD_PERCENT = 80;

// Real time-series metrics, sourced from the exact same Docker Engine
// container.stats() accounting the milestone 3 live-stats panel already
// reads live (apps/api/src/adapters/docker/instance.ts's getStats) --
// this collector just also persists a sample every 15s so a resource has a
// real history, not only a live snapshot. Scope: `instance` resources only
// for this pass (see ROADMAP.md) -- k8s pods/nodes and CI runner containers
// are ephemeral enough that persisting their metrics was judged lower value
// than covering the remaining milestones.
async function sampleInstance(resourceId: string, projectId: string) {
  let container;
  try {
    container = docker.getContainer(containerNameFor(resourceId));
    const stats = await container.stats({ stream: false });
    const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
    const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;
    const onlineCpus = stats.cpu_stats.online_cpus || stats.cpu_stats.cpu_usage.percpu_usage?.length || 1;
    const cpuPercent = systemDelta > 0 && cpuDelta > 0 ? (cpuDelta / systemDelta) * onlineCpus * 100 : 0;
    const memUsageBytes = stats.memory_stats.usage ?? 0;
    const memLimitBytes = stats.memory_stats.limit ?? 0;
    const networkRxBytes = Object.values(stats.networks ?? {}).reduce((sum: number, n: any) => sum + (n.rx_bytes ?? 0), 0);
    const networkTxBytes = Object.values(stats.networks ?? {}).reduce((sum: number, n: any) => sum + (n.tx_bytes ?? 0), 0);

    const roundedCpu = Math.round(cpuPercent);
    await db.insert(resourceMetrics).values({
      resourceId,
      projectId,
      cpuPercent: roundedCpu,
      memUsageMb: Math.round(memUsageBytes / 1024 / 1024),
      memLimitMb: Math.round(memLimitBytes / 1024 / 1024),
      networkRxBytes,
      networkTxBytes,
    });

    if (roundedCpu >= HIGH_CPU_THRESHOLD_PERCENT) {
      await openOrRefreshAlert({
        projectId,
        resourceId,
        ruleKey: "high_cpu",
        severity: "WARNING",
        message: `CPU at ${roundedCpu}% (threshold ${HIGH_CPU_THRESHOLD_PERCENT}%)`,
      });
    } else {
      await resolveAlert(resourceId, "high_cpu");
    }
  } catch {
    // Container stopped/removed between the resource query and the stats
    // call -- skip this tick for this resource rather than failing the loop.
  }
}

export async function collectMetricsOnce() {
  const readyInstances = await db.select().from(resources).where(eq(resources.type, "instance"));
  for (const instance of readyInstances) {
    if (instance.status !== "READY") continue;
    await sampleInstance(instance.id, instance.projectId);
  }
}

export function startMetricsCollector() {
  const timer = setInterval(() => {
    collectMetricsOnce().catch((err) => console.error("metrics collector tick failed:", err));
  }, COLLECT_INTERVAL_MS);
  timer.unref();
  console.log(`metrics collector started (every ${COLLECT_INTERVAL_MS / 1000}s)`);
}

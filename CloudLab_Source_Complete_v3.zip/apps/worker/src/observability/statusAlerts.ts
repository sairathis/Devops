import { and, notInArray } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { openOrRefreshAlert, resolveAlert } from "./alerts.js";

const CHECK_INTERVAL_MS = 15_000;

// The simplest, most honest alert rule there is: a resource's own status is
// already the ground truth for "something is wrong" (every processor in
// this codebase sets FAILED/DEGRADED only on a genuine infrastructure
// error, never speculatively) -- this just turns that existing signal into
// a first-class alert instead of something a user would only notice by
// scanning the resource table for a red badge.
export async function evaluateStatusAlertsOnce() {
  const broken = await db.select().from(resources).where(and(notInArray(resources.status, ["DELETED"])));
  for (const r of broken) {
    if (r.status === "FAILED" || r.status === "DEGRADED") {
      await openOrRefreshAlert({
        projectId: r.projectId,
        resourceId: r.id,
        ruleKey: "resource_unhealthy",
        severity: r.status === "FAILED" ? "CRITICAL" : "WARNING",
        message: `${r.type} "${r.name}" is ${r.status}`,
      });
    } else {
      await resolveAlert(r.id, "resource_unhealthy");
    }
  }
}

export function startStatusAlertEvaluator() {
  const timer = setInterval(() => {
    evaluateStatusAlertsOnce().catch((err) => console.error("status alert evaluator tick failed:", err));
  }, CHECK_INTERVAL_MS);
  timer.unref();
  console.log(`status alert evaluator started (every ${CHECK_INTERVAL_MS / 1000}s)`);
}

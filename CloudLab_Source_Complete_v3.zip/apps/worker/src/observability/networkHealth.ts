import { and, eq, notInArray } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources, operations } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, networkNameFor } from "../docker.js";
import { publishResourceUpdate } from "../events.js";

const CHECK_INTERVAL_MS = 15_000;

// A network.delete already owns the transition off of READY; nothing else
// takes a READY network away from READY except this monitor detecting real
// drift (network.fault_blackhole moves it to DEGRADED, not away from
// READY, so it doesn't need to be excluded here).
const IN_FLIGHT_TYPES = ["network.delete"];

// Milestone 13: the network-side counterpart to Milestone 11's instance
// health monitor -- the same real gap existed for networks and nothing had
// closed it yet. A READY network's `metadata.dockerNetworkId` is only ever
// true the moment network.create's worker processor writes it; if that
// real Docker network is later removed by anything outside this app (a
// host-level `docker network rm`, a Docker prune, manual sandbox cleanup),
// the database goes on claiming READY forever with nothing to catch it.
// This also directly matters for Milestone 13's CIDR-collision check
// (routes/networks.ts) -- that check trusts `status` to mean "this CIDR is
// genuinely still reserved", so a stale READY row for a network that no
// longer exists in Docker would incorrectly block a brand new network from
// reusing that same address space forever.
export async function checkNetworkHealthOnce() {
  const networks = await db.select().from(resources).where(eq(resources.type, "network"));
  for (const network of networks) {
    if (network.status !== "READY") continue;

    const inFlight = await db
      .select()
      .from(operations)
      .where(and(eq(operations.resourceId, network.id), notInArray(operations.status, ["SUCCEEDED", "FAILED"])));
    if (inFlight.some((op) => IN_FLIGHT_TYPES.includes(op.type))) continue;

    const dockerNetworkId = (network.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    if (!dockerNetworkId) {
      // A genuinely-provisioned READY network always gets a dockerNetworkId
      // written by network.create's processor -- a READY row without one is
      // itself real drift (incomplete provisioning that somehow reached
      // READY anyway), not something to silently skip forever.
      await setResourceStatus(
        network.id,
        "FAILED",
        "Health monitor found this network READY with no dockerNetworkId on record -- it was never genuinely backed by a real Docker network. Create a new network to replace it.",
        { lastFault: { type: "detected_missing_network" } },
      );
      await publishResourceUpdate(network.projectId, network.id);
      continue;
    }

    try {
      await docker.getNetwork(networkNameFor(network.id)).inspect();
    } catch (err) {
      const statusCode = (err as { statusCode?: number }).statusCode;
      if (statusCode === 404) {
        await setResourceStatus(
          network.id,
          "FAILED",
          "Health monitor found this network's real Docker network missing from the daemon entirely -- " +
            "the database record was stale until this check caught it. Create a new network to replace it.",
          { lastFault: { type: "detected_missing_network" } },
        );
        await publishResourceUpdate(network.projectId, network.id);
      }
      // Any other error (daemon briefly unreachable, etc.) is left for the
      // next tick rather than flipping status on a transient monitor failure.
    }
  }
}

export function startNetworkHealthMonitor() {
  const timer = setInterval(() => {
    checkNetworkHealthOnce().catch((err) => console.error("network health monitor tick failed:", err));
  }, CHECK_INTERVAL_MS);
  timer.unref();
  console.log(`network health monitor started (every ${CHECK_INTERVAL_MS / 1000}s)`);
}

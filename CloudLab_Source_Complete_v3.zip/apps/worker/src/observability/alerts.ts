import { and, eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { alerts } from "../../../api/src/db/schema.js";

// Every alert here is derived from real state this build already collects
// (a resource's own status transitions, a real docker stats sample, the k8s
// reconciler's own missing-pod count) -- never a synthetic "3 alerts" number
// for a dashboard to look populated.
export async function openOrRefreshAlert(opts: { projectId: string; resourceId: string; ruleKey: string; severity: "WARNING" | "CRITICAL"; message: string }) {
  const [existing] = await db
    .select()
    .from(alerts)
    .where(and(eq(alerts.resourceId, opts.resourceId), eq(alerts.ruleKey, opts.ruleKey), eq(alerts.status, "OPEN")))
    .limit(1);
  if (existing) {
    if (existing.message !== opts.message) {
      await db.update(alerts).set({ message: opts.message }).where(eq(alerts.id, existing.id));
    }
    return existing.id;
  }
  const [row] = await db
    .insert(alerts)
    .values({ projectId: opts.projectId, resourceId: opts.resourceId, ruleKey: opts.ruleKey, severity: opts.severity, message: opts.message, status: "OPEN" })
    .returning();
  return row.id;
}

export async function resolveAlert(resourceId: string, ruleKey: string) {
  await db
    .update(alerts)
    .set({ status: "RESOLVED", resolvedAt: new Date() })
    .where(and(eq(alerts.resourceId, resourceId), eq(alerts.ruleKey, ruleKey), eq(alerts.status, "OPEN")));
}

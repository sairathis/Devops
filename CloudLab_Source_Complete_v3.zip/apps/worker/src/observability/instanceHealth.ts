import { and, eq, notInArray } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources, operations } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, containerNameFor } from "../docker.js";
import { publishResourceUpdate } from "../events.js";

const CHECK_INTERVAL_MS = 10_000;

// Any of these still being PENDING/RUNNING for a resource means a
// legitimate operation already owns its status transition right now --
// the monitor must not race it.
const IN_FLIGHT_TYPES = ["instance.start", "instance.stop", "instance.delete", "instance.crash"];

// Milestone 11: this is the other half of "fault injection & troubleshooting"
// -- detecting a real crash, not just causing one. Before this, nothing in
// the codebase ever re-checked a READY instance's actual container state;
// apps/worker/src/observability/statusAlerts.ts (Milestone 9) only reads
// the resources.status column, so a container that died for any reason
// other than going through this app (an out-of-band `docker kill`, an OOM
// kill, the Milestone 11 crash fault itself if this loop is the one that
// catches it) would leave the database silently claiming READY forever.
// This closes that gap with the same dockerode inspect() call every
// processor already uses -- comparing real Docker state against the
// database's belief and correcting the belief when they disagree.
export async function checkInstanceHealthOnce() {
  const instances = await db.select().from(resources).where(eq(resources.type, "instance"));
  for (const instance of instances) {
    if (instance.status !== "READY") continue; // only watching for READY -> unexpectedly-down drift

    const inFlight = await db
      .select()
      .from(operations)
      .where(and(eq(operations.resourceId, instance.id), notInArray(operations.status, ["SUCCEEDED", "FAILED"])));
    if (inFlight.some((op) => IN_FLIGHT_TYPES.includes(op.type))) continue;

    try {
      const container = docker.getContainer(containerNameFor(instance.id));
      const info = await container.inspect();
      if (!info.State.Running) {
        await setResourceStatus(
          instance.id,
          "FAILED",
          `Health monitor detected the container is no longer running (exit code ${info.State.ExitCode}` +
            `${info.State.OOMKilled ? ", OOM-killed" : ""}, stopped at ${info.State.FinishedAt}) -- ` +
            `the database record was stale until this check caught it. Use Start to recover.`,
          { lastFault: { type: "detected_crash", exitCode: info.State.ExitCode, oomKilled: info.State.OOMKilled, finishedAt: info.State.FinishedAt } },
        );
        await publishResourceUpdate(instance.projectId, instance.id);
      }
    } catch (err) {
      const statusCode = (err as { statusCode?: number }).statusCode;
      if (statusCode === 404) {
        await setResourceStatus(instance.id, "FAILED", "Health monitor found the container missing from the Docker daemon entirely.");
        await publishResourceUpdate(instance.projectId, instance.id);
      }
      // Any other error (daemon briefly unreachable, etc.) is left for the
      // next tick rather than flipping status on a transient monitor failure.
    }
  }
}

export function startInstanceHealthMonitor() {
  const timer = setInterval(() => {
    checkInstanceHealthOnce().catch((err) => console.error("instance health monitor tick failed:", err));
  }, CHECK_INTERVAL_MS);
  timer.unref();
  console.log(`instance health monitor started (every ${CHECK_INTERVAL_MS / 1000}s)`);
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { config } from "../../../api/src/config.js";
import { docker, networkNameFor, cloudRunContainerNameFor } from "../docker.js";
import { publishResourceUpdate } from "../events.js";

export interface CloudRunSpec {
  networkId: string;
  image?: string;
  idleTimeoutSeconds?: number;
}

async function isRunning(name: string): Promise<boolean> {
  try {
    const info = await docker.getContainer(name).inspect();
    return info.State.Running;
  } catch {
    return false;
  }
}

// Real scale-to-zero: no container exists for a Cloud Run service until this
// is called by a genuine invoke request (see routes/cloudRun.ts) -- a true
// cold start, `docker run` happening synchronously inside the request that
// needed it, exactly mirroring GCP Cloud Run's own cold-start behavior for a
// scaled-to-zero revision (instead of a container quietly kept warm the
// whole time, which would misrepresent what "scale to zero" means).
export async function ensureRunning(resourceId: string): Promise<{ ip?: string; hostPort?: string; coldStart: boolean }> {
  const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  if (!row) throw new Error("cloud run service not found");
  const spec = row.spec as CloudRunSpec;
  const name = cloudRunContainerNameFor(resourceId);
  const networkName = networkNameFor(spec.networkId);

  if (await isRunning(name)) {
    const info = await docker.getContainer(name).inspect();
    const ip = info.NetworkSettings.Networks[networkName]?.IPAddress;
    const hostPort = info.NetworkSettings.Ports?.["8080/tcp"]?.[0]?.HostPort;
    return { ip, hostPort, coldStart: false };
  }

  try {
    await docker.getContainer(name).remove({ force: true });
  } catch {
    // no stale container -- fine
  }
  const container = await docker.createContainer({
    name,
    Image: spec.image || config.guestImage,
    ExposedPorts: { "8080/tcp": {} },
    Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": row.projectId, "cloudlab.cloudRun": "true" },
    HostConfig: {
      NetworkMode: networkName,
      PortBindings: { "8080/tcp": [{ HostPort: "" }] },
      RestartPolicy: { Name: "no" },
    },
  });
  await container.start();
  const info = await container.inspect();
  const ip = info.NetworkSettings.Networks[networkName]?.IPAddress;
  const hostPort = info.NetworkSettings.Ports["8080/tcp"]?.[0]?.HostPort;

  await setResourceStatus(resourceId, "READY", "Cold-started for an invoke request", { state: "RUNNING", ip, hostPort });
  await publishResourceUpdate(row.projectId, resourceId);
  return { ip, hostPort, coldStart: true };
}

export async function scaleToZero(resourceId: string): Promise<void> {
  const name = cloudRunContainerNameFor(resourceId);
  const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  try {
    await docker.getContainer(name).remove({ force: true });
  } catch (err) {
    if ((err as { statusCode?: number }).statusCode !== 404) throw err;
  }
  if (row && row.status !== "DELETED" && row.status !== "DELETING") {
    await setResourceStatus(resourceId, "READY", "Scaled to zero after idle timeout -- no container running", { state: "IDLE" });
    await publishResourceUpdate(row.projectId, resourceId);
  }
}

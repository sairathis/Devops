import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { scaleToZero } from "./lifecycle.js";

const CHECK_INTERVAL_MS = 15_000; // same cadence as the other observability loops

interface CloudRunMeta {
  state?: string;
  lastInvokedAt?: string | null;
}
interface CloudRunSpec {
  idleTimeoutSeconds?: number;
}

// Real scale-to-zero enforcement: every 15s, stop any Cloud Run container
// that has been idle longer than its configured idleTimeoutSeconds (default
// 60s). This is a genuine `docker rm -f`, verifiable with `docker ps` --
// not a metadata flag flipped without the container actually going away.
export async function runIdleCheckOnce() {
  const services = await db.select().from(resources).where(eq(resources.type, "cloud_run_service"));
  for (const svc of services) {
    if (svc.status !== "READY") continue;
    const meta = svc.metadata as CloudRunMeta;
    if (meta.state !== "RUNNING" || !meta.lastInvokedAt) continue;
    const spec = svc.spec as CloudRunSpec;
    const idleTimeoutMs = Math.max(10, Math.min(3600, spec.idleTimeoutSeconds ?? 60)) * 1000;
    const idleMs = Date.now() - new Date(meta.lastInvokedAt).getTime();
    if (idleMs >= idleTimeoutMs) {
      try {
        await scaleToZero(svc.id);
        console.log(`cloud run idle checker: scaled '${svc.name}' (${svc.id}) to zero after ${Math.round(idleMs / 1000)}s idle`);
      } catch (err) {
        console.error(`cloud run idle checker: failed to scale down ${svc.id}:`, (err as Error).message);
      }
    }
  }
}

export function startCloudRunIdleChecker() {
  const timer = setInterval(() => {
    runIdleCheckOnce().catch((err) => console.error("cloud run idle checker tick failed:", err));
  }, CHECK_INTERVAL_MS);
  timer.unref();
  console.log(`cloud run idle checker started (every ${CHECK_INTERVAL_MS / 1000}s)`);
}

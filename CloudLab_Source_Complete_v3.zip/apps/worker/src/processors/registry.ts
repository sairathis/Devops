import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, registryNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// A real cloudlab/registry container (infra/registry-image) implementing
// enough of the Docker/OCI Distribution HTTP API v2 for a genuine `docker
// push`/`docker pull` to interoperate with it -- see registry.go for what's
// implemented vs. deliberately out of scope. Published on a host port so it
// can be pushed to from outside this sandbox's own Docker daemon too, the
// same way any other CloudLab-managed container is.
export async function processRegistryCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "docker run cloudlab/registry");
    const container = await docker.createContainer({
      name: registryNameFor(resourceId),
      Image: "cloudlab/registry:latest",
      ExposedPorts: { "5000/tcp": {} },
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId },
      HostConfig: {
        PortBindings: { "5000/tcp": [{ HostPort: "" }] },
        RestartPolicy: { Name: "unless-stopped" },
      },
    });
    await container.start();
    const info = await container.inspect();
    const hostPort = info.NetworkSettings.Ports["5000/tcp"]?.[0]?.HostPort;
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "Registry container started", {
      containerId: info.Id,
      hostPort,
      registryHost: `localhost:${hostPort}`,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processRegistryDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const container = docker.getContainer(registryNameFor(resourceId));
    try {
      await container.remove({ force: true, v: true });
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Registry container removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

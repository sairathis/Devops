import { setResourceStatus } from "../../../api/src/resources/model.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// Unlike every other resource type, a secret has no external infrastructure
// to provision -- the real work (AES-256-GCM encryption) already happened
// synchronously in the API route handler, before the resource row was even
// created, specifically so the plaintext value never has to travel through
// this job queue (Redis retains completed job data for a while, which would
// otherwise be a real, avoidable place for a secret to leak). This processor
// only exists so secrets go through the same CREATING -> READY operation
// lifecycle as everything else in the console/API, for consistency.
export async function processSecretCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "PROVISIONING", "DONE", "encrypted value already stored");
    await setResourceStatus(resourceId, "READY", "Secret encrypted and stored");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "INTERNAL_ERROR", message });
  }
}

export async function processSecretDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Secret deleted");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "INTERNAL_ERROR", message });
  }
}

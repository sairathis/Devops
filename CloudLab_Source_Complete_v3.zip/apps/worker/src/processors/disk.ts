import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, diskVolumeNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// A real Docker named volume. `sizeGb` is recorded for the UI/quota-style
// bookkeeping but is not enforced by Docker's local volume driver -- there
// is no quota to set without a different driver, and pretending otherwise
// would be exactly the kind of fake success this project avoids. Documented
// in ROADMAP.md rather than silently implied.
export async function processDiskCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "docker volume create");
    const name = diskVolumeNameFor(resourceId);
    const info = await docker.createVolume({ Name: name, Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId } });
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "Docker volume created", { volumeName: name, mountpoint: info.Mountpoint });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processDiskDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const volume = docker.getVolume(diskVolumeNameFor(resourceId));
    try {
      await volume.remove();
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Docker volume removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { applyVpcPeering, revokeVpcPeering } from "../net/iptables.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface PeeringSpec {
  networkAId: string;
  networkBId: string;
}

// GCP VPC Network Peering equivalent. Real bidirectional iptables FORWARD
// ACCEPT rules between the two networks' own Linux bridges -- two Docker
// networks otherwise cannot route to each other at all, so this genuinely
// enables (and, on delete, genuinely revokes) private-IP reachability
// between instances on each side, verifiable with a real ping/curl.
export async function processVpcPeeringCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as PeeringSpec;
    if (spec.networkAId === spec.networkBId) throw new Error("cannot peer a network with itself");
    const [networkA] = await db.select().from(resources).where(eq(resources.id, spec.networkAId)).limit(1);
    const [networkB] = await db.select().from(resources).where(eq(resources.id, spec.networkBId)).limit(1);
    if (!networkA || networkA.status !== "READY") throw new Error(`network ${spec.networkAId} is not READY`);
    if (!networkB || networkB.status !== "READY") throw new Error(`network ${spec.networkBId} is not READY`);
    const idA = (networkA.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    const idB = (networkB.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    if (!idA || !idB) throw new Error("one of the peered networks is missing docker network info");
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "iptables FORWARD ACCEPT both directions");
    await applyVpcPeering(resourceId, idA, idB);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await addRelationship(resourceId, networkA.id, "connects_to");
    await addRelationship(resourceId, networkB.id, "connects_to");
    await setResourceStatus(resourceId, "READY", `Peered '${networkA.name}' <-> '${networkB.name}' -- cross-network private IP routing is now real and active`, {
      dockerNetworkIdA: idA,
      dockerNetworkIdB: idB,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processVpcPeeringDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const meta = row.metadata as { dockerNetworkIdA?: string; dockerNetworkIdB?: string };
    if (meta.dockerNetworkIdA && meta.dockerNetworkIdB) {
      await revokeVpcPeering(resourceId, meta.dockerNetworkIdA, meta.dockerNetworkIdB);
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Peering rules removed -- networks are isolated again");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

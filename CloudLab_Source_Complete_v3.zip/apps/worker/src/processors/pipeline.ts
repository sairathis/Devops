import { setResourceStatus } from "../../../api/src/resources/model.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// A `pipeline` resource is just a definition (stage list + runner image) --
// no infrastructure of its own, same reasoning as processors/secret.ts. The
// real work happens per-execution in processors/pipelineRun.ts.
export async function processPipelineCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "DONE");
    await setResourceStatus(resourceId, "READY", "Pipeline definition saved");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "VALIDATION_ERROR", message });
  }
}

export async function processPipelineDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Pipeline definition removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "INTERNAL_ERROR", message });
  }
}

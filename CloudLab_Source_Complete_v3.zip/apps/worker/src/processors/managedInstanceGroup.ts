import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { networkNameFor } from "../docker.js";
import { createMember, removeAllMembers, listLiveMembers, type InstanceTemplateSpec } from "../mig/members.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface MigSpec {
  instanceTemplateId: string;
  networkId: string;
  targetSize: number;
}

// GCP Managed Instance Group equivalent. Create provisions the initial
// members synchronously (so "create a MIG" feels like one real operation,
// same as every other resource here); mig/reconciler.ts then keeps the live
// member count pinned to spec.targetSize forever after, self-healing a
// member that's crashed or been `docker kill`-ed exactly like the k8s
// deployment reconciler does for pods.
export async function processManagedInstanceGroupCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as MigSpec;
    const [template] = await db.select().from(resources).where(eq(resources.id, spec.instanceTemplateId)).limit(1);
    if (!template || template.status !== "READY" || template.type !== "instance_template") {
      throw new Error(`instance template ${spec.instanceTemplateId} is not a READY instance_template`);
    }
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    if (!network || network.status !== "READY") throw new Error(`network ${spec.networkId} is not READY`);
    const targetSize = Math.max(1, Math.min(10, spec.targetSize ?? 1));
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", `starting ${targetSize} member(s) from template '${template.name}'`);
    const networkName = networkNameFor(network.id);
    const templateSpec = template.spec as InstanceTemplateSpec;
    for (let i = 0; i < targetSize; i++) {
      await createMember({ migResourceId: resourceId, projectId, index: i, networkName, template: templateSpec });
    }
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await addRelationship(resourceId, template.id, "depends_on");
    await addRelationship(resourceId, network.id, "connects_to");
    await setResourceStatus(resourceId, "READY", `${targetSize} member(s) running; a reconciler tick (every 10s) will restart any that crash`, {
      liveCount: targetSize,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processManagedInstanceGroupResize(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "UPDATING", "RUNNING");
    // The actual scale-up/down is left to the next reconciler tick (<=10s) --
    // it already knows how to add missing members and remove excess ones,
    // so resize only needs to change the desired count it reconciles toward.
    const live = await listLiveMembers(resourceId);
    await pushStep(operationId, projectId, "UPDATING", "DONE", `${live.length} member(s) currently live; reconciler will adjust to the new target size`);
    await setResourceStatus(resourceId, "READY", "Target size updated");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processManagedInstanceGroupDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    await removeAllMembers(resourceId);
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "All members removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { config } from "../../../api/src/config.js";
import { docker, k8sClusterNetworkNameFor, k8sNodeNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// CloudLab's own lightweight container-orchestration layer, modeled on
// Kubernetes' cluster/node/pod/deployment concepts -- explicitly NOT real
// Kubernetes (no real kube-apiserver/etcd/kubelet/CNI). Every registry this
// sandbox can reach is network-blocked (docker.io, ghcr.io, registry.k8s.io,
// gcr.io, quay.io, mcr.microsoft.com all refuse the CONNECT), and a real
// kubelet or kind/k3s node needs to pull at least the pause/coredns images
// from one of those on first boot -- so standing up genuine Kubernetes here
// is not possible regardless of engineering effort, not just impractical.
// What IS real: real Docker containers as "nodes", a real Docker network as
// the cluster fabric, real containers as "pods" that a real reconciliation
// loop (see reconciler.ts) restarts if one dies -- genuine self-healing
// behavior, verifiable by `docker kill`-ing a pod container and watching a
// replacement appear, just not driven by a real kubelet's watch loop.
export async function processK8sClusterCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const nodeCount = Math.max(1, Math.min(10, (resource.spec as { nodeCount?: number }).nodeCount ?? 2));

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "docker network create (cluster fabric)");
    const network = await docker.createNetwork({
      Name: k8sClusterNetworkNameFor(resourceId),
      Driver: "bridge",
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId, "cloudlab.k8sCluster": "true" },
    });
    const networkInfo = await network.inspect();
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await pushStep(operationId, projectId, "NODES", "RUNNING", `starting ${nodeCount} node container(s)`);
    const nodeContainerIds: string[] = [];
    for (let i = 0; i < nodeCount; i++) {
      const container = await docker.createContainer({
        name: k8sNodeNameFor(resourceId, i),
        Image: config.guestImage,
        Labels: {
          "cloudlab.resourceId": resourceId,
          "cloudlab.projectId": projectId,
          "cloudlab.k8sRole": "node",
          "cloudlab.k8sNodeIndex": String(i),
        },
        HostConfig: { NetworkMode: k8sClusterNetworkNameFor(resourceId), RestartPolicy: { Name: "unless-stopped" } },
      });
      await container.start();
      const info = await container.inspect();
      nodeContainerIds.push(info.Id);
    }
    await pushStep(operationId, projectId, "NODES", "DONE");

    await setResourceStatus(resourceId, "READY", `${nodeCount}-node cluster ready`, {
      dockerNetworkId: networkInfo.Id,
      nodeCount,
      nodeContainerIds,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processK8sClusterDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const nodeCount = (resource.metadata as { nodeCount?: number })?.nodeCount ?? 0;
    for (let i = 0; i < nodeCount; i++) {
      try {
        await docker.getContainer(k8sNodeNameFor(resourceId, i)).remove({ force: true });
      } catch (err) {
        if ((err as { statusCode?: number }).statusCode !== 404) throw err;
      }
    }
    try {
      await docker.getNetwork(k8sClusterNetworkNameFor(resourceId)).remove();
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Cluster nodes and network removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

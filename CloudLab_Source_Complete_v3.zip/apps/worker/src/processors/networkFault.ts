import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, createOperation } from "../../../api/src/resources/model.js";
import { operationsQueue } from "../../../api/src/queue/queue.js";
import { applyNetworkBlackhole, revokeNetworkBlackhole } from "../net/faults.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// Milestone 11: real network fault injection. See net/faults.ts for why a
// total blackhole (real iptables DROP on the network's real bridge) is the
// fault this build can genuinely deliver, and why netem-style partial
// degradation (latency/packet-loss percentages) is not available in this
// sandbox's kernel.
export async function processNetworkFaultBlackhole(job: OperationJobData) {
  const { operationId, projectId, resourceId, params } = job;
  await startOperation(operationId, projectId);
  try {
    const durationSeconds = Math.max(5, Math.min(600, Number(params?.durationSeconds) || 30));

    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const dockerNetworkId = (resource.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    if (!dockerNetworkId) throw new Error(`network '${resource.name}' has no docker network id yet (not READY?)`);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "INJECTING_FAULT", "RUNNING", "iptables -I DOCKER-USER -i/-o <bridge> -j DROP");
    await applyNetworkBlackhole(resourceId, dockerNetworkId);
    await pushStep(operationId, projectId, "INJECTING_FAULT", "DONE");

    const appliedAt = new Date();
    const expiresAt = new Date(appliedAt.getTime() + durationSeconds * 1000);
    await setResourceStatus(
      resourceId,
      "DEGRADED",
      `Network blackholed by fault injection for ${durationSeconds}s -- all real ingress/egress traffic is being dropped at the bridge. Auto-reverts at ${expiresAt.toISOString()}.`,
      { activeFault: { type: "blackhole", appliedAt: appliedAt.toISOString(), expiresAt: expiresAt.toISOString(), durationSeconds } },
    );
    await publishResourceUpdate(projectId, resourceId);

    // The revert is a real, separately-tracked operation scheduled as a
    // delayed BullMQ job -- persisted in Redis, not an in-process setTimeout
    // -- so it survives a worker restart instead of leaving the network
    // blackholed forever if the process happens to restart mid-fault.
    const revertOp = await createOperation({ projectId, resourceId, type: "network.fault_revert", createdBy: resource.createdBy });
    await operationsQueue.add(
      "network.fault_revert",
      { operationId: revertOp.id, projectId, resourceId, type: "network.fault_revert" },
      { delay: durationSeconds * 1000, jobId: `fault-revert-${resourceId}` },
    );

    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "FAULT_INJECTION_FAILED", message });
  }
}

export async function processNetworkFaultRevert(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const meta = (resource?.metadata as { activeFault?: { type: string }; dockerNetworkId?: string }) ?? {};

    // Idempotent no-op if the fault was already cleared by a manual cancel
    // (which enqueues this same job type immediately) or the resource is gone.
    if (!resource || resource.status === "DELETED" || meta.activeFault?.type !== "blackhole") {
      await pushStep(operationId, projectId, "REVERTING", "DONE", "fault already cleared -- nothing to revert");
      await finishOperation(operationId, projectId, true);
      return;
    }

    await pushStep(operationId, projectId, "REVERTING", "RUNNING", "iptables -D DOCKER-USER -i/-o <bridge> -j DROP");
    if (meta.dockerNetworkId) await revokeNetworkBlackhole(resourceId, meta.dockerNetworkId);
    await pushStep(operationId, projectId, "REVERTING", "DONE");

    await setResourceStatus(resourceId, "READY", "Fault injection reverted -- real network traffic restored", { activeFault: null });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await finishOperation(operationId, projectId, false, { code: "FAULT_REVERT_FAILED", message });
  }
}

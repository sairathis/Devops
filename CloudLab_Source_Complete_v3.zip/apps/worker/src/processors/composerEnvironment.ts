import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { assertValidCron } from "../composer/cron.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface ComposerSpec {
  pipelineId: string;
  schedule: string; // 5-field cron, UTC -- see composer/cron.ts
}

// Cloud Composer equivalent: wraps an existing real CI/CD pipeline (see
// Milestone 8) with a real cron schedule. What's genuinely real: the cron
// parsing/matching and the scheduler loop (composer/scheduler.ts) that
// actually enqueues real pipeline_run resources on schedule, with no human
// clicking "run". What's simplified: this is one project's worth of
// scheduled DAG triggers, not Composer's real managed Airflow cluster with
// its own web UI, task-level retries and cross-DAG dependencies.
export async function processComposerEnvironmentCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as ComposerSpec;
    const [pipeline] = await db.select().from(resources).where(eq(resources.id, spec.pipelineId)).limit(1);
    if (!pipeline || pipeline.type !== "pipeline") throw new Error(`'${spec.pipelineId}' is not a pipeline resource`);
    assertValidCron(spec.schedule);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await addRelationship(resourceId, pipeline.id, "depends_on");
    await setResourceStatus(resourceId, "READY", `Scheduler active -- '${pipeline.name}' will run automatically on schedule '${spec.schedule}' (UTC)`, {
      lastTriggeredMinuteKey: null,
      triggerCount: 0,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processComposerEnvironmentDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await setResourceStatus(resourceId, "DELETED", "Scheduler stopped");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

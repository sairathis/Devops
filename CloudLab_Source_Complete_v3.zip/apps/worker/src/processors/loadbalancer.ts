import { eq, inArray } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { docker, networkNameFor, lbProxyNameFor } from "../docker.js";
import { writeFileToContainer } from "../net/containerfiles.js";
import { computeMigBackends } from "../mig/backends.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

const CONFIG_PATH = "/etc/cloudlab";
const CONFIG_FILE = "lb-backends.json";

interface LbSpec {
  networkId: string;
  backendInstanceIds: string[];
  // Milestone 15: a load balancer can target a Managed Instance Group's live
  // member set instead of a fixed instance list -- the backend pool then
  // grows/shrinks/self-heals with the MIG automatically (see
  // mig/backends.ts and mig/reconciler.ts, which re-writes this same config
  // file on every reconcile tick).
  managedInstanceGroupId?: string;
  publish?: boolean;
}

async function writeBackendsConfig(spec: LbSpec, container: Awaited<ReturnType<typeof docker.getContainer>>) {
  let config: { name: string; ip?: string }[];
  if (spec.managedInstanceGroupId) {
    config = await computeMigBackends(spec.managedInstanceGroupId);
  } else {
    const backends = spec.backendInstanceIds.length
      ? await db.select().from(resources).where(inArray(resources.id, spec.backendInstanceIds))
      : [];
    config = backends
      .filter((b) => b.status === "READY")
      .map((b) => ({ name: b.name, ip: (b.metadata as { ip?: string }).ip }))
      .filter((b) => !!b.ip);
  }
  await writeFileToContainer(container, CONFIG_PATH, CONFIG_FILE, JSON.stringify(config, null, 2));
  return config.length;
}

// Exported so the MIG reconciler can hot-reload a load balancer's backend
// set on every tick without going through a full operation lifecycle --
// mirrors how the k8s reconciler patches deployment state directly.
export async function refreshLoadBalancerForMig(lbResourceId: string, spec: LbSpec) {
  const container = docker.getContainer(lbProxyNameFor(lbResourceId));
  return writeBackendsConfig(spec, container);
}

// Real HTTP reverse proxy (infra/lb-image) doing round-robin over healthy
// backends with active health checks against each backend's /healthz -- see
// lb-proxy.go. `/__lb_status` on the container reports which backends are
// currently considered healthy, exposed through the API for the UI.
export async function processLoadBalancerCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as LbSpec;
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    if (!network || network.status !== "READY") throw new Error(`network ${spec.networkId} is not READY`);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "docker run cloudlab/lb-proxy");
    const dockerNetworkName = networkNameFor(network.id);
    const publish = spec.publish !== false;
    const container = await docker.createContainer({
      name: lbProxyNameFor(resourceId),
      Image: "cloudlab/lb-proxy:latest",
      ExposedPorts: { "8080/tcp": {} },
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId },
      HostConfig: {
        NetworkMode: dockerNetworkName,
        PortBindings: publish ? { "8080/tcp": [{ HostPort: "" }] } : undefined,
        RestartPolicy: { Name: "unless-stopped" },
      },
    });
    await container.start();
    const count = await writeBackendsConfig(spec, container);
    const info = await container.inspect();
    const ip = info.NetworkSettings.Networks[dockerNetworkName]?.IPAddress;
    const hostPort = info.NetworkSettings.Ports["8080/tcp"]?.[0]?.HostPort;
    await pushStep(operationId, projectId, "PROVISIONING", "DONE", `${count} healthy backend(s) configured`);

    await addRelationship(resourceId, network.id, "connects_to");
    for (const backendId of spec.backendInstanceIds) await addRelationship(resourceId, backendId, "routes_to");

    await setResourceStatus(resourceId, "READY", "Load balancer container started with round-robin + health checks", {
      containerId: info.Id,
      ip,
      hostPort,
      publicUrl: hostPort ? `http://localhost:${hostPort}` : null,
      backendCount: count,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processLoadBalancerUpdate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "UPDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as LbSpec;
    const container = docker.getContainer(lbProxyNameFor(resourceId));
    const count = await writeBackendsConfig(spec, container);
    await pushStep(operationId, projectId, "UPDATING", "DONE", `${count} healthy backend(s) configured`);

    await setResourceStatus(resourceId, "READY", "Backend set updated (config hot-reloaded by the proxy)", { backendCount: count });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processLoadBalancerDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const container = docker.getContainer(lbProxyNameFor(resourceId));
    try {
      await container.remove({ force: true });
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Load balancer container removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

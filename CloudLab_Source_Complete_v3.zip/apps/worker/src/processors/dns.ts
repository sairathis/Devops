import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { docker, networkNameFor, dnsResolverNameFor } from "../docker.js";
import { writeFileToContainer } from "../net/containerfiles.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

const RECORDS_PATH = "/etc/cloudlab";
const RECORDS_FILE = "dns-records.json";

// One real dns-resolver container (see infra/dns-image) per network,
// created lazily the first time a dns_record is added to that network, and
// reused for every subsequent record. It answers real UDP DNS queries on
// port 53 for the hostnames in its records file and forwards everything
// else to Docker's embedded resolver, so instances on the network can
// actually `nslookup` these names if configured to use it.
async function ensureResolverContainer(projectId: string, networkResourceId: string, dockerNetworkName: string) {
  const name = dnsResolverNameFor(networkResourceId);
  const container = docker.getContainer(name);
  try {
    const info = await container.inspect();
    if (!info.State.Running) await container.start();
    return container;
  } catch (err) {
    if ((err as { statusCode?: number }).statusCode !== 404) throw err;
  }
  const created = await docker.createContainer({
    name,
    Image: "cloudlab/dns-resolver:latest",
    Labels: { "cloudlab.dnsForNetwork": networkResourceId, "cloudlab.projectId": projectId },
    HostConfig: { NetworkMode: dockerNetworkName, RestartPolicy: { Name: "unless-stopped" } },
  });
  await created.start();
  return created;
}

async function writeRecordsFor(networkResourceId: string, container: Awaited<ReturnType<typeof docker.getContainer>>) {
  const rows = await db.select().from(resources).where(eq(resources.type, "dns_record"));
  const records = rows
    .filter((r) => (r.spec as { networkId?: string }).networkId === networkResourceId && r.status !== "DELETED")
    .map((r) => {
      const spec = r.spec as { hostname: string; ip: string };
      // Field name must match dns-resolver.go's `record` struct exactly
      // (json:"name") -- a mismatch here silently produces empty-keyed
      // records that never match a query, which is exactly the bug this
      // comment is here to prevent regressing.
      return { name: spec.hostname, ip: spec.ip };
    });
  await writeFileToContainer(container, RECORDS_PATH, RECORDS_FILE, JSON.stringify(records, null, 2));
  return records.length;
}

export async function processDnsRecordCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { networkId: string; hostname: string; ip: string };
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    if (!network || network.status !== "READY") throw new Error(`network ${spec.networkId} is not READY`);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "ensuring cloudlab/dns-resolver container");
    const dockerNetworkName = networkNameFor(network.id);
    const resolver = await ensureResolverContainer(projectId, network.id, dockerNetworkName);
    const info = await resolver.inspect();
    const resolverIp = info.NetworkSettings.Networks[dockerNetworkName]?.IPAddress;
    const count = await writeRecordsFor(network.id, resolver);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE", `${count} record(s) written to resolver`);

    await addRelationship(resourceId, network.id, "depends_on");
    await setResourceStatus(resourceId, "READY", "DNS record written to real resolver container", { resolverIp, resolverName: dnsResolverNameFor(network.id) });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processDnsRecordUpdate(job: OperationJobData) {
  await processDnsRecordCreate(job); // same effect: recompute + rewrite the full record set
}

export async function processDnsRecordDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { networkId: string };
    await setResourceStatus(resourceId, "DELETED", "");
    const name = dnsResolverNameFor(spec.networkId);
    try {
      const resolver = docker.getContainer(name);
      const remaining = await writeRecordsFor(spec.networkId, resolver);
      // Last record for this network gone -- tear down the resolver container
      // too, rather than leaving an orphaned sidecar attached to the network
      // (which would otherwise silently block the network's own deletion
      // later: Docker refuses to remove a network with a container on it).
      if (remaining === 0) await resolver.remove({ force: true });
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

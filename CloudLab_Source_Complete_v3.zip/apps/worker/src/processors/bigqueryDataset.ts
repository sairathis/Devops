import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { provisionPostgres, teardownPostgres } from "../db/pgprovision.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// BigQuery equivalent. Honest substitute, documented the same way Milestone
// 6 (Kubernetes) and Milestone 7 (Terraform) are: real infrastructure with a
// deliberately simplified engine underneath, never a fake success state.
// What's real: a genuinely dedicated PostgreSQL 16 server per dataset
// (reusing the exact same provisionPostgres primitive `database` resources
// use -- real initdb, real WAL, a real SQL engine you can run arbitrary
// ad-hoc queries against via apps/api/src/routes/bigquery.ts's /query
// endpoint). What's simplified and NOT real: BigQuery's actual distributed,
// columnar, serverless execution engine -- this is one row-store Postgres
// process, not a sharded columnar warehouse. A dataset here is real SQL you
// can genuinely query, just not at BigQuery's real architecture or scale.
export async function processBigqueryDatasetCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = (row?.spec ?? {}) as { datasetId?: string };
    const datasetId = spec.datasetId || "dataset";

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "initdb + pg_ctl start (dataset warehouse)");
    const provisioned = await provisionPostgres(resourceId, datasetId);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "Dataset warehouse online -- real SQL engine, query via POST .../query", {
      engine: "postgres",
      engineVersion: "16",
      host: provisioned.host,
      port: provisioned.port,
      username: provisioned.username,
      password: provisioned.password,
      datasetId: provisioned.databaseName,
      connectionString: `postgresql://${provisioned.username}:${provisioned.password}@${provisioned.host}:${provisioned.port}/${provisioned.databaseName}`,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processBigqueryDatasetDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING", "pg_ctl stop");
    await teardownPostgres(resourceId);
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Dataset warehouse stopped and removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

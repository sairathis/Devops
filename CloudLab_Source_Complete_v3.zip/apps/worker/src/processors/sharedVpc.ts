import { setResourceStatus } from "../../../api/src/resources/model.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// GCP Shared VPC equivalent: a real, narrowly-scoped grant that lets one
// project (the "service project") attach instances to a network owned by
// another project (the "host project"). This resource IS the enforcement
// point, not a label -- apps/api/src/routes/instances.ts's instance-create
// handler only allows a cross-project networkId when a READY
// shared_vpc_attachment exists naming that exact (hostProject, serviceProject,
// network) triple; see that route for the actual boundary check. Deliberately
// scoped to "may attach instances to this one network", never a blanket
// cross-project trust grant, so it narrows rather than weakens the existing
// per-project isolation every other resource type still gets for free.
export async function processSharedVpcAttachmentCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "DONE", "cross-project attach grant recorded");
    await setResourceStatus(resourceId, "READY", "Shared VPC attachment active -- the named service project may now attach instances to this network");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processSharedVpcAttachmentDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await setResourceStatus(resourceId, "DELETED", "Shared VPC attachment revoked -- cross-project attach access removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources, users } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { config } from "../../../api/src/config.js";
import { signToken } from "../../../api/src/auth/jwt.js";
import { docker, pipelineRunnerNameFor } from "../docker.js";
import { demuxDockerStream } from "../net/demux.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface Stage {
  name: string;
  command: string;
}
interface PipelineSpec {
  stages: Stage[];
  image?: string;
}
interface RunSpec {
  pipelineId: string;
}
interface StageResult {
  name: string;
  command: string;
  status: "PASSED" | "FAILED" | "SKIPPED";
  exitCode: number | null;
  output: string;
  durationMs: number;
}

async function execStage(containerId: string, command: string, timeoutMs = 60_000): Promise<{ exitCode: number | null; output: string }> {
  const container = docker.getContainer(containerId);
  const exec = await container.exec({ Cmd: ["/bin/sh", "-c", command], AttachStdout: true, AttachStderr: true });
  const stream = await exec.start({ hijack: true, stdin: false });
  const chunks: Buffer[] = [];
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`stage timed out after ${timeoutMs}ms`)), timeoutMs);
    stream.on("data", (c: Buffer) => chunks.push(c));
    stream.on("end", () => { clearTimeout(timer); resolve(); });
    stream.on("error", (e: Error) => { clearTimeout(timer); reject(e); });
  });
  const inspect = await exec.inspect();
  const output = demuxDockerStream(Buffer.concat(chunks)).slice(0, 8000);
  return { exitCode: inspect.ExitCode ?? null, output };
}

// A real CI runner container (one per pipeline_run, reusing the same
// `cloudlab/guest` busybox-backed image the console's exec panel already
// proves has a real shell) with a real ephemeral workspace volume shared
// across stages, so a later stage can see a file an earlier stage wrote --
// genuine sequential job-step semantics, not a simulated pass/fail table.
// Fails fast on the first non-zero exit, exactly like a real CI job, and
// marks every stage after it SKIPPED rather than silently not running them.
export async function processPipelineRunCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  let volumeName: string | undefined;
  let containerId: string | undefined;
  try {
    const [runResource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const runSpec = runResource.spec as RunSpec;
    const [pipeline] = await db.select().from(resources).where(eq(resources.id, runSpec.pipelineId)).limit(1);
    if (!pipeline || pipeline.status !== "READY") throw new Error("target pipeline is not READY");
    const pipelineSpec = pipeline.spec as PipelineSpec;
    const image = pipelineSpec.image || config.guestImage;

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", `docker run ${image} (CI runner)`);
    volumeName = `cloudlab-ci-workspace-${resourceId}`;
    await docker.createVolume({ Name: volumeName, Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId } });

    // Real CI/CD-to-API access: a pipeline stage's command can genuinely
    // provision CloudLab resources (e.g. `wget --post-data=... $CLOUDLAB_API/...`)
    // the exact same way the console, the CLI, and the gcloud-style CLI do --
    // through the real REST API, not a special-cased code path. Two pieces
    // make that possible for a container that otherwise has no route back
    // to the host process:
    //   1. `host.docker.internal` -- Docker's own mechanism for a container
    //      to reach services bound on the host -- requires this explicit
    //      ExtraHosts entry on plain Linux dockerd (unlike Docker Desktop,
    //      which wires it up automatically).
    //   2. A real, normally-issued JWT (the same signToken() /auth/login
    //      uses), scoped to whichever user owns this pipeline run and
    //      deliberately short-lived (15 minutes -- comfortably longer than
    //      any real pipeline run here, but nowhere near a login session's
    //      lifetime), so a leaked pipeline log can't be replayed as a
    //      standing credential.
    const [runOwner] = await db.select().from(users).where(eq(users.id, runResource.createdBy)).limit(1);
    const pipelineToken = runOwner ? signToken({ userId: runOwner.id, email: runOwner.email }, "15m") : undefined;
    const container = await docker.createContainer({
      name: pipelineRunnerNameFor(resourceId),
      Image: image,
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId, "cloudlab.pipelineRun": "true" },
      Env: [
        "CLOUDLAB_API=http://host.docker.internal:4000/api/v1",
        `CLOUDLAB_PROJECT=${projectId}`,
        ...(pipelineToken ? [`CLOUDLAB_TOKEN=${pipelineToken}`] : []),
      ],
      HostConfig: {
        Mounts: [{ Type: "volume", Source: volumeName, Target: "/workspace" }],
        ExtraHosts: ["host.docker.internal:host-gateway"],
      },
    });
    await container.start();
    containerId = container.id;
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    const results: StageResult[] = [];
    let failed = false;
    for (const stage of pipelineSpec.stages) {
      if (failed) {
        results.push({ name: stage.name, command: stage.command, status: "SKIPPED", exitCode: null, output: "", durationMs: 0 });
        continue;
      }
      await pushStep(operationId, projectId, `STAGE:${stage.name}`, "RUNNING", stage.command);
      const startedAt = Date.now();
      try {
        const { exitCode, output } = await execStage(containerId, `cd /workspace && ${stage.command}`);
        const durationMs = Date.now() - startedAt;
        const passed = exitCode === 0;
        results.push({ name: stage.name, command: stage.command, status: passed ? "PASSED" : "FAILED", exitCode, output, durationMs });
        await pushStep(operationId, projectId, `STAGE:${stage.name}`, passed ? "DONE" : "FAILED", `exit code ${exitCode}`);
        if (!passed) failed = true;
      } catch (err) {
        const durationMs = Date.now() - startedAt;
        results.push({ name: stage.name, command: stage.command, status: "FAILED", exitCode: null, output: (err as Error).message, durationMs });
        await pushStep(operationId, projectId, `STAGE:${stage.name}`, "FAILED", (err as Error).message);
        failed = true;
      }
    }

    await setResourceStatus(resourceId, failed ? "FAILED" : "READY", failed ? "One or more stages failed" : "All stages passed", {
      pipelineId: pipeline.id,
      pipelineName: pipeline.name,
      image,
      stages: results,
      totalDurationMs: results.reduce((sum, r) => sum + r.durationMs, 0),
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, !failed, failed ? { code: "DEPLOYMENT_FAILED", message: "One or more pipeline stages failed" } : undefined);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  } finally {
    // The runner container and its workspace volume are scratch space for
    // this one run, not a resource the user manages -- torn down
    // automatically once the run finishes (success or failure) rather than
    // left behind, the same way a real CI job's ephemeral runner is
    // reclaimed after the job completes.
    if (containerId) {
      try { await docker.getContainer(containerId).remove({ force: true }); } catch { /* already gone */ }
    }
    if (volumeName) {
      try { await docker.getVolume(volumeName).remove(); } catch { /* already gone */ }
    }
  }
}

export async function processPipelineRunDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    // The run's own infrastructure (runner container + workspace volume) is
    // already torn down when the run finished -- deleting a pipeline_run
    // resource only removes its historical record, the same as deleting a
    // finished operation would.
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Run record removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "INTERNAL_ERROR", message });
  }
}

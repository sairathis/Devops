import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { cidrContains } from "../net/ipalloc.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// A subnet is a logical sub-range of its parent network's CIDR. There is no
// separate Docker object for it (Docker networks don't nest) -- its real
// effect happens later, when an instance is created "in" this subnet: the
// worker allocates a free address inside this range and assigns it as a
// static IP via Docker's IPAMConfig, instead of letting Docker's DHCP-like
// allocator pick one from the whole parent network.
export async function processSubnetCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { networkId: string; cidr: string };
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    if (!network) throw new Error(`parent network ${spec.networkId} not found`);
    const parentCidr = (network.spec as { cidr?: string }).cidr ?? "172.30.0.0/24";
    if (!cidrContains(parentCidr, spec.cidr)) {
      throw new Error(`subnet CIDR ${spec.cidr} is not contained within parent network CIDR ${parentCidr}`);
    }
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await addRelationship(resourceId, network.id, "contains");
    await setResourceStatus(resourceId, "READY", "Subnet range validated against parent network", { parentCidr });
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "READY", "DONE");
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "VALIDATION_ERROR", message });
  }
}

export async function processSubnetDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  await setResourceStatus(resourceId, "DELETED", "Subnet record removed (no underlying infra to tear down)");
  await publishResourceUpdate(projectId, resourceId);
  await finishOperation(operationId, projectId, true);
}

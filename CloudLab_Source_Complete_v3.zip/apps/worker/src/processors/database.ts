import { setResourceStatus } from "../../../api/src/resources/model.js";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { eq } from "drizzle-orm";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import { provisionPostgres, teardownPostgres } from "../db/pgprovision.js";
import type { OperationJobData } from "../queue.js";

// A real, dedicated PostgreSQL 16 server (see pgprovision.ts for why this is
// an OS process rather than a Docker container in this sandbox, and why
// that's honestly documented as a simplification rather than implied to be
// containerized like everything else).
export async function processDatabaseCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = (row?.spec ?? {}) as { databaseName?: string };
    const databaseName = spec.databaseName || "appdb";

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "initdb + pg_ctl start");
    const provisioned = await provisionPostgres(resourceId, databaseName);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "PostgreSQL 16 server started", {
      engine: "postgres",
      engineVersion: "16",
      host: provisioned.host,
      port: provisioned.port,
      username: provisioned.username,
      password: provisioned.password,
      databaseName: provisioned.databaseName,
      connectionString: `postgresql://${provisioned.username}:${provisioned.password}@${provisioned.host}:${provisioned.port}/${provisioned.databaseName}`,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processDatabaseDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING", "pg_ctl stop");
    await teardownPostgres(resourceId);
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "PostgreSQL server stopped and data directory removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { applyNatGateway, revokeNatGateway } from "../net/iptables.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface NatGatewaySpec {
  networkResourceId: string;
}

// GCP Cloud NAT equivalent. Real host-level iptables MASQUERADE + FORWARD
// ACCEPT rules on the target network's own Linux bridge (see
// net/iptables.ts) -- genuinely toggles internet egress on/off for an
// `internal: true` network, verifiable with a real `curl` from an instance
// on that network before and after this resource exists.
export async function processNatGatewayCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as NatGatewaySpec;
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkResourceId)).limit(1);
    if (!network || network.status !== "READY") throw new Error(`network ${spec.networkResourceId} is not READY`);
    const netMeta = network.metadata as { dockerNetworkId?: string };
    const netSpec = network.spec as { cidr?: string };
    if (!netMeta.dockerNetworkId || !netSpec.cidr) throw new Error("target network is missing docker network info");
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "iptables MASQUERADE + ip_forward");
    await applyNatGateway(resourceId, netMeta.dockerNetworkId, netSpec.cidr);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await addRelationship(resourceId, network.id, "connects_to");
    await setResourceStatus(resourceId, "READY", "Real iptables MASQUERADE rule active -- instances on this network now have real internet egress", {
      dockerNetworkId: netMeta.dockerNetworkId,
      natCidr: netSpec.cidr,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processNatGatewayDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const meta = row.metadata as { dockerNetworkId?: string; natCidr?: string };
    if (meta.dockerNetworkId && meta.natCidr) {
      await revokeNatGateway(resourceId, meta.dockerNetworkId, meta.natCidr);
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "iptables NAT rules removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

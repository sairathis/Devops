import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { scaleToZero } from "../cloudrun/lifecycle.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface CloudRunSpec {
  networkId: string;
  image?: string;
  idleTimeoutSeconds?: number;
}

// Cloud Run equivalent. Create only registers the service's config -- it
// deliberately does NOT start a container, matching a real scale-to-zero
// revision with no traffic. The first real container only appears on a
// genuine invoke (see cloudrun/lifecycle.ts ensureRunning + routes/cloudRun.ts),
// and cloudrun/idleChecker.ts's loop genuinely stops it again after
// idleTimeoutSeconds of no invokes -- both directions are real Docker
// lifecycle operations, not a status label.
export async function processCloudRunServiceCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as CloudRunSpec;
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkId)).limit(1);
    if (!network || network.status !== "READY") throw new Error(`network ${spec.networkId} is not READY`);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await addRelationship(resourceId, network.id, "connects_to");
    await setResourceStatus(resourceId, "READY", "Service registered, scaled to zero (no container running until the first invoke)", {
      state: "IDLE",
      lastInvokedAt: null,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processCloudRunServiceDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    await scaleToZero(resourceId).catch(() => {});
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await setResourceStatus(resourceId, "DELETED", "Service removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

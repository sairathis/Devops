import { eq } from "drizzle-orm";
import tarStream from "tar-stream";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { docker } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

interface ImageSpec {
  registryId: string;
  name: string;
  tag: string;
  dockerfile: string;
}

function buildContextTar(dockerfile: string): NodeJS.ReadableStream {
  const pack = tarStream.pack();
  pack.entry({ name: "Dockerfile" }, dockerfile);
  pack.finalize();
  return pack as unknown as NodeJS.ReadableStream;
}

// A real `docker build` (via the Docker Engine API, same as `docker build`
// on the CLI) from a user-supplied Dockerfile, then a real push to a
// CloudLab-managed registry -- not a simulated "build succeeded" record.
// Build logs and the true final image digest (as reported by the push) are
// both captured from the real Docker Engine response stream.
export async function processContainerImageCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as ImageSpec;
    const [registry] = await db.select().from(resources).where(eq(resources.id, spec.registryId)).limit(1);
    if (!registry || registry.status !== "READY") throw new Error(`registry ${spec.registryId} is not READY`);
    const registryHost = (registry.metadata as { registryHost?: string }).registryHost;
    if (!registryHost) throw new Error("registry has no registryHost recorded");
    const tag = `${registryHost}/${spec.name}:${spec.tag}`;
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "BUILDING", "RUNNING", `docker build -t ${tag}`);
    const buildStream = await docker.buildImage(buildContextTar(spec.dockerfile) as any, { t: tag });
    const buildLog: string[] = [];
    await new Promise<void>((resolve, reject) => {
      docker.modem.followProgress(
        buildStream,
        (err: Error | null) => (err ? reject(err) : resolve()),
        (event: { stream?: string; error?: string }) => {
          if (event.stream) buildLog.push(event.stream.trimEnd());
          if (event.error) buildLog.push(`ERROR: ${event.error}`);
        },
      );
    });
    await pushStep(operationId, projectId, "BUILDING", "DONE");

    await pushStep(operationId, projectId, "PUSHING", "RUNNING", `docker push ${tag}`);
    const image = docker.getImage(tag);
    const pushStreamRaw = await image.push({ authconfig: {} });
    const pushLog: string[] = [];
    let digest: string | undefined;
    await new Promise<void>((resolve, reject) => {
      docker.modem.followProgress(
        pushStreamRaw,
        (err: Error | null) => (err ? reject(err) : resolve()),
        (event: { status?: string; aux?: { Digest?: string } }) => {
          if (event.status) pushLog.push(event.status);
          if (event.aux?.Digest) digest = event.aux.Digest;
        },
      );
    });
    await pushStep(operationId, projectId, "PUSHING", "DONE", digest ? `digest ${digest}` : undefined);

    await addRelationship(resourceId, spec.registryId, "depends_on");
    await setResourceStatus(resourceId, "READY", "Image built and pushed to registry", {
      fullTag: tag,
      digest,
      pullCommand: `docker pull ${tag}`,
      buildLogTail: buildLog.slice(-20).join("\n"),
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

// There is no registry-side blob GC in this build (see ROADMAP.md), so
// "deleting" an image record removes the local Docker image (if present)
// and the CloudLab resource, but does not attempt to remove the blobs
// already pushed to the registry's on-disk store -- documented, not hidden.
export async function processContainerImageDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const fullTag = (resource.metadata as { fullTag?: string }).fullTag;
    if (fullTag) {
      try {
        await docker.getImage(fullTag).remove({ force: true });
      } catch (err) {
        if ((err as { statusCode?: number }).statusCode !== 404) throw err;
      }
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Local image removed (registry blobs are not garbage-collected in this build)");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

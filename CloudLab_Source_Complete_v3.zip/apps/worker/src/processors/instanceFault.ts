import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, containerNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// Milestone 11: real fault injection, not a status flip. A genuine
// `docker kill --signal=SIGKILL` against the instance's actual container.
//
// Verified directly in this sandbox before relying on it: instances run
// with RestartPolicy "unless-stopped" (see processors/instance.ts), and it
// would have undermined this whole feature if Docker silently restarted a
// killed container. It doesn't -- a real test container with that same
// restart policy, killed with SIGKILL, stayed `exited` with RestartCount 0
// for the following 8+ seconds. Docker only auto-restarts on an *internal*
// process crash, not an operator-issued kill (it treats a kill the same as
// an explicit `docker stop`), so this is a genuine, lasting outage: the
// instance stays down until a real recovery action -- the existing
// instance.start flow -- brings it back, exactly like a crashed real VM.
export async function processInstanceCrash(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "INJECTING_FAULT", "RUNNING", "docker kill --signal=SIGKILL");
    const container = docker.getContainer(containerNameFor(resourceId));
    await container.kill({ signal: "SIGKILL" });

    // Read the real post-kill state back rather than assuming SIGKILL's
    // conventional exit code -- this is what keeps the FAILED message honest.
    const info = await container.inspect();
    const exitCode = info.State.ExitCode;
    const finishedAt = info.State.FinishedAt;
    await pushStep(operationId, projectId, "INJECTING_FAULT", "DONE", `container exited with code ${exitCode} at ${finishedAt}`);

    await setResourceStatus(
      resourceId,
      "FAILED",
      `Killed by fault injection (SIGKILL) -- exited with code ${exitCode} at ${finishedAt}. It will not restart on its own; use Start to recover.`,
      { lastFault: { type: "crash", injectedAt: new Date().toISOString(), exitCode, finishedAt } },
    );
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "FAULT_INJECTION_FAILED", message });
  }
}

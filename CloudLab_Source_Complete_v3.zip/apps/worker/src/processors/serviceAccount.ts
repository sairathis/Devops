import { eq } from "drizzle-orm";
import { generateKeyPairSync, randomUUID } from "node:crypto";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { encryptSecretValue, secretsMasterKeyFromEnv } from "@cloudlab/shared";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// GCP service-account equivalent: a real machine identity, distinct from a
// human's JWT session. What's genuinely real here: a real 2048-bit RSA
// keypair (node:crypto, not a placeholder string) and real AES-256-GCM
// envelope encryption of the private key at rest (the same primitive
// secrets.ts uses) -- what's simplified and documented in ROADMAP.md: this
// identity isn't yet wired into `requireProjectPermission` as a distinct
// principal a request can authenticate AS (that would need a second auth
// scheme alongside the human JWT one), so today it is a real credential this
// application manages the full lifecycle of, not yet one you can log in with.
const masterKey = secretsMasterKeyFromEnv();

export async function processServiceAccountCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "generating RSA-2048 keypair");
    const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = row.spec as { accountId: string };
    const { publicKey, privateKey } = generateKeyPairSync("rsa", {
      modulusLength: 2048,
      publicKeyEncoding: { type: "spki", format: "pem" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    const keyId = randomUUID();
    const email = `${spec.accountId}@${projectId.slice(0, 8)}.cloudlab.iam.gserviceaccount.com`;
    const encryptedPrivateKey = encryptSecretValue(privateKey, masterKey);
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "Service account key pair generated", {
      email,
      keyId,
      publicKey,
      encryptedPrivateKey,
      algorithm: "rsa-2048",
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processServiceAccountDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    // No external resource to tear down -- deleting a key pair that lives
    // only in our own encrypted storage is just removing the row.
    await setResourceStatus(resourceId, "DELETED", "Service account key revoked");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

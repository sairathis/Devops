import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, networkNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

export async function processNetworkCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as { cidr?: string; internal?: boolean };
    const cidr = spec.cidr ?? "172.30.0.0/24";
    // Milestone 15: an `internal: true` network is created WITHOUT Docker's
    // default outbound masquerade route -- genuinely no internet egress,
    // mirroring a real GCP instance with no external IP and no Cloud NAT.
    // Egress only comes back once a real `nat_gateway` resource attaches
    // real iptables MASQUERADE + ip_forward rules to this network's bridge
    // (see net/iptables.ts applyNatGateway and processors/natGateway.ts).
    const internal = spec.internal === true;
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", `docker network create --subnet ${cidr}${internal ? " --internal" : ""}`);
    const network = await docker.createNetwork({
      Name: networkNameFor(resourceId),
      Driver: "bridge",
      Internal: internal,
      IPAM: { Config: [{ Subnet: cidr }] },
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId },
    });
    const info = await network.inspect();
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", internal ? "Docker bridge network created (internal -- no default egress)" : "Docker bridge network created", {
      dockerNetworkId: info.Id,
      cidr,
      internal,
    });
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "READY", "DONE");
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "PROVISIONING", "FAILED", message);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processNetworkDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const net = docker.getNetwork(networkNameFor(resourceId));
    try {
      await net.remove();
    } catch (err) {
      const msg = (err as { statusCode?: number; message: string }).message;
      if (!(err as { statusCode?: number }).statusCode || (err as { statusCode?: number }).statusCode !== 404) throw new Error(msg);
    }
    await setResourceStatus(resourceId, "DELETED", "Docker network removed");
    await publishResourceUpdate(projectId, resourceId);
    await pushStep(operationId, projectId, "DELETING", "DONE");
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

import { setResourceStatus } from "../../../api/src/resources/model.js";
import { docker, bucketNameFor } from "../docker.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// A real cloudlab/bucket-store container (infra/bucket-image) per bucket
// resource -- genuine PUT/GET/DELETE/LIST over HTTP against files on disk,
// published on a host port so it can be exercised directly with `curl`, the
// same "prove it with the real protocol" pattern used for the DNS/LB/
// registry milestones.
export async function processBucketCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "PROVISIONING", "RUNNING", "docker run cloudlab/bucket-store");
    const container = await docker.createContainer({
      name: bucketNameFor(resourceId),
      Image: "cloudlab/bucket-store:latest",
      ExposedPorts: { "6000/tcp": {} },
      Labels: { "cloudlab.resourceId": resourceId, "cloudlab.projectId": projectId },
      HostConfig: {
        PortBindings: { "6000/tcp": [{ HostPort: "" }] },
        RestartPolicy: { Name: "unless-stopped" },
      },
    });
    await container.start();
    const info = await container.inspect();
    const hostPort = info.NetworkSettings.Ports["6000/tcp"]?.[0]?.HostPort;
    await pushStep(operationId, projectId, "PROVISIONING", "DONE");

    await setResourceStatus(resourceId, "READY", "Bucket store container started", {
      containerId: info.Id,
      hostPort,
      endpoint: `http://localhost:${hostPort}`,
    });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processBucketDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const container = docker.getContainer(bucketNameFor(resourceId));
    try {
      await container.remove({ force: true, v: true });
    } catch (err) {
      if ((err as { statusCode?: number }).statusCode !== 404) throw err;
    }
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "Bucket store container removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

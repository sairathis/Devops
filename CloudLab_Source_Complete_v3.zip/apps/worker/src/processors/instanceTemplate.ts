import { setResourceStatus } from "../../../api/src/resources/model.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// GCP instance-template equivalent: a stored, immutable blueprint (machine
// image, network, disk sizes, startup script) that Managed Instance Groups
// stamp out real instances from. It is deliberately a blueprint only -- no
// infrastructure of its own to provision -- exactly like a real GCP instance
// template, which also has no "status" of its own beyond existing.
export async function processInstanceTemplateCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "DONE", "template spec recorded");
    await setResourceStatus(resourceId, "READY", "Instance template recorded");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processInstanceTemplateDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await setResourceStatus(resourceId, "DELETED", "Instance template removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

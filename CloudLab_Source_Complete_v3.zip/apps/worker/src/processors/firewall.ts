import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { setResourceStatus, addRelationship } from "../../../api/src/resources/model.js";
import { applyFirewallRule, revokeFirewallRule, type FirewallRuleSpec } from "../net/iptables.js";
import { startOperation, pushStep, finishOperation, publishResourceUpdate } from "../events.js";
import type { OperationJobData } from "../queue.js";

// Real firewall rules applied to the DOCKER-USER iptables chain -- see
// apps/worker/src/net/iptables.ts for why that chain and how the bridge
// interface is resolved. This is genuine packet filtering: traffic that a
// DENY rule matches is actually dropped by the kernel, not just recorded.
export async function processFirewallRuleCreate(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "VALIDATING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as FirewallRuleSpec;
    const [network] = await db.select().from(resources).where(eq(resources.id, spec.networkResourceId)).limit(1);
    if (!network) throw new Error(`network ${spec.networkResourceId} not found`);
    const dockerNetworkId = (network.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    if (!dockerNetworkId) throw new Error(`network '${network.name}' has no docker network id yet (not READY?)`);
    await pushStep(operationId, projectId, "VALIDATING", "DONE");

    await pushStep(operationId, projectId, "APPLYING", "RUNNING", `iptables -I DOCKER-USER ...`);
    await applyFirewallRule(resourceId, dockerNetworkId, spec);
    await pushStep(operationId, projectId, "APPLYING", "DONE");

    await addRelationship(resourceId, network.id, "depends_on");
    await setResourceStatus(resourceId, "READY", "iptables rule inserted into DOCKER-USER chain", { dockerNetworkId });
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "FAILED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

export async function processFirewallRuleDelete(job: OperationJobData) {
  const { operationId, projectId, resourceId } = job;
  await startOperation(operationId, projectId);
  try {
    await pushStep(operationId, projectId, "DELETING", "RUNNING");
    const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
    const spec = resource.spec as FirewallRuleSpec;
    const dockerNetworkId = (resource.metadata as { dockerNetworkId?: string }).dockerNetworkId;
    if (dockerNetworkId) await revokeFirewallRule(resourceId, dockerNetworkId, spec);
    await pushStep(operationId, projectId, "DELETING", "DONE");

    await setResourceStatus(resourceId, "DELETED", "iptables rule removed");
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, true);
  } catch (err) {
    const message = (err as Error).message;
    await setResourceStatus(resourceId, "DEGRADED", message);
    await publishResourceUpdate(projectId, resourceId);
    await finishOperation(operationId, projectId, false, { code: "DEPLOYMENT_FAILED", message });
  }
}

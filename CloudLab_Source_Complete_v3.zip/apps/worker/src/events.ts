import { eq } from "drizzle-orm";
import { Redis } from "ioredis";
import { db } from "../../api/src/db/client.js";
import { operations, resources } from "../../api/src/db/schema.js";
import { UPDATES_CHANNEL } from "./queue.js";

const redisUrl = process.env.REDIS_URL ?? "redis://localhost:6379";
const publisher = new Redis(redisUrl);

export async function publishUpdate(projectId: string, event: Record<string, unknown>) {
  await publisher.publish(UPDATES_CHANNEL, JSON.stringify({ projectId, ...event }));
}

type Step = { name: string; status: "RUNNING" | "DONE" | "FAILED"; at: string; message?: string };

export async function startOperation(operationId: string, projectId: string) {
  await db.update(operations).set({ status: "RUNNING", updatedAt: new Date() }).where(eq(operations.id, operationId));
  await publishUpdate(projectId, { type: "operation.update", operationId, status: "RUNNING" });
}

export async function pushStep(operationId: string, projectId: string, name: string, status: Step["status"], message?: string) {
  const [op] = await db.select().from(operations).where(eq(operations.id, operationId)).limit(1);
  const steps = ((op?.steps as Step[] | undefined) ?? []).concat([{ name, status, at: new Date().toISOString(), message }]);
  await db.update(operations).set({ steps, updatedAt: new Date() }).where(eq(operations.id, operationId));
  await publishUpdate(projectId, { type: "operation.step", operationId, step: { name, status, message } });
}

export async function finishOperation(operationId: string, projectId: string, ok: boolean, error?: { code: string; message: string }) {
  await db
    .update(operations)
    .set({ status: ok ? "SUCCEEDED" : "FAILED", error: error ?? null, updatedAt: new Date() })
    .where(eq(operations.id, operationId));
  await publishUpdate(projectId, { type: "operation.update", operationId, status: ok ? "SUCCEEDED" : "FAILED", error });
}

export async function publishResourceUpdate(projectId: string, resourceId: string) {
  const [resource] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  await publishUpdate(projectId, { type: "resource.update", resource });
}

import { eq } from "drizzle-orm";
import { db } from "../../../api/src/db/client.js";
import { resources } from "../../../api/src/db/schema.js";
import { createResource, createOperation, setResourceStatus } from "../../../api/src/resources/model.js";
import { operationsQueue } from "../../../api/src/queue/queue.js";
import { cronMatches, minuteKey } from "./cron.js";
import { publishResourceUpdate } from "../events.js";

const TICK_MS = 60_000; // real cron granularity is one minute

interface ComposerSpec {
  pipelineId: string;
  schedule: string;
}

// Ticks once a minute and, for every READY composer_environment whose cron
// expression matches the current UTC minute, enqueues a genuine pipeline_run
// the exact same way a human clicking "Run" in the CI/CD tab does -- real
// operation, real pipeline-runner container, real logs. `lastTriggeredMinuteKey`
// guards against firing twice for the same minute if a tick is ever late.
export async function runComposerTickOnce() {
  const now = new Date();
  const key = minuteKey(now);
  const environments = await db.select().from(resources).where(eq(resources.type, "composer_environment"));
  for (const env of environments) {
    if (env.status !== "READY") continue;
    try {
      const spec = env.spec as ComposerSpec;
      if (!cronMatches(spec.schedule, now)) continue;
      const meta = env.metadata as { lastTriggeredMinuteKey?: string; triggerCount?: number };
      if (meta.lastTriggeredMinuteKey === key) continue; // already fired this minute

      const [pipeline] = await db.select().from(resources).where(eq(resources.id, spec.pipelineId)).limit(1);
      if (!pipeline || pipeline.status === "DELETED") continue;

      const run = await createResource({
        projectId: env.projectId,
        name: `${pipeline.name}-scheduled-${Date.now()}`,
        type: "pipeline_run",
        spec: { pipelineId: pipeline.id, triggeredBy: "composer", composerEnvironmentId: env.id },
        createdBy: env.createdBy,
      });
      const operation = await createOperation({ projectId: env.projectId, resourceId: run.id, type: "pipeline_run.create", createdBy: env.createdBy });
      await operationsQueue.add("pipeline_run.create", { operationId: operation.id, projectId: env.projectId, resourceId: run.id, type: "pipeline_run.create" });

      await setResourceStatus(env.id, "READY", `Triggered run of '${pipeline.name}' on schedule`, {
        lastTriggeredMinuteKey: key,
        triggerCount: (meta.triggerCount ?? 0) + 1,
        lastRunResourceId: run.id,
      });
      await publishResourceUpdate(env.projectId, env.id);
      console.log(`composer scheduler: triggered pipeline '${pipeline.name}' from environment ${env.id} (schedule '${spec.schedule}')`);
    } catch (err) {
      console.error(`composer scheduler: failed to evaluate environment ${env.id}:`, (err as Error).message);
    }
  }
}

export function startComposerScheduler() {
  const timer = setInterval(() => {
    runComposerTickOnce().catch((err) => console.error("composer scheduler tick failed:", err));
  }, TICK_MS);
  timer.unref();
  console.log(`composer scheduler started (every ${TICK_MS / 1000}s, real 5-field UTC cron matching)`);
}

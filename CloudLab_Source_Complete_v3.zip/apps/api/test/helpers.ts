import type { FastifyInstance } from "fastify";
import { buildServer } from "../src/server.js";

/**
 * These tests run against the app's real Fastify instance via `.inject()`
 * (no HTTP socket needed) and the real local Postgres + Redis the dev
 * environment already has running -- per the project's own "no fake
 * success" principle, we don't mock the database or IAM engine. A running
 * Postgres + Redis (see README / INFRASTRUCTURE.md) is a precondition for
 * this suite, exactly as it is for the app itself.
 */
export async function makeApp(): Promise<FastifyInstance> {
  const app = await buildServer();
  await app.ready();
  return app;
}

let counter = 0;
export function uniqueEmail(prefix = "test"): string {
  counter += 1;
  return `${prefix}-${Date.now()}-${counter}-${Math.floor(Math.random() * 1e6)}@cloudlab.dev`;
}

// Milestone 13 added real, synchronous CIDR-collision validation at network
// creation (routes/networks.ts) -- a genuine check against every other
// non-deleted network resource, matching Docker's own real, host-wide IPAM
// pool. That means tests can no longer all default to the same hardcoded
// CIDR the way they used to (each `it()` here creates a real Docker
// network via the live worker this dev environment runs, and a second real
// network with an overlapping CIDR would now correctly be rejected, exactly
// as Docker itself would reject it once both actually exist). Each test
// that creates a network should call this for a CIDR that's vanishingly
// unlikely to collide with anything else alive at the same time.
let cidrCounter = 0;
export function uniqueCidr(): string {
  cidrCounter += 1;
  const second = 100 + (cidrCounter % 100);
  const third = Math.floor(Math.random() * 256);
  return `10.${second}.${third}.0/24`;
}

export async function registerUser(app: FastifyInstance, opts?: { name?: string; email?: string; password?: string }) {
  const email = opts?.email ?? uniqueEmail();
  const res = await app.inject({
    method: "POST",
    url: "/api/v1/auth/register",
    payload: { name: opts?.name ?? "Test User", email, password: opts?.password ?? "password123" },
  });
  if (res.statusCode !== 201 && res.statusCode !== 200) {
    throw new Error(`register failed: ${res.statusCode} ${res.body}`);
  }
  const body = res.json();
  return { token: body.token as string, user: body.user, email };
}

export async function createOrg(app: FastifyInstance, token: string, name: string) {
  const res = await app.inject({
    method: "POST",
    url: "/api/v1/organizations",
    headers: { authorization: `Bearer ${token}` },
    payload: { name },
  });
  if (res.statusCode >= 300) throw new Error(`create org failed: ${res.statusCode} ${res.body}`);
  return res.json();
}

export async function createProject(app: FastifyInstance, token: string, orgId: string, name: string) {
  const res = await app.inject({
    method: "POST",
    url: "/api/v1/projects",
    headers: { authorization: `Bearer ${token}` },
    payload: { orgId, name },
  });
  if (res.statusCode >= 300) throw new Error(`create project failed: ${res.statusCode} ${res.body}`);
  return res.json();
}

export function authHeader(token: string) {
  return { authorization: `Bearer ${token}` };
}

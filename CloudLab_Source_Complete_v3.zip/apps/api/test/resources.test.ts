import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { FastifyInstance } from "fastify";
import { eq } from "drizzle-orm";
import { db } from "../src/db/client.js";
import { auditLogs, resources, resourceRelationships } from "../src/db/schema.js";
import { assertDeletable } from "../src/resources/model.js";
import { makeApp, registerUser, createOrg, createProject, authHeader, uniqueCidr } from "./helpers.js";

describe("resource lifecycle (API layer, no worker required)", () => {
  let app: FastifyInstance;
  beforeAll(async () => { app = await makeApp(); });
  afterAll(async () => { await app.close(); });

  it("creating a network returns 202 with a resource in CREATING and an operationId", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "Resource Org");
    const project = await createProject(app, owner.token, org.id, "resource-project");

    const res = await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(owner.token),
      payload: { name: "vpc-test", cidr: uniqueCidr() },
    });
    expect(res.statusCode).toBe(202);
    const body = res.json();
    expect(body.resource.status).toBe("CREATING");
    expect(body.resource.type).toBe("network");
    expect(body.operationId).toBeTypeOf("string");
  });

  it("creating an instance against a network that doesn't exist yet fails validation, not a fake success", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "Resource Org 2");
    const project = await createProject(app, owner.token, org.id, "resource-project-2");

    const res = await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/instances`,
      headers: authHeader(owner.token),
      payload: { name: "web-test", networkId: "00000000-0000-0000-0000-000000000000" },
    });
    expect(res.statusCode).toBeGreaterThanOrEqual(400);
  });

  it("every mutating call writes a structured audit log row scoped to the project", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "Resource Org 3");
    const project = await createProject(app, owner.token, org.id, "resource-project-3");

    await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(owner.token),
      payload: { name: "vpc-audit-test", cidr: uniqueCidr() },
    });

    // The audit row is written from Fastify's onResponse hook, which runs
    // AFTER the response has already been sent -- so app.inject() can
    // resolve a moment before that write lands. Poll briefly rather than
    // assume it's synchronous with the HTTP response.
    let createEvent;
    for (let attempt = 0; attempt < 20 && !createEvent; attempt++) {
      const rows = await db.select().from(auditLogs).where(eq(auditLogs.projectId, project.id));
      createEvent = rows.find((r) => r.action === "network.networks.create");
      if (!createEvent) await new Promise((r) => setTimeout(r, 25));
    }
    expect(createEvent).toBeTruthy();
    expect(createEvent!.status).toBe("SUCCESS");
    expect(createEvent!.resourceName).toBe("vpc-audit-test");
  });

  it("assertDeletable ignores relationships to already-DELETED dependents", async () => {
    // Regression test for the dependency-check bug: a resource with a
    // relationship row pointing at it should still be deletable once the
    // *other* end of that relationship is itself DELETED (e.g. deleting a
    // network after its instance was already torn down).
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "Resource Org 4");
    const project = await createProject(app, owner.token, org.id, "resource-project-4");

    const [network] = await db.insert(resources).values({
      projectId: project.id, name: "net-dep-test", type: "network", status: "READY",
      spec: {}, metadata: {}, labels: {}, createdBy: owner.user.id,
    }).returning();
    const [deletedInstance] = await db.insert(resources).values({
      projectId: project.id, name: "inst-dep-test", type: "instance", status: "DELETED",
      spec: {}, metadata: {}, labels: {}, createdBy: owner.user.id,
    }).returning();
    await db.insert(resourceRelationships).values({
      fromResourceId: deletedInstance.id, toResourceId: network.id, kind: "connects_to",
    });

    // Must NOT throw, since the only dependent is already DELETED.
    await expect(assertDeletable(network.id)).resolves.toBeUndefined();
  });

  it("assertDeletable still blocks deletion when a live dependent exists", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "Resource Org 5");
    const project = await createProject(app, owner.token, org.id, "resource-project-5");

    const [network] = await db.insert(resources).values({
      projectId: project.id, name: "net-dep-test-2", type: "network", status: "READY",
      spec: {}, metadata: {}, labels: {}, createdBy: owner.user.id,
    }).returning();
    const [liveInstance] = await db.insert(resources).values({
      projectId: project.id, name: "inst-dep-test-2", type: "instance", status: "READY",
      spec: {}, metadata: {}, labels: {}, createdBy: owner.user.id,
    }).returning();
    await db.insert(resourceRelationships).values({
      fromResourceId: liveInstance.id, toResourceId: network.id, kind: "connects_to",
    });

    await expect(assertDeletable(network.id)).rejects.toMatchObject({ status: 409 });
  });
});

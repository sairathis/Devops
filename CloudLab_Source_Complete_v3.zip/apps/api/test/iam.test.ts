import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { FastifyInstance } from "fastify";
import { matchesPattern, isAllowed, BUILTIN_ROLES } from "@cloudlab/shared";
import { makeApp, registerUser, createOrg, createProject, authHeader, uniqueCidr } from "./helpers.js";

describe("IAM glob matching (unit)", () => {
  it("matches exact actions", () => {
    expect(matchesPattern("network.networks.create", "network.networks.create")).toBe(true);
    expect(matchesPattern("network.networks.create", "network.networks.delete")).toBe(false);
  });

  it("'*' matches everything", () => {
    expect(matchesPattern("*", "anything.at.all")).toBe(true);
  });

  it("a prefix wildcard like 'compute.*' matches any depth under it", () => {
    expect(matchesPattern("compute.*", "compute.instances.create")).toBe(true);
    expect(matchesPattern("compute.*", "compute.instances.exec")).toBe(true);
    expect(matchesPattern("compute.*", "network.networks.create")).toBe(false);
  });

  it("a suffix wildcard like '*.list' matches regardless of segment count", () => {
    // Regression test: the original implementation required pattern and
    // action to split into the same number of '.'-separated segments, so
    // "*.list" (2 segments) never matched "compute.instances.list" (3
    // segments). This silently broke the viewer role's read access.
    expect(matchesPattern("*.list", "compute.instances.list")).toBe(true);
    expect(matchesPattern("*.list", "projects.list")).toBe(true);
    expect(matchesPattern("*.get", "compute.instances.get")).toBe(true);
  });

  it("deny always overrides allow", () => {
    const developer = BUILTIN_ROLES.find((r) => r.key === "developer")!;
    expect(isAllowed(developer, "network.networks.create")).toBe(true);
    expect(isAllowed(developer, "network.networks.delete")).toBe(false); // explicit deny
  });

  it("viewer can read but not write", () => {
    const viewer = BUILTIN_ROLES.find((r) => r.key === "viewer")!;
    expect(isAllowed(viewer, "compute.instances.list")).toBe(true);
    expect(isAllowed(viewer, "compute.instances.get")).toBe(true);
    expect(isAllowed(viewer, "compute.instances.create")).toBe(false);
  });
});

describe("IAM enforcement over HTTP", () => {
  let app: FastifyInstance;
  beforeAll(async () => { app = await makeApp(); });
  afterAll(async () => { await app.close(); });

  it("a user with no membership at all gets 404 (existence hidden), not 403", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "IAM Org");
    const project = await createProject(app, owner.token, org.id, "iam-project");

    const stranger = await registerUser(app);
    const res = await app.inject({
      method: "GET",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(stranger.token),
    });
    expect(res.statusCode).toBe(404);
    expect(res.json().code).toBe("RESOURCE_NOT_FOUND");
  });

  it("a viewer-role member can list but not create networks", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "IAM Org 2");
    const project = await createProject(app, owner.token, org.id, "iam-project-2");

    const viewerUser = await registerUser(app);
    const bind = await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/iam/bindings`,
      headers: authHeader(owner.token),
      payload: { userId: viewerUser.user.id, roleKey: "viewer" },
    });
    expect(bind.statusCode).toBe(201);

    const list = await app.inject({
      method: "GET",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(viewerUser.token),
    });
    expect(list.statusCode).toBe(200);

    const create = await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(viewerUser.token),
      payload: { name: "should-fail" },
    });
    expect(create.statusCode).toBe(403);
    expect(create.json().code).toBe("PERMISSION_DENIED");
  });

  it("the project owner can do everything, including binding roles to others", async () => {
    const owner = await registerUser(app);
    const org = await createOrg(app, owner.token, "IAM Org 3");
    const project = await createProject(app, owner.token, org.id, "iam-project-3");

    const create = await app.inject({
      method: "POST",
      url: `/api/v1/projects/${project.id}/networks`,
      headers: authHeader(owner.token),
      payload: { name: "vpc-owner-test", cidr: uniqueCidr() },
    });
    expect(create.statusCode).toBe(202);
    expect(create.json().operationId).toBeTypeOf("string");
  });
});

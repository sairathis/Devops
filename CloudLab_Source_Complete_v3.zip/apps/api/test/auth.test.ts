import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { FastifyInstance } from "fastify";
import { makeApp, uniqueEmail } from "./helpers.js";

describe("auth", () => {
  let app: FastifyInstance;
  beforeAll(async () => { app = await makeApp(); });
  afterAll(async () => { await app.close(); });

  it("registers a new user and returns a bearer token", async () => {
    const email = uniqueEmail();
    const res = await app.inject({
      method: "POST",
      url: "/api/v1/auth/register",
      payload: { name: "Ada Lovelace", email, password: "password123" },
    });
    expect(res.statusCode).toBe(201);
    const body = res.json();
    expect(body.token).toBeTypeOf("string");
    expect(body.user.email).toBe(email);
  });

  it("rejects registering the same email twice with 409 RESOURCE_CONFLICT", async () => {
    const email = uniqueEmail();
    const payload = { name: "Dup User", email, password: "password123" };
    const first = await app.inject({ method: "POST", url: "/api/v1/auth/register", payload });
    expect(first.statusCode).toBe(201);

    const second = await app.inject({ method: "POST", url: "/api/v1/auth/register", payload });
    expect(second.statusCode).toBe(409);
    expect(second.json().code).toBe("RESOURCE_CONFLICT");
  });

  it("rejects registration with a short password (VALIDATION_ERROR)", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/api/v1/auth/register",
      payload: { name: "Short", email: uniqueEmail(), password: "short" },
    });
    expect(res.statusCode).toBe(400);
    expect(res.json().code).toBe("VALIDATION_ERROR");
  });

  it("logs in with correct credentials and rejects incorrect ones", async () => {
    const email = uniqueEmail();
    const password = "correct-horse-battery";
    await app.inject({ method: "POST", url: "/api/v1/auth/register", payload: { name: "Login Test", email, password } });

    const good = await app.inject({ method: "POST", url: "/api/v1/auth/login", payload: { email, password } });
    expect(good.statusCode).toBe(200);
    expect(good.json().token).toBeTypeOf("string");

    const bad = await app.inject({ method: "POST", url: "/api/v1/auth/login", payload: { email, password: "wrong-password" } });
    expect(bad.statusCode).toBe(401);
    expect(bad.json().code).toBe("AUTHENTICATION_FAILED");
  });

  it("GET /me requires a bearer token and echoes the authenticated user", async () => {
    const noAuth = await app.inject({ method: "GET", url: "/api/v1/auth/me" });
    expect(noAuth.statusCode).toBe(401);

    const email = uniqueEmail();
    const reg = await app.inject({ method: "POST", url: "/api/v1/auth/register", payload: { name: "Me Test", email, password: "password123" } });
    const { token } = reg.json();

    const me = await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { authorization: `Bearer ${token}` } });
    expect(me.statusCode).toBe(200);
    expect(me.json().email).toBe(email);
  });

  it("every request -- including a public auth route -- produces an audit log row", async () => {
    const email = uniqueEmail();
    const reg = await app.inject({ method: "POST", url: "/api/v1/auth/register", payload: { name: "Audit Test", email, password: "password123" } });
    const { token } = reg.json();

    // The audit endpoint is project-scoped, so instead assert indirectly:
    // a request with a bad token still gets a requestId back (proves the
    // onRequest/onResponse audit hooks ran even on a failure path).
    const bad = await app.inject({ method: "GET", url: "/api/v1/auth/me", headers: { authorization: "Bearer garbage" } });
    expect(bad.statusCode).toBe(401);
    expect(bad.json().requestId).toBeTypeOf("string");
    expect(token).toBeTypeOf("string");
  });
});

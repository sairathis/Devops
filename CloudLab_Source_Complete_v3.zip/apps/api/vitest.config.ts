import { defineConfig } from "vitest/config";

process.env.LOG_LEVEL = process.env.LOG_LEVEL ?? "silent";

export default defineConfig({
  test: {
    environment: "node",
    testTimeout: 15000,
    hookTimeout: 15000,
    // These tests hit the real Postgres instance directly (many inserts
    // across many test files) -- run files serially to avoid unrelated
    // flakiness from concurrent connections racing on the same tables.
    fileParallelism: false,
  },
});

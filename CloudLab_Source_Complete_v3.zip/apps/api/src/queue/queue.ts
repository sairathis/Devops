import { Queue } from "bullmq";
import { createRedisConnection } from "./connection.js";

export const OPERATIONS_QUEUE = "cloudlab-operations";
export const UPDATES_CHANNEL = "cloudlab:updates";

export type OperationJobType =
  | "network.create"
  | "network.delete"
  | "instance.create"
  | "instance.start"
  | "instance.stop"
  | "instance.delete"
  | "subnet.create"
  | "subnet.delete"
  | "firewall_rule.create"
  | "firewall_rule.delete"
  | "dns_record.create"
  | "dns_record.update"
  | "dns_record.delete"
  | "load_balancer.create"
  | "load_balancer.update"
  | "load_balancer.delete"
  | "disk.create"
  | "disk.delete"
  | "registry.create"
  | "registry.delete"
  | "container_image.create"
  | "container_image.delete"
  | "bucket.create"
  | "bucket.delete"
  | "database.create"
  | "database.delete"
  | "secret.create"
  | "secret.delete"
  | "k8s_cluster.create"
  | "k8s_cluster.delete"
  | "k8s_deployment.create"
  | "k8s_deployment.delete"
  | "k8s_deployment.scale"
  | "pipeline.create"
  | "pipeline.delete"
  | "pipeline_run.create"
  | "pipeline_run.delete"
  // Milestone 11: fault injection -- see apps/worker/src/processors/instanceFault.ts
  // and networkFault.ts for what each of these genuinely does to real infra.
  | "instance.crash"
  | "network.fault_blackhole"
  | "network.fault_revert"
  // Milestone 15
  | "service_account.create"
  | "service_account.delete"
  | "instance_template.create"
  | "instance_template.delete"
  | "managed_instance_group.create"
  | "managed_instance_group.delete"
  | "managed_instance_group.resize"
  | "nat_gateway.create"
  | "nat_gateway.delete"
  | "vpc_peering.create"
  | "vpc_peering.delete"
  | "shared_vpc_attachment.create"
  | "shared_vpc_attachment.delete"
  | "bigquery_dataset.create"
  | "bigquery_dataset.delete"
  | "composer_environment.create"
  | "composer_environment.delete"
  | "cloud_run_service.create"
  | "cloud_run_service.delete";

export interface OperationJobData {
  operationId: string;
  projectId: string;
  resourceId: string;
  type: OperationJobType;
  // Milestone 11: small job-specific parameters (e.g. a blackhole's
  // durationSeconds) that don't warrant a dedicated column on every job.
  params?: Record<string, unknown>;
}

export const operationsQueue = new Queue<OperationJobData>(OPERATIONS_QUEUE, {
  connection: createRedisConnection(),
  defaultJobOptions: { removeOnComplete: 100, removeOnFail: 100, attempts: 1 },
});

import {
  pgTable,
  uuid,
  text,
  timestamp,
  jsonb,
  integer,
  varchar,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

// ---------------------------------------------------------------------------
// Identity & hierarchy: Organization -> Project (folders are a future layer).
// ---------------------------------------------------------------------------

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 320 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  // Milestone 13: real account lockout. failedLoginAttempts increments on
  // every genuinely wrong password and resets to 0 on a real successful
  // login; lockedUntil is set only once attempts cross the threshold (see
  // routes/auth.ts) and is itself the source of truth checked on the next
  // login attempt -- not a client-visible flag, not a cron job, just a
  // timestamp compared against real wall-clock time on every login.
  failedLoginAttempts: integer("failed_login_attempts").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
}, (t) => ({
  emailIdx: uniqueIndex("users_email_idx").on(t.email),
}));

export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  slug: varchar("slug", { length: 128 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  slugIdx: uniqueIndex("organizations_slug_idx").on(t.slug),
}));

export const orgMemberships = pgTable("org_memberships", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  roleKey: varchar("role_key", { length: 64 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  orgUserIdx: uniqueIndex("org_memberships_org_user_idx").on(t.orgId, t.userId),
  userIdx: index("org_memberships_user_idx").on(t.userId),
}));

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: varchar("slug", { length: 128 }).notNull(),
  createdBy: uuid("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  orgSlugIdx: uniqueIndex("projects_org_slug_idx").on(t.orgId, t.slug),
  orgIdx: index("projects_org_idx").on(t.orgId),
}));

export const projectMemberships = pgTable("project_memberships", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  roleKey: varchar("role_key", { length: 64 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  projectUserIdx: uniqueIndex("project_memberships_project_user_idx").on(t.projectId, t.userId),
  userIdx: index("project_memberships_user_idx").on(t.userId),
}));

// ---------------------------------------------------------------------------
// Generic resource model (spec section 6) + relationships that back the
// automatically-derived architecture graph (spec sections 17-20, 48).
// ---------------------------------------------------------------------------

export const resources = pgTable("resources", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: varchar("type", { length: 64 }).notNull(),
  region: varchar("region", { length: 64 }).notNull().default("local-1"),
  status: varchar("status", { length: 32 }).notNull().default("CREATING"),
  spec: jsonb("spec").notNull().default(sql`'{}'::jsonb`),
  metadata: jsonb("metadata").notNull().default(sql`'{}'::jsonb`),
  labels: jsonb("labels").notNull().default(sql`'{}'::jsonb`),
  createdBy: uuid("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  version: integer("version").notNull().default(1),
}, (t) => ({
  projectIdx: index("resources_project_idx").on(t.projectId),
  projectNameIdx: uniqueIndex("resources_project_name_idx").on(t.projectId, t.name),
  typeIdx: index("resources_type_idx").on(t.type),
  statusIdx: index("resources_status_idx").on(t.status),
}));

export const resourceRelationships = pgTable("resource_relationships", {
  id: uuid("id").primaryKey().defaultRandom(),
  fromResourceId: uuid("from_resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  toResourceId: uuid("to_resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  kind: varchar("kind", { length: 32 }).notNull(), // contains | connects_to | routes_to | depends_on | exposes
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  fromIdx: index("resource_relationships_from_idx").on(t.fromResourceId),
  toIdx: index("resource_relationships_to_idx").on(t.toResourceId),
}));

export const resourceEvents = pgTable("resource_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  fromStatus: varchar("from_status", { length: 32 }),
  toStatus: varchar("to_status", { length: 32 }).notNull(),
  message: text("message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  resourceIdx: index("resource_events_resource_idx").on(t.resourceId),
}));

// ---------------------------------------------------------------------------
// Operations: the async job envelope. POST returns {operationId}; the worker
// drives it through steps and the API streams updates over WebSocket.
// ---------------------------------------------------------------------------

export const operations = pgTable("operations", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  resourceId: uuid("resource_id").references(() => resources.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 64 }).notNull(), // e.g. network.create, instance.create, instance.delete
  requestId: varchar("request_id", { length: 64 }), // correlates to audit_logs.request_id -- see routes/observability.ts's trace endpoint
  status: varchar("status", { length: 32 }).notNull().default("PENDING"),
  steps: jsonb("steps").notNull().default(sql`'[]'::jsonb`),
  error: jsonb("error"),
  createdBy: uuid("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  projectIdx: index("operations_project_idx").on(t.projectId),
  resourceIdx: index("operations_resource_idx").on(t.resourceId),
}));

// ---------------------------------------------------------------------------
// Audit: every API call, automatically, via middleware -- never opt-in.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Milestone 9: Observability. Metrics are real time-series samples backed by
// the Docker Engine's own container.stats() accounting (the same source the
// milestone 3 live-stats panel reads live, now persisted); alerts are
// derived from real state transitions and real metric samples, evaluated by
// a background loop (apps/worker/src/observability/), never hand-set.
// ---------------------------------------------------------------------------

export const resourceMetrics = pgTable("resource_metrics", {
  id: uuid("id").primaryKey().defaultRandom(),
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  cpuPercent: integer("cpu_percent"), // rounded to the nearest whole percent -- good enough for dashboards/alerting
  memUsageMb: integer("mem_usage_mb"),
  memLimitMb: integer("mem_limit_mb"),
  networkRxBytes: integer("network_rx_bytes"),
  networkTxBytes: integer("network_tx_bytes"),
  sampledAt: timestamp("sampled_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  resourceIdx: index("resource_metrics_resource_idx").on(t.resourceId),
  sampledAtIdx: index("resource_metrics_sampled_at_idx").on(t.sampledAt),
}));

export const alerts = pgTable("alerts", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  resourceId: uuid("resource_id").references(() => resources.id, { onDelete: "cascade" }),
  ruleKey: varchar("rule_key", { length: 64 }).notNull(), // e.g. resource_failed, high_cpu, pods_under_replicated
  severity: varchar("severity", { length: 16 }).notNull().default("WARNING"), // WARNING | CRITICAL
  status: varchar("status", { length: 16 }).notNull().default("OPEN"), // OPEN | RESOLVED
  message: text("message").notNull(),
  firedAt: timestamp("fired_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
}, (t) => ({
  projectIdx: index("alerts_project_idx").on(t.projectId),
  statusIdx: index("alerts_status_idx").on(t.status),
}));

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  orgId: uuid("org_id"),
  projectId: uuid("project_id"),
  userId: uuid("user_id"),
  ip: varchar("ip", { length: 64 }),
  userAgent: text("user_agent"),
  requestId: varchar("request_id", { length: 64 }).notNull(),
  action: varchar("action", { length: 128 }).notNull(),
  resourceType: varchar("resource_type", { length: 64 }),
  resourceId: uuid("resource_id"),
  resourceName: text("resource_name"),
  previousState: jsonb("previous_state"),
  newState: jsonb("new_state"),
  status: varchar("status", { length: 16 }).notNull(), // SUCCESS | ERROR
  error: text("error"),
  apiEndpoint: text("api_endpoint").notNull(),
  httpMethod: varchar("http_method", { length: 8 }).notNull(),
  source: varchar("source", { length: 16 }).notNull().default("api"), // api | ui | cli
  authMethod: varchar("auth_method", { length: 16 }),
  durationMs: integer("duration_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  projectIdx: index("audit_logs_project_idx").on(t.projectId),
  userIdx: index("audit_logs_user_idx").on(t.userId),
  actionIdx: index("audit_logs_action_idx").on(t.action),
  createdAtIdx: index("audit_logs_created_at_idx").on(t.createdAt),
}));

// ---------------------------------------------------------------------------
// Milestone 12: Learning system. Deliberately *not* a "steps completed"
// checklist a client can PATCH -- every scenario's steps are real predicates
// over this same schema (a READY resource, a SUCCEEDED operation of a given
// type, a RESOLVED alert...), re-evaluated server-side every time. This
// table only ever gets a row once every one of a scenario's real checks has
// passed (see routes/scenarios.ts) -- it's the record of *when* that first
// became true, not the thing that decides whether it's true.
// ---------------------------------------------------------------------------

export const scenarioProgress = pgTable("scenario_progress", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id),
  scenarioKey: varchar("scenario_key", { length: 64 }).notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  uniq: uniqueIndex("scenario_progress_unique_idx").on(t.projectId, t.userId, t.scenarioKey),
  projectIdx: index("scenario_progress_project_idx").on(t.projectId),
}));

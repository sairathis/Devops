import "fastify";

export interface AuditContext {
  action?: string;
  resourceType?: string;
  resourceId?: string;
  resourceName?: string;
  previousState?: unknown;
  newState?: unknown;
  orgId?: string;
  projectId?: string;
}

declare module "fastify" {
  interface FastifyRequest {
    userId?: string;
    requestId: string;
    startTimeMs: number;
    audit: AuditContext;
    lastError?: { code: string; message: string };
  }
}

import type { FastifyRequest, FastifyReply } from "fastify";
import { verifyToken } from "../auth/jwt.js";
import { authFailed } from "../errors.js";

export async function authenticate(req: FastifyRequest, _reply: FastifyReply) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) throw authFailed("Missing bearer token");
  try {
    const payload = verifyToken(header.slice("Bearer ".length));
    req.userId = payload.userId;
  } catch {
    throw authFailed("Invalid or expired token");
  }
}

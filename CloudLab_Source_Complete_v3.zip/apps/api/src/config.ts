// dotenv/config's default `path` is `process.cwd()/.env` -- when this
// process is started with `cd apps/api && npm run dev` (as the dev scripts
// do), that resolves to apps/api/.env, which doesn't exist, silently
// skipping the real .env at the monorepo root. That was previously masked
// because SECRETS_MASTER_KEY has a per-process-random fallback that only
// matters when two DIFFERENT processes need to agree on the same key (e.g.
// Milestone 15's service-account keys, encrypted in the worker and decrypted
// here) -- unlike `secret` resources, which both encrypt and decrypt inside
// this same api process and so never surfaced the mismatch. Loading the
// monorepo root .env explicitly (in addition to, not instead of, any
// process-local .env) makes every process agree on one real key again.
import dotenv from "dotenv";
import { fileURLToPath } from "node:url";
dotenv.config();
dotenv.config({ path: fileURLToPath(new URL("../../../.env", import.meta.url)) });

export const config = {
  port: Number(process.env.PORT ?? 4000),
  jwtSecret: process.env.JWT_SECRET ?? "change-me-in-production",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "12h",
  dockerSocket: process.env.DOCKER_SOCKET ?? "/var/run/docker.sock",
  guestImage: process.env.GUEST_IMAGE ?? "cloudlab/guest:latest",
  publicHost: process.env.PUBLIC_HOST ?? "localhost",
  redisUrl: process.env.REDIS_URL ?? "redis://localhost:6379",
};

import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "../db/client.js";
import { alerts, operations, resourceMetrics, resources } from "../db/schema.js";
import { SCENARIOS } from "@cloudlab/shared";

export interface StepResult {
  key: string;
  title: string;
  instructions: string;
  passed: boolean;
  evidence?: string;
}

export interface ScenarioResult {
  key: string;
  title: string;
  description: string;
  steps: StepResult[];
  completed: boolean;
}

type StepCheck = (projectId: string) => Promise<{ passed: boolean; evidence?: string }>;

async function countReady(projectId: string, type: string, extra?: (rows: (typeof resources.$inferSelect)[]) => (typeof resources.$inferSelect)[]) {
  const rows = await db.select().from(resources).where(and(eq(resources.projectId, projectId), eq(resources.type, type), eq(resources.status, "READY")));
  return extra ? extra(rows) : rows;
}

// Real inter-operation sequencing: did a SUCCEEDED `firstType` operation on
// some resource get followed by a SUCCEEDED `secondType` operation on that
// *same* resource, strictly later? This is what actually distinguishes
// "stopped, then started again" (or "crashed, then recovered") from just
// having done either one in isolation, without inventing a new "lifecycle
// exercised" flag anywhere -- it's read straight off the real operations
// history every processor in this app already writes.
async function hasSucceededSequence(projectId: string, firstType: string, secondType: string, label: string): Promise<{ passed: boolean; evidence?: string }> {
  const rows = await db
    .select({ resourceId: operations.resourceId, type: operations.type, createdAt: operations.createdAt })
    .from(operations)
    .where(and(eq(operations.projectId, projectId), eq(operations.status, "SUCCEEDED"), inArray(operations.type, [firstType, secondType])))
    .orderBy(operations.createdAt);

  const firstSeenAt = new Map<string, Date>();
  for (const row of rows) {
    if (!row.resourceId) continue;
    if (row.type === firstType) {
      if (!firstSeenAt.has(row.resourceId)) firstSeenAt.set(row.resourceId, row.createdAt);
    } else if (row.type === secondType) {
      const firstAt = firstSeenAt.get(row.resourceId);
      if (firstAt && row.createdAt.getTime() > firstAt.getTime()) {
        return { passed: true, evidence: `${label} on the same instance (verified from its real operations history)` };
      }
    }
  }
  return { passed: false };
}

const CHECKS: Record<string, Record<string, StepCheck>> = {
  "networking-fundamentals": {
    "create-network": async (projectId) => {
      const rows = await countReady(projectId, "network");
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY network(s)` : undefined };
    },
    "create-subnet": async (projectId) => {
      const rows = await countReady(projectId, "subnet");
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY subnet(s)` : undefined };
    },
    "create-instance-in-subnet": async (projectId) => {
      const rows = await countReady(projectId, "instance", (all) => all.filter((r) => !!(r.spec as { subnetId?: string })?.subnetId));
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY instance(s) with a real subnet-assigned IP` : undefined };
    },
    "add-firewall-rule": async (projectId) => {
      const rows = await countReady(projectId, "firewall_rule");
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY firewall rule(s)` : undefined };
    },
  },
  "compute-lifecycle": {
    "create-instance": async (projectId) => {
      const rows = await countReady(projectId, "instance");
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY instance(s)` : undefined };
    },
    "stop-and-start": (projectId) => hasSucceededSequence(projectId, "instance.stop", "instance.start", "a real Stop followed by a real Start"),
    "crash-and-recover": (projectId) => hasSucceededSequence(projectId, "instance.crash", "instance.start", "a real fault-injected crash followed by a real recovery"),
  },
  "kubernetes-basics": {
    "create-cluster": async (projectId) => {
      const rows = await countReady(projectId, "k8s_cluster");
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY cluster(s)` : undefined };
    },
    deploy: async (projectId) => {
      const rows = await countReady(projectId, "k8s_deployment", (all) => all.filter((r) => Number((r.spec as { replicas?: number })?.replicas ?? 0) >= 2));
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} READY deployment(s) with 2+ replicas` : undefined };
    },
    scale: async (projectId) => {
      const rows = await db.select().from(operations).where(and(eq(operations.projectId, projectId), eq(operations.type, "k8s_deployment.scale"), eq(operations.status, "SUCCEEDED")));
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} successful scale operation(s)` : undefined };
    },
  },
  "observability-alerting": {
    "collect-metrics": async (projectId) => {
      const [row] = await db.select({ count: sql<number>`count(*)` }).from(resourceMetrics).where(eq(resourceMetrics.projectId, projectId));
      const count = Number(row?.count ?? 0);
      return { passed: count > 0, evidence: count ? `${count} real metric sample(s) recorded` : undefined };
    },
    "trigger-alert": async (projectId) => {
      const rows = await db.select().from(alerts).where(eq(alerts.projectId, projectId));
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} real alert(s) fired` : undefined };
    },
    "resolve-alert": async (projectId) => {
      const rows = await db.select().from(alerts).where(and(eq(alerts.projectId, projectId), eq(alerts.status, "RESOLVED")));
      return { passed: rows.length > 0, evidence: rows.length ? `${rows.length} alert(s) resolved` : undefined };
    },
  },
};

export async function evaluateScenario(scenarioKey: string, projectId: string): Promise<ScenarioResult | null> {
  const def = SCENARIOS.find((s) => s.key === scenarioKey);
  if (!def) return null;
  const checks = CHECKS[scenarioKey] ?? {};
  const steps: StepResult[] = await Promise.all(
    def.steps.map(async (step) => {
      const check = checks[step.key];
      const result = check ? await check(projectId) : { passed: false };
      return { key: step.key, title: step.title, instructions: step.instructions, passed: result.passed, evidence: result.evidence };
    }),
  );
  return { key: def.key, title: def.title, description: def.description, steps, completed: steps.every((s) => s.passed) };
}

export async function evaluateAllScenarios(projectId: string): Promise<ScenarioResult[]> {
  return Promise.all(SCENARIOS.map((def) => evaluateScenario(def.key, projectId))).then((rs) => rs.filter((r): r is ScenarioResult => r !== null));
}

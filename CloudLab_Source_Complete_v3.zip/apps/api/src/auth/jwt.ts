import jwt from "jsonwebtoken";
import { config } from "../config.js";

export interface TokenPayload {
  userId: string;
  email: string;
}

export function signToken(payload: TokenPayload, expiresIn?: string): string {
  return jwt.sign(payload, config.jwtSecret, { expiresIn: (expiresIn ?? config.jwtExpiresIn) as jwt.SignOptions["expiresIn"] });
}

export function verifyToken(token: string): TokenPayload {
  return jwt.verify(token, config.jwtSecret) as TokenPayload;
}

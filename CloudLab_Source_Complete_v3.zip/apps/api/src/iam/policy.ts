import { eq, and } from "drizzle-orm";
import { db } from "../db/client.js";
import { orgMemberships, projectMemberships, projects } from "../db/schema.js";
import { BUILTIN_ROLES, isAllowed, type Role } from "@cloudlab/shared";
import { permissionDenied, notFound } from "../errors.js";

const roleByKey = new Map(BUILTIN_ROLES.map((r) => [r.key, r]));

export function resolveRole(key: string): Role {
  return roleByKey.get(key) ?? { key, name: key, allow: [], deny: ["*"] };
}

export interface EffectiveAccess {
  orgId: string;
  projectId: string;
  role: Role;
  source: "project" | "org";
}

/**
 * Resource-level IAM (spec section 7) simplifies, for this milestone, to
 * project-level bindings with inheritance from the org role when no
 * project-specific binding exists ("Role inheritance").
 */
export async function getEffectiveAccess(userId: string, projectId: string): Promise<EffectiveAccess | null> {
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return null;

  const [projectBinding] = await db
    .select()
    .from(projectMemberships)
    .where(and(eq(projectMemberships.projectId, projectId), eq(projectMemberships.userId, userId)))
    .limit(1);
  if (projectBinding) {
    return { orgId: project.orgId, projectId, role: resolveRole(projectBinding.roleKey), source: "project" };
  }

  const [orgBinding] = await db
    .select()
    .from(orgMemberships)
    .where(and(eq(orgMemberships.orgId, project.orgId), eq(orgMemberships.userId, userId)))
    .limit(1);
  if (orgBinding) {
    return { orgId: project.orgId, projectId, role: resolveRole(orgBinding.roleKey), source: "org" };
  }

  return null;
}

/**
 * Throws PERMISSION_DENIED with a realistic diagnostic, or RESOURCE_NOT_FOUND
 * if the project itself doesn't exist / isn't visible to this user -- mirrors
 * how real cloud APIs avoid leaking existence of resources you can't see.
 */
export async function requireProjectPermission(userId: string, projectId: string, action: string): Promise<EffectiveAccess> {
  const access = await getEffectiveAccess(userId, projectId);
  if (!access) throw notFound("project", projectId);
  if (!isAllowed(access.role, action)) throw permissionDenied(action, access.role.key);
  return access;
}

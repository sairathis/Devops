import { and, eq, ne } from "drizzle-orm";
import { db } from "../db/client.js";
import { resources } from "../db/schema.js";

// Milestone 15 (Shared VPC): the actual enforcement point for cross-project
// network attachment. Every other resource type in this app is hard-isolated
// per project (apps/api/src/resources/model.ts's getResource always filters
// by projectId) -- this is the one, deliberately narrow exception: a service
// project may attach an instance to a host project's network ONLY when a
// READY shared_vpc_attachment names that exact (host, service, network)
// triple. No attachment, no access -- this is a real, checked boundary, not
// a label.
export async function hasSharedVpcGrant(hostProjectId: string, serviceProjectId: string, networkResourceId: string): Promise<boolean> {
  const rows = await db
    .select()
    .from(resources)
    .where(and(eq(resources.projectId, hostProjectId), eq(resources.type, "shared_vpc_attachment"), ne(resources.status, "DELETED")));
  return rows.some((r) => {
    const spec = r.spec as { serviceProjectId?: string; networkResourceId?: string };
    return r.status === "READY" && spec.serviceProjectId === serviceProjectId && spec.networkResourceId === networkResourceId;
  });
}

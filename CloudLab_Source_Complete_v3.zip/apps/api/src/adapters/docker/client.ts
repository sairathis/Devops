import Docker from "dockerode";
import { config } from "../../config.js";

// The single Docker Engine connection the API uses for read/interactive
// operations (logs, exec). Resource lifecycle (create/start/stop/delete) is
// owned by the worker process -- the API never mutates infrastructure
// directly, it only enqueues an operation (spec section 4: "Never put
// infrastructure provisioning logic directly inside UI/API request handlers").
export const docker = new Docker({ socketPath: config.dockerSocket });

export function containerNameFor(instanceResourceId: string) {
  return `cloudlab-vm-${instanceResourceId}`;
}

export function networkNameFor(networkResourceId: string) {
  return `cloudlab-net-${networkResourceId}`;
}

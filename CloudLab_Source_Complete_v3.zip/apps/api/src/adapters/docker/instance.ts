import { docker, containerNameFor } from "./client.js";

export async function runCommand(instanceResourceId: string, command: string, timeoutMs = 15_000) {
  const container = docker.getContainer(containerNameFor(instanceResourceId));
  const exec = await container.exec({
    Cmd: ["/bin/sh", "-c", command],
    AttachStdout: true,
    AttachStderr: true,
  });
  const stream = await exec.start({ hijack: true, stdin: false });

  const chunks: Buffer[] = [];
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("command timed out")), timeoutMs);
    stream.on("data", (chunk: Buffer) => chunks.push(chunk));
    stream.on("end", () => {
      clearTimeout(timer);
      resolve();
    });
    stream.on("error", (err: Error) => {
      clearTimeout(timer);
      reject(err);
    });
  });

  const output = demuxDockerStream(Buffer.concat(chunks));
  const inspect = await exec.inspect();
  return { output, exitCode: inspect.ExitCode };
}

// Real per-instance resource usage, computed the same way `docker stats`
// does (cpu delta / system-cpu delta * online CPUs), from one non-streaming
// snapshot of the Docker Engine's own accounting -- not sampled/estimated.
export async function getStats(instanceResourceId: string) {
  const container = docker.getContainer(containerNameFor(instanceResourceId));
  const stats = await container.stats({ stream: false });
  const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
  const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;
  const onlineCpus = stats.cpu_stats.online_cpus || stats.cpu_stats.cpu_usage.percpu_usage?.length || 1;
  const cpuPercent = systemDelta > 0 && cpuDelta > 0 ? (cpuDelta / systemDelta) * onlineCpus * 100 : 0;
  const memUsageBytes = stats.memory_stats.usage ?? 0;
  const memLimitBytes = stats.memory_stats.limit ?? 0;
  return {
    cpuPercent: Math.round(cpuPercent * 10) / 10,
    memUsageMb: Math.round((memUsageBytes / 1024 / 1024) * 10) / 10,
    memLimitMb: Math.round((memLimitBytes / 1024 / 1024) * 10) / 10,
    networkRxBytes: Object.values(stats.networks ?? {}).reduce((sum: number, n: any) => sum + (n.rx_bytes ?? 0), 0),
    networkTxBytes: Object.values(stats.networks ?? {}).reduce((sum: number, n: any) => sum + (n.tx_bytes ?? 0), 0),
    sampledAt: new Date().toISOString(),
  };
}

export async function getLogs(instanceResourceId: string, tail = 200): Promise<string> {
  const container = docker.getContainer(containerNameFor(instanceResourceId));
  const buffer = (await container.logs({ stdout: true, stderr: true, tail, timestamps: true })) as unknown as Buffer;
  return demuxDockerStream(buffer);
}

/**
 * Docker's raw log/exec stream multiplexes stdout/stderr with an 8-byte
 * header per frame when Tty is disabled. Strip it so callers see plain text.
 */
function demuxDockerStream(buf: Buffer): string {
  let out = "";
  let offset = 0;
  while (offset + 8 <= buf.length) {
    const length = buf.readUInt32BE(offset + 4);
    const start = offset + 8;
    const end = start + length;
    if (end > buf.length) break;
    out += buf.subarray(start, end).toString("utf8");
    offset = end;
  }
  return out || buf.toString("utf8");
}

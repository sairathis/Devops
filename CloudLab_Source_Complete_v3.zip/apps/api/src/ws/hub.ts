import type { FastifyInstance } from "fastify";
import type { WebSocket } from "ws";
import { createRedisConnection } from "../queue/connection.js";
import { UPDATES_CHANNEL } from "../queue/queue.js";
import { verifyToken } from "../auth/jwt.js";

interface Client {
  socket: WebSocket;
  projectId: string;
}

const clients = new Set<Client>();

export function broadcastToProject(projectId: string, payload: unknown) {
  const msg = JSON.stringify(payload);
  for (const c of clients) {
    if (c.projectId === projectId && c.socket.readyState === c.socket.OPEN) {
      c.socket.send(msg);
    }
  }
}

/**
 * The worker process runs in a separate Node process from the API, so it
 * cannot call broadcastToProject() directly -- it publishes to Redis instead,
 * and this subscriber relays those events to whichever WS clients are
 * connected to THIS API instance. This is the real-time UI plumbing behind
 * spec section 51 (no manual refresh) and section 38 (operation status
 * streamed over WebSocket/SSE).
 */
export function registerWsHub(app: FastifyInstance) {
  const sub = createRedisConnection();
  sub.subscribe(UPDATES_CHANNEL).catch((err: Error) => app.log.error({ err }, "redis subscribe failed"));
  sub.on("message", (_channel: string, message: string) => {
    try {
      const event = JSON.parse(message) as { projectId: string };
      broadcastToProject(event.projectId, event);
    } catch (err) {
      app.log.error({ err }, "failed to relay ws event");
    }
  });

  app.get("/ws", { websocket: true }, (socket, req) => {
    const url = new URL(req.url ?? "", "http://internal");
    const token = url.searchParams.get("token");
    const projectId = url.searchParams.get("projectId");
    if (!token || !projectId) {
      socket.close(4000, "token and projectId query params are required");
      return;
    }
    try {
      verifyToken(token);
    } catch {
      socket.close(4001, "invalid token");
      return;
    }
    const client: Client = { socket, projectId };
    clients.add(client);
    socket.send(JSON.stringify({ type: "connected", projectId }));
    socket.on("close", () => clients.delete(client));
  });
}

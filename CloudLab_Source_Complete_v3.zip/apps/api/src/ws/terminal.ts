import type { FastifyInstance } from "fastify";
import { docker, containerNameFor } from "../adapters/docker/client.js";
import { verifyToken } from "../auth/jwt.js";

/**
 * A real interactive terminal (spec section 14): a Tty-attached `docker exec`
 * into the actual running container, piped bidirectionally over WebSocket.
 * This is genuinely the same mechanism `docker exec -it` uses -- not a canned
 * command list.
 */
export function registerTerminal(app: FastifyInstance) {
  app.get("/ws/terminal", { websocket: true }, async (socket, req) => {
    const url = new URL(req.url ?? "", "http://internal");
    const token = url.searchParams.get("token");
    const instanceId = url.searchParams.get("instanceId");
    if (!token || !instanceId) {
      socket.close(4000, "token and instanceId query params are required");
      return;
    }
    try {
      verifyToken(token);
    } catch {
      socket.close(4001, "invalid token");
      return;
    }

    try {
      const container = docker.getContainer(containerNameFor(instanceId));
      const exec = await container.exec({
        Cmd: ["/bin/sh"],
        AttachStdin: true,
        AttachStdout: true,
        AttachStderr: true,
        Tty: true,
      });
      const stream = await exec.start({ hijack: true, stdin: true, Tty: true });

      stream.on("data", (chunk: Buffer) => {
        if (socket.readyState === socket.OPEN) socket.send(chunk);
      });
      stream.on("error", () => socket.close());
      stream.on("end", () => socket.close(1000, "session ended"));

      socket.on("message", (data: Buffer) => {
        stream.write(data);
      });
      socket.on("close", () => {
        stream.end();
      });
    } catch (err) {
      socket.send(`\r\n[cloudlab] failed to attach terminal: ${(err as Error).message}\r\n`);
      socket.close();
    }
  });
}

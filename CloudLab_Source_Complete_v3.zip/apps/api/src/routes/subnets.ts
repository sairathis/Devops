import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerSubnetRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkId: string; cidr: string } }>(
      "/api/v1/projects/:projectId/subnets",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.subnets.create");
        const { name, networkId, cidr } = req.body ?? {};
        if (!name || !networkId || !cidr) throw validationError("name, networkId and cidr are required");

        const resource = await createResource({ projectId, name, type: "subnet", spec: { networkId, cidr }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "subnet.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("subnet.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "subnet.create" });

        req.audit.action = "network.subnets.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "subnet";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/subnets", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.subnets.list");
      reply.send(await listResources(req.params.projectId, "subnet"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/subnets/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.subnets.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/subnets/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.subnets.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "subnet.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("subnet.delete", { operationId: operation.id, projectId, resourceId: id, type: "subnet.delete" });

      req.audit.action = "network.subnets.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "subnet";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

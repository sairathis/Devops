import type { FastifyInstance } from "fastify";
import { eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { users } from "../db/schema.js";
import { hashPassword, verifyPassword } from "../auth/password.js";
import { signToken } from "../auth/jwt.js";
import { authFailed, accountLocked, conflict, validationError } from "../errors.js";
import { authenticate } from "../middleware/authenticate.js";

// Milestone 13: real account lockout. This is the actual brute-force
// defense (the IP-based rate limit in server.ts is a secondary, coarser
// backstop) -- it counts genuinely wrong passwords per account in the
// database and locks that account for a real, honestly-reported duration
// once the threshold is crossed, regardless of which IP the attempts came
// from.
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

// A stricter per-route limit than the global default, applied to both
// register and login below -- generous enough not to trip on normal
// traffic (or this app's own test suite), but a real backstop against a
// scripted credential-stuffing loop hammering this endpoint specifically.
const AUTH_RATE_LIMIT = { max: 60, timeWindow: "1 minute" };

export function registerAuthRoutes(app: FastifyInstance) {
  app.post<{ Body: { email: string; password: string; name: string } }>("/api/v1/auth/register", { config: { rateLimit: AUTH_RATE_LIMIT } }, async (req, reply) => {
    const { email, password, name } = req.body ?? {};
    if (!email || !password || !name) throw validationError("email, password and name are required");
    if (password.length < 8) throw validationError("password must be at least 8 characters");

    const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing) throw conflict(`An account with email '${email}' already exists.`);

    const passwordHash = await hashPassword(password);
    const [user] = await db.insert(users).values({ email, passwordHash, name }).returning();

    req.audit.action = "auth.register";
    req.audit.resourceType = "user";
    req.audit.resourceId = user.id;
    req.audit.resourceName = user.email;
    req.userId = user.id;

    const token = signToken({ userId: user.id, email: user.email });
    reply.status(201).send({ token, user: { id: user.id, email: user.email, name: user.name } });
  });

  app.post<{ Body: { email: string; password: string } }>("/api/v1/auth/login", { config: { rateLimit: AUTH_RATE_LIMIT } }, async (req, reply) => {
    const { email, password } = req.body ?? {};
    if (!email || !password) throw validationError("email and password are required");

    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

    // A locked account is rejected before even checking the password --
    // this is the real point of a lockout (stop guessing), not a cosmetic
    // extra check after the fact.
    if (user?.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      throw accountLocked(Math.ceil((user.lockedUntil.getTime() - Date.now()) / 1000));
    }

    const passwordOk = user ? await verifyPassword(password, user.passwordHash) : false;
    if (!user || !passwordOk) {
      if (user) {
        const attempts = user.failedLoginAttempts + 1;
        const lockedUntil = attempts >= MAX_FAILED_ATTEMPTS ? new Date(Date.now() + LOCKOUT_MS) : null;
        await db.update(users).set({ failedLoginAttempts: attempts, lockedUntil }).where(eq(users.id, user.id));
        if (lockedUntil) throw accountLocked(Math.ceil(LOCKOUT_MS / 1000));
      }
      throw authFailed();
    }

    // Real success resets the real counter -- a lockout only ever reflects
    // a genuinely unbroken run of wrong passwords, not a lifetime tally.
    if (user.failedLoginAttempts > 0 || user.lockedUntil) {
      await db.update(users).set({ failedLoginAttempts: 0, lockedUntil: null }).where(eq(users.id, user.id));
    }

    req.userId = user.id;
    req.audit.action = "auth.login";
    req.audit.resourceType = "user";
    req.audit.resourceId = user.id;
    req.audit.resourceName = user.email;

    const token = signToken({ userId: user.id, email: user.email });
    reply.send({ token, user: { id: user.id, email: user.email, name: user.name } });
  });

  app.get("/api/v1/auth/me", { preHandler: authenticate }, async (req, reply) => {
    const [user] = await db.select().from(users).where(eq(users.id, req.userId!)).limit(1);
    if (!user) throw authFailed();
    reply.send({ id: user.id, email: user.email, name: user.name });
  });
}

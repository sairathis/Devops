import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation, updateResourceSpec } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

// GCP Managed Instance Group equivalent: `targetSize` real container
// instances stamped from an instance_template, kept at that count forever
// after by a real reconciler loop (apps/worker/src/mig/reconciler.ts).
export function registerManagedInstanceGroupRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; instanceTemplateId: string; networkId: string; targetSize?: number } }>(
      "/api/v1/projects/:projectId/managed-instance-groups",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "compute.instanceGroups.create");
        const { name, instanceTemplateId, networkId, targetSize } = req.body ?? {};
        if (!name || !instanceTemplateId || !networkId) throw validationError("name, instanceTemplateId and networkId are required");

        const template = await getResource(projectId, instanceTemplateId);
        if (template.type !== "instance_template") throw validationError(`'${instanceTemplateId}' is not an instance_template resource`);
        if (template.status !== "READY") throw conflict(`Instance template '${template.name}' is not READY`);
        const network = await getResource(projectId, networkId);
        if (network.type !== "network") throw validationError(`'${networkId}' is not a network resource`);
        if (network.status !== "READY") throw conflict(`Network '${network.name}' is not READY`);

        const size = Math.max(1, Math.min(10, Number(targetSize) || 1));
        const resource = await createResource({
          projectId,
          name,
          type: "managed_instance_group",
          spec: { instanceTemplateId, networkId, targetSize: size },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "managed_instance_group.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("managed_instance_group.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "managed_instance_group.create" });

        req.audit.action = "compute.instanceGroups.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "managed_instance_group";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/managed-instance-groups", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.instanceGroups.list");
      reply.send(await listResources(req.params.projectId, "managed_instance_group"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/managed-instance-groups/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.instanceGroups.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    // GCP's own `gcloud compute instance-groups managed resize` -- changes
    // desired count; the reconciler (next tick, <=10s) does the real work.
    app.post<{ Params: { projectId: string; id: string }; Body: { targetSize: number } }>(
      "/api/v1/projects/:projectId/managed-instance-groups/:id/resize",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "compute.instanceGroups.resize");
        const resource = await getResource(projectId, id);
        if (resource.status !== "READY") throw conflict(`Group '${resource.name}' is not READY (status: ${resource.status})`);
        const targetSize = Math.max(1, Math.min(10, Number(req.body?.targetSize)));
        if (!Number.isFinite(targetSize)) throw validationError("targetSize must be a number between 1 and 10");

        await updateResourceSpec(id, { targetSize });
        const operation = await createOperation({ projectId, resourceId: id, type: "managed_instance_group.resize", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("managed_instance_group.resize", { operationId: operation.id, projectId, resourceId: id, type: "managed_instance_group.resize" });

        req.audit.action = "compute.instanceGroups.resize";
        req.audit.projectId = projectId;
        req.audit.resourceType = "managed_instance_group";
        req.audit.resourceId = id;
        req.audit.newState = { targetSize };

        reply.status(202).send({ operationId: operation.id, targetSize });
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/managed-instance-groups/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "compute.instanceGroups.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "managed_instance_group.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("managed_instance_group.delete", { operationId: operation.id, projectId, resourceId: id, type: "managed_instance_group.delete" });

      req.audit.action = "compute.instanceGroups.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "managed_instance_group";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

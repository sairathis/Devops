import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerPipelineRunRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { pipelineId: string } }>(
      "/api/v1/projects/:projectId/pipeline-runs",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "cicd.pipelineRuns.create");
        const { pipelineId } = req.body ?? {};
        if (!pipelineId) throw validationError("pipelineId is required");
        const pipeline = await getResource(projectId, pipelineId);

        const resource = await createResource({
          projectId,
          name: `${pipeline.name}-run-${Date.now()}`,
          type: "pipeline_run",
          spec: { pipelineId },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "pipeline_run.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("pipeline_run.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "pipeline_run.create" });

        req.audit.action = "cicd.pipelineRuns.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "pipeline_run";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/pipeline-runs", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "cicd.pipelineRuns.list");
      reply.send(await listResources(req.params.projectId, "pipeline_run"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/pipeline-runs/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "cicd.pipelineRuns.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/pipeline-runs/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "cicd.pipelineRuns.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "pipeline_run.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("pipeline_run.delete", { operationId: operation.id, projectId, resourceId: id, type: "pipeline_run.delete" });

      req.audit.action = "cicd.pipelineRuns.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "pipeline_run";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerDiskRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; sizeGb?: number } }>(
      "/api/v1/projects/:projectId/disks",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "compute.disks.create");
        const { name, sizeGb } = req.body ?? {};
        if (!name) throw validationError("name is required");

        const resource = await createResource({ projectId, name, type: "disk", spec: { sizeGb: sizeGb ?? 10 }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "disk.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("disk.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "disk.create" });

        req.audit.action = "compute.disks.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "disk";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/disks", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.disks.list");
      reply.send(await listResources(req.params.projectId, "disk"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/disks/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.disks.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/disks/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "compute.disks.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "disk.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("disk.delete", { operationId: operation.id, projectId, resourceId: id, type: "disk.delete" });

      req.audit.action = "compute.disks.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "disk";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

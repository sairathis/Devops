import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";
import { assertValidCron } from "@cloudlab/shared";

// Cloud Composer equivalent. Wraps a real CI/CD pipeline with a real 5-field
// UTC cron schedule -- see apps/worker/src/composer/scheduler.ts for the
// loop that actually fires real pipeline runs on schedule, and cron.ts for
// what subset of real cron syntax is supported (documented simplification).
export function registerComposerEnvironmentRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; pipelineId: string; schedule: string } }>(
      "/api/v1/projects/:projectId/composer-environments",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "composer.environments.create");
        const { name, pipelineId, schedule } = req.body ?? {};
        if (!name || !pipelineId || !schedule) throw validationError("name, pipelineId and schedule are required");
        const pipeline = await getResource(projectId, pipelineId);
        if (pipeline.type !== "pipeline") throw validationError(`'${pipelineId}' is not a pipeline resource`);
        try {
          assertValidCron(schedule);
        } catch (err) {
          throw validationError((err as Error).message);
        }

        const resource = await createResource({ projectId, name, type: "composer_environment", spec: { pipelineId, schedule }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "composer_environment.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("composer_environment.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "composer_environment.create" });

        req.audit.action = "composer.environments.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "composer_environment";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/composer-environments", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "composer.environments.list");
      reply.send(await listResources(req.params.projectId, "composer_environment"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/composer-environments/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "composer.environments.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/composer-environments/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "composer.environments.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "composer_environment.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("composer_environment.delete", { operationId: operation.id, projectId, resourceId: id, type: "composer_environment.delete" });

      req.audit.action = "composer.environments.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "composer_environment";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerDnsRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkId: string; hostname: string; ip: string } }>(
      "/api/v1/projects/:projectId/dns-records",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.dns.create");
        const { name, networkId, hostname, ip } = req.body ?? {};
        if (!name || !networkId || !hostname || !ip) throw validationError("name, networkId, hostname and ip are required");

        const resource = await createResource({ projectId, name, type: "dns_record", spec: { networkId, hostname, ip }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "dns_record.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("dns_record.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "dns_record.create" });

        req.audit.action = "network.dns.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "dns_record";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/dns-records", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.dns.list");
      reply.send(await listResources(req.params.projectId, "dns_record"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/dns-records/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.dns.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/dns-records/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.dns.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "dns_record.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("dns_record.delete", { operationId: operation.id, projectId, resourceId: id, type: "dns_record.delete" });

      req.audit.action = "network.dns.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "dns_record";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { getOperation } from "../resources/model.js";

export function registerOperationRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/operations/:id", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
    reply.send(await getOperation(req.params.projectId, req.params.id));
  });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

// GCP Cloud NAT equivalent -- see apps/worker/src/net/iptables.ts
// applyNatGateway for the real host-level MASQUERADE rules this creates.
export function registerNatGatewayRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkResourceId: string } }>(
      "/api/v1/projects/:projectId/nat-gateways",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.natGateways.create");
        const { name, networkResourceId } = req.body ?? {};
        if (!name || !networkResourceId) throw validationError("name and networkResourceId are required");
        const network = await getResource(projectId, networkResourceId);
        if (network.type !== "network") throw validationError(`'${networkResourceId}' is not a network resource`);
        if (network.status !== "READY") throw conflict(`Network '${network.name}' is not READY`);

        const resource = await createResource({ projectId, name, type: "nat_gateway", spec: { networkResourceId }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "nat_gateway.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("nat_gateway.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "nat_gateway.create" });

        req.audit.action = "network.natGateways.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "nat_gateway";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/nat-gateways", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.natGateways.list");
      reply.send(await listResources(req.params.projectId, "nat_gateway"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/nat-gateways/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.natGateways.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/nat-gateways/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.natGateways.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "nat_gateway.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("nat_gateway.delete", { operationId: operation.id, projectId, resourceId: id, type: "nat_gateway.delete" });

      req.audit.action = "network.natGateways.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "nat_gateway";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

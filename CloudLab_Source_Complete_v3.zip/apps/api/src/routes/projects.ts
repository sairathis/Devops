import type { FastifyInstance } from "fastify";
import { and, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { projects, projectMemberships, orgMemberships } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { validationError, notFound, permissionDenied } from "../errors.js";
import { getEffectiveAccess, requireProjectPermission } from "../iam/policy.js";
import { BUILTIN_ROLES } from "@cloudlab/shared";

function slugify(name: string) {
  return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "project";
}

export function registerProjectRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.post<{ Body: { orgId: string; name: string } }>("/api/v1/projects", async (req, reply) => {
    const { orgId, name } = req.body ?? {};
    if (!orgId || !name) throw validationError("orgId and name are required");

    const [membership] = await db
      .select()
      .from(orgMemberships)
      .where(and(eq(orgMemberships.orgId, orgId), eq(orgMemberships.userId, req.userId!)))
      .limit(1);
    if (!membership) throw notFound("organization", orgId);
    if (!["owner", "admin"].includes(membership.roleKey)) throw permissionDenied("projects.create", membership.roleKey);

    const slug = `${slugify(name)}-${Math.random().toString(36).slice(2, 6)}`;
    const [project] = await db.insert(projects).values({ orgId, name, slug, createdBy: req.userId! }).returning();
    await db.insert(projectMemberships).values({ projectId: project.id, userId: req.userId!, roleKey: "owner" });

    req.audit.action = "projects.create";
    req.audit.orgId = orgId;
    req.audit.projectId = project.id;
    req.audit.resourceType = "project";
    req.audit.resourceId = project.id;
    req.audit.resourceName = project.name;
    req.audit.newState = project;

    reply.status(201).send(project);
  });

  app.get<{ Querystring: { orgId?: string } }>("/api/v1/projects", async (req, reply) => {
    const rows = await db
      .select({ project: projects, roleKey: projectMemberships.roleKey })
      .from(projectMemberships)
      .innerJoin(projects, eq(projectMemberships.projectId, projects.id))
      .where(eq(projectMemberships.userId, req.userId!));
    const filtered = req.query.orgId ? rows.filter((r) => r.project.orgId === req.query.orgId) : rows;
    reply.send(filtered.map((r) => ({ ...r.project, myRole: r.roleKey })));
  });

  app.get<{ Params: { id: string } }>("/api/v1/projects/:id", async (req, reply) => {
    const access = await getEffectiveAccess(req.userId!, req.params.id);
    if (!access) throw notFound("project", req.params.id);
    const [project] = await db.select().from(projects).where(eq(projects.id, req.params.id)).limit(1);
    reply.send({ ...project, myRole: access.role.key });
  });

  app.get<{ Params: { id: string } }>("/api/v1/projects/:id/iam", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.id, "iam.roles.read");
    const bindings = await db.select().from(projectMemberships).where(eq(projectMemberships.projectId, req.params.id));
    reply.send({ roles: BUILTIN_ROLES, bindings });
  });

  app.post<{ Params: { id: string }; Body: { userId: string; roleKey: string } }>(
    "/api/v1/projects/:id/iam/bindings",
    async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.id, "iam.bindings.create");
      const { userId, roleKey } = req.body ?? {};
      if (!userId || !roleKey) throw validationError("userId and roleKey are required");
      if (!BUILTIN_ROLES.some((r) => r.key === roleKey)) throw validationError(`Unknown role '${roleKey}'`);

      const [binding] = await db
        .insert(projectMemberships)
        .values({ projectId: req.params.id, userId, roleKey })
        .onConflictDoUpdate({ target: [projectMemberships.projectId, projectMemberships.userId], set: { roleKey } })
        .returning();

      req.audit.action = "iam.bindings.create";
      req.audit.projectId = req.params.id;
      req.audit.resourceType = "iam_binding";
      req.audit.resourceId = binding.id;
      req.audit.newState = binding;

      reply.status(201).send(binding);
    },
  );
  });
}

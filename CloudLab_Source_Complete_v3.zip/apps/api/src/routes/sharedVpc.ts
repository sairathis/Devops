import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict, notFound } from "../errors.js";
import { db } from "../db/client.js";
import { projects } from "../db/schema.js";
import { eq } from "drizzle-orm";

// GCP Shared VPC equivalent. Created in the HOST project (the one that owns
// the network being shared); grants exactly one named service project the
// ability to attach instances to exactly one named network. See
// apps/api/src/iam/sharedVpc.ts for the real enforcement check and
// routes/instances.ts for where it's actually consulted.
export function registerSharedVpcRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; serviceProjectId: string; networkResourceId: string } }>(
      "/api/v1/projects/:projectId/shared-vpc-attachments",
      async (req, reply) => {
        const { projectId } = req.params; // the HOST project
        await requireProjectPermission(req.userId!, projectId, "network.sharedVpc.create");
        const { name, serviceProjectId, networkResourceId } = req.body ?? {};
        if (!name || !serviceProjectId || !networkResourceId) throw validationError("name, serviceProjectId and networkResourceId are required");
        if (serviceProjectId === projectId) throw validationError("serviceProjectId must be a different project than the host project");

        const network = await getResource(projectId, networkResourceId);
        if (network.type !== "network") throw validationError(`'${networkResourceId}' is not a network resource`);
        if (network.status !== "READY") throw conflict(`Network '${network.name}' is not READY`);

        // The caller must also have visibility into the service project --
        // otherwise this endpoint could be used to probe for project ids
        // that exist without being a member of them. Same permission check
        // any other project-scoped action would require.
        await requireProjectPermission(req.userId!, serviceProjectId, "projects.get").catch(() => {
          throw notFound("project", serviceProjectId);
        });
        const [serviceProject] = await db.select().from(projects).where(eq(projects.id, serviceProjectId)).limit(1);
        if (!serviceProject) throw notFound("project", serviceProjectId);

        const resource = await createResource({
          projectId,
          name,
          type: "shared_vpc_attachment",
          spec: { serviceProjectId, networkResourceId },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "shared_vpc_attachment.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("shared_vpc_attachment.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "shared_vpc_attachment.create" });

        req.audit.action = "network.sharedVpc.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "shared_vpc_attachment";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/shared-vpc-attachments", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.sharedVpc.list");
      reply.send(await listResources(req.params.projectId, "shared_vpc_attachment"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/shared-vpc-attachments/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.sharedVpc.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/shared-vpc-attachments/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.sharedVpc.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "shared_vpc_attachment.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("shared_vpc_attachment.delete", { operationId: operation.id, projectId, resourceId: id, type: "shared_vpc_attachment.delete" });

      req.audit.action = "network.sharedVpc.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "shared_vpc_attachment";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

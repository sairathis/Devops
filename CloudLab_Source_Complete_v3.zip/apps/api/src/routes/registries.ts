import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerRegistryRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string } }>(
      "/api/v1/projects/:projectId/registries",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "registry.registries.create");
        const { name } = req.body ?? {};
        if (!name) throw validationError("name is required");

        const resource = await createResource({ projectId, name, type: "registry", spec: {}, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "registry.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("registry.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "registry.create" });

        req.audit.action = "registry.registries.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "registry";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/registries", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.registries.list");
      reply.send(await listResources(req.params.projectId, "registry"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/registries/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.registries.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/registries/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "registry.registries.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "registry.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("registry.delete", { operationId: operation.id, projectId, resourceId: id, type: "registry.delete" });

      req.audit.action = "registry.registries.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "registry";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

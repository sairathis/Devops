import type { FastifyInstance } from "fastify";
import { eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { organizations, orgMemberships } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { validationError, notFound } from "../errors.js";

function slugify(name: string) {
  return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "org";
}

export function registerOrganizationRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.post<{ Body: { name: string } }>("/api/v1/organizations", async (req, reply) => {
    const { name } = req.body ?? {};
    if (!name) throw validationError("name is required");
    const slug = `${slugify(name)}-${Math.random().toString(36).slice(2, 7)}`;

    const [org] = await db.insert(organizations).values({ name, slug }).returning();
    await db.insert(orgMemberships).values({ orgId: org.id, userId: req.userId!, roleKey: "owner" });

    req.audit.action = "organizations.create";
    req.audit.orgId = org.id;
    req.audit.resourceType = "organization";
    req.audit.resourceId = org.id;
    req.audit.resourceName = org.name;
    req.audit.newState = org;

    reply.status(201).send(org);
  });

  app.get("/api/v1/organizations", async (req, reply) => {
    const rows = await db
      .select({ org: organizations, roleKey: orgMemberships.roleKey })
      .from(orgMemberships)
      .innerJoin(organizations, eq(orgMemberships.orgId, organizations.id))
      .where(eq(orgMemberships.userId, req.userId!));
    reply.send(rows.map((r) => ({ ...r.org, myRole: r.roleKey })));
  });

  app.get<{ Params: { id: string } }>("/api/v1/organizations/:id", async (req, reply) => {
    const [membership] = await db
      .select()
      .from(orgMemberships)
      .where(eq(orgMemberships.orgId, req.params.id))
      .limit(1);
    const [org] = await db.select().from(organizations).where(eq(organizations.id, req.params.id)).limit(1);
    if (!org || !membership) throw notFound("organization", req.params.id);
    reply.send(org);
  });
  });
}

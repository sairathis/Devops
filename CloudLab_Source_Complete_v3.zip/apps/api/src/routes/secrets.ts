import type { FastifyInstance } from "fastify";
import { encryptSecretValue, decryptSecretValue, secretsMasterKeyFromEnv, type EncryptedSecretPayload } from "@cloudlab/shared";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

// Real AES-256-GCM encryption (packages/shared's secretsMasterKeyFromEnv/
// encryptSecretValue), done synchronously right here rather than in the
// worker -- see processors/secret.ts for why. The plaintext `value` is
// accepted in the request body, encrypted immediately, and never written to
// `spec` or passed to the job queue; only the ciphertext payload is
// persisted. GET .../reveal is the only path that ever produces plaintext
// again, gated by its own `secrets.secrets.reveal` permission (denied by
// default for the developer role) so listing/viewing a secret resource never
// exposes its value by accident.
const masterKey = secretsMasterKeyFromEnv();

export function registerSecretRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; value: string } }>(
      "/api/v1/projects/:projectId/secrets",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "secrets.secrets.create");
        const { name, value } = req.body ?? {};
        if (!name) throw validationError("name is required");
        if (!value) throw validationError("value is required");

        const encrypted = encryptSecretValue(value, masterKey);

        const resource = await createResource({
          projectId,
          name,
          type: "secret",
          spec: { ...encrypted, valueLength: value.length },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "secret.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("secret.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "secret.create" });

        req.audit.action = "secrets.secrets.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "secret";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = { ...resource, spec: { redacted: true } };

        reply.status(202).send({ resource: { ...resource, spec: { redacted: true } }, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/secrets", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "secrets.secrets.list");
      const rows = await listResources(req.params.projectId, "secret");
      reply.send(rows.map((r) => ({ ...r, spec: { redacted: true, valueLength: (r.spec as { valueLength?: number })?.valueLength } })));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/secrets/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "secrets.secrets.get");
      const row = await getResource(req.params.projectId, req.params.id);
      reply.send({ ...row, spec: { redacted: true, valueLength: (row.spec as { valueLength?: number })?.valueLength } });
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/secrets/:id/reveal", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "secrets.secrets.reveal");
      const row = await getResource(projectId, id);
      if (row.status !== "READY") throw validationError("secret is not READY yet");
      const value = decryptSecretValue(row.spec as unknown as EncryptedSecretPayload, masterKey);

      req.audit.action = "secrets.secrets.reveal";
      req.audit.projectId = projectId;
      req.audit.resourceType = "secret";
      req.audit.resourceId = id;

      reply.send({ value });
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/secrets/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "secrets.secrets.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "secret.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("secret.delete", { operationId: operation.id, projectId, resourceId: id, type: "secret.delete" });

      req.audit.action = "secrets.secrets.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "secret";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerK8sClusterRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; nodeCount?: number } }>(
      "/api/v1/projects/:projectId/k8s-clusters",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "k8s.clusters.create");
        const { name, nodeCount } = req.body ?? {};
        if (!name) throw validationError("name is required");

        const resource = await createResource({
          projectId,
          name,
          type: "k8s_cluster",
          spec: { nodeCount: nodeCount ?? 2 },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "k8s_cluster.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("k8s_cluster.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "k8s_cluster.create" });

        req.audit.action = "k8s.clusters.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "k8s_cluster";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/k8s-clusters", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "k8s.clusters.list");
      reply.send(await listResources(req.params.projectId, "k8s_cluster"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/k8s-clusters/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "k8s.clusters.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/k8s-clusters/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "k8s.clusters.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "k8s_cluster.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("k8s_cluster.delete", { operationId: operation.id, projectId, resourceId: id, type: "k8s_cluster.delete" });

      req.audit.action = "k8s.clusters.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "k8s_cluster";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

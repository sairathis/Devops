import type { FastifyInstance } from "fastify";
import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "../db/client.js";
import { alerts, auditLogs, operations, resourceMetrics, resources } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { notFound } from "../errors.js";

/**
 * Milestone 9: Observability. Metrics are real container.stats() samples
 * persisted every 15s (apps/worker/src/observability/metricsCollector.ts);
 * alerts are derived from real resource status and real metric samples
 * (apps/worker/src/observability/*.ts, apps/worker/src/k8s/reconciler.ts);
 * a "trace" is a real correlation of the audit log entry and the async
 * operation (with its real step timeline) that a single HTTP request
 * produced, joined on the requestId both already carry -- not a synthetic
 * span tree.
 */
export function registerObservabilityRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.get<{ Params: { projectId: string; resourceId: string }; Querystring: { minutes?: string } }>(
      "/api/v1/projects/:projectId/metrics/:resourceId",
      async (req, reply) => {
        await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
        const minutes = Math.max(1, Math.min(1440, Number(req.query.minutes) || 60));
        const since = new Date(Date.now() - minutes * 60_000);
        const rows = await db
          .select()
          .from(resourceMetrics)
          .where(and(eq(resourceMetrics.resourceId, req.params.resourceId), gte(resourceMetrics.sampledAt, since)))
          .orderBy(resourceMetrics.sampledAt)
          .limit(2000);
        reply.send(rows);
      },
    );

    app.get<{ Params: { projectId: string }; Querystring: { status?: string } }>(
      "/api/v1/projects/:projectId/alerts",
      async (req, reply) => {
        await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
        const conditions = [eq(alerts.projectId, req.params.projectId)];
        if (req.query.status) conditions.push(eq(alerts.status, req.query.status));
        const rows = await db.select().from(alerts).where(and(...conditions)).orderBy(desc(alerts.firedAt)).limit(500);
        reply.send(rows);
      },
    );

    app.post<{ Params: { projectId: string; id: string } }>(
      "/api/v1/projects/:projectId/alerts/:id/resolve",
      async (req, reply) => {
        await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
        const [row] = await db
          .update(alerts)
          .set({ status: "RESOLVED", resolvedAt: new Date() })
          .where(and(eq(alerts.id, req.params.id), eq(alerts.projectId, req.params.projectId)))
          .returning();
        if (!row) throw notFound("alert", req.params.id);

        req.audit.action = "observability.alerts.resolve";
        req.audit.projectId = req.params.projectId;
        req.audit.resourceId = row.resourceId ?? undefined;

        reply.send(row);
      },
    );

    app.get<{ Params: { projectId: string; requestId: string } }>(
      "/api/v1/projects/:projectId/traces/:requestId",
      async (req, reply) => {
        await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
        const { projectId, requestId } = req.params;

        const [auditEntry] = await db
          .select()
          .from(auditLogs)
          .where(and(eq(auditLogs.requestId, requestId), eq(auditLogs.projectId, projectId)))
          .limit(1);
        if (!auditEntry) throw notFound("trace", requestId);

        const relatedOperations = await db.select().from(operations).where(eq(operations.requestId, requestId));
        const resourceRow = auditEntry.resourceId
          ? (await db.select().from(resources).where(eq(resources.id, auditEntry.resourceId)).limit(1))[0]
          : undefined;

        reply.send({
          requestId,
          request: {
            action: auditEntry.action,
            httpMethod: auditEntry.httpMethod,
            apiEndpoint: auditEntry.apiEndpoint,
            status: auditEntry.status,
            durationMs: auditEntry.durationMs,
            createdAt: auditEntry.createdAt,
            error: auditEntry.error,
          },
          resource: resourceRow ? { id: resourceRow.id, type: resourceRow.type, name: resourceRow.name, status: resourceRow.status } : null,
          operations: relatedOperations.map((op) => ({
            id: op.id,
            type: op.type,
            status: op.status,
            steps: op.steps,
            error: op.error,
            createdAt: op.createdAt,
            updatedAt: op.updatedAt,
          })),
        });
      },
    );
  });
}

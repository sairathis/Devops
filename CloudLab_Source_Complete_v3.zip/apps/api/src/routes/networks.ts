import type { FastifyInstance } from "fastify";
import { and, eq, ne, notInArray } from "drizzle-orm";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus } from "../resources/model.js";
import { createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";
import { db } from "../db/client.js";
import { resources } from "../db/schema.js";
import { cidrsOverlap } from "@cloudlab/shared";

// Milestone 13: real CIDR-collision prevention (ROADMAP.md limitation #1).
// Docker's IPAM pool is host-wide, not scoped per project, so two networks
// with overlapping CIDRs anywhere in this deployment will genuinely fail at
// the daemon with "Pool overlaps with other one on this address space" --
// previously that only surfaced asynchronously as a real but confusing
// FAILED network. This checks the same real constraint synchronously,
// before an operation is even created, against every other network
// resource's real spec.cidr that isn't already DELETED or FAILED.
async function findCidrCollision(cidr: string, excludeResourceId?: string) {
  const conditions = [eq(resources.type, "network"), notInArray(resources.status, ["DELETED", "FAILED"])];
  if (excludeResourceId) conditions.push(ne(resources.id, excludeResourceId));
  const existing = await db.select().from(resources).where(and(...conditions));
  for (const row of existing) {
    const existingCidr = (row.spec as { cidr?: string }).cidr;
    if (existingCidr && cidrsOverlap(cidr, existingCidr)) {
      return { id: row.id, name: row.name, cidr: existingCidr };
    }
  }
  return null;
}

export function registerNetworkRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.post<{ Params: { projectId: string }; Body: { name: string; cidr?: string } }>(
    "/api/v1/projects/:projectId/networks",
    async (req, reply) => {
      const { projectId } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.networks.create");
      const { name, cidr } = req.body ?? {};
      if (!name) throw validationError("name is required");
      const effectiveCidr = cidr ?? "172.30.0.0/24";
      let collision: Awaited<ReturnType<typeof findCidrCollision>>;
      try {
        // parseCidr (inside cidrsOverlap) throws on a malformed block --
        // surface that as a real 400 instead of a 500 from deep in the check.
        collision = await findCidrCollision(effectiveCidr);
      } catch (err) {
        throw validationError((err as Error).message);
      }
      if (collision) {
        throw validationError(
          `CIDR '${effectiveCidr}' overlaps with network '${collision.name}' (${collision.cidr}), which is not deleted.`,
          { collidesWith: collision },
        );
      }

      const resource = await createResource({
        projectId,
        name,
        type: "network",
        spec: { cidr: effectiveCidr },
        createdBy: req.userId!,
      });
      const operation = await createOperation({ projectId, resourceId: resource.id, type: "network.create", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("network.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "network.create" });

      req.audit.action = "network.networks.create";
      req.audit.projectId = projectId;
      req.audit.resourceType = "network";
      req.audit.resourceId = resource.id;
      req.audit.resourceName = resource.name;
      req.audit.newState = resource;

      reply.status(202).send({ resource, operationId: operation.id });
    },
  );

  app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/networks", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "network.networks.list");
    reply.send(await listResources(req.params.projectId, "network"));
  });

  app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/networks/:id", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "network.networks.get");
    reply.send(await getResource(req.params.projectId, req.params.id));
  });

  // Milestone 11: fault injection. A real total blackhole -- iptables DROP
  // on both directions of the network's actual bridge -- see
  // apps/worker/src/net/faults.ts for why this (and not netem-style partial
  // degradation, which this sandbox's kernel can't run) is the real fault
  // this build can deliver, and processors/networkFault.ts for the
  // self-scheduled, idempotent revert.
  app.post<{ Params: { projectId: string; id: string }; Body: { durationSeconds?: number } }>(
    "/api/v1/projects/:projectId/networks/:id/faults/blackhole",
    async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.networks.fault");
      const resource = await getResource(projectId, id);
      if (resource.status !== "READY") throw conflict(`network must be READY to blackhole it (currently ${resource.status})`);

      const durationSeconds = Math.max(5, Math.min(600, Number(req.body?.durationSeconds) || 30));
      const operation = await createOperation({ projectId, resourceId: id, type: "network.fault_blackhole", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("network.fault_blackhole", { operationId: operation.id, projectId, resourceId: id, type: "network.fault_blackhole", params: { durationSeconds } });

      req.audit.action = "network.networks.fault";
      req.audit.projectId = projectId;
      req.audit.resourceType = "network";
      req.audit.resourceId = id;
      req.audit.previousState = { status: resource.status };

      reply.status(202).send({ operationId: operation.id, durationSeconds });
    },
  );

  app.post<{ Params: { projectId: string; id: string } }>(
    "/api/v1/projects/:projectId/networks/:id/faults/blackhole/cancel",
    async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.networks.fault");
      const resource = await getResource(projectId, id);
      const activeFault = (resource.metadata as { activeFault?: { type: string } }).activeFault;
      if (activeFault?.type !== "blackhole") throw conflict("no active blackhole fault on this network");

      // Enqueues the exact same revert job type the scheduled auto-revert
      // uses; that delayed job still fires later too but is a guarded no-op
      // by then (see processNetworkFaultRevert).
      const operation = await createOperation({ projectId, resourceId: id, type: "network.fault_revert", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("network.fault_revert", { operationId: operation.id, projectId, resourceId: id, type: "network.fault_revert" });

      req.audit.action = "network.networks.fault";
      req.audit.projectId = projectId;
      req.audit.resourceType = "network";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    },
  );

  app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/networks/:id", async (req, reply) => {
    const { projectId, id } = req.params;
    await requireProjectPermission(req.userId!, projectId, "network.networks.delete");
    await getResource(projectId, id);
    await assertDeletable(id);

    await setResourceStatus(id, "DELETING");
    const operation = await createOperation({ projectId, resourceId: id, type: "network.delete", createdBy: req.userId!, requestId: req.requestId });
    await operationsQueue.add("network.delete", { operationId: operation.id, projectId, resourceId: id, type: "network.delete" });

    req.audit.action = "network.networks.delete";
    req.audit.projectId = projectId;
    req.audit.resourceType = "network";
    req.audit.resourceId = id;

    reply.status(202).send({ operationId: operation.id });
  });
  });
}

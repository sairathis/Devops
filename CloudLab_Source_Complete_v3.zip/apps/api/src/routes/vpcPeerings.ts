import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

// GCP VPC Network Peering equivalent -- see
// apps/worker/src/net/iptables.ts applyVpcPeering for the real bidirectional
// iptables FORWARD rules this creates between the two networks' bridges.
export function registerVpcPeeringRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkAId: string; networkBId: string } }>(
      "/api/v1/projects/:projectId/vpc-peerings",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.peerings.create");
        const { name, networkAId, networkBId } = req.body ?? {};
        if (!name || !networkAId || !networkBId) throw validationError("name, networkAId and networkBId are required");
        if (networkAId === networkBId) throw validationError("networkAId and networkBId must be different networks");
        const networkA = await getResource(projectId, networkAId);
        const networkB = await getResource(projectId, networkBId);
        if (networkA.type !== "network" || networkB.type !== "network") throw validationError("both networkAId and networkBId must be network resources");
        if (networkA.status !== "READY") throw conflict(`Network '${networkA.name}' is not READY`);
        if (networkB.status !== "READY") throw conflict(`Network '${networkB.name}' is not READY`);

        const resource = await createResource({ projectId, name, type: "vpc_peering", spec: { networkAId, networkBId }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "vpc_peering.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("vpc_peering.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "vpc_peering.create" });

        req.audit.action = "network.peerings.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "vpc_peering";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/vpc-peerings", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.peerings.list");
      reply.send(await listResources(req.params.projectId, "vpc_peering"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/vpc-peerings/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.peerings.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/vpc-peerings/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.peerings.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "vpc_peering.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("vpc_peering.delete", { operationId: operation.id, projectId, resourceId: id, type: "vpc_peering.delete" });

      req.audit.action = "network.peerings.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "vpc_peering";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

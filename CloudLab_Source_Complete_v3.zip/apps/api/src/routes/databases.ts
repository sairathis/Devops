import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

const IDENTIFIER_RE = /^[a-zA-Z][a-zA-Z0-9_]{0,62}$/;

export function registerDatabaseRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; databaseName?: string } }>(
      "/api/v1/projects/:projectId/databases",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "database.databases.create");
        const { name, databaseName } = req.body ?? {};
        if (!name) throw validationError("name is required");
        if (databaseName && !IDENTIFIER_RE.test(databaseName)) {
          throw validationError("databaseName must be a plain SQL identifier (letters, digits, underscore)");
        }

        const resource = await createResource({
          projectId,
          name,
          type: "database",
          spec: { engine: "postgres", databaseName: databaseName || "appdb" },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "database.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("database.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "database.create" });

        req.audit.action = "database.databases.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "database";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/databases", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "database.databases.list");
      reply.send(await listResources(req.params.projectId, "database"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/databases/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "database.databases.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/databases/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "database.databases.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "database.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("database.delete", { operationId: operation.id, projectId, resourceId: id, type: "database.delete" });

      req.audit.action = "database.databases.delete";
      req.audit.projectId = projectId;
      req.audit.resourceId = id;
      req.audit.resourceType = "database";

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { desc, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { alerts, operations, resourceEvents } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { getResource } from "../resources/model.js";
import { docker, containerNameFor } from "../adapters/docker/client.js";

/**
 * Milestone 11: troubleshooting. This is a generic, resource-type-agnostic
 * diagnostic view -- everything in it is either already-recorded history
 * (resource_events, alerts, operations, all real rows this app already
 * writes for every resource) or, for instances, a live read straight from
 * the Docker Engine at request time. The API is allowed to read Docker
 * directly (see adapters/docker/client.ts) -- only *mutating* infrastructure
 * has to go through the worker's queue. Nothing here is a canned
 * "recommendation"; the one piece of synthesis is a single honest sentence
 * comparing what the database currently believes against what Docker just
 * reported, when the two actually disagree.
 */
export function registerTroubleshootRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.get<{ Params: { projectId: string; id: string } }>(
      "/api/v1/projects/:projectId/resources/:id/troubleshoot",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "projects.get");
        const resource = await getResource(projectId, id);

        const [events, resourceAlerts, ops] = await Promise.all([
          db.select().from(resourceEvents).where(eq(resourceEvents.resourceId, id)).orderBy(desc(resourceEvents.createdAt)).limit(20),
          db.select().from(alerts).where(eq(alerts.resourceId, id)).orderBy(desc(alerts.firedAt)).limit(20),
          db.select().from(operations).where(eq(operations.resourceId, id)).orderBy(desc(operations.createdAt)).limit(10),
        ]);

        let live: Record<string, unknown> | null = null;
        let drift: string | null = null;

        if (resource.type === "instance" && resource.status !== "DELETED") {
          const containerId = (resource.metadata as { containerId?: string }).containerId;
          if (containerId) {
            try {
              const info = await docker.getContainer(containerNameFor(id)).inspect();
              // Docker reports Go's zero-value timestamp ("0001-01-01T00:00:00Z")
              // for StartedAt/FinishedAt when that event hasn't happened yet --
              // real data, but not worth showing a user as if it were a date.
              const isZeroTime = (t: string) => t.startsWith("0001-01-01");
              live = {
                running: info.State.Running,
                status: info.State.Status,
                exitCode: info.State.ExitCode,
                oomKilled: info.State.OOMKilled,
                startedAt: isZeroTime(info.State.StartedAt) ? null : info.State.StartedAt,
                finishedAt: isZeroTime(info.State.FinishedAt) ? null : info.State.FinishedAt,
              };
              const dbSaysUp = resource.status === "READY";
              if (dbSaysUp && !info.State.Running) {
                drift = `The database says READY, but the container is actually ${info.State.Status} (exit code ${info.State.ExitCode}) right now -- the health monitor should catch this within 10s if it hasn't already.`;
              } else if (!dbSaysUp && info.State.Running) {
                drift = `The database says ${resource.status}, but the container is actually running right now -- this usually means it was started outside the app, or a recovery just hasn't been reflected yet.`;
              }
            } catch (err) {
              const statusCode = (err as { statusCode?: number }).statusCode;
              live = statusCode === 404 ? { running: false, status: "missing" } : { error: (err as Error).message };
              if (statusCode === 404 && resource.status !== "FAILED") {
                drift = `The database says ${resource.status}, but no such container exists on the Docker daemon at all.`;
              }
            }
          }
        }

        if (resource.type === "network" && resource.status !== "DELETED") {
          const dockerNetworkId = (resource.metadata as { dockerNetworkId?: string }).dockerNetworkId;
          if (dockerNetworkId) {
            try {
              const info = await docker.getNetwork(dockerNetworkId).inspect();
              live = { exists: true, containersAttached: Object.keys(info.Containers ?? {}).length };
            } catch (err) {
              const statusCode = (err as { statusCode?: number }).statusCode;
              live = statusCode === 404 ? { exists: false } : { error: (err as Error).message };
              if (statusCode === 404 && resource.status !== "DELETED") {
                drift = `The database says ${resource.status}, but no such Docker network exists at all.`;
              }
            }
          }
        }

        reply.send({
          resource: { id: resource.id, type: resource.type, name: resource.name, status: resource.status, spec: resource.spec, metadata: resource.metadata, updatedAt: resource.updatedAt },
          live,
          drift,
          recentEvents: events.map((e) => ({ fromStatus: e.fromStatus, toStatus: e.toStatus, message: e.message, createdAt: e.createdAt })),
          alerts: resourceAlerts.map((a) => ({ id: a.id, ruleKey: a.ruleKey, severity: a.severity, status: a.status, message: a.message, firedAt: a.firedAt, resolvedAt: a.resolvedAt })),
          recentOperations: ops.map((o) => ({ id: o.id, type: o.type, status: o.status, error: o.error, createdAt: o.createdAt, updatedAt: o.updatedAt })),
        });
      },
    );
  });
}

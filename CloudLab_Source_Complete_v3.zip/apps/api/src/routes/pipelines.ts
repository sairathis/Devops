import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

interface Stage {
  name: string;
  command: string;
}

export function registerPipelineRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; stages: Stage[]; image?: string } }>(
      "/api/v1/projects/:projectId/pipelines",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "cicd.pipelines.create");
        const { name, stages, image } = req.body ?? {};
        if (!name) throw validationError("name is required");
        if (!Array.isArray(stages) || stages.length === 0) throw validationError("stages must be a non-empty array of {name, command}");
        for (const s of stages) {
          if (!s.name || !s.command) throw validationError("every stage needs a name and a command");
        }

        const resource = await createResource({ projectId, name, type: "pipeline", spec: { stages, image }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "pipeline.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("pipeline.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "pipeline.create" });

        req.audit.action = "cicd.pipelines.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "pipeline";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/pipelines", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "cicd.pipelines.list");
      reply.send(await listResources(req.params.projectId, "pipeline"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/pipelines/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "cicd.pipelines.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/pipelines/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "cicd.pipelines.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "pipeline.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("pipeline.delete", { operationId: operation.id, projectId, resourceId: id, type: "pipeline.delete" });

      req.audit.action = "cicd.pipelines.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "pipeline";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

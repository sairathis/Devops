import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

interface FirewallBody {
  name: string;
  networkResourceId: string;
  direction: "ingress" | "egress";
  action: "ALLOW" | "DENY";
  protocol: "tcp" | "udp" | "all";
  portRange?: string;
  cidr: string;
}

export function registerFirewallRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: FirewallBody }>(
      "/api/v1/projects/:projectId/firewall-rules",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.firewall.create");
        const { name, networkResourceId, direction, action, protocol, portRange, cidr } = req.body ?? {};
        if (!name || !networkResourceId || !direction || !action || !protocol || !cidr) {
          throw validationError("name, networkResourceId, direction, action, protocol and cidr are required");
        }
        if (!["ingress", "egress"].includes(direction)) throw validationError("direction must be 'ingress' or 'egress'");
        if (!["ALLOW", "DENY"].includes(action)) throw validationError("action must be 'ALLOW' or 'DENY'");
        if (!["tcp", "udp", "all"].includes(protocol)) throw validationError("protocol must be 'tcp', 'udp' or 'all'");

        const resource = await createResource({
          projectId,
          name,
          type: "firewall_rule",
          spec: { networkResourceId, direction, action, protocol, portRange, cidr },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "firewall_rule.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("firewall_rule.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "firewall_rule.create" });

        req.audit.action = "network.firewall.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "firewall_rule";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/firewall-rules", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.firewall.list");
      reply.send(await listResources(req.params.projectId, "firewall_rule"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/firewall-rules/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.firewall.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/firewall-rules/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.firewall.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "firewall_rule.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("firewall_rule.delete", { operationId: operation.id, projectId, resourceId: id, type: "firewall_rule.delete" });

      req.audit.action = "network.firewall.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "firewall_rule";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

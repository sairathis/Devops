import type { FastifyInstance } from "fastify";
import { and, eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { scenarioProgress } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { evaluateAllScenarios, evaluateScenario } from "../scenarios/checks.js";
import { conflict, notFound } from "../errors.js";
import { SCENARIOS } from "@cloudlab/shared";

/**
 * Milestone 12: learning system. Every scenario's pass/fail is computed
 * fresh, server-side, from real database state every time this is called
 * (see scenarios/checks.ts) -- there is no client-settable "mark done"
 * anywhere. scenario_progress exists only to remember the first moment a
 * scenario was genuinely observed complete and who observed it; claiming
 * it re-runs the same real checks and refuses (409) if they don't all
 * actually pass right now, so the row can never drift ahead of reality.
 */
export function registerScenarioRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.get<{ Params: { projectId: string } }>(
      "/api/v1/projects/:projectId/scenarios",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "projects.get");

        const [results, progressRows] = await Promise.all([
          evaluateAllScenarios(projectId),
          db.select().from(scenarioProgress).where(and(eq(scenarioProgress.projectId, projectId), eq(scenarioProgress.userId, req.userId!))),
        ]);

        const progressByKey = new Map(progressRows.map((p) => [p.scenarioKey, p]));
        reply.send({
          scenarios: results.map((r) => ({ ...r, claimedAt: progressByKey.get(r.key)?.completedAt ?? null })),
        });
      },
    );

    app.post<{ Params: { projectId: string; key: string } }>(
      "/api/v1/projects/:projectId/scenarios/:key/claim",
      async (req, reply) => {
        const { projectId, key } = req.params;
        await requireProjectPermission(req.userId!, projectId, "projects.get");

        const def = SCENARIOS.find((s) => s.key === key);
        if (!def) throw notFound("scenario", key);

        const result = await evaluateScenario(key, projectId);
        if (!result) throw notFound("scenario", key);

        if (!result.completed) {
          const incomplete = result.steps.filter((s) => !s.passed).map((s) => s.title);
          throw conflict(`Scenario '${result.title}' is not complete yet -- ${incomplete.length} step(s) still unmet.`, {
            what: `Steps not yet verified: ${incomplete.join(", ")}.`,
            why: "Claiming a scenario re-runs the same real database checks shown in the scenario view -- it does not trust client-reported progress.",
            diagnose: "Reopen the Learning tab for this scenario and check which steps are missing real evidence.",
            fix: "Complete the missing steps for real (create the resources / run the operations described), then claim again.",
            details: { incompleteSteps: incomplete },
          });
        }

        // Insert-if-not-exists on the (projectId, userId, scenarioKey) unique
        // index -- a re-claim of an already-completed scenario is a harmless
        // no-op that keeps the original completedAt rather than bumping it.
        await db.insert(scenarioProgress).values({ projectId, userId: req.userId!, scenarioKey: key }).onConflictDoNothing();

        const [row] = await db
          .select()
          .from(scenarioProgress)
          .where(and(eq(scenarioProgress.projectId, projectId), eq(scenarioProgress.userId, req.userId!), eq(scenarioProgress.scenarioKey, key)));

        reply.send({ scenario: result, claimedAt: row?.completedAt ?? new Date().toISOString() });
      },
    );
  });
}

import type { FastifyInstance } from "fastify";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "../db/client.js";
import { auditLogs } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";

const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 200;

/**
 * Spec section 49: a human-readable feed of the same audit facts.
 *
 * Milestone 13: real offset pagination (ROADMAP.md limitation #7) --
 * previously this always returned a fixed top-200 slice with no way to see
 * anything older. `page`/`pageSize` do a genuine `LIMIT`/`OFFSET` against
 * Postgres and `total` is a real `count(*)` of the same filtered set, so
 * `hasMore` reflects the actual remaining rows rather than a guess.
 */
export function registerActivityRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.get<{ Params: { projectId: string }; Querystring: { page?: string; pageSize?: string } }>(
    "/api/v1/projects/:projectId/activity",
    async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
      const page = Math.max(1, Number(req.query.page) || 1);
      const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, Number(req.query.pageSize) || DEFAULT_PAGE_SIZE));
      const where = eq(auditLogs.projectId, req.params.projectId);

      const [rows, [{ count }]] = await Promise.all([
        db.select().from(auditLogs).where(where).orderBy(desc(auditLogs.createdAt)).limit(pageSize).offset((page - 1) * pageSize),
        db.select({ count: sql<number>`count(*)` }).from(auditLogs).where(where),
      ]);

      const total = Number(count);
      reply.send({ items: rows, page, pageSize, total, hasMore: page * pageSize < total });
    },
  );
  });
}

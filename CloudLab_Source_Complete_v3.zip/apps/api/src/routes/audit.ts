import type { FastifyInstance } from "fastify";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "../db/client.js";
import { auditLogs } from "../db/schema.js";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";

const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 200;

/**
 * Spec section 16: filterable, and never editable from this API (no
 * PATCH/DELETE routes exist for it).
 *
 * Milestone 13: real offset pagination (ROADMAP.md limitation #7) --
 * `page`/`pageSize` are a genuine `LIMIT`/`OFFSET` against Postgres and
 * `total` a real `count(*)` of the same filtered set (same action/status/
 * userId filters apply to both), replacing the old fixed top-500 slice.
 */
export function registerAuditRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.get<{ Params: { projectId: string }; Querystring: { action?: string; status?: string; userId?: string; page?: string; pageSize?: string } }>(
    "/api/v1/projects/:projectId/audit",
    async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
      const { action, status, userId } = req.query;
      const page = Math.max(1, Number(req.query.page) || 1);
      const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, Number(req.query.pageSize) || DEFAULT_PAGE_SIZE));

      const conditions = [eq(auditLogs.projectId, req.params.projectId)];
      if (action) conditions.push(eq(auditLogs.action, action));
      if (status) conditions.push(eq(auditLogs.status, status));
      if (userId) conditions.push(eq(auditLogs.userId, userId));
      const where = and(...conditions);

      const [rows, [{ count }]] = await Promise.all([
        db.select().from(auditLogs).where(where).orderBy(desc(auditLogs.createdAt)).limit(pageSize).offset((page - 1) * pageSize),
        db.select({ count: sql<number>`count(*)` }).from(auditLogs).where(where),
      ]);

      const total = Number(count);
      reply.send({ items: rows, page, pageSize, total, hasMore: page * pageSize < total });
    },
  );
  });
}

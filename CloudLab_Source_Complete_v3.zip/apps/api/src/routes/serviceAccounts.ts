import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";
import { decryptSecretValue, secretsMasterKeyFromEnv } from "@cloudlab/shared";

const ID_RE = /^[a-z][a-z0-9-]{2,28}[a-z0-9]$/;
const masterKey = secretsMasterKeyFromEnv();

// GCP IAM Service Account equivalent: a real machine identity with a real
// RSA-2048 keypair (see apps/worker/src/processors/serviceAccount.ts).
export function registerServiceAccountRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; accountId: string } }>(
      "/api/v1/projects/:projectId/service-accounts",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "iam.serviceAccounts.create");
        const { name, accountId } = req.body ?? {};
        if (!name || !accountId) throw validationError("name and accountId are required");
        if (!ID_RE.test(accountId)) throw validationError("accountId must be 4-30 lowercase letters/digits/hyphens, matching GCP's own service-account id rules");

        const resource = await createResource({ projectId, name, type: "service_account", spec: { accountId }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "service_account.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("service_account.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "service_account.create" });

        req.audit.action = "iam.serviceAccounts.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "service_account";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/service-accounts", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "iam.serviceAccounts.list");
      reply.send(await listResources(req.params.projectId, "service_account"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/service-accounts/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "iam.serviceAccounts.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    // Real decrypt-on-demand, gated by its own permission and audited --
    // mirrors secrets.ts's /reveal endpoint exactly.
    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/service-accounts/:id/key", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "iam.serviceAccounts.get");
      const resource = await getResource(req.params.projectId, req.params.id);
      const meta = resource.metadata as { email?: string; keyId?: string; encryptedPrivateKey?: Parameters<typeof decryptSecretValue>[0] };
      if (!meta.encryptedPrivateKey) throw validationError("key is not ready yet");
      const privateKey = decryptSecretValue(meta.encryptedPrivateKey, masterKey);

      req.audit.action = "iam.serviceAccounts.get";
      req.audit.projectId = req.params.projectId;
      req.audit.resourceType = "service_account";
      req.audit.resourceId = req.params.id;

      reply.send({ type: "service_account", project_id: req.params.projectId, private_key_id: meta.keyId, private_key: privateKey, client_email: meta.email });
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/service-accounts/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "iam.serviceAccounts.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "service_account.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("service_account.delete", { operationId: operation.id, projectId, resourceId: id, type: "service_account.delete" });

      req.audit.action = "iam.serviceAccounts.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "service_account";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

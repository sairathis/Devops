import type { FastifyInstance } from "fastify";
import { Client } from "pg";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

const IDENTIFIER_RE = /^[a-zA-Z][a-zA-Z0-9_]{0,62}$/;

// BigQuery equivalent. See apps/worker/src/processors/bigqueryDataset.ts for
// what's real (a genuinely dedicated Postgres 16 server per dataset) vs.
// simplified (not BigQuery's real distributed columnar engine) here. The
// /query endpoint below runs REAL, arbitrary SQL against that real server --
// not a canned/fake result set -- which is the whole point of an "honest
// substitute": every query genuinely executes.
export function registerBigqueryRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; datasetId?: string } }>(
      "/api/v1/projects/:projectId/bigquery-datasets",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "bigquery.datasets.create");
        const { name, datasetId } = req.body ?? {};
        if (!name) throw validationError("name is required");
        if (datasetId && !IDENTIFIER_RE.test(datasetId)) throw validationError("datasetId must be a plain SQL identifier (letters, digits, underscore)");

        const resource = await createResource({ projectId, name, type: "bigquery_dataset", spec: { datasetId: datasetId || "dataset" }, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "bigquery_dataset.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("bigquery_dataset.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "bigquery_dataset.create" });

        req.audit.action = "bigquery.datasets.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "bigquery_dataset";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/bigquery-datasets", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "bigquery.datasets.list");
      reply.send(await listResources(req.params.projectId, "bigquery_dataset"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/bigquery-datasets/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "bigquery.datasets.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    // Genuine ad-hoc SQL execution against the dataset's own dedicated
    // Postgres server -- a real ResultSet comes back, including real
    // errors for bad SQL (not swallowed into a fake success).
    app.post<{ Params: { projectId: string; id: string }; Body: { sql: string } }>(
      "/api/v1/projects/:projectId/bigquery-datasets/:id/query",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "bigquery.datasets.query");
        const { sql } = req.body ?? {};
        if (!sql?.trim()) throw validationError("sql is required");
        const resource = await getResource(projectId, id);
        if (resource.status !== "READY") throw conflict(`Dataset '${resource.name}' is not READY (status: ${resource.status})`);
        const meta = resource.metadata as { host: string; port: number; username: string; password: string; datasetId: string };

        const client = new Client({ host: meta.host, port: meta.port, user: meta.username, password: meta.password, database: meta.datasetId, connectionTimeoutMillis: 5000 });
        const startedAt = Date.now();
        try {
          await client.connect();
          const result = await client.query(sql);
          req.audit.action = "bigquery.datasets.query";
          req.audit.projectId = projectId;
          req.audit.resourceType = "bigquery_dataset";
          req.audit.resourceId = id;
          req.audit.newState = { sql, rowCount: result.rowCount };
          reply.send({ rows: result.rows ?? [], rowCount: result.rowCount ?? 0, fields: (result.fields ?? []).map((f) => f.name), tookMs: Date.now() - startedAt });
        } catch (err) {
          throw validationError(`Query failed: ${(err as Error).message}`);
        } finally {
          await client.end().catch(() => {});
        }
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/bigquery-datasets/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "bigquery.datasets.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "bigquery_dataset.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("bigquery_dataset.delete", { operationId: operation.id, projectId, resourceId: id, type: "bigquery_dataset.delete" });

      req.audit.action = "bigquery.datasets.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "bigquery_dataset";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

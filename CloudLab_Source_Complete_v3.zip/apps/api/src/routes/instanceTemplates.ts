import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";
import { config } from "../config.js";

// GCP Instance Template equivalent: an immutable, reusable blueprint that
// Managed Instance Groups stamp real instances out of.
export function registerInstanceTemplateRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; image?: string; command?: string[]; publish?: boolean } }>(
      "/api/v1/projects/:projectId/instance-templates",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "compute.instanceTemplates.create");
        const { name, image, command, publish } = req.body ?? {};
        if (!name) throw validationError("name is required");

        const resource = await createResource({
          projectId,
          name,
          type: "instance_template",
          spec: { image: image || config.guestImage, command, publish: publish === true },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "instance_template.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("instance_template.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "instance_template.create" });

        req.audit.action = "compute.instanceTemplates.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "instance_template";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/instance-templates", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.instanceTemplates.list");
      reply.send(await listResources(req.params.projectId, "instance_template"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instance-templates/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "compute.instanceTemplates.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/instance-templates/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "compute.instanceTemplates.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "instance_template.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("instance_template.delete", { operationId: operation.id, projectId, resourceId: id, type: "instance_template.delete" });

      req.audit.action = "compute.instanceTemplates.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "instance_template";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

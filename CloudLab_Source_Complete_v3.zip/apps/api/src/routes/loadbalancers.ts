import type { FastifyInstance } from "fastify";
import { eq } from "drizzle-orm";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";
import { db } from "../db/client.js";
import { resources } from "../db/schema.js";

export function registerLoadBalancerRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkId: string; backendInstanceIds?: string[]; managedInstanceGroupId?: string; publish?: boolean } }>(
      "/api/v1/projects/:projectId/load-balancers",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.loadbalancers.create");
        const { name, networkId, backendInstanceIds, managedInstanceGroupId, publish } = req.body ?? {};
        if (!name || !networkId) throw validationError("name and networkId are required");
        // Milestone 15: a load balancer can target a Managed Instance Group's
        // live member set instead of (or as well as recording alongside) a
        // fixed instance list -- see mig/backends.ts for how the backend pool
        // is computed fresh from real container state whenever this is set.
        if (managedInstanceGroupId) {
          const mig = await getResource(projectId, managedInstanceGroupId);
          if (mig.type !== "managed_instance_group") throw validationError(`'${managedInstanceGroupId}' is not a managed_instance_group resource`);
        }

        const resource = await createResource({
          projectId,
          name,
          type: "load_balancer",
          spec: { networkId, backendInstanceIds: backendInstanceIds ?? [], managedInstanceGroupId, publish: publish !== false },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "load_balancer.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("load_balancer.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "load_balancer.create" });

        req.audit.action = "network.loadbalancers.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "load_balancer";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/load-balancers", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.loadbalancers.list");
      reply.send(await listResources(req.params.projectId, "load_balancer"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/load-balancers/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "network.loadbalancers.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.patch<{ Params: { projectId: string; id: string }; Body: { backendInstanceIds: string[] } }>(
      "/api/v1/projects/:projectId/load-balancers/:id/backends",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "network.loadbalancers.update");
        const { backendInstanceIds } = req.body ?? {};
        if (!Array.isArray(backendInstanceIds)) throw validationError("backendInstanceIds must be an array");
        const resource = await getResource(projectId, id);
        const spec = { ...(resource.spec as Record<string, unknown>), backendInstanceIds };
        await db.update(resources).set({ spec, updatedAt: new Date() }).where(eq(resources.id, id));

        const operation = await createOperation({ projectId, resourceId: id, type: "load_balancer.update", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("load_balancer.update", { operationId: operation.id, projectId, resourceId: id, type: "load_balancer.update" });

        req.audit.action = "network.loadbalancers.update";
        req.audit.projectId = projectId;
        req.audit.resourceType = "load_balancer";
        req.audit.resourceId = id;
        req.audit.newState = { backendInstanceIds };

        reply.status(202).send({ operationId: operation.id });
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/load-balancers/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "network.loadbalancers.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "load_balancer.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("load_balancer.delete", { operationId: operation.id, projectId, resourceId: id, type: "load_balancer.delete" });

      req.audit.action = "network.loadbalancers.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "load_balancer";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";

export function registerImageRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; registryId: string; tag?: string; dockerfile: string } }>(
      "/api/v1/projects/:projectId/images",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "registry.images.create");
        const { name, registryId, tag, dockerfile } = req.body ?? {};
        if (!name || !registryId || !dockerfile) throw validationError("name, registryId and dockerfile are required");
        const registry = await getResource(projectId, registryId);
        if (registry.type !== "registry") throw validationError(`'${registryId}' is not a registry resource`);
        if (registry.status !== "READY") throw conflict(`Registry '${registry.name}' is not READY yet (status: ${registry.status}).`);

        const resource = await createResource({
          projectId,
          name,
          type: "container_image",
          spec: { registryId, name, tag: tag || "latest", dockerfile },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "container_image.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("container_image.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "container_image.create" });

        req.audit.action = "registry.images.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "container_image";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/images", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.images.list");
      reply.send(await listResources(req.params.projectId, "container_image"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/images/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "registry.images.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/images/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "registry.images.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "container_image.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("container_image.delete", { operationId: operation.id, projectId, resourceId: id, type: "container_image.delete" });

      req.audit.action = "registry.images.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "container_image";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError, conflict } from "../errors.js";
import { config } from "../config.js";

// Cloud Run equivalent -- see apps/worker/src/cloudrun/lifecycle.ts for the
// real cold-start-on-invoke / scale-to-zero-on-idle Docker lifecycle this
// wraps. The API process itself does the cold start synchronously inside
// the invoke request (calling straight into worker code, same process
// family, same host) rather than round-tripping through the BullMQ queue --
// an invoke is a synchronous request/response by nature, unlike every other
// resource's async create/delete.
export function registerCloudRunRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; networkId: string; image?: string; idleTimeoutSeconds?: number } }>(
      "/api/v1/projects/:projectId/cloud-run-services",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "run.services.create");
        const { name, networkId, image, idleTimeoutSeconds } = req.body ?? {};
        if (!name || !networkId) throw validationError("name and networkId are required");
        const network = await getResource(projectId, networkId);
        if (network.type !== "network") throw validationError(`'${networkId}' is not a network resource`);
        if (network.status !== "READY") throw conflict(`Network '${network.name}' is not READY`);

        const resource = await createResource({
          projectId,
          name,
          type: "cloud_run_service",
          spec: { networkId, image: image || config.guestImage, idleTimeoutSeconds: Math.max(10, Math.min(3600, Number(idleTimeoutSeconds) || 60)) },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "cloud_run_service.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("cloud_run_service.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "cloud_run_service.create" });

        req.audit.action = "run.services.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "cloud_run_service";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/cloud-run-services", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "run.services.list");
      reply.send(await listResources(req.params.projectId, "cloud_run_service"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/cloud-run-services/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "run.services.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    // A real invoke: cold-starts the container if it isn't running (genuine
    // `docker run`, see lifecycle.ts), then makes a real HTTP request to the
    // guest agent's /healthz over the real Docker bridge IP -- not a
    // simulated 200.
    app.post<{ Params: { projectId: string; id: string } }>(
      "/api/v1/projects/:projectId/cloud-run-services/:id/invoke",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "run.services.invoke");
        const resource = await getResource(projectId, id);
        if (resource.type !== "cloud_run_service") throw validationError(`'${id}' is not a cloud_run_service resource`);
        if (resource.status !== "READY") throw conflict(`Service '${resource.name}' is not READY (status: ${resource.status})`);

        const { ensureRunning } = await import("../../../worker/src/cloudrun/lifecycle.js");
        const { ip, hostPort, coldStart } = await ensureRunning(id);
        let invokeStatus = "unreachable";
        if (ip) {
          try {
            const res = await fetch(`http://${ip}:8080/healthz`, { signal: AbortSignal.timeout(5000) });
            invokeStatus = res.ok ? "ok" : `http_${res.status}`;
          } catch (err) {
            invokeStatus = `error: ${(err as Error).message}`;
          }
        }
        await setResourceStatus(id, "READY", coldStart ? "Cold-started for this invoke" : "Warm invoke", { state: "RUNNING", ip, hostPort, lastInvokedAt: new Date().toISOString() });

        req.audit.action = "run.services.invoke";
        req.audit.projectId = projectId;
        req.audit.resourceType = "cloud_run_service";
        req.audit.resourceId = id;
        req.audit.newState = { coldStart, invokeStatus };

        reply.send({ coldStart, invokeStatus, ip, hostPort, publicUrl: hostPort ? `http://${config.publicHost}:${hostPort}` : null });
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/cloud-run-services/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "run.services.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "cloud_run_service.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("cloud_run_service.delete", { operationId: operation.id, projectId, resourceId: id, type: "cloud_run_service.delete" });

      req.audit.action = "run.services.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "cloud_run_service";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

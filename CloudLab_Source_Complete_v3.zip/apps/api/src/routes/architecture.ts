import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { buildProjectGraph } from "../resources/graph.js";

export function registerArchitectureRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

  app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/architecture", async (req, reply) => {
    await requireProjectPermission(req.userId!, req.params.projectId, "projects.get");
    reply.send(await buildProjectGraph(req.params.projectId));
  });
  });
}

import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation, updateResourceSpec } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerK8sDeploymentRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string; clusterId: string; image?: string; replicas?: number; command?: string[] } }>(
      "/api/v1/projects/:projectId/k8s-deployments",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "k8s.deployments.create");
        const { name, clusterId, image, replicas, command } = req.body ?? {};
        if (!name) throw validationError("name is required");
        if (!clusterId) throw validationError("clusterId is required");

        const resource = await createResource({
          projectId,
          name,
          type: "k8s_deployment",
          spec: { clusterId, image, replicas: replicas ?? 1, command },
          createdBy: req.userId!,
        });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "k8s_deployment.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("k8s_deployment.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "k8s_deployment.create" });

        req.audit.action = "k8s.deployments.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "k8s_deployment";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/k8s-deployments", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "k8s.deployments.list");
      reply.send(await listResources(req.params.projectId, "k8s_deployment"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/k8s-deployments/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "k8s.deployments.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.post<{ Params: { projectId: string; id: string }; Body: { replicas: number } }>(
      "/api/v1/projects/:projectId/k8s-deployments/:id/scale",
      async (req, reply) => {
        const { projectId, id } = req.params;
        await requireProjectPermission(req.userId!, projectId, "k8s.deployments.scale");
        const { replicas } = req.body ?? {};
        if (!Number.isInteger(replicas) || replicas < 1 || replicas > 20) throw validationError("replicas must be an integer between 1 and 20");

        const existing = await getResource(projectId, id);
        if (existing.status !== "READY") throw validationError("deployment must be READY to scale");
        await updateResourceSpec(id, { replicas });
        await setResourceStatus(id, "UPDATING");

        const operation = await createOperation({ projectId, resourceId: id, type: "k8s_deployment.scale", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("k8s_deployment.scale", { operationId: operation.id, projectId, resourceId: id, type: "k8s_deployment.scale" });

        req.audit.action = "k8s.deployments.scale";
        req.audit.projectId = projectId;
        req.audit.resourceType = "k8s_deployment";
        req.audit.resourceId = id;

        reply.status(202).send({ operationId: operation.id });
      },
    );

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/k8s-deployments/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "k8s.deployments.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "k8s_deployment.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("k8s_deployment.delete", { operationId: operation.id, projectId, resourceId: id, type: "k8s_deployment.delete" });

      req.audit.action = "k8s.deployments.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "k8s_deployment";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

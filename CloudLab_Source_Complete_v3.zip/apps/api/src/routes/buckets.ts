import type { FastifyInstance } from "fastify";
import { authenticate } from "../middleware/authenticate.js";
import { requireProjectPermission } from "../iam/policy.js";
import { createResource, listResources, getResource, assertDeletable, setResourceStatus, createOperation } from "../resources/model.js";
import { operationsQueue } from "../queue/queue.js";
import { validationError } from "../errors.js";

export function registerBucketRoutes(app: FastifyInstance) {
  app.register(async (app) => {
    app.addHook("preHandler", authenticate);

    app.post<{ Params: { projectId: string }; Body: { name: string } }>(
      "/api/v1/projects/:projectId/buckets",
      async (req, reply) => {
        const { projectId } = req.params;
        await requireProjectPermission(req.userId!, projectId, "storage.buckets.create");
        const { name } = req.body ?? {};
        if (!name) throw validationError("name is required");

        const resource = await createResource({ projectId, name, type: "bucket", spec: {}, createdBy: req.userId! });
        const operation = await createOperation({ projectId, resourceId: resource.id, type: "bucket.create", createdBy: req.userId!, requestId: req.requestId });
        await operationsQueue.add("bucket.create", { operationId: operation.id, projectId, resourceId: resource.id, type: "bucket.create" });

        req.audit.action = "storage.buckets.create";
        req.audit.projectId = projectId;
        req.audit.resourceType = "bucket";
        req.audit.resourceId = resource.id;
        req.audit.resourceName = resource.name;
        req.audit.newState = resource;

        reply.status(202).send({ resource, operationId: operation.id });
      },
    );

    app.get<{ Params: { projectId: string } }>("/api/v1/projects/:projectId/buckets", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "storage.buckets.list");
      reply.send(await listResources(req.params.projectId, "bucket"));
    });

    app.get<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/buckets/:id", async (req, reply) => {
      await requireProjectPermission(req.userId!, req.params.projectId, "storage.buckets.get");
      reply.send(await getResource(req.params.projectId, req.params.id));
    });

    app.delete<{ Params: { projectId: string; id: string } }>("/api/v1/projects/:projectId/buckets/:id", async (req, reply) => {
      const { projectId, id } = req.params;
      await requireProjectPermission(req.userId!, projectId, "storage.buckets.delete");
      await getResource(projectId, id);
      await assertDeletable(id);

      await setResourceStatus(id, "DELETING");
      const operation = await createOperation({ projectId, resourceId: id, type: "bucket.delete", createdBy: req.userId!, requestId: req.requestId });
      await operationsQueue.add("bucket.delete", { operationId: operation.id, projectId, resourceId: id, type: "bucket.delete" });

      req.audit.action = "storage.buckets.delete";
      req.audit.projectId = projectId;
      req.audit.resourceType = "bucket";
      req.audit.resourceId = id;

      reply.status(202).send({ operationId: operation.id });
    });
  });
}

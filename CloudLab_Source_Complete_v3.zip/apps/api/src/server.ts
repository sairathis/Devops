import Fastify from "fastify";
import cors from "@fastify/cors";
import fstatic from "@fastify/static";
import websocket from "@fastify/websocket";
import rateLimit from "@fastify/rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import "./types.js";
import { sql } from "drizzle-orm";
import { db } from "./db/client.js";
import { createRedisConnection } from "./queue/connection.js";

const healthRedis = createRedisConnection();

import { registerAudit } from "./middleware/audit.js";
import { registerAuthRoutes } from "./routes/auth.js";
import { registerOrganizationRoutes } from "./routes/organizations.js";
import { registerProjectRoutes } from "./routes/projects.js";
import { registerNetworkRoutes } from "./routes/networks.js";
import { registerSubnetRoutes } from "./routes/subnets.js";
import { registerFirewallRoutes } from "./routes/firewall.js";
import { registerDnsRoutes } from "./routes/dns.js";
import { registerLoadBalancerRoutes } from "./routes/loadbalancers.js";
import { registerDiskRoutes } from "./routes/disks.js";
import { registerRegistryRoutes } from "./routes/registries.js";
import { registerImageRoutes } from "./routes/images.js";
import { registerBucketRoutes } from "./routes/buckets.js";
import { registerDatabaseRoutes } from "./routes/databases.js";
import { registerSecretRoutes } from "./routes/secrets.js";
import { registerK8sClusterRoutes } from "./routes/k8sClusters.js";
import { registerK8sDeploymentRoutes } from "./routes/k8sDeployments.js";
import { registerPipelineRoutes } from "./routes/pipelines.js";
import { registerPipelineRunRoutes } from "./routes/pipelineRuns.js";
import { registerObservabilityRoutes } from "./routes/observability.js";
import { registerTroubleshootRoutes } from "./routes/troubleshoot.js";
import { registerScenarioRoutes } from "./routes/scenarios.js";
import { registerInstanceRoutes } from "./routes/instances.js";
import { registerOperationRoutes } from "./routes/operations.js";
import { registerActivityRoutes } from "./routes/activity.js";
import { registerAuditRoutes } from "./routes/audit.js";
import { registerArchitectureRoutes } from "./routes/architecture.js";
import { registerServiceAccountRoutes } from "./routes/serviceAccounts.js";
import { registerInstanceTemplateRoutes } from "./routes/instanceTemplates.js";
import { registerManagedInstanceGroupRoutes } from "./routes/managedInstanceGroups.js";
import { registerNatGatewayRoutes } from "./routes/natGateways.js";
import { registerVpcPeeringRoutes } from "./routes/vpcPeerings.js";
import { registerSharedVpcRoutes } from "./routes/sharedVpc.js";
import { registerBigqueryRoutes } from "./routes/bigquery.js";
import { registerComposerEnvironmentRoutes } from "./routes/composerEnvironments.js";
import { registerCloudRunRoutes } from "./routes/cloudRun.js";
import { registerWsHub } from "./ws/hub.js";
import { registerTerminal } from "./ws/terminal.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function buildServer() {
  const app = Fastify({ logger: { level: process.env.LOG_LEVEL ?? "info" } });

  await app.register(cors, { origin: true });
  await app.register(websocket);
  await app.register(fstatic, { root: path.join(__dirname, "..", "public") });

  // Milestone 13: real rate limiting -- a genuine Redis-backed sliding
  // window (survives API restarts and is shared across however many API
  // processes run behind a load balancer, unlike an in-memory counter).
  // The default here is a generous network-abuse backstop, not the primary
  // brute-force defense -- that's the per-account lockout in auth.ts, which
  // is what actually limits guesses against one specific email address.
  // Per-route overrides (see routes/auth.ts) tighten this further on
  // register/login specifically.
  await app.register(rateLimit, {
    global: true,
    max: 1000,
    timeWindow: "1 minute",
    redis: createRedisConnection(),
    nameSpace: "cloudlab-ratelimit:",
    // NOTE: the plugin does `throw errorResponseBuilder(req, context)` (see
    // @fastify/rate-limit's onRequest hook) -- this thrown value then runs
    // through OUR OWN global error handler (registerAudit in
    // middleware/audit.ts), not the plugin's default reply path. That
    // handler only recognized our own HttpError class and otherwise coerced
    // everything to a generic 500, which was silently turning every real
    // 429 into a 500 (caught by TC-46 in the QA suite). statusCode here is
    // what audit.ts's error handler now reads to pick the real status.
    errorResponseBuilder: (_req, context) => ({
      statusCode: context.statusCode,
      code: "RATE_LIMITED",
      message: `Too many requests -- limit is ${context.max} per ${context.after}.`,
      what: `More than ${context.max} requests were made from this client within ${context.after}.`,
      why: "Rate limiting protects the API and its shared Postgres/Redis/Docker backends from being overwhelmed by a single client.",
      diagnose: "Check for a retry loop or polling interval that's firing faster than intended.",
      fix: `Wait and retry -- the window resets in ${context.after}.`,
    }),
  });

  // The frontend's api() wrapper (and plenty of real API clients) always
  // sends "content-type: application/json", even on bodyless requests like
  // DELETE /networks/:id. Fastify's default JSON parser rejects an empty
  // body under that content-type (FST_ERR_CTP_EMPTY_JSON_BODY), which was
  // silently breaking every delete button in the web console. Treat an
  // empty JSON body as "no body" instead of a parse error.
  app.addContentTypeParser("application/json", { parseAs: "string" }, (_req, body, done) => {
    if (typeof body !== "string" || body.length === 0) {
      done(null, undefined);
      return;
    }
    try {
      done(null, JSON.parse(body));
    } catch (err) {
      (err as any).statusCode = 400;
      done(err as Error, undefined);
    }
  });

  registerAudit(app); // must be first: sets requestId/timers/error handler for every route below

  registerAuthRoutes(app);
  registerOrganizationRoutes(app);
  registerProjectRoutes(app);
  registerNetworkRoutes(app);
  registerSubnetRoutes(app);
  registerFirewallRoutes(app);
  registerDnsRoutes(app);
  registerLoadBalancerRoutes(app);
  registerDiskRoutes(app);
  registerRegistryRoutes(app);
  registerImageRoutes(app);
  registerBucketRoutes(app);
  registerDatabaseRoutes(app);
  registerSecretRoutes(app);
  registerK8sClusterRoutes(app);
  registerK8sDeploymentRoutes(app);
  registerPipelineRoutes(app);
  registerPipelineRunRoutes(app);
  registerObservabilityRoutes(app);
  registerTroubleshootRoutes(app);
  registerScenarioRoutes(app);
  registerInstanceRoutes(app);
  registerOperationRoutes(app);
  registerActivityRoutes(app);
  registerAuditRoutes(app);
  registerArchitectureRoutes(app);
  registerServiceAccountRoutes(app);
  registerInstanceTemplateRoutes(app);
  registerManagedInstanceGroupRoutes(app);
  registerNatGatewayRoutes(app);
  registerVpcPeeringRoutes(app);
  registerSharedVpcRoutes(app);
  registerBigqueryRoutes(app);
  registerComposerEnvironmentRoutes(app);
  registerCloudRunRoutes(app);
  registerWsHub(app);
  registerTerminal(app);

  // A real health check, not a static "yes" -- it genuinely pings both
  // backends the API depends on, so a monitor can tell "process is up" from
  // "process is up but its database is unreachable" apart.
  app.get("/api/v1/health", async (_req, reply) => {
    const [dbCheck, redisCheck] = await Promise.allSettled([
      db.execute(sql`select 1`),
      healthRedis.ping(),
    ]);
    const healthy = dbCheck.status === "fulfilled" && redisCheck.status === "fulfilled";
    reply.status(healthy ? 200 : 503).send({
      status: healthy ? "HEALTHY" : "DEGRADED",
      service: "cloudlab-api",
      checks: {
        postgres: dbCheck.status === "fulfilled" ? "ok" : `error: ${(dbCheck as PromiseRejectedResult).reason?.message ?? "unknown"}`,
        redis: redisCheck.status === "fulfilled" ? "ok" : `error: ${(redisCheck as PromiseRejectedResult).reason?.message ?? "unknown"}`,
      },
    });
  });

  app.setNotFoundHandler((req, reply) => {
    if (req.url.startsWith("/api/") || req.url.startsWith("/ws")) {
      reply.status(404).send({ code: "RESOURCE_NOT_FOUND", message: `No route ${req.method} ${req.url}` });
      return;
    }
    reply.sendFile("index.html");
  });

  return app;
}

import type { ApiError, ErrorCode } from "@cloudlab/shared";

// Consistent error model (spec section 39): every error explains what
// happened, why, how to diagnose it, and how to fix it -- not just a code.
export class HttpError extends Error {
  status: number;
  body: ApiError;

  constructor(status: number, code: ErrorCode, message: string, extra: Partial<ApiError> = {}) {
    super(message);
    this.status = status;
    this.body = { code, message, ...extra };
  }
}

export function permissionDenied(action: string, roleKey?: string) {
  return new HttpError(403, "PERMISSION_DENIED", `Permission denied for '${action}'`, {
    what: `Your role${roleKey ? ` (${roleKey})` : ""} does not include '${action}'.`,
    why: "IAM policy evaluation denied this action (explicit deny, or no matching allow rule).",
    diagnose: "Check Project > IAM to see your current role and its allow/deny lists.",
    fix: "Ask a project Owner or Admin to grant a role that allows this action.",
  });
}

export function notFound(resourceType: string, id: string) {
  return new HttpError(404, "RESOURCE_NOT_FOUND", `${resourceType} '${id}' not found`, {
    what: `No ${resourceType} with id '${id}' exists in this project (or you cannot see it).`,
    why: "Either it was never created, was already deleted, or belongs to a different project.",
    diagnose: `GET /api/v1/${resourceType}s to list what actually exists.`,
    fix: "Double-check the id and the active project.",
  });
}

export function conflict(message: string, extra: Partial<ApiError> = {}) {
  return new HttpError(409, "RESOURCE_CONFLICT", message, extra);
}

export function dependencyExists(message: string, dependents: string[]) {
  return new HttpError(409, "DEPENDENCY_EXISTS", message, {
    what: message,
    why: "Other resources reference this one; deleting it would leave dangling state.",
    diagnose: "See details.dependents for the exact resources blocking this delete.",
    fix: "Delete or detach the dependents first, then retry.",
    details: { dependents },
  });
}

export function validationError(message: string, details?: Record<string, unknown>) {
  return new HttpError(400, "VALIDATION_ERROR", message, { details });
}

export function authFailed(message = "Invalid credentials") {
  return new HttpError(401, "AUTHENTICATION_FAILED", message, {
    what: "The request could not be authenticated.",
    why: "The email/password did not match, or the bearer token is missing/expired/invalid.",
    diagnose: "Confirm you're sending 'Authorization: Bearer <token>' from a fresh login.",
    fix: "POST /api/v1/auth/login again to obtain a new token.",
  });
}

// Milestone 13: real per-account lockout after repeated failed logins (see
// routes/auth.ts) -- 423 Locked, the correct status for "the resource is
// currently locked", distinct from 401 (wrong credentials this time) so a
// client can tell the two apart.
export function accountLocked(retryAfterSeconds: number) {
  return new HttpError(423, "ACCOUNT_LOCKED", "This account is temporarily locked after too many failed login attempts.", {
    what: `Too many failed login attempts -- the account is locked for about ${retryAfterSeconds}s more.`,
    why: "Real per-account lockout protects against password-guessing even from an attacker who rotates IP addresses (which the IP-based rate limit alone would not catch).",
    diagnose: "Confirm you have the right password, or wait for the lock to expire.",
    fix: `Wait ~${retryAfterSeconds}s and try again, or use a password reset flow if one exists.`,
  });
}

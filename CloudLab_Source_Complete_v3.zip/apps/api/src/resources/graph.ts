import { eq } from "drizzle-orm";
import { db } from "../db/client.js";
import { resources, resourceRelationships, projects } from "../db/schema.js";
import type { GraphEdge, GraphNode } from "@cloudlab/shared";

/**
 * Spec sections 17/48: the architecture graph is NEVER hand-drawn. It is
 * rebuilt on every request straight from resources + resource_relationships,
 * which the worker populates as a side effect of actually provisioning
 * things (see apps/worker/src/processors). If a human had to draw this, the
 * requirement would already be violated.
 */
export async function buildProjectGraph(projectId: string): Promise<{ nodes: GraphNode[]; edges: GraphEdge[] }> {
  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  const resourceRows = await db.select().from(resources).where(eq(resources.projectId, projectId));
  const resourceIds = resourceRows.map((r) => r.id);

  const nodes: GraphNode[] = [
    ...(project ? [{ id: `project:${project.id}`, type: "project" as const, label: project.name }] : []),
    ...resourceRows.map((r) => ({ id: r.id, type: r.type as GraphNode["type"], label: r.name, status: r.status as GraphNode["status"] })),
  ];

  const relRows = resourceIds.length
    ? await db.select().from(resourceRelationships)
    : [];
  const relevantRels = relRows.filter((r) => resourceIds.includes(r.fromResourceId) && resourceIds.includes(r.toResourceId));

  const edges: GraphEdge[] = [
    ...(project ? resourceRows.map((r) => ({ id: `contains:${project.id}:${r.id}`, from: `project:${project.id}`, to: r.id, kind: "contains" as const })) : []),
    ...relevantRels.map((r) => ({ id: r.id, from: r.fromResourceId, to: r.toResourceId, kind: r.kind as GraphEdge["kind"] })),
  ];

  return { nodes, edges };
}

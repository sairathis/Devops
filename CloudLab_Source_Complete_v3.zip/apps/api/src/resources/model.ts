import { and, eq, or } from "drizzle-orm";
import { db } from "../db/client.js";
import { resources, resourceEvents, resourceRelationships, operations } from "../db/schema.js";
import type { ResourceStatus, ResourceType } from "@cloudlab/shared";
import { conflict, dependencyExists, notFound } from "../errors.js";

export async function createResource(input: {
  projectId: string;
  name: string;
  type: ResourceType;
  spec: Record<string, unknown>;
  createdBy: string;
  region?: string;
}) {
  const existing = await db
    .select()
    .from(resources)
    .where(and(eq(resources.projectId, input.projectId), eq(resources.name, input.name)))
    .limit(1);
  if (existing.length > 0) {
    throw conflict(`A resource named '${input.name}' already exists in this project.`, {
      what: `Resource name '${input.name}' is taken.`,
      why: "Resource names must be unique per project.",
      fix: "Choose a different name.",
    });
  }

  const [row] = await db
    .insert(resources)
    .values({
      projectId: input.projectId,
      name: input.name,
      type: input.type,
      region: input.region ?? "local-1",
      status: "CREATING",
      spec: input.spec,
      createdBy: input.createdBy,
    })
    .returning();

  await db.insert(resourceEvents).values({ resourceId: row.id, fromStatus: null, toStatus: "CREATING" });
  return row;
}

export async function getResource(projectId: string, resourceId: string) {
  const [row] = await db
    .select()
    .from(resources)
    .where(and(eq(resources.id, resourceId), eq(resources.projectId, projectId)))
    .limit(1);
  if (!row) throw notFound("resource", resourceId);
  return row;
}

/** Milestone 15 (Shared VPC): looks a resource up by id alone, with NO project
 * filter. Used only by the one controlled cross-project path -- resolving a
 * network that a shared_vpc_attachment has genuinely granted a *different*
 * project access to (see routes/instances.ts) -- never exposed directly as
 * an endpoint, so it can't be used to probe for resources in other projects. */
export async function getResourceById(resourceId: string) {
  const [row] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  if (!row) throw notFound("resource", resourceId);
  return row;
}

export async function listResources(projectId: string, type?: ResourceType) {
  const conditions = type ? and(eq(resources.projectId, projectId), eq(resources.type, type)) : eq(resources.projectId, projectId);
  return db.select().from(resources).where(conditions);
}

export async function setResourceStatus(resourceId: string, status: ResourceStatus, message?: string, metadata?: Record<string, unknown>) {
  const [prev] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  if (!prev) throw notFound("resource", resourceId);

  const update: Partial<typeof resources.$inferInsert> = {
    status,
    updatedAt: new Date(),
    version: (prev.version ?? 1) + 1,
  };
  if (metadata) update.metadata = { ...(prev.metadata as object), ...metadata };

  const [row] = await db.update(resources).set(update).where(eq(resources.id, resourceId)).returning();
  await db.insert(resourceEvents).values({ resourceId, fromStatus: prev.status, toStatus: status, message });
  return row;
}

/** Merges into a resource's `spec` (distinct from setResourceStatus's `metadata` merge) --
 * used by k8s_deployment scaling, where the desired replica count IS the spec. */
export async function updateResourceSpec(resourceId: string, spec: Record<string, unknown>) {
  const [prev] = await db.select().from(resources).where(eq(resources.id, resourceId)).limit(1);
  if (!prev) throw notFound("resource", resourceId);
  const [row] = await db
    .update(resources)
    .set({ spec: { ...(prev.spec as object), ...spec }, version: (prev.version ?? 1) + 1, updatedAt: new Date() })
    .where(eq(resources.id, resourceId))
    .returning();
  return row;
}

export async function addRelationship(fromResourceId: string, toResourceId: string, kind: string) {
  await db.insert(resourceRelationships).values({ fromResourceId, toResourceId, kind });
}

export async function getDependents(resourceId: string) {
  const rows = await db
    .select()
    .from(resourceRelationships)
    .where(or(eq(resourceRelationships.toResourceId, resourceId), eq(resourceRelationships.fromResourceId, resourceId)));
  return rows;
}

/** Refuses to orphan dependents (spec section 20): "Cannot delete VPC, still used by...". */
export async function assertDeletable(resourceId: string) {
  const rels = await db.select().from(resourceRelationships).where(eq(resourceRelationships.toResourceId, resourceId));
  if (rels.length === 0) return;

  const dependentIds = rels.map((r) => r.fromResourceId);
  const candidates = await db.select().from(resources).where(or(...dependentIds.map((id) => eq(resources.id, id))));
  // A dependent that has since been deleted no longer counts -- otherwise a
  // network could never be cleaned up once anything had ever connected to it.
  const dependents = candidates.filter((d) => d.status !== "DELETED");
  if (dependents.length > 0) {
    throw dependencyExists(
      `Cannot delete this resource: it is still used by ${dependents.map((d) => d.name).join(", ")}.`,
      dependents.map((d) => `${d.type}:${d.name}`),
    );
  }
}

export async function createOperation(input: { projectId: string; resourceId?: string; type: string; createdBy: string; requestId?: string }) {
  const [row] = await db
    .insert(operations)
    .values({
      projectId: input.projectId,
      resourceId: input.resourceId ?? null,
      type: input.type,
      status: "PENDING",
      createdBy: input.createdBy,
      requestId: input.requestId ?? null,
    })
    .returning();
  return row;
}

export async function getOperation(projectId: string, operationId: string) {
  const [row] = await db
    .select()
    .from(operations)
    .where(and(eq(operations.id, operationId), eq(operations.projectId, projectId)))
    .limit(1);
  if (!row) throw notFound("operation", operationId);
  return row;
}

import { buildServer } from "./server.js";
import { config } from "./config.js";

const app = await buildServer();

app.listen({ port: config.port, host: "0.0.0.0" }, (err, address) => {
  if (err) {
    app.log.error(err);
    process.exit(1);
  }
  app.log.info(`cloudlab-api listening on ${address}`);
});

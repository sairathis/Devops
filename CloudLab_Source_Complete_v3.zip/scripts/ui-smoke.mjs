// One-off manual smoke test of the web console via a real headless browser.
// Not part of the automated test suite (that's scripts/e2e.ts against the API);
// this exists purely to catch console/runtime errors in app.js during development.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";

const browser = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome",
  args: ["--no-sandbox"],
});
const page = await browser.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
page.on("console", (msg) => { if (msg.type() === "error") errors.push(`console.error: ${msg.text()}`); });

const email = `ui-${Date.now()}@cloudlab.dev`;

await page.goto("http://localhost:4000/");
await page.waitForSelector("h1"); // auth screen

await page.click("text=Register");
await page.fill('input[name="name"]', "UI Tester");
await page.fill('input[name="email"]', email);
await page.fill('input[name="password"]', "password123");
await page.click('button:has-text("Create account")');

await page.waitForSelector("text=Welcome, UI Tester", { timeout: 5000 });
await page.fill('input[placeholder="Organization name"]', "UI Test Org");
await page.click('button:has-text("Create")');

await page.waitForSelector("text=Projects", { timeout: 5000 });
await page.fill('input[placeholder="Project name"]', "ui-test-project");
await page.click('button:has-text("Create")');

await page.waitForSelector("text=Networking", { timeout: 5000 }); // nav visible = project loaded
console.log("dashboard loaded ok");

await page.click("text=Networking");
await page.fill('input[placeholder="vpc-main"]', "vpc-ui");
await page.click('button:has-text("Create network")');
await page.waitForSelector("td:has-text('vpc-ui')", { timeout: 5000 });
await page.waitForSelector("span.badge.READY", { timeout: 15000 });
console.log("network reached READY in the UI");

await page.click("text=Compute");
await page.selectOption("#network-select", { label: "vpc-ui" });
await page.fill('input[placeholder="web-01"]', "web-ui");
await page.click('button:has-text("Create instance")');
await page.waitForSelector("a:has-text('web-ui')", { timeout: 5000 });
await page.waitForSelector("span.badge.READY", { timeout: 20000 });
console.log("instance reached READY in the UI");

await page.click("a:has-text('web-ui')");
await page.waitForSelector("text=Run a command", { timeout: 5000 });
await page.fill('input[placeholder="hostname && uname -a"]', "hostname");
await page.click('button:has-text("Run")');
await page.waitForTimeout(1000);
const execText = await page.textContent(".terminal");
console.log("exec panel shows:", execText.trim().split("\n").slice(-2).join(" | "));

await page.click("text=← back to Compute");
await page.click("text=Architecture");
await page.waitForSelector(".graph .node", { timeout: 5000 });
const nodeCount = await page.$$eval(".graph .node", (els) => els.length);
console.log("architecture graph node count:", nodeCount);

await page.click("text=Activity");
await page.waitForSelector(".timeline .event", { timeout: 5000 });
console.log("activity timeline populated");

await page.click("text=Audit Log");
await page.waitForSelector("table tbody tr", { timeout: 5000 });
console.log("audit log populated");

console.log(errors.length ? `ERRORS:\n${errors.join("\n")}` : "NO CONSOLE ERRORS");

await browser.close();
process.exit(errors.length ? 1 : 0);

#!/usr/bin/env tsx
/**
 * End-to-end vertical-slice test for CloudLab.
 *
 * Unlike apps/api/test/*.test.ts (which exercise the Fastify app in-process
 * via `.inject()` and don't require the worker or Docker), this script
 * drives the REAL running stack over real HTTP: API server + worker process
 * + Postgres + Redis + the local Docker daemon. It creates a network and an
 * instance, waits for them to reach READY the same way a real client would
 * (polling the API), and then cross-checks the result against the actual
 * Docker Engine state -- not just what the database says happened. This is
 * the concrete enforcement of the spec's "no fake success" principle: if
 * the API claims a resource is READY, the underlying container/network
 * must genuinely exist and behave as claimed.
 *
 * Preconditions (see INFRASTRUCTURE.md): Postgres and Redis running, the
 * Docker daemon reachable, apps/api and apps/worker both running, and the
 * cloudlab/guest:latest image built (infra/guest-image/build.sh).
 *
 * Usage:  npm run e2e   (from repo root)
 */
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const API = process.env.CLOUDLAB_API_BASE ?? "http://localhost:4000/api/v1";

let passed = 0;
let failed = 0;

function ok(label: string) {
  passed += 1;
  console.log(`  ✓ ${label}`);
}
function fail(label: string, detail?: unknown) {
  failed += 1;
  console.error(`  ✗ ${label}`, detail ?? "");
}
function assert(cond: unknown, label: string, detail?: unknown) {
  if (cond) ok(label);
  else fail(label, detail);
}

async function api(path: string, opts: RequestInit & { token?: string } = {}) {
  const { token, headers, ...rest } = opts;
  const res = await fetch(`${API}${path}`, {
    ...rest,
    headers: {
      "content-type": "application/json",
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
  });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  return { status: res.status, body };
}

async function waitForStatus(
  path: string,
  token: string,
  wantStatuses: string[],
  timeoutMs: number,
): Promise<any> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const { body } = await api(path, { token });
    if (body && wantStatuses.includes(body.status)) return body;
    if (body && body.status === "FAILED") throw new Error(`resource FAILED: ${JSON.stringify(body.error ?? body)}`);
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`timed out waiting for ${wantStatuses.join("|")} on ${path}`);
}

async function dockerInspect(args: string[]): Promise<{ code: number; stdout: string }> {
  try {
    const { stdout } = await execFileAsync("docker", args);
    return { code: 0, stdout };
  } catch (err: any) {
    return { code: err.code ?? 1, stdout: err.stdout ?? "" };
  }
}

async function main() {
  const stamp = Date.now();
  const email = `e2e-${stamp}@cloudlab.dev`;

  console.log(`\nCloudLab vertical-slice e2e against ${API}\n`);

  // 1. Register + auth
  console.log("Auth");
  const reg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: "E2E Runner", email, password: "password123" }) });
  assert(reg.status === 201, "register returns 201", reg);
  const token = reg.body.token as string;

  const me = await api("/auth/me", { token });
  assert(me.status === 200 && me.body.email === email, "GET /me echoes the authenticated user", me);

  const badLogin = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password: "wrong" }) });
  assert(badLogin.status === 401, "login with wrong password is rejected", badLogin);

  // 2. Org + project
  console.log("Organizations & projects");
  const org = await api("/organizations", { method: "POST", token, body: JSON.stringify({ name: "E2E Org" }) });
  assert(org.status === 201, "create organization", org);

  const project = await api("/projects", { method: "POST", token, body: JSON.stringify({ orgId: org.body.id, name: `e2e-project-${stamp}` }) });
  assert(project.status === 201, "create project", project);
  const projectId = project.body.id as string;

  const strangerReg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: "Stranger", email: `stranger-${stamp}@cloudlab.dev`, password: "password123" }) });
  const strangerToken = strangerReg.body.token as string;
  const strangerAccess = await api(`/projects/${projectId}/networks`, { token: strangerToken });
  assert(strangerAccess.status === 404, "a user with no membership gets 404, not 403, for a project they can't see", strangerAccess);

  // 3. Real network provisioning
  console.log("Networking (real Docker network)");
  const cidr = `172.${50 + (stamp % 100)}.0.0/24`;
  const netCreate = await api(`/projects/${projectId}/networks`, { method: "POST", token, body: JSON.stringify({ name: "vpc-e2e", cidr }) });
  assert(netCreate.status === 202, "POST network returns 202 with an operationId", netCreate);
  const networkId = netCreate.body.resource.id as string;

  const network = await waitForStatus(`/projects/${projectId}/networks/${networkId}`, token, ["READY"], 20000);
  assert(network.status === "READY", "network reaches READY", network);
  assert(typeof network.metadata?.dockerNetworkId === "string", "READY network has a real dockerNetworkId in metadata", network.metadata);

  const dockerNet = await dockerInspect(["network", "inspect", network.metadata.dockerNetworkId]);
  assert(dockerNet.code === 0, "the Docker network genuinely exists on the daemon (docker network inspect succeeds)", dockerNet.stdout.slice(0, 200));

  // 4. Real instance provisioning
  console.log("Compute (real container)");
  const instCreate = await api(`/projects/${projectId}/instances`, { method: "POST", token, body: JSON.stringify({ name: "web-e2e", networkId }) });
  assert(instCreate.status === 202, "POST instance returns 202 with an operationId", instCreate);
  const instanceId = instCreate.body.resource.id as string;

  const instance = await waitForStatus(`/projects/${projectId}/instances/${instanceId}`, token, ["READY"], 30000);
  assert(instance.status === "READY", "instance reaches READY", instance);
  assert(typeof instance.metadata?.containerId === "string", "READY instance has a real containerId in metadata", instance.metadata);
  assert(typeof instance.metadata?.ip === "string", "READY instance has a real container IP", instance.metadata);

  const dockerContainer = await dockerInspect(["inspect", instance.metadata.containerId, "--format", "{{.State.Running}}"]);
  assert(dockerContainer.stdout.trim() === "true", "the container genuinely exists and is running (docker inspect)", dockerContainer);

  // 5. Real exec through the API (proves the guest OS is a real, running Linux userland)
  console.log("Exec");
  const exec = await api(`/projects/${projectId}/instances/${instanceId}/exec`, { method: "POST", token, body: JSON.stringify({ command: "hostname" }) });
  assert(exec.status === 200 && typeof exec.body.output === "string" && exec.body.output.trim().length > 0, "exec runs a real command inside the container and returns real output", exec.body);

  const healthz = await fetch(instance.metadata.publicUrl + "/healthz").then((r) => r.text()).catch((e) => `ERROR: ${e}`);
  assert(healthz.trim() === "ok", "the guest agent's published port answers a real HTTP health check", healthz);

  // 6. Architecture graph is derived, not drawn
  console.log("Architecture graph");
  const graph = await api(`/projects/${projectId}/architecture`, { token });
  const nodeIds = (graph.body.nodes ?? []).map((n: any) => n.id);
  assert(nodeIds.includes(networkId) && nodeIds.includes(instanceId), "graph includes both live resources", graph.body);
  const hasConnectsTo = (graph.body.edges ?? []).some((e: any) => e.from === instanceId && e.to === networkId && e.kind === "connects_to");
  assert(hasConnectsTo, "graph has a real connects_to edge from instance to network", graph.body.edges);

  // 7. Activity + audit reflect what actually happened
  console.log("Activity & audit");
  // Milestone 13: both endpoints now return a real paginated envelope
  // ({ items, page, pageSize, total, hasMore }) instead of a bare array.
  const activity = await api(`/projects/${projectId}/activity`, { token });
  assert(Array.isArray(activity.body?.items) && activity.body.items.length > 0, "activity timeline is populated", activity.status);

  const audit = await api(`/projects/${projectId}/audit`, { token });
  const auditActions = (audit.body?.items ?? []).map((a: any) => a.action);
  assert(auditActions.includes("network.networks.create") && auditActions.includes("compute.instances.create"), "audit log recorded both create actions", auditActions);

  // 8. IAM: bind a viewer and confirm read-only enforcement
  console.log("IAM");
  const viewerReg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: "Viewer", email: `viewer-${stamp}@cloudlab.dev`, password: "password123" }) });
  const viewerToken = viewerReg.body.token as string;
  const bind = await api(`/projects/${projectId}/iam/bindings`, { method: "POST", token, body: JSON.stringify({ userId: viewerReg.body.user.id, roleKey: "viewer" }) });
  assert(bind.status === 201, "owner can bind a viewer role", bind);

  const viewerList = await api(`/projects/${projectId}/instances`, { token: viewerToken });
  assert(viewerList.status === 200, "viewer can list instances", viewerList.status);
  const viewerCreate = await api(`/projects/${projectId}/networks`, { method: "POST", token: viewerToken, body: JSON.stringify({ name: "should-fail" }) });
  assert(viewerCreate.status === 403, "viewer cannot create resources (403 PERMISSION_DENIED)", viewerCreate);

  // 9. Teardown: delete instance, then network, honestly enforcing dependency order
  console.log("Teardown");
  const netDeleteTooEarly = await api(`/projects/${projectId}/networks/${networkId}`, { method: "DELETE", token });
  assert(netDeleteTooEarly.status === 409, "deleting a network with a live dependent instance is blocked with 409 DEPENDENCY_EXISTS", netDeleteTooEarly);

  const instDelete = await api(`/projects/${projectId}/instances/${instanceId}`, { method: "DELETE", token });
  assert(instDelete.status === 202, "instance delete accepted", instDelete);
  const deletedInstance = await waitForStatus(`/projects/${projectId}/instances/${instanceId}`, token, ["DELETED"], 15000);
  assert(deletedInstance.status === "DELETED", "instance reaches DELETED", deletedInstance);

  const containerGone = await dockerInspect(["inspect", instance.metadata.containerId]);
  assert(containerGone.code !== 0, "the container is genuinely gone from the Docker daemon", containerGone.stdout);

  const netDeleteNow = await api(`/projects/${projectId}/networks/${networkId}`, { method: "DELETE", token });
  assert(netDeleteNow.status === 202, "network delete accepted once its dependent is gone", netDeleteNow);
  const deletedNetwork = await waitForStatus(`/projects/${projectId}/networks/${networkId}`, token, ["DELETED"], 15000);
  assert(deletedNetwork.status === "DELETED", "network reaches DELETED", deletedNetwork);

  const dockerNetGone = await dockerInspect(["network", "inspect", network.metadata.dockerNetworkId]);
  assert(dockerNetGone.code !== 0, "the Docker network is genuinely gone from the daemon", dockerNetGone.stdout);

  console.log(`\n${passed} passed, ${failed} failed\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("\nFATAL:", err);
  console.log(`\n${passed} passed, ${failed + 1} failed\n`);
  process.exit(1);
});

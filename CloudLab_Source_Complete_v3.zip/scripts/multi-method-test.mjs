#!/usr/bin/env node
// Multi-method test suite: for each of CloudLab's four non-console
// provisioning methods (JSON CLI, Terraform-lab, gcloud-style CLI, CI/CD
// pipeline) -- the console/manual method's own create+delete coverage of
// these same seven core services already lives in scripts/qa-run.mjs's
// TC-* suite -- this script creates, verifies (real READY status, real
// list/describe output), and deletes (with real gone-ness re-checked) all
// seven core services, PLUS several negative/edge cases per method that
// exercise real error paths (bad input, dangling references, dependency
// conflicts, missing auth). Every assertion is checked against the real
// REST API's actual response, never against a CLI's own stdout claiming
// success.
//
// Usage: node scripts/multi-method-test.mjs
// Output: prints a live PASS/FAIL log and writes
//         test-results/multi-method-results.json

import { execFileSync } from "node:child_process";
import { writeFileSync, mkdtempSync, readFileSync, renameSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomInt } from "node:crypto";

const writeFile = writeFileSync;

// Real Docker CIDR collisions (Milestone 13) are checked host-wide, not
// per-project -- and this sandbox has accumulated plenty of networks from
// earlier milestone/QA runs. A narrow, time-derived octet range collides
// often enough to flake this suite on nothing but bad luck, so every
// method below draws from a wide random /24 space (same fix applied to
// cicd-lab/run-lab.mjs) instead.
function randomOctets() {
  return { o2: randomInt(1, 250), o3: randomInt(0, 250) };
}

const ROOT = "/home/claude/cloudlab";
const API = "http://localhost:4000/api/v1";
const results = [];

function record(method, id, description, status, details = "") {
  results.push({ method, id, description, status, details });
  const mark = status === "PASS" ? "PASS" : "FAIL";
  console.log(`[${mark}] ${method} ${id}: ${description}${details ? `  (${details})` : ""}`);
}

async function api(p, opts = {}, token) {
  const headers = { "content-type": "application/json", ...(opts.headers || {}) };
  if (token) headers.authorization = `Bearer ${token}`;
  const res = await fetch(`${API}${p}`, { ...opts, headers });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  return { ok: res.ok, status: res.status, body };
}

async function registerProject(prefix) {
  const stamp = Date.now();
  const email = `${prefix}-${stamp}@cloudlab.dev`;
  const reg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: prefix, email, password: "password123" }) });
  const token = reg.body.token;
  const org = await api("/organizations", { method: "POST", body: JSON.stringify({ name: `${prefix} org` }) }, token);
  const project = await api("/projects", { method: "POST", body: JSON.stringify({ orgId: org.body.id, name: `${prefix}-${stamp}` }) }, token);
  return { email, token, projectId: project.body.id, stamp };
}

// Runs a CLI script and never throws -- returns {code, stdout, stderr} so
// callers can assert on a *failing* invocation just as easily as a
// succeeding one.
function run(cmd, args, env) {
  try {
    const stdout = execFileSync(cmd, args, { cwd: ROOT, env: { ...process.env, ...env }, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
    return { code: 0, stdout, stderr: "" };
  } catch (err) {
    return { code: err.status ?? 1, stdout: err.stdout?.toString() ?? "", stderr: err.stderr?.toString() ?? "" };
  }
}

async function verifyAllReady(projectId, token, kinds, names) {
  for (const [kind, name] of Object.entries(names)) {
    const rows = (await api(`/projects/${projectId}/${kind}`, {}, token)).body;
    const match = rows.find((r) => r.name === name);
    if (!match) return { ok: false, detail: `${kind}/${name} not found via GET list` };
    if (match.status !== "READY") return { ok: false, detail: `${kind}/${name} status=${match.status}, expected READY` };
  }
  return { ok: true };
}

async function verifyAllGone(projectId, token, names) {
  for (const [kind, name] of Object.entries(names)) {
    const rows = (await api(`/projects/${projectId}/${kind}`, {}, token)).body;
    const match = rows.find((r) => r.name === name);
    if (match && match.status !== "DELETED") return { ok: false, detail: `${kind}/${name} still present, status=${match.status}` };
  }
  return { ok: true };
}

// ============================================================================
// METHOD 1: JSON CLI (scripts/cloudlab-cli.ts)
// ============================================================================
function buildJsonPlan(o2, o3) {
  return {
    resources: [
      { type: "network", name: "jc-net", spec: { cidr: `10.${o2}.${o3}.0/24` } },
      { type: "subnet", name: "jc-subnet", spec: { networkId: "$jc-net", cidr: `10.${o2}.${o3}.0/25` } },
      { type: "firewall_rule", name: "jc-fw", spec: { networkResourceId: "$jc-net", direction: "ingress", action: "ALLOW", protocol: "tcp", portRange: "80", cidr: "0.0.0.0/0" } },
      { type: "instance", name: "jc-inst", spec: { networkId: "$jc-net", subnetId: "$jc-subnet" } },
      { type: "disk", name: "jc-disk", spec: { sizeGb: 10 } },
      { type: "bucket", name: "jc-bucket", spec: {} },
      { type: "database", name: "jc-db", spec: {} },
    ],
  };
}

async function testJsonCli() {
  const M = "JSON-CLI";
  const { token, projectId } = await registerProject("jsoncli-test");
  const planPath = path.join(mkdtempSync(path.join(tmpdir(), "jsoncli-")), "plan.json");
  const env = { CLOUDLAB_TOKEN: token, CLOUDLAB_PROJECT: projectId };

  // Retry with a freshly randomized CIDR only on a real collision (see
  // randomOctets' comment) -- any other failure is a genuine test failure,
  // not something to paper over by retrying.
  let apply;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const { o2, o3 } = randomOctets();
    writeFile(planPath, JSON.stringify(buildJsonPlan(o2, o3), null, 2));
    apply = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "apply", "-f", planPath], env);
    if (apply.code === 0 || !apply.stderr.includes("overlaps with network")) break;
  }
  record(M, "TC-01", "apply creates all 7 core services", apply.code === 0 ? "PASS" : "FAIL", apply.code === 0 ? "" : apply.stderr.trim());

  const names = { networks: "jc-net", subnets: "jc-subnet", "firewall-rules": "jc-fw", instances: "jc-inst", disks: "jc-disk", buckets: "jc-bucket", databases: "jc-db" };
  const ready = await verifyAllReady(projectId, token, null, names);
  record(M, "TC-02", "all 7 resources independently verified READY via GET", ready.ok ? "PASS" : "FAIL", ready.detail ?? "");

  const applyAgain = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "apply", "-f", planPath], env);
  record(M, "TC-03", "re-running apply is idempotent (0 creates, no errors)", applyAgain.code === 0 && applyAgain.stdout.includes("7 resource(s) managed") ? "PASS" : "FAIL", applyAgain.stdout.trim().split("\n").pop());

  // Negative: unknown resource type
  const badTypePath = path.join(path.dirname(planPath), "bad_type.json");
  writeFile(badTypePath, JSON.stringify({ resources: [{ type: "not_a_real_type", name: "x", spec: {} }] }));
  const badType = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "apply", "-f", badTypePath], env);
  record(M, "TC-04 (negative)", "apply with an unknown resource type fails loudly, doesn't crash silently", badType.code !== 0 && badType.stderr.includes("unknown resource type") ? "PASS" : "FAIL", badType.stderr.trim());

  // Negative: dangling reference
  const danglingPath = path.join(path.dirname(planPath), "dangling.json");
  writeFile(danglingPath, JSON.stringify({ resources: [{ type: "subnet", name: "jc-orphan-subnet", spec: { networkId: "$does-not-exist", cidr: "10.99.0.0/25" } }] }));
  const dangling = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "apply", "-f", danglingPath], env);
  record(M, "TC-05 (negative)", "apply with a reference to an undefined resource fails with a clear dependency error", dangling.code !== 0 && dangling.stderr.includes("could not resolve dependencies") ? "PASS" : "FAIL", dangling.stderr.trim());

  // Negative: duplicate name across types (project-wide name uniqueness)
  const dupPath = path.join(path.dirname(planPath), "dup.json");
  writeFile(dupPath, JSON.stringify({ resources: [{ type: "bucket", name: "jc-net", spec: {} }] })); // "jc-net" already exists as a network
  const dup = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "apply", "-f", dupPath], env);
  record(M, "TC-06 (negative)", "apply with a name colliding with an existing resource (any type) fails with a real 409", dup.code !== 0 && /409|already exists/.test(dup.stderr) ? "PASS" : "FAIL", dup.stderr.trim());

  const destroy = run("npx", ["tsx", "scripts/cloudlab-cli.ts", "destroy", "-f", planPath], env);
  record(M, "TC-07", "destroy removes all 7 core services (dependency-ordered retries)", destroy.code === 0 ? "PASS" : "FAIL", destroy.code === 0 ? "" : destroy.stderr.trim());

  const gone = await verifyAllGone(projectId, token, names);
  record(M, "TC-08", "all 7 resources independently verified gone via GET", gone.ok ? "PASS" : "FAIL", gone.detail ?? "");
}

// ============================================================================
// METHOD 2: Terraform-lab (terraform-lab/tf-lab-cli.ts)
// ============================================================================
function buildTf(o2, o3) {
  return `
resource "cloudlab_network" "tf_net" {
  cidr = "10.${o2}.${o3}.0/24"
}
resource "cloudlab_subnet" "tf_subnet" {
  network_id = cloudlab_network.tf_net.id
  cidr       = "10.${o2}.${o3}.0/25"
}
resource "cloudlab_firewall_rule" "tf_fw" {
  network_resource_id = cloudlab_network.tf_net.id
  direction            = "ingress"
  action               = "ALLOW"
  protocol             = "tcp"
  port_range           = "80"
  cidr                 = "0.0.0.0/0"
}
resource "cloudlab_instance" "tf_inst" {
  network_id = cloudlab_network.tf_net.id
  subnet_id  = cloudlab_subnet.tf_subnet.id
}
resource "cloudlab_disk" "tf_disk" {
  size_gb = 10
}
resource "cloudlab_bucket" "tf_bucket" {
}
resource "cloudlab_database" "tf_db" {
}
`.trim();
}

async function testTerraformLab() {
  const M = "Terraform-lab";
  const { token, projectId } = await registerProject("tflab-test");
  const tfPath = path.join(mkdtempSync(path.join(tmpdir(), "tflab-")), "main.tf");
  const env = { CLOUDLAB_TOKEN: token, CLOUDLAB_PROJECT: projectId };

  let apply;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const { o2, o3 } = randomOctets();
    writeFile(tfPath, buildTf(o2, o3));
    apply = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "apply", "-f", tfPath], env);
    if (apply.code === 0 || !apply.stderr.includes("overlaps with network")) break;
  }
  record(M, "TC-01", "apply parses real .tf syntax and creates all 7 core services", apply.code === 0 ? "PASS" : "FAIL", apply.code === 0 ? "" : apply.stderr.trim());

  const names = { networks: "tf_net", subnets: "tf_subnet", "firewall-rules": "tf_fw", instances: "tf_inst", disks: "tf_disk", buckets: "tf_bucket", databases: "tf_db" };
  const ready = await verifyAllReady(projectId, token, null, names);
  record(M, "TC-02", "all 7 resources independently verified READY via GET", ready.ok ? "PASS" : "FAIL", ready.detail ?? "");

  const planAgain = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "plan", "-f", tfPath], env);
  record(M, "TC-03", "re-running plan reports 0 to add, 7 unchanged (real idempotent diff)", planAgain.code === 0 && planAgain.stdout.includes("0 to add, 7 unchanged") ? "PASS" : "FAIL", planAgain.stdout.trim().split("\n").pop());

  // Negative: unrecognized provider-style type
  const badPath = path.join(path.dirname(tfPath), "bad.tf");
  writeFile(badPath, `resource "aws_vpc" "main" {\n  cidr = "10.0.0.0/16"\n}\n`);
  const bad = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "plan", "-f", badPath], env);
  record(M, "TC-04 (negative)", "a non-cloudlab_ resource type is rejected with a clear parse error", bad.code !== 0 && bad.stderr.includes("unrecognized resource type") ? "PASS" : "FAIL", bad.stderr.trim());

  // Negative: reserved "name" attribute
  const nameAttrPath = path.join(path.dirname(tfPath), "name_attr.tf");
  writeFile(nameAttrPath, `resource "cloudlab_network" "x" {\n  cidr = "10.0.0.0/16"\n  name = "override"\n}\n`);
  const nameAttr = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "plan", "-f", nameAttrPath], env);
  record(M, "TC-05 (negative)", "a 'name' attribute inside a resource block is rejected (label IS the name)", nameAttr.code !== 0 && nameAttr.stderr.includes('"name" attribute') ? "PASS" : "FAIL", nameAttr.stderr.trim());

  // Negative: dangling reference
  const orphanPath = path.join(path.dirname(tfPath), "orphan.tf");
  writeFile(orphanPath, `resource "cloudlab_subnet" "orphan" {\n  network_id = cloudlab_network.nonexistent.id\n  cidr       = "10.98.0.0/25"\n}\n`);
  const orphan = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "apply", "-f", orphanPath], env);
  record(M, "TC-06 (negative)", "a reference to a resource absent from the file fails at apply with a dependency error", orphan.code !== 0 && orphan.stderr.includes("could not resolve dependencies") ? "PASS" : "FAIL", orphan.stderr.trim());

  const destroy = run("npx", ["tsx", "terraform-lab/tf-lab-cli.ts", "destroy", "-f", tfPath], env);
  record(M, "TC-07", "destroy removes all 7 core services", destroy.code === 0 ? "PASS" : "FAIL", destroy.code === 0 ? "" : destroy.stderr.trim());

  const gone = await verifyAllGone(projectId, token, names);
  record(M, "TC-08", "all 7 resources independently verified gone via GET", gone.ok ? "PASS" : "FAIL", gone.detail ?? "");
}

// ============================================================================
// METHOD 3: gcloud-style CLI (gcloud-lab/gcloud.ts)
// ============================================================================
async function testGcloudCli() {
  const M = "gcloud-CLI";
  const gcloud = (...args) => run("npx", ["tsx", "gcloud-lab/gcloud.ts", ...args], {});

  const init = gcloud("init", "--name=MultiMethodTest");
  const projMatch = /Your current project has been set to: \[([a-f0-9-]+)\]/.exec(init.stdout);
  record(M, "TC-00", "gcloud init registers an account+org+project and caches credentials", init.code === 0 && projMatch ? "PASS" : "FAIL", init.code === 0 ? "" : init.stderr.trim());
  const projectId = projMatch?.[1];

  let netCreate;
  let o2, o3;
  for (let attempt = 1; attempt <= 3; attempt++) {
    ({ o2, o3 } = randomOctets());
    netCreate = gcloud("compute", "networks", "create", "gc-net", `--range=10.${o2}.${o3}.0/24`);
    if (netCreate.code === 0 || !netCreate.stderr.includes("overlaps with network")) break;
  }
  record(M, "TC-01a", "compute networks create", netCreate.code === 0 ? "PASS" : "FAIL", netCreate.code === 0 ? "" : netCreate.stderr.trim());
  const subCreate = gcloud("compute", "networks", "subnets", "create", "gc-subnet", "--network=gc-net", `--range=10.${o2}.${o3}.0/25`);
  record(M, "TC-01b", "compute networks subnets create (resolves --network=name to id)", subCreate.code === 0 ? "PASS" : "FAIL", subCreate.code === 0 ? "" : subCreate.stderr.trim());
  const fwCreate = gcloud("compute", "firewall-rules", "create", "gc-fw", "--network=gc-net", "--direction=INGRESS", "--action=ALLOW", "--rules=tcp:80", "--source-ranges=0.0.0.0/0");
  record(M, "TC-01c", "compute firewall-rules create", fwCreate.code === 0 ? "PASS" : "FAIL", fwCreate.code === 0 ? "" : fwCreate.stderr.trim());
  const instCreate = gcloud("compute", "instances", "create", "gc-inst", "--network=gc-net", "--subnet=gc-subnet");
  record(M, "TC-01d", "compute instances create", instCreate.code === 0 ? "PASS" : "FAIL", instCreate.code === 0 ? "" : instCreate.stderr.trim());
  const diskCreate = gcloud("compute", "disks", "create", "gc-disk", "--size=10");
  record(M, "TC-01e", "compute disks create", diskCreate.code === 0 ? "PASS" : "FAIL", diskCreate.code === 0 ? "" : diskCreate.stderr.trim());
  const bucketCreate = gcloud("storage", "buckets", "create", "gs://gc-bucket");
  record(M, "TC-01f", "storage buckets create", bucketCreate.code === 0 ? "PASS" : "FAIL", bucketCreate.code === 0 ? "" : bucketCreate.stderr.trim());
  const dbCreate = gcloud("sql", "instances", "create", "gc-db");
  record(M, "TC-01g", "sql instances create (-> CloudLab database resource)", dbCreate.code === 0 ? "PASS" : "FAIL", dbCreate.code === 0 ? "" : dbCreate.stderr.trim());

  const names = { networks: "gc-net", subnets: "gc-subnet", "firewall-rules": "gc-fw", instances: "gc-inst", disks: "gc-disk", buckets: "gc-bucket", databases: "gc-db" };
  const loginBody = JSON.parse(readFileSync(path.join(ROOT, "gcloud-lab/.cloudshell/config.json"), "utf8"));
  const ready = await verifyAllReady(projectId, loginBody.token, null, names);
  record(M, "TC-02", "all 7 resources independently verified READY via GET (not just gcloud's own stdout)", ready.ok ? "PASS" : "FAIL", ready.detail ?? "");

  const describe = gcloud("compute", "networks", "describe", "gc-net");
  record(M, "TC-03", "describe prints real spec/metadata fields (e.g. dockerNetworkId), proving real infra underneath", describe.code === 0 && describe.stdout.includes("dockerNetworkId") ? "PASS" : "FAIL", describe.stdout.includes("dockerNetworkId") ? "" : "no dockerNetworkId in output");

  // Negative: missing required flag
  const missingFlag = gcloud("compute", "networks", "create", "gc-bad-net");
  record(M, "TC-04 (negative)", "create with a missing required flag fails before ever calling the API", missingFlag.code !== 0 && missingFlag.stderr.includes("--range") ? "PASS" : "FAIL", missingFlag.stderr.trim());

  // Negative: delete-with-dependency
  const blockedDelete = gcloud("compute", "networks", "delete", "gc-net");
  record(M, "TC-05 (negative)", "deleting a network that still has a subnet attached fails with the real 409 dependency error", blockedDelete.code !== 0 && /409|used by/.test(blockedDelete.stderr) ? "PASS" : "FAIL", blockedDelete.stderr.trim());

  // Negative: unauthenticated
  const cfgPath = path.join(ROOT, "gcloud-lab/.cloudshell/config.json");
  renameSync(cfgPath, `${cfgPath}.bak`);
  const noAuth = gcloud("compute", "networks", "list");
  record(M, "TC-06 (negative)", "running a command with no cached credentials fails with a clear auth error, not a crash", noAuth.code !== 0 && noAuth.stderr.includes("active account") ? "PASS" : "FAIL", noAuth.stderr.trim());
  renameSync(`${cfgPath}.bak`, cfgPath);

  // Cleanup in dependency order, then verify gone
  gcloud("compute", "instances", "delete", "gc-inst");
  gcloud("compute", "firewall-rules", "delete", "gc-fw");
  gcloud("compute", "networks", "subnets", "delete", "gc-subnet");
  const netDelete = gcloud("compute", "networks", "delete", "gc-net");
  gcloud("compute", "disks", "delete", "gc-disk");
  gcloud("storage", "buckets", "delete", "gs://gc-bucket");
  gcloud("sql", "instances", "delete", "gc-db");
  record(M, "TC-07", "delete (in dependency order) succeeds for all 7 core services", netDelete.code === 0 ? "PASS" : "FAIL", netDelete.code === 0 ? "" : netDelete.stderr.trim());

  const gone = await verifyAllGone(projectId, loginBody.token, names);
  record(M, "TC-08", "all 7 resources independently verified gone via GET", gone.ok ? "PASS" : "FAIL", gone.detail ?? "");

  const describeDeleted = gcloud("compute", "networks", "describe", "gc-net");
  record(M, "TC-09 (negative)", "describing an already-deleted resource returns a clear NOT_FOUND", describeDeleted.code !== 0 && describeDeleted.stderr.includes("NOT_FOUND") ? "PASS" : "FAIL", describeDeleted.stderr.trim());
}

// ============================================================================
// METHOD 4: CI/CD pipeline (cicd-lab/)
// ============================================================================
async function testCicdPipeline() {
  const M = "CI/CD-pipeline";

  const runOut = run("node", ["cicd-lab/run-lab.mjs", `cicd-multitest-${Date.now()}`], {});
  const projMatch = /Project: .* \(([a-f0-9-]+)\)/.exec(runOut.stdout);
  const teardownMatch = /destroy-lab\.mjs (\S+) "([^"]+)"/.exec(runOut.stdout);
  const runStatusMatch = /Run status: (\w+)/.exec(runOut.stdout);
  record(M, "TC-01", "a real pipeline run provisions all 7 core services via shell stages calling the real API", runOut.code === 0 && runStatusMatch?.[1] === "READY" ? "PASS" : "FAIL", runOut.code === 0 ? `run status=${runStatusMatch?.[1]}` : runOut.stderr.trim());

  const projectId = projMatch?.[1];
  const [, , email] = teardownMatch ?? [];
  if (projectId) {
    const login = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password: "password123" }) });
    const token = login.body.token;
    const names = { networks: "vpc-cicd-lab", subnets: "subnet-cicd-lab", "firewall-rules": "fw-cicd-lab", instances: "web-cicd-lab", disks: "disk-cicd-lab", buckets: "bucket-cicd-lab", databases: "database-cicd-lab" };
    const ready = await verifyAllReady(projectId, token, null, names);
    record(M, "TC-02", "all 7 resources independently verified READY via GET (not just the pipeline's own stage output)", ready.ok ? "PASS" : "FAIL", ready.detail ?? "");

    // Negative: a pipeline stage that fails should mark the run FAILED and skip later stages -- proving this is real
    // sequential execution with real fail-fast semantics, not a label that always reports success.
    const badPipeline = {
      name: "broken-pipeline-negative-test",
      stages: [
        { name: "will-fail", command: "exit 7" },
        { name: "should-be-skipped", command: "echo this should never run" },
      ],
    };
    const pipe = await api(`/projects/${projectId}/pipelines`, { method: "POST", body: JSON.stringify(badPipeline) }, token);
    let pipelineId = pipe.body?.resource?.id;
    for (let i = 0; i < 20 && pipelineId; i++) {
      const rows = (await api(`/projects/${projectId}/pipelines`, {}, token)).body;
      if (rows.find((r) => r.id === pipelineId)?.status === "READY") break;
      await new Promise((r) => setTimeout(r, 500));
    }
    const runRes = await api(`/projects/${projectId}/pipeline-runs`, { method: "POST", body: JSON.stringify({ pipelineId }) }, token);
    const runId = runRes.body?.resource?.id;
    let runRow;
    for (let i = 0; i < 60 && runId; i++) {
      const rows = (await api(`/projects/${projectId}/pipeline-runs`, {}, token)).body;
      runRow = rows.find((r) => r.id === runId);
      if (runRow?.status === "READY" || runRow?.status === "FAILED") break;
      await new Promise((r) => setTimeout(r, 1000));
    }
    const stages = runRow?.metadata?.stages ?? [];
    const skipped = stages.find((s) => s.name === "should-be-skipped");
    record(
      M,
      "TC-03 (negative)",
      "a stage that exits non-zero fails the run and skips remaining stages (real fail-fast, not a fixed success label)",
      runRow?.status === "FAILED" && skipped?.status === "SKIPPED" ? "PASS" : "FAIL",
      `run.status=${runRow?.status}, skipped-stage.status=${skipped?.status}`,
    );

    const destroyOut = run("node", ["cicd-lab/destroy-lab.mjs", projectId, email], {});
    record(M, "TC-04", "destroy-lab tears down all 7 resources through real DELETE endpoints", destroyOut.code === 0 && destroyOut.stdout.includes("Destroy complete") ? "PASS" : "FAIL", destroyOut.code === 0 ? "" : destroyOut.stderr.trim());

    const gone = await verifyAllGone(projectId, token, names);
    record(M, "TC-05", "all 7 resources independently verified gone via GET", gone.ok ? "PASS" : "FAIL", gone.detail ?? "");
  } else {
    record(M, "TC-02..05", "skipped -- could not parse project id from run-lab.mjs output", "FAIL", runOut.stdout.slice(0, 300));
  }
}

async function main() {
  console.log("=== CloudLab multi-method test suite ===\n");
  console.log("--- Method 1: JSON CLI ---");
  await testJsonCli();
  console.log("\n--- Method 2: Terraform-lab ---");
  await testTerraformLab();
  console.log("\n--- Method 3: gcloud-style CLI ---");
  await testGcloudCli();
  console.log("\n--- Method 4: CI/CD pipeline ---");
  await testCicdPipeline();

  const pass = results.filter((r) => r.status === "PASS").length;
  const fail = results.filter((r) => r.status === "FAIL").length;
  console.log(`\n=== Summary: ${pass}/${results.length} passed, ${fail} failed ===`);
  writeFileSync(path.join(ROOT, "test-results/multi-method-results.json"), JSON.stringify({ runAt: new Date().toISOString(), pass, fail, total: results.length, results }, null, 2));
  if (fail > 0) process.exit(1);
}

main().catch((err) => {
  console.error("FATAL:", err);
  process.exit(1);
});

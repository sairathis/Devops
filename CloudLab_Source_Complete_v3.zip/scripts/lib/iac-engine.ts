// Shared plan/apply/destroy engine against the real CloudLab REST API.
//
// This is the one real implementation behind BOTH of CloudLab's
// infrastructure-as-code tools:
//   - scripts/cloudlab-cli.ts        -- reads a plain JSON desired-state file
//   - terraform-lab/engine/tf-lab.ts -- reads real .tf-style HCL files
// Both parse their own input format into the same PlanResource[] shape and
// hand it to the functions here, so there is exactly one place that talks
// to the API, resolves references, and drives a real apply/destroy to
// completion -- consistent with the rest of this codebase's "one real
// implementation, multiple front ends" pattern (e.g. the pipeline runner's
// shell library vs. the console's own fetch calls).
//
// See scripts/cloudlab-cli.ts's file header for why this exists instead of
// a real Terraform provider (short version: the sandbox this was built in
// has no network path to install `terraform` or fetch terraform-plugin-go's
// gRPC/protobuf dependency tree).

export const TYPE_PATHS: Record<string, string> = {
  network: "networks",
  subnet: "subnets",
  firewall_rule: "firewall-rules",
  dns_record: "dns-records",
  load_balancer: "load-balancers",
  disk: "disks",
  registry: "registries",
  container_image: "images",
  bucket: "buckets",
  database: "databases",
  secret: "secrets",
  k8s_cluster: "k8s-clusters",
  k8s_deployment: "k8s-deployments",
  instance: "instances",
  // Milestone 15
  service_account: "service-accounts",
  instance_template: "instance-templates",
  managed_instance_group: "managed-instance-groups",
  nat_gateway: "nat-gateways",
  vpc_peering: "vpc-peerings",
  shared_vpc_attachment: "shared-vpc-attachments",
  bigquery_dataset: "bigquery-datasets",
  composer_environment: "composer-environments",
  cloud_run_service: "cloud-run-services",
};

export interface PlanResource {
  type: string;
  name: string;
  spec: Record<string, unknown>;
}
export interface PlanFile {
  projectId?: string;
  resources: PlanResource[];
}

export interface EngineConfig {
  api: string;
  token: string;
  projectId: string;
  log?: (line: string) => void;
}

async function apiCall(cfg: EngineConfig, path: string, opts: RequestInit = {}) {
  const headers: Record<string, string> = { "content-type": "application/json", ...(opts.headers as Record<string, string> | undefined) };
  if (cfg.token) headers.authorization = `Bearer ${cfg.token}`;
  const res = await fetch(`${cfg.api}${path}`, { ...opts, headers });
  const text = await res.text();
  const body = text ? JSON.parse(text) : undefined;
  if (!res.ok) throw new Error(`${opts.method ?? "GET"} ${path} -> ${res.status}: ${body?.message ?? text}`);
  return body;
}

function resolveRefs(spec: Record<string, unknown>, nameToId: Map<string, string>): Record<string, unknown> {
  function walk(v: unknown): unknown {
    if (typeof v === "string" && v.startsWith("$")) {
      const ref = v.slice(1);
      const id = nameToId.get(ref);
      if (!id) throw new Error(`unresolved reference "$${ref}" -- is it defined earlier in resources[]?`);
      return id;
    }
    if (Array.isArray(v)) return v.map(walk);
    if (v && typeof v === "object") return Object.fromEntries(Object.entries(v as object).map(([k, val]) => [k, walk(val)]));
    return v;
  }
  return walk(spec) as Record<string, unknown>;
}

function specHasUnresolvedRefs(spec: Record<string, unknown>, nameToId: Map<string, string>): boolean {
  try {
    resolveRefs(spec, nameToId);
    return false;
  } catch {
    return true;
  }
}

async function currentResourcesByType(cfg: EngineConfig, type: string) {
  const path = TYPE_PATHS[type];
  if (!path) throw new Error(`unknown resource type "${type}" -- add it to TYPE_PATHS`);
  const rows = await apiCall(cfg, `/projects/${cfg.projectId}/${path}`);
  return (rows as Array<{ id: string; name: string; status: string }>).filter((r) => r.status !== "DELETED");
}

async function waitForOperation(cfg: EngineConfig, operationId: string, timeoutMs = 60_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const op = await apiCall(cfg, `/projects/${cfg.projectId}/operations/${operationId}`);
    if (op.status === "SUCCEEDED" || op.status === "FAILED") return op;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`operation ${operationId} did not finish within ${timeoutMs}ms`);
}

export interface PlanLine {
  action: "create" | "unchanged";
  type: string;
  name: string;
  id?: string;
}

export async function planResources(cfg: EngineConfig, resources: PlanResource[]): Promise<PlanLine[]> {
  const lines: PlanLine[] = [];
  for (const desired of resources) {
    const existing = await currentResourcesByType(cfg, desired.type);
    const match = existing.find((r) => r.name === desired.name);
    lines.push(match ? { action: "unchanged", type: desired.type, name: desired.name, id: match.id } : { action: "create", type: desired.type, name: desired.name });
  }
  return lines;
}

export interface ApplyResultRow {
  type: string;
  name: string;
  id: string;
  alreadyExisted: boolean;
}

export async function applyResources(cfg: EngineConfig, resources: PlanResource[]): Promise<ApplyResultRow[]> {
  const log = cfg.log ?? (() => {});
  const nameToId = new Map<string, string>();
  const alreadyExisted = new Set<string>();
  const typesUsed = [...new Set(resources.map((r) => r.type))];
  for (const type of typesUsed) {
    for (const r of await currentResourcesByType(cfg, type)) {
      nameToId.set(r.name, r.id);
      alreadyExisted.add(r.name);
    }
  }

  const remaining = resources.filter((r) => !nameToId.has(r.name));
  let progressed = true;
  while (remaining.length > 0 && progressed) {
    progressed = false;
    for (let i = remaining.length - 1; i >= 0; i--) {
      const desired = remaining[i];
      if (specHasUnresolvedRefs(desired.spec, nameToId)) continue;
      const resolvedSpec = resolveRefs(desired.spec, nameToId);
      const path = TYPE_PATHS[desired.type];
      log(`  creating ${desired.type}.${desired.name} ...`);
      const res = await apiCall(cfg, `/projects/${cfg.projectId}/${path}`, { method: "POST", body: JSON.stringify({ name: desired.name, ...resolvedSpec }) });
      const op = await waitForOperation(cfg, res.operationId);
      if (op.status !== "SUCCEEDED") throw new Error(`${desired.type}.${desired.name} failed: ${op.error?.message ?? "unknown error"}`);
      nameToId.set(desired.name, res.resource.id);
      log(`    -> READY (id ${res.resource.id})`);
      remaining.splice(i, 1);
      progressed = true;
    }
  }
  if (remaining.length > 0) throw new Error(`could not resolve dependencies for: ${remaining.map((r) => r.name).join(", ")} -- check for a cycle or a typo'd reference`);

  return resources.map((r) => ({ type: r.type, name: r.name, id: nameToId.get(r.name)!, alreadyExisted: alreadyExisted.has(r.name) }));
}

export async function destroyResources(cfg: EngineConfig, resources: PlanResource[]): Promise<void> {
  const log = cfg.log ?? (() => {});
  const toDelete: { type: string; id: string; name: string }[] = [];
  for (const type of [...new Set(resources.map((r) => r.type))]) {
    for (const r of await currentResourcesByType(cfg, type)) {
      if (resources.some((d) => d.type === type && d.name === r.name)) toDelete.push({ type, id: r.id, name: r.name });
    }
  }

  let progressed = true;
  while (toDelete.length > 0 && progressed) {
    progressed = false;
    for (let i = toDelete.length - 1; i >= 0; i--) {
      const target = toDelete[i];
      const path = TYPE_PATHS[target.type];
      try {
        log(`  deleting ${target.type}.${target.name} ...`);
        const res = await apiCall(cfg, `/projects/${cfg.projectId}/${path}/${target.id}`, { method: "DELETE" });
        await waitForOperation(cfg, res.operationId);
        log(`    -> DELETED`);
        toDelete.splice(i, 1);
        progressed = true;
      } catch (err) {
        log(`    (blocked, retrying later: ${(err as Error).message})`);
      }
    }
  }
  if (toDelete.length > 0) throw new Error(`could not delete (dependency cycle or external dependent?): ${toDelete.map((t) => t.name).join(", ")}`);
}

#!/usr/bin/env -S npx tsx
// CloudLab's own declarative infra-as-code CLI -- a real, working `plan` /
// `apply` / `destroy` workflow against the real CloudLab REST API.
//
// Why this exists instead of a real Terraform provider (Milestone 7 as
// originally scoped): a real Terraform provider needs a real `terraform`
// binary to load it into, and building one requires either the HashiCorp
// release binary (releases.hashicorp.com and apt.releases.hashicorp.com are
// both network-blocked in this sandbox) or compiling terraform-plugin-sdk/
// terraform-plugin-go from source (proxy.golang.org is blocked, and
// github.com's git/HTTP endpoint returns 403 here too -- only
// raw.githubusercontent.com happens to be reachable, nowhere near enough to
// vendor a real gRPC + protobuf dependency tree by hand). There is no
// engineering workaround for a genuinely unreachable dependency, so rather
// than claim a "Terraform provider" that cannot actually load into a real
// terraform binary, this CLI honestly delivers the workflow's core value
// instead: declarative desired-state config, a real diff against live
// state, and a real apply that provisions genuine infrastructure through
// the exact same REST API the console uses. It is terraform-inspired, not
// Terraform-compatible -- it does not read HCL, and it is not a drop-in
// replacement for `terraform plan`/`apply`. (For an HCL-reading version of
// the same idea, see terraform-lab/ -- it parses real .tf-style files into
// the same PlanResource[] shape and calls the exact same engine below.)
//
// Usage:
//   npx tsx scripts/cloudlab-cli.ts plan    -f infra.json
//   npx tsx scripts/cloudlab-cli.ts apply   -f infra.json
//   npx tsx scripts/cloudlab-cli.ts destroy -f infra.json
//
// Config env (or flags): CLOUDLAB_API, CLOUDLAB_TOKEN, CLOUDLAB_PROJECT
//
// infra.json shape:
// {
//   "projectId": "...",                       // optional if CLOUDLAB_PROJECT is set
//   "resources": [
//     { "type": "network", "name": "vpc-main", "spec": { "cidr": "172.31.0.0/24" } },
//     { "type": "instance", "name": "web-01", "spec": { "networkId": "$vpc-main" } }
//   ]
// }
//
// A spec value of "$<name>" is resolved to that other managed resource's
// real id once it exists -- this is the same kind of implicit dependency
// graph Terraform builds from resource references, just derived from a
// plain string convention instead of HCL's expression language.

import { readFileSync } from "node:fs";
import { planResources, applyResources, destroyResources, type PlanFile, type EngineConfig } from "./lib/iac-engine.js";

const API = process.env.CLOUDLAB_API ?? "http://localhost:4000/api/v1";
const TOKEN = process.env.CLOUDLAB_TOKEN ?? "";

async function loadPlan(path: string): Promise<{ plan: PlanFile; cfg: EngineConfig }> {
  const plan: PlanFile = JSON.parse(readFileSync(path, "utf8"));
  const projectId = plan.projectId ?? process.env.CLOUDLAB_PROJECT;
  if (!projectId) throw new Error("no projectId -- set it in the plan file or CLOUDLAB_PROJECT");
  if (!TOKEN) throw new Error("CLOUDLAB_TOKEN is not set -- log in via POST /auth/login and export the token first");
  return { plan, cfg: { api: API, token: TOKEN, projectId, log: (line) => console.log(line) } };
}

async function cmdPlan(planPath: string) {
  const { plan, cfg } = await loadPlan(planPath);
  console.log(`CloudLab plan against project ${cfg.projectId}\n`);
  const lines = await planResources(cfg, plan.resources);
  let creates = 0;
  let noops = 0;
  for (const line of lines) {
    if (line.action === "unchanged") {
      console.log(`  = ${line.type}.${line.name} (unchanged, id ${line.id})`);
      noops++;
    } else {
      console.log(`  + ${line.type}.${line.name} (will be created)`);
      creates++;
    }
  }
  console.log(`\nPlan: ${creates} to create, ${noops} unchanged.`);
}

async function cmdApply(planPath: string) {
  const { plan, cfg } = await loadPlan(planPath);
  console.log(`CloudLab apply against project ${cfg.projectId}\n`);
  const rows = await applyResources(cfg, plan.resources);
  console.log(`\nApply complete: ${rows.length} resource(s) managed.`);
}

async function cmdDestroy(planPath: string) {
  const { plan, cfg } = await loadPlan(planPath);
  console.log(`CloudLab destroy against project ${cfg.projectId}\n`);
  await destroyResources(cfg, plan.resources);
  console.log(`\nDestroy complete.`);
}

async function main() {
  const [, , cmd, ...rest] = process.argv;
  const fIndex = rest.indexOf("-f");
  const planPath = fIndex >= 0 ? rest[fIndex + 1] : "infra.json";

  if (cmd === "plan") return cmdPlan(planPath);
  if (cmd === "apply") return cmdApply(planPath);
  if (cmd === "destroy") return cmdDestroy(planPath);
  console.log("usage: cloudlab-cli.ts <plan|apply|destroy> -f <file.json>");
  process.exit(1);
}

main().catch((err) => {
  console.error(`error: ${(err as Error).message}`);
  process.exit(1);
});

# CloudLab — Database

PostgreSQL is the single source of truth for everything except in-flight
Docker state itself (which is queried live via the Docker Engine API when
needed). Schema is defined with Drizzle ORM at
`apps/api/src/db/schema.ts`; migrations live in `apps/api/drizzle/` and are
generated with `npm run db:generate` and applied with `npm run db:migrate`.

## Entity overview

```
users ──< org_memberships >── organizations ──< projects ──< project_memberships >── users
                                                   │
                                                   ├──< resources >──┐
                                                   │                 │
                                                   │   resource_relationships
                                                   │  (from_resource_id, to_resource_id, kind)
                                                   │
                                                   ├──< operations (async job envelope)
                                                   │
                                                   └──< audit_logs (also references org/user)

resources ──< resource_events (status transition history)
```

## Tables

**`users`** — `id, email (unique), password_hash, name, created_at`.
Passwords are bcrypt-hashed (bcryptjs — pure JS, no native build step).

**`organizations`** — `id, name, slug (unique)`. The top of the hierarchy;
a user's role here (`owner`/`admin`/`developer`/`viewer`) is the fallback
IAM source when a project has no explicit binding for that user.

**`org_memberships`** — join table, one row per (org, user), carries
`role_key`. Unique on `(org_id, user_id)`.

**`projects`** — belongs to an org, has its own `slug` unique within the
org, records `created_by`.

**`project_memberships`** — join table, one row per (project, user),
carries `role_key`. This is what `POST /projects/:id/iam/bindings` upserts
(`onConflictDoUpdate` on `(project_id, user_id)`).

**`resources`** — the generic resource model (spec section 6). Every
provisionable thing (`network`, `instance`, and any future type) is one row
here:

| column | notes |
|---|---|
| `type` | `"network"` \| `"instance"` today; the model doesn't hardcode a fixed enum, new types are additive |
| `status` | `CREATING → PROVISIONING → READY`, or `→ FAILED`; also `STOPPING/STOPPED`, `DELETING/DELETED`, `UPDATING/DEGRADED` per the lifecycle spec |
| `spec` | jsonb — what the caller asked for (e.g. `{cidr}`, `{networkId, machineType, image, publish}`) |
| `metadata` | jsonb — what the worker actually observed after provisioning (e.g. `{dockerNetworkId, cidr}`, `{containerId, ip, hostPort, publicUrl}`) |
| `labels` | jsonb — free-form user labels, unused by any built-in feature yet |
| `version` | optimistic-concurrency counter, incremented on update |

Unique on `(project_id, name)` — resource names are unique per project, like
real cloud APIs.

**`resource_relationships`** — `from_resource_id → to_resource_id`, typed by
`kind` (`contains | connects_to | routes_to | depends_on | exposes`). This
table plus `resources` is the *entire* input to the architecture graph
(`resources/graph.ts`) — nothing about the graph is hand-drawn or cached.
It is also what `assertDeletable()` walks to block deleting a resource that
something else still depends on (excluding dependents that are themselves
already `DELETED`).

**`resource_events`** — append-only status-transition log per resource
(`from_status → to_status`, optional `message`). Written by
`setResourceStatus()` every time a resource's status changes, independent
of the audit log (this is resource history; audit log is request history).

**`operations`** — the async job envelope every mutating call returns an id
for. `steps` is a jsonb array the worker appends named progress entries to
(e.g. `VALIDATING`, `NETWORKING`, `VM_PROVISIONING`, `HEALTH_CHECK`,
`READY`), each broadcast over WebSocket as it happens. `error` holds a
structured failure when `status` ends at `FAILED`.

**`audit_logs`** — one row per HTTP request, always, written by the global
`onResponse` hook regardless of whether the specific route annotated
`req.audit`. Carries `org_id`/`project_id`/`user_id`, `ip`, `user_agent`,
`request_id`, `action`, `resource_type/id/name`, `previous_state`/
`new_state` (jsonb, when the route provided them), `status`
(`SUCCESS`/`ERROR`), `error`, `api_endpoint`, `http_method`, `source`
(`api`/`ui`/`cli` via an `x-cloudlab-source` header), `auth_method`,
`duration_ms`. There is deliberately no PATCH/DELETE route for this table —
per spec section 16, audit logs are never editable from the API.

## Indexes

Every foreign-key-shaped lookup the API actually performs has a
corresponding index: `resources` by `project_id`/`type`/`status` and a
unique `(project_id, name)`; `resource_relationships` by both
`from_resource_id` and `to_resource_id`; `operations` by `project_id` and
`resource_id`; `audit_logs` by `project_id`, `user_id`, `action`, and
`created_at` (the last one backs the activity/audit timeline's
`ORDER BY created_at DESC`).

## Migrations

Generated migration: `apps/api/drizzle/0000_lean_susan_delgado.sql` (the
name is Drizzle's auto-generated migration slug). Applied at startup time
via `apps/api/src/db/migrate.ts`, which uses
`drizzle-orm/node-postgres/migrator`. There is currently exactly one
migration — the full schema above was designed up front rather than evolved
incrementally, since this is a first build pass.

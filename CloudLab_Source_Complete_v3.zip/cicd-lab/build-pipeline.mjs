#!/usr/bin/env node
// Generates cicd-lab/pipeline-core-infra.json -- the body to POST to
// /projects/:projectId/pipelines to create a real CI/CD pipeline that
// provisions the "core services" lab set (VPC network, subnet, firewall
// rule, instance, disk, bucket, database) purely through sequential shell
// stages calling CloudLab's own REST API -- the same API the console, the
// JSON CLI, the Terraform-lab, and the gcloud-style CLI all use.
//
// Why a generator script instead of hand-writing the JSON: each stage's
// `command` is a shell one-liner with several layers of quoting (JSON
// inside a shell string inside a JSON file), and building it in JS makes
// that mechanical instead of error-prone. See README.md in this directory
// for how the pipeline is actually wired to reach the real API from inside
// its runner container (host.docker.internal + a short-lived real token
// injected as CLOUDLAB_TOKEN/CLOUDLAB_API/CLOUDLAB_PROJECT -- see
// apps/worker/src/processors/pipelineRun.ts).
//
// Usage: node cicd-lab/build-pipeline.mjs > cicd-lab/pipeline-core-infra.json

const LIB = `
extract() { # extract <json> <field> -- naive but sufficient for this lab's flat response fields
  R="$1"; F="$2"
  V=\${R#*\\"$F\\":\\"}
  V=\${V%%\\"*}
  echo "$V"
}
poll_ready() { # poll_ready <resource-path-plural> <id> [maxSeconds=40] -- waits for status READY
  PATHSEG="$1"; ID="$2"; MAX="\${3:-40}"
  i=0
  while [ $i -lt "$MAX" ]; do
    ROW=$(wget -qO- --header="Authorization: Bearer $CLOUDLAB_TOKEN" "$CLOUDLAB_API/projects/$CLOUDLAB_PROJECT/$PATHSEG/$ID")
    ST=$(extract "$ROW" status)
    if [ "$ST" = "READY" ]; then echo "$PATHSEG/$ID -> READY"; return 0; fi
    if [ "$ST" = "FAILED" ]; then echo "$PATHSEG/$ID -> FAILED: $ROW"; return 1; fi
    i=$((i+1)); sleep 1
  done
  echo "$PATHSEG/$ID did not reach READY in time"; return 1
}
create() { # create <path-plural> <json-body> [maxSeconds] -- POSTs, extracts resource.id, polls it to READY, echoes the id
  PATHSEG="$1"; BODY="$2"; MAX="$3"
  RESP=$(wget -qO- --header="Authorization: Bearer $CLOUDLAB_TOKEN" --header="content-type: application/json" --post-data="$BODY" "$CLOUDLAB_API/projects/$CLOUDLAB_PROJECT/$PATHSEG")
  ID=$(extract "$RESP" id)
  if [ -z "$ID" ]; then echo "create $PATHSEG failed: $RESP" >&2; return 1; fi
  poll_ready "$PATHSEG" "$ID" "$MAX" >&2 || return 1
  echo "$ID"
}
`.trim();

const stages = [
  {
    name: "setup",
    command: `cat > /workspace/lib.sh <<'EOF'\n${LIB}\nEOF\necho "lib installed"`,
  },
  {
    name: "network",
    command: `. /workspace/lib.sh
NET_ID=$(create networks '{"name":"vpc-cicd-lab","cidr":"10.90.0.0/24"}') || exit 1
echo "$NET_ID" > /workspace/network_id
echo "network=$NET_ID"`,
  },
  {
    name: "subnet",
    command: `. /workspace/lib.sh
NET_ID=$(cat /workspace/network_id)
SUB_ID=$(create subnets "{\\"name\\":\\"subnet-cicd-lab\\",\\"networkId\\":\\"$NET_ID\\",\\"cidr\\":\\"10.90.0.0/25\\"}") || exit 1
echo "$SUB_ID" > /workspace/subnet_id
echo "subnet=$SUB_ID"`,
  },
  {
    name: "firewall",
    command: `. /workspace/lib.sh
NET_ID=$(cat /workspace/network_id)
FW_ID=$(create firewall-rules "{\\"name\\":\\"fw-cicd-lab\\",\\"networkResourceId\\":\\"$NET_ID\\",\\"direction\\":\\"ingress\\",\\"action\\":\\"ALLOW\\",\\"protocol\\":\\"tcp\\",\\"portRange\\":\\"80\\",\\"cidr\\":\\"0.0.0.0/0\\"}") || exit 1
echo "firewall=$FW_ID"`,
  },
  {
    name: "instance",
    command: `. /workspace/lib.sh
NET_ID=$(cat /workspace/network_id)
SUB_ID=$(cat /workspace/subnet_id)
INST_ID=$(create instances "{\\"name\\":\\"web-cicd-lab\\",\\"networkId\\":\\"$NET_ID\\",\\"subnetId\\":\\"$SUB_ID\\"}") || exit 1
echo "$INST_ID" > /workspace/instance_id
echo "instance=$INST_ID"`,
  },
  {
    name: "disk",
    command: `. /workspace/lib.sh
DISK_ID=$(create disks '{"name":"disk-cicd-lab","sizeGb":5}') || exit 1
echo "disk=$DISK_ID"`,
  },
  {
    name: "bucket",
    command: `. /workspace/lib.sh
BUCKET_ID=$(create buckets '{"name":"bucket-cicd-lab"}') || exit 1
echo "bucket=$BUCKET_ID"`,
  },
  {
    name: "database",
    command: `. /workspace/lib.sh
DB_ID=$(create databases '{"name":"database-cicd-lab"}') || exit 1
echo "database=$DB_ID"`,
  },
];

const pipeline = { name: "core-infra-cicd-lab", stages };
console.log(JSON.stringify(pipeline, null, 2));

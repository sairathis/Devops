#!/usr/bin/env node
// End-to-end runner for the CI/CD lab's Milestone-15 extension: registers a
// throwaway user, creates an org/project, submits
// cicd-lab/pipeline-platform-services.json as a real pipeline, triggers a
// run, waits for it, and prints every stage's real output plus the final
// state of the platform-services resources it provisioned. This proves the
// exact same generic pipeline mechanism used for core-infra (a pipeline
// stage is just a shell command hitting the real REST API) needs zero code
// changes to provision NAT Gateways, Service Accounts, Instance Templates,
// Managed Instance Groups, BigQuery datasets, and Cloud Run services -- only
// a new pipeline JSON, exactly like the JSON CLI and Terraform-lab needed
// only a TYPE_PATHS entry (see scripts/lib/iac-engine.ts).
//
// Usage: node cicd-lab/run-platform-services-lab.mjs [projectName]
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { randomInt } from "node:crypto";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const API = process.env.CLOUDLAB_API_BASE ?? "http://localhost:4000/api/v1";

// Same CIDR-collision-avoidance rationale as run-lab.mjs: this pipeline's
// fixed 10.95.0.0/24 network is randomized across a wide range of /24s to
// keep collision odds low against whatever else is on the Docker host, with
// a retry if a run still lands on an occupied block.
function randomCidrPipeline() {
  const oct2 = randomInt(1, 250);
  const oct3 = randomInt(0, 250);
  const pipelineRaw = readFileSync(path.join(HERE, "pipeline-platform-services.json"), "utf8").replaceAll("10.95.0.0", `10.${oct2}.${oct3}.0`);
  return JSON.parse(pipelineRaw);
}

async function api(p, opts = {}) {
  const res = await fetch(`${API}${p}`, { ...opts, headers: { "content-type": "application/json", ...(opts.headers ?? {}) } });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`${opts.method ?? "GET"} ${p} -> ${res.status}: ${JSON.stringify(body)}`);
  return body;
}

async function main() {
  const stamp = Date.now();
  const email = `platformcicdlab-${stamp}@cloudlab.dev`;
  const reg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: "Platform Services CI/CD Lab", email, password: "password123" }) });
  const auth = { headers: { authorization: `Bearer ${reg.token}` } };

  const org = await api("/organizations", { method: "POST", ...auth, body: JSON.stringify({ name: "Platform Services CI/CD Lab Org" }) });
  const projectName = process.argv[2] ?? `platform-cicd-lab-${stamp}`;
  const project = await api("/projects", { method: "POST", ...auth, body: JSON.stringify({ orgId: org.id, name: projectName }) });
  console.log(`Project: ${project.name} (${project.id})\n`);

  let runRow;
  let pipelineDef;
  const maxAttempts = 3;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    pipelineDef = randomCidrPipeline();
    const pipe = await api(`/projects/${project.id}/pipelines`, { method: "POST", ...auth, body: JSON.stringify(pipelineDef) });
    const pipelineId = pipe.resource.id;
    for (let i = 0; i < 20; i++) {
      const rows = await api(`/projects/${project.id}/pipelines`, auth);
      if (rows.find((r) => r.id === pipelineId)?.status === "READY") break;
      await new Promise((r) => setTimeout(r, 500));
    }

    console.log(`Triggering pipeline run (attempt ${attempt}/${maxAttempts}) ...`);
    const run = await api(`/projects/${project.id}/pipeline-runs`, { method: "POST", ...auth, body: JSON.stringify({ pipelineId }) });
    const runId = run.resource.id;
    // This pipeline provisions a Managed Instance Group and a dedicated
    // Postgres server (BigQuery dataset), both slower than core-infra's
    // stages -- give it more time and a longer poll window.
    for (let i = 0; i < 180; i++) {
      const rows = await api(`/projects/${project.id}/pipeline-runs`, auth);
      runRow = rows.find((r) => r.id === runId);
      if (runRow.status === "READY" || runRow.status === "FAILED") break;
      await new Promise((r) => setTimeout(r, 1000));
    }

    const networkStageFailed = runRow.metadata?.stages?.find((s) => s.name === "network" && s.status === "FAILED");
    const isCidrCollision = networkStageFailed && /overlaps with network/.test(networkStageFailed.output ?? "");
    if (runRow.status === "READY" || !isCidrCollision) break;
    console.log(`  (CIDR collision on attempt ${attempt}, retrying with a new randomly-chosen /24 ...)`);
  }

  console.log(`\nRun status: ${runRow.status}\n`);
  for (const s of runRow.metadata?.stages ?? []) {
    console.log(`--- stage ${s.name} (${s.status}, exit ${s.exitCode}) ---`);
    console.log((s.output ?? "").trim());
  }

  console.log("\nResources provisioned:");
  for (const kind of ["networks", "nat-gateways", "service-accounts", "instance-templates", "managed-instance-groups", "bigquery-datasets", "cloud-run-services"]) {
    const rows = await api(`/projects/${project.id}/${kind}`, auth);
    for (const r of rows) console.log(`  ${kind.padEnd(24)} ${r.name.padEnd(28)} ${r.status}`);
  }

  console.log(`\nDone. To tear this down: node cicd-lab/destroy-platform-services-lab.mjs ${project.id} "${email}"`);
}

main().catch((err) => {
  console.error("FATAL:", err.message);
  process.exit(1);
});

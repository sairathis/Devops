#!/usr/bin/env node
// Tears down every resource in a platform-services CI/CD-lab project through
// the real DELETE endpoints, in dependency order, retrying a
// DEPENDENCY_EXISTS response the same way destroy-lab.mjs and the JSON CLI's
// `destroy` command do.
//
// Usage: node cicd-lab/destroy-platform-services-lab.mjs <projectId> <email> [password=password123]
const API = process.env.CLOUDLAB_API_BASE ?? "http://localhost:4000/api/v1";

async function api(p, opts = {}) {
  const res = await fetch(`${API}${p}`, { ...opts, headers: { "content-type": "application/json", ...(opts.headers ?? {}) } });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`${opts.method ?? "GET"} ${p} -> ${res.status}: ${JSON.stringify(body)}`);
  return body;
}

async function main() {
  const [projectId, email, password = "password123"] = process.argv.slice(2);
  if (!projectId || !email) {
    console.log("usage: node cicd-lab/destroy-platform-services-lab.mjs <projectId> <email> [password]");
    process.exit(1);
  }
  const login = await api("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
  const auth = { headers: { authorization: `Bearer ${login.token}` } };

  // Reverse dependency order: cloud-run-services/managed-instance-groups
  // (depend on network+template) before instance-templates, nat-gateways
  // and bigquery-datasets (independent) before networks last.
  const order = ["cloud-run-services", "managed-instance-groups", "instance-templates", "bigquery-datasets", "service-accounts", "nat-gateways", "networks"];
  let anyDeleted = true;
  while (anyDeleted) {
    anyDeleted = false;
    for (const kind of order) {
      const rows = await api(`/projects/${projectId}/${kind}`, auth).catch(() => []);
      for (const r of rows) {
        if (r.status === "DELETED" || r.status === "DELETING") continue;
        try {
          await api(`/projects/${projectId}/${kind}/${r.id}`, { method: "DELETE", ...auth });
          console.log(`deleted ${kind}/${r.name}`);
          anyDeleted = true;
        } catch (err) {
          console.log(`  (blocked, will retry: ${kind}/${r.name}: ${err.message.slice(0, 120)})`);
        }
      }
    }
    if (anyDeleted) await new Promise((r) => setTimeout(r, 1500)); // let async deletes finish before the next pass
  }
  console.log("Destroy complete.");
}

main().catch((err) => {
  console.error("FATAL:", err.message);
  process.exit(1);
});

#!/usr/bin/env node
// End-to-end runner for the CI/CD lab: registers a throwaway user, creates
// an org/project, submits cicd-lab/pipeline-core-infra.json as a real
// pipeline, triggers a run, waits for it, and prints every stage's real
// output plus the final state of the seven resources it provisioned.
//
// Usage: node cicd-lab/run-lab.mjs [projectName]
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { randomInt } from "node:crypto";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const API = process.env.CLOUDLAB_API_BASE ?? "http://localhost:4000/api/v1";

// The generated pipeline hardcodes 10.90.0.0/24 (network) and 10.90.0.0/25
// (subnet) for readability -- but CIDRs are checked for collisions across
// the whole Docker host (Milestone 13), not just within one project, so a
// run against a host that already has *some* other network (from this lab,
// the console, another lab, or a previous run that was never torn down)
// sitting on the same block would otherwise fail at the network stage.
// There is no client-side way to see every other project's real CIDR
// choices (the API deliberately doesn't expose one project's resources to
// another -- that's a real access-control boundary, not an oversight), so
// this can only lower collision odds, not eliminate them, exactly like a
// real IPAM allocator racing other real allocators: randomize BOTH the
// second and third octet across a wide range (this pipeline's fixed
// 10.90.0.0/24 becomes one of ~62,000 equally-likely /24s), and if a run
// still lands on an occupied block, retry with a freshly randomized one.
function randomCidrPipeline() {
  const oct2 = randomInt(1, 250);
  const oct3 = randomInt(0, 250);
  const pipelineRaw = readFileSync(path.join(HERE, "pipeline-core-infra.json"), "utf8").replaceAll("10.90.0.0", `10.${oct2}.${oct3}.0`);
  return JSON.parse(pipelineRaw);
}

async function api(p, opts = {}) {
  const res = await fetch(`${API}${p}`, { ...opts, headers: { "content-type": "application/json", ...(opts.headers ?? {}) } });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`${opts.method ?? "GET"} ${p} -> ${res.status}: ${JSON.stringify(body)}`);
  return body;
}

async function main() {
  const stamp = Date.now();
  const email = `cicdlab-${stamp}@cloudlab.dev`;
  const reg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: "CICD Lab", email, password: "password123" }) });
  const auth = { headers: { authorization: `Bearer ${reg.token}` } };

  const org = await api("/organizations", { method: "POST", ...auth, body: JSON.stringify({ name: "CI/CD Lab Org" }) });
  const projectName = process.argv[2] ?? `cicd-lab-${stamp}`;
  const project = await api("/projects", { method: "POST", ...auth, body: JSON.stringify({ orgId: org.id, name: projectName }) });
  console.log(`Project: ${project.name} (${project.id})\n`);

  // Retry with a freshly randomized CIDR if (and only if) the run fails
  // specifically because the network stage hit a real CIDR collision --
  // the same real Milestone-13 constraint every other front end hits, not
  // something worth hiding, just something worth not letting flake this
  // lab's result on a low-probability random draw.
  let runRow;
  let pipelineDef;
  const maxAttempts = 3;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    pipelineDef = randomCidrPipeline();
    const pipe = await api(`/projects/${project.id}/pipelines`, { method: "POST", ...auth, body: JSON.stringify(pipelineDef) });
    const pipelineId = pipe.resource.id;
    for (let i = 0; i < 20; i++) {
      const rows = await api(`/projects/${project.id}/pipelines`, auth);
      if (rows.find((r) => r.id === pipelineId)?.status === "READY") break;
      await new Promise((r) => setTimeout(r, 500));
    }

    console.log(`Triggering pipeline run (attempt ${attempt}/${maxAttempts}) ...`);
    const run = await api(`/projects/${project.id}/pipeline-runs`, { method: "POST", ...auth, body: JSON.stringify({ pipelineId }) });
    const runId = run.resource.id;
    for (let i = 0; i < 120; i++) {
      const rows = await api(`/projects/${project.id}/pipeline-runs`, auth);
      runRow = rows.find((r) => r.id === runId);
      if (runRow.status === "READY" || runRow.status === "FAILED") break;
      await new Promise((r) => setTimeout(r, 1000));
    }

    const networkStageFailed = runRow.metadata?.stages?.find((s) => s.name === "network" && s.status === "FAILED");
    const isCidrCollision = networkStageFailed && /overlaps with network/.test(networkStageFailed.output ?? "");
    if (runRow.status === "READY" || !isCidrCollision) break;
    console.log(`  (CIDR collision on attempt ${attempt}, retrying with a new randomly-chosen /24 ...)`);
  }

  console.log(`\nRun status: ${runRow.status}\n`);
  for (const s of runRow.metadata?.stages ?? []) {
    console.log(`--- stage ${s.name} (${s.status}, exit ${s.exitCode}) ---`);
    console.log((s.output ?? "").trim());
  }

  console.log("\nResources provisioned:");
  for (const kind of ["networks", "subnets", "firewall-rules", "instances", "disks", "buckets", "databases"]) {
    const rows = await api(`/projects/${project.id}/${kind}`, auth);
    for (const r of rows) console.log(`  ${kind.padEnd(16)} ${r.name.padEnd(24)} ${r.status}`);
  }

  console.log(`\nDone. To tear this down: node cicd-lab/destroy-lab.mjs ${project.id} "${email}"`);
}

main().catch((err) => {
  console.error("FATAL:", err.message);
  process.exit(1);
});

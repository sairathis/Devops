# CI/CD Lab — provisioning core infrastructure from a real pipeline

This directory demonstrates CloudLab's CI/CD pipeline (Milestone 8) doing
something a label-only CI/CD simulation couldn't: a pipeline stage's shell
command genuinely calls back into CloudLab's own REST API — the exact same
API the console, the JSON CLI (`scripts/cloudlab-cli.ts`), the
Terraform-lab, and the gcloud-style CLI all use — and provisions **real**
infrastructure (a real Docker network, a real container, a real volume,
and so on) as a side effect of a CI job running.

## How a pipeline stage reaches the API

A pipeline run's stages all execute inside one real, ephemeral runner
container (see `apps/worker/src/processors/pipelineRun.ts`). For that
container to call back into the API running on the host, two things are
wired up when the container is created:

1. `--add-host=host.docker.internal:host-gateway` — the standard Docker
   mechanism for a container to reach a service bound on the host, which
   (unlike Docker Desktop) has to be requested explicitly on plain Linux
   `dockerd`.
2. A **real, normally-issued JWT** — the same `signToken()` that
   `/auth/login` uses — minted server-side for whichever user owns the
   pipeline run, deliberately short-lived (15 minutes, comfortably longer
   than any run here but nowhere near a login session's lifetime so a
   leaked pipeline log can't be replayed as a standing credential).

The runner container receives three environment variables as a result:

| Variable | Value |
|---|---|
| `CLOUDLAB_API` | `http://host.docker.internal:4000/api/v1` |
| `CLOUDLAB_PROJECT` | the pipeline's own project id |
| `CLOUDLAB_TOKEN` | a real, 15-minute-lived bearer token for the run's owner |

Nothing about the API routes themselves knows or cares that the caller is
a pipeline stage rather than a browser or a CLI — it's the same
`requireProjectPermission` / IAM check every other caller goes through.

## What's in this directory

- **`build-pipeline.mjs`** — generates `pipeline-core-infra.json` from
  readable JS template strings (the alternative is hand-writing a shell
  script wrapped in a JSON string wrapped in a JSON file, which is exactly
  as unpleasant to maintain as it sounds).
- **`pipeline-core-infra.json`** — the ready-to-POST pipeline definition:
  eight stages (`setup`, `network`, `subnet`, `firewall`, `instance`,
  `disk`, `bucket`, `database`) that together provision one of each of the
  lab's seven core services, each stage polling its own resource to a real
  READY (or failing loudly on a real FAILED) before the next stage runs.
- **`run-lab.mjs`** — an end-to-end runner: registers a throwaway user,
  creates an org/project, submits the pipeline above, triggers a run,
  waits for it, and prints every stage's real output plus a final listing
  of the seven resources it created (all genuinely READY).
- **`destroy-lab.mjs`** — tears every resource in the target project back
  down through the real DELETE endpoints, in dependency order, retrying a
  `DEPENDENCY_EXISTS` response the same way the JSON CLI's `destroy`
  command does.

## Running it

```bash
node cicd-lab/build-pipeline.mjs > cicd-lab/pipeline-core-infra.json   # regenerate if you edit it
node cicd-lab/run-lab.mjs                                              # provisions everything, prints the project id
node cicd-lab/destroy-lab.mjs <projectId>                              # tears it back down
```

You can also paste the contents of `pipeline-core-infra.json` directly
into a `POST /api/v1/projects/:id/pipelines` call (or, once the console
grows a "paste pipeline JSON" affordance, into the CI/CD tab) against any
existing project — it doesn't need to be the one `run-lab.mjs` creates.

## Milestone 15: the same mechanism, zero new code, seven new services

`pipeline-platform-services.json` / `run-platform-services-lab.mjs` /
`destroy-platform-services-lab.mjs` are the Milestone 15 counterpart to
the three files above — same `lib.sh` shell library, same
`setup`/`create`/`poll_ready` pattern, same runner/destroyer shape — but
provisioning a NAT Gateway, a Service Account, an Instance Template, a
Managed Instance Group, a BigQuery dataset, and a Cloud Run service
instead of the seven core services. Nothing in `apps/api`, `apps/worker`,
or the pipeline-runner mechanism itself changed to support this — the
`requireProjectPermission`/REST-API path a pipeline stage calls into is
exactly the one described above, so a new resource type only ever needs a
new pipeline JSON, never a code change. That is the same generic-by-design
property `scripts/lib/iac-engine.ts`'s `TYPE_PATHS` map already proved for
the JSON CLI and Terraform-lab (see `terraform-lab/README.md`).

```bash
node cicd-lab/run-platform-services-lab.mjs                              # provisions all seven, prints the project id
node cicd-lab/destroy-platform-services-lab.mjs <projectId> <email>      # tears it back down
```

`composer_environment` is intentionally left out of this pipeline for the
same reason it's left out of `terraform-lab/configs/platform-services.tf`:
it needs a real `pipeline_id` to schedule, and authoring a *second*,
nested pipeline definition inside this lab's flat JSON stage list would
only exercise the same `create`/`poll_ready` mechanism a second time, not
demonstrate anything new. Composer's CI/CD creation path is documented
directly in the services report instead (create the target pipeline
first, by any method, then `create composer-environments '{"name":...,
"pipelineId":"<id>","cronSchedule":"..."}'` from a stage exactly like any
other resource here).

## The `extract`/`poll_ready`/`create` shell library

Each stage sources a tiny POSIX-`sh` library (`/workspace/lib.sh`, written
by the `setup` stage into the run's own shared workspace volume) built
entirely from `ash`/busybox built-ins — parameter expansion for JSON field
extraction, no `jq`, `sed`, or `awk`, since the guest image's busybox build
doesn't include them:

- `extract <json> <field>` — pulls a flat `"field":"value"` string field
  out of a JSON response body.
- `poll_ready <path-plural> <id> [maxSeconds=40]` — polls
  `GET .../<path-plural>/<id>` until its `status` is `READY` (or fails
  loudly on `FAILED`, or after `maxSeconds`).
- `create <path-plural> <json-body> [maxSeconds]` — `POST`s the body,
  extracts the new resource's id, polls it to `READY`, and echoes the id
  so the caller can capture it (`ID=$(create ...)`) and hand it to a later
  stage via a file in `/workspace`, the same way real CI stages pass
  artifacts between steps.

## Honest scope

This is real, but it is not meant to imply a full CI/CD-as-IaC product:
there's no rollback-on-partial-failure beyond the pipeline's existing
fail-fast/SKIPPED semantics, no drift detection, and the `extract` helper
only handles flat string fields (fine for every ID/status field used
here, not a general JSON parser). It demonstrates the same underlying
capability a real "Terraform-in-CI" job would rely on: a CI runner with
real credentials and real network access to the platform's own control
plane.

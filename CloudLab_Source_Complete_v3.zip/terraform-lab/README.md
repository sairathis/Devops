# Terraform Lab — real `.tf`-style config, real infrastructure

This lab lets you write genuine `.tf`-syntax files (`resource "type" "name" { ... }`
blocks, real HCL literals, real cross-resource references) and run a real
`plan` / `apply` / `destroy` against them, provisioning the exact same real
Docker-backed infrastructure the console, the JSON CLI, the gcloud-style
CLI, and the CI/CD pipelines all provision — through the exact same REST
API and the exact same underlying engine (`scripts/lib/iac-engine.ts`).

## Why this isn't a real Terraform provider

A real Terraform provider is a Go binary that speaks gRPC to the real
`terraform` binary over Terraform's plugin protocol. Building one here
would need either the HashiCorp release binary (`releases.hashicorp.com`
and `apt.releases.hashicorp.com` are both network-blocked in this sandbox)
or compiling `terraform-plugin-go` from source (`proxy.golang.org` is
blocked, and `github.com`'s git/HTTP endpoints return 403 here too — only
`raw.githubusercontent.com` happens to be reachable, nowhere near enough to
vendor a real gRPC + protobuf dependency tree by hand). That's a genuinely
unreachable dependency, not a shortcut — so rather than fake a "Terraform
provider" that could never actually load into a real `terraform` binary,
this lab is honest about being CloudLab's own thing: a hand-rolled parser
for a deliberately narrow *subset* of real HCL syntax
(`terraform-lab/engine/tf-lab.ts`, no HashiCorp code, no HCL library), that
feeds into the same real plan/apply/destroy engine the JSON CLI uses.

You can point a real `terraform` binary at a `.tf` file from this
directory and it would be perfectly valid HCL as far as *syntax* goes —
what it lacks is a `terraform-provider-cloudlab` for that binary to load,
which is precisely the piece that can't be built in this sandbox.

## What's in this directory

- **`engine/tf-lab.ts`** — the HCL-subset parser: strips comments,
  brace-matches `resource "cloudlab_<type>" "<label>" { ... }` blocks,
  parses each attribute line, and converts the result into the same
  `PlanResource[]` shape `scripts/cloudlab-cli.ts`'s JSON files parse into.
- **`tf-lab-cli.ts`** — the `plan` / `apply` / `destroy` command-line tool,
  a direct sibling of `scripts/cloudlab-cli.ts` that reads `.tf` files
  instead of JSON but calls the identical `scripts/lib/iac-engine.ts`
  functions underneath.
- **`configs/core-services.tf`** — a real example: one VPC network, one
  subnet, one firewall rule, one compute instance, one disk, one storage
  bucket, and one managed database, wired together with real dependency
  references.

## Supported grammar

```hcl
resource "cloudlab_<type>" "<label>" {
  <snake_case_key> = <value>
  ...
}
```

- **Resource types**: any of `network`, `subnet`, `firewall_rule`,
  `dns_record`, `load_balancer`, `disk`, `registry`, `container_image`,
  `bucket`, `database`, `secret`, `k8s_cluster`, `k8s_deployment`,
  `instance` — spelled `cloudlab_<type>` (e.g. `cloudlab_firewall_rule`),
  matching CloudLab's own resource-type names, not any real cloud
  provider's.
- **Values**: `"string literals"`, bare numbers (`20`, `1.5`), `true` /
  `false`, and `[ "array", "of", "values" ]` — the same JSON-compatible
  value set the JSON CLI supports, just written as HCL literals.
- **References**: `cloudlab_<type>.<label>.id` refers to another
  resource's real id once it's created (e.g.
  `cloudlab_network.vpc_main.id`) — internally this becomes the exact
  same `"$vpc_main"` string convention `scripts/lib/iac-engine.ts` already
  resolves, just spelled the way real Terraform spells a resource
  reference. **The referenced resource must appear earlier or later in
  the same file** — the engine resolves references by repeatedly retrying
  unresolved resources until nothing more can progress (the same
  fixed-point approach the JSON CLI uses), so order in the file doesn't
  matter, but a reference to a resource that doesn't exist anywhere in the
  file fails loudly at `apply` time.
- **Comments**: `# ...`, `// ...`, and `/* ... */` — all standard HCL
  comment forms.
- **A block's label IS its real resource name.** `resource
  "cloudlab_network" "vpc_main" { ... }` creates a resource actually named
  `vpc_main`, and that's also the identifier `$vpc_main`/
  `cloudlab_network.vpc_main.id` references resolve against. Real
  Terraform separates a resource's *local address* from its cloud-side
  `name` attribute; this lab deliberately keeps them identical (the same
  simplification the JSON CLI's plain `"name"` field already makes), so
  setting an explicit `name = "..."` attribute is rejected with an error
  rather than silently accepted — allowing it to diverge would let a
  reference resolve against the wrong string.

## What real Terraform features this deliberately does NOT support

No `variable` / `local` / `output` blocks, no `provider` blocks (there is
exactly one provider, the CloudLab API, wired through
`CLOUDLAB_API`/`CLOUDLAB_TOKEN`/`CLOUDLAB_PROJECT` env vars — see below),
no modules, no `for_each`/`count`, no expression language beyond a literal
or a single `<type>.<label>.id` reference, no state file (state is simply
"whatever currently exists in the project," queried fresh on every `plan`/
`apply`/`destroy`, exactly like the JSON CLI), and no plan approval step
between `plan` and `apply`.

## Running it

```bash
export CLOUDLAB_API=http://localhost:4000/api/v1
export CLOUDLAB_TOKEN=<a real JWT from POST /auth/login>
export CLOUDLAB_PROJECT=<a real project id>

npx tsx terraform-lab/tf-lab-cli.ts plan    -f terraform-lab/configs/core-services.tf
npx tsx terraform-lab/tf-lab-cli.ts apply   -f terraform-lab/configs/core-services.tf
npx tsx terraform-lab/tf-lab-cli.ts destroy -f terraform-lab/configs/core-services.tf
```

`plan` diffs the file against whatever's actually in the project right
now; `apply` creates whatever's missing (in dependency order, same
fixed-point retry as the JSON CLI) and is safe to re-run — a second
`apply` reports everything `unchanged`; `destroy` deletes everything the
file describes, retrying anything blocked by a `DEPENDENCY_EXISTS`
response until the whole set is gone or nothing more can progress.

## Verified end-to-end

`plan` → `apply` → `plan` (idempotent, 0 to add) → `destroy`, run against
a real project, has been exercised for `configs/core-services.tf`: all
seven resources reached real `READY` status backed by real Docker
containers/volumes (confirmed via `docker ps` showing
`cloudlab-vm-<instance-id>` actually running), and `destroy` removed all
seven cleanly. Parse-time and apply-time error handling was also
exercised: an unrecognized resource type, a rejected `name` attribute, and
a reference to a resource that doesn't exist in the file all fail with a
specific, honest error message rather than silently doing the wrong
thing.

#!/usr/bin/env -S npx tsx
// The Terraform-lab CLI: `plan` / `apply` / `destroy` against real .tf-style
// files, using CloudLab's own hand-rolled HCL-subset parser (engine/tf-lab.ts)
// and the exact same real apply/destroy engine scripts/cloudlab-cli.ts's JSON
// workflow uses (scripts/lib/iac-engine.ts) -- see README.md in this
// directory for the supported HCL grammar and why this isn't a real
// Terraform provider.
//
// Usage:
//   npx tsx terraform-lab/tf-lab-cli.ts plan    -f configs/core-services.tf
//   npx tsx terraform-lab/tf-lab-cli.ts apply   -f configs/core-services.tf
//   npx tsx terraform-lab/tf-lab-cli.ts destroy -f configs/core-services.tf
//
// Config env: CLOUDLAB_API, CLOUDLAB_TOKEN, CLOUDLAB_PROJECT (same as the
// JSON CLI -- there is no per-file provider block; this lab has exactly one
// "provider", the CloudLab API itself).

import { readFileSync } from "node:fs";
import { parseTf, tfBlocksToPlanResources } from "./engine/tf-lab.js";
import { planResources, applyResources, destroyResources, type PlanResource, type EngineConfig } from "../scripts/lib/iac-engine.js";

const API = process.env.CLOUDLAB_API ?? "http://localhost:4000/api/v1";
const TOKEN = process.env.CLOUDLAB_TOKEN ?? "";

function loadTf(path: string): { resources: PlanResource[]; cfg: EngineConfig } {
  const projectId = process.env.CLOUDLAB_PROJECT;
  if (!projectId) throw new Error("CLOUDLAB_PROJECT is not set");
  if (!TOKEN) throw new Error("CLOUDLAB_TOKEN is not set -- log in via POST /auth/login and export the token first");
  const src = readFileSync(path, "utf8");
  const blocks = parseTf(src);
  const resources = tfBlocksToPlanResources(blocks) as PlanResource[];
  return { resources, cfg: { api: API, token: TOKEN, projectId, log: (line) => console.log(line) } };
}

async function cmdPlan(path: string) {
  const { resources, cfg } = loadTf(path);
  console.log(`Terraform-lab plan (${path}) against project ${cfg.projectId}\n`);
  const lines = await planResources(cfg, resources);
  let creates = 0;
  let noops = 0;
  for (const line of lines) {
    if (line.action === "unchanged") {
      console.log(`  = cloudlab_${line.type}.${line.name} (unchanged, id ${line.id})`);
      noops++;
    } else {
      console.log(`  + cloudlab_${line.type}.${line.name} (will be created)`);
      creates++;
    }
  }
  console.log(`\nPlan: ${creates} to add, ${noops} unchanged.`);
}

async function cmdApply(path: string) {
  const { resources, cfg } = loadTf(path);
  console.log(`Terraform-lab apply (${path}) against project ${cfg.projectId}\n`);
  const rows = await applyResources(cfg, resources);
  console.log(`\nApply complete! Resources: ${rows.length} managed.`);
}

async function cmdDestroy(path: string) {
  const { resources, cfg } = loadTf(path);
  console.log(`Terraform-lab destroy (${path}) against project ${cfg.projectId}\n`);
  await destroyResources(cfg, resources);
  console.log(`\nDestroy complete! Resources destroyed.`);
}

async function main() {
  const [, , cmd, ...rest] = process.argv;
  const fIndex = rest.indexOf("-f");
  const tfPath = fIndex >= 0 ? rest[fIndex + 1] : "configs/core-services.tf";

  if (cmd === "plan") return cmdPlan(tfPath);
  if (cmd === "apply") return cmdApply(tfPath);
  if (cmd === "destroy") return cmdDestroy(tfPath);
  console.log("usage: tf-lab-cli.ts <plan|apply|destroy> -f <file.tf>");
  process.exit(1);
}

main().catch((err) => {
  console.error(`error: ${(err as Error).message}`);
  process.exit(1);
});

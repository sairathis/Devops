# CloudLab Terraform-lab example -- provisions one of each of the seven
# "core services" through real .tf-style config: a VPC network, a subnet,
# a firewall rule, a compute instance, a persistent disk, a storage bucket,
# and a managed database.
#
# This is parsed by CloudLab's own hand-rolled HCL-subset engine
# (terraform-lab/engine/tf-lab.ts), NOT by hashicorp/hcl or a real
# `terraform` binary -- see README.md in this directory for exactly which
# slice of real HCL syntax is supported (resource blocks, string/number/
# bool/array literals, and cloudlab_<type>.<name>.id references) and which
# parts of real Terraform this deliberately does not attempt (no modules,
# no variables/locals, no provider blocks, no state file, no expression
# language beyond attribute references).
#
# Run it with:
#   npx tsx terraform-lab/tf-lab-cli.ts plan    -f terraform-lab/configs/core-services.tf
#   npx tsx terraform-lab/tf-lab-cli.ts apply   -f terraform-lab/configs/core-services.tf
#   npx tsx terraform-lab/tf-lab-cli.ts destroy -f terraform-lab/configs/core-services.tf

resource "cloudlab_network" "vpc_main" {
  cidr = "10.20.0.0/24"
}

resource "cloudlab_subnet" "subnet_web" {
  network_id = cloudlab_network.vpc_main.id
  cidr       = "10.20.0.0/25"
}

resource "cloudlab_firewall_rule" "allow_http" {
  network_resource_id = cloudlab_network.vpc_main.id
  direction            = "ingress"
  action               = "ALLOW"
  protocol             = "tcp"
  port_range           = "80"
  cidr                 = "0.0.0.0/0"
}

resource "cloudlab_instance" "web01" {
  network_id = cloudlab_network.vpc_main.id
  subnet_id  = cloudlab_subnet.subnet_web.id
}

resource "cloudlab_disk" "data01" {
  size_gb = 20
}

resource "cloudlab_bucket" "uploads" {
}

resource "cloudlab_database" "app_db" {
}

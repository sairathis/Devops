# CloudLab Terraform-lab example -- Milestone 15's GCP Platform/DevOps
# architect pass: NAT Gateway, VPC Peering, Shared VPC, Service Accounts,
# Instance Templates, Managed Instance Groups, and BigQuery/Cloud Run's
# honest substitutes, all provisioned through the same real .tf-style
# engine as core-services.tf.
#
# Not included here: cloudlab_composer_environment. Its `pipeline_id`
# attribute needs a real `cloudlab_pipeline` resource, and a pipeline's
# `stages` attribute is an array of OBJECTS ({name=..., command=...}) --
# this HCL subset (see README.md) supports strings/numbers/bools/arrays and
# references, but not object literals, so a pipeline can't be authored in
# this file. You can still target composer from Terraform-lab against a
# pipeline created another way (console/CLI/gcloud-lab), by hardcoding its
# real id as a plain string: `pipeline_id = "<existing-pipeline-id>"`.
#
# Run it with:
#   npx tsx terraform-lab/tf-lab-cli.ts plan    -f terraform-lab/configs/platform-services.tf
#   npx tsx terraform-lab/tf-lab-cli.ts apply   -f terraform-lab/configs/platform-services.tf
#   npx tsx terraform-lab/tf-lab-cli.ts destroy -f terraform-lab/configs/platform-services.tf

resource "cloudlab_network" "vpc_platform_a" {
  cidr = "10.40.0.0/24"
}

resource "cloudlab_network" "vpc_platform_b" {
  cidr = "10.41.0.0/24"
}

# GCP Cloud NAT equivalent -- real iptables MASQUERADE on vpc_platform_a's bridge.
resource "cloudlab_nat_gateway" "nat_a" {
  network_resource_id = cloudlab_network.vpc_platform_a.id
}

# GCP VPC Network Peering equivalent -- real iptables FORWARD ACCEPT between
# the two networks' bridges.
resource "cloudlab_vpc_peering" "peer_a_b" {
  network_a_id = cloudlab_network.vpc_platform_a.id
  network_b_id = cloudlab_network.vpc_platform_b.id
}

# GCP IAM Service Account equivalent -- a real RSA-2048 keypair.
resource "cloudlab_service_account" "deploy_bot" {
  account_id = "deploy-bot-sa"
}

# GCP Instance Template equivalent -- a stored blueprint, no infra of its own.
resource "cloudlab_instance_template" "web_template" {
  image = "cloudlab/guest:latest"
}

# GCP Managed Instance Group equivalent -- real containers, self-healing
# reconciler keeps live count pinned to target_size.
resource "cloudlab_managed_instance_group" "web_group" {
  instance_template_id = cloudlab_instance_template.web_template.id
  network_id            = cloudlab_network.vpc_platform_a.id
  target_size           = 3
}

# Load balancer targeting the managed instance group's live members instead
# of a fixed instance list -- backend pool grows/shrinks/self-heals with it.
resource "cloudlab_load_balancer" "web_lb" {
  network_id                = cloudlab_network.vpc_platform_a.id
  backend_instance_ids       = []
  managed_instance_group_id = cloudlab_managed_instance_group.web_group.id
}

# BigQuery equivalent -- a real dedicated Postgres 16 server per dataset.
resource "cloudlab_bigquery_dataset" "analytics" {
  dataset_id = "analytics"
}

# Cloud Run equivalent -- registers config only; scaled to zero until invoked.
resource "cloudlab_cloud_run_service" "hello_service" {
  network_id            = cloudlab_network.vpc_platform_a.id
  idle_timeout_seconds = 60
}

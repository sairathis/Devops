// A minimal, hand-rolled parser for a *subset* of real HCL (HashiCorp
// Configuration Language) syntax -- the same file format `.tf` files use --
// that turns `resource "cloudlab_<type>" "<name>" { ... }` blocks into the
// same PlanResource[] shape scripts/cloudlab-cli.ts's JSON files parse into,
// and hands them to the exact same real engine (scripts/lib/iac-engine.ts)
// that talks to CloudLab's REST API.
//
// This is NOT a real Terraform provider and does not use HashiCorp's own
// HCL library (hashicorp/hcl is a Go module; there is no Node port, and
// vendoring it would mean compiling Go -- see cloudlab-cli.ts's file header
// for why a real `terraform` binary can't be installed in this sandbox at
// all). What follows is CloudLab's own small parser for a deliberately
// narrow slice of HCL syntax: enough to write genuinely real `.tf`-style
// config by hand and have it genuinely provision real infrastructure, not
// enough to run someone else's arbitrary Terraform module. See README.md
// in this directory for the exact supported grammar and its honest limits.

export interface TfResourceBlock {
  cloudlabType: string; // e.g. "network" (the "cloudlab_" prefix stripped from the HCL type)
  label: string; // the quoted resource label, e.g. "vpc_main" -- doubles as both the local
  // reference name (cloudlab_network.vpc_main.id) AND the real resource `name`
  // sent to the API, same simplification the JSON CLI's "name" field makes.
  attrs: Record<string, unknown>;
}

class ParseError extends Error {}

function stripComments(src: string): string {
  // Block comments /* ... */ (non-greedy, no nesting -- real HCL doesn't nest them either)
  let out = src.replace(/\/\*[\s\S]*?\*\//g, "");
  // Line comments: // ... and # ... to end of line, but never inside a "..." string
  const lines = out.split("\n").map((line) => {
    let inString = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"' && line[i - 1] !== "\\") inString = !inString;
      if (!inString && (line.startsWith("//", i) || line.startsWith("#", i))) {
        return line.slice(0, i);
      }
    }
    return line;
  });
  return lines.join("\n");
}

// Splits the file into top-level `resource "type" "label" { body }` blocks
// by scanning for the `resource` keyword and then brace-matching from the
// following `{` to its balanced `}` (bodies here are flat key=value pairs,
// but brace-matching is done properly anyway rather than assuming no
// nesting, since a block value like `{ key = "v" }` is legal HCL).
function splitResourceBlocks(src: string): { header: string; body: string }[] {
  const blocks: { header: string; body: string }[] = [];
  const re = /\bresource\s+"([^"]+)"\s+"([^"]+)"\s*\{/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    const openBraceIdx = m.index + m[0].length - 1;
    let depth = 1;
    let i = openBraceIdx + 1;
    let inString = false;
    for (; i < src.length && depth > 0; i++) {
      const c = src[i];
      if (c === '"' && src[i - 1] !== "\\") inString = !inString;
      if (inString) continue;
      if (c === "{") depth++;
      else if (c === "}") depth--;
    }
    if (depth !== 0) throw new ParseError(`unbalanced braces in resource "${m[1]}" "${m[2]}"`);
    blocks.push({ header: `${m[1]}::${m[2]}`, body: src.slice(openBraceIdx + 1, i - 1) });
    re.lastIndex = i;
  }
  return blocks;
}

function snakeToCamel(key: string): string {
  return key.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
}

// Parses one HCL "expression" -- deliberately a small subset:
//   "string literal"          -> string
//   123 / 12.5                -> number
//   true / false              -> boolean
//   cloudlab_TYPE.name.id     -> "$name" (a reference to another managed
//                                resource's id, resolved once it's created --
//                                exactly scripts/lib/iac-engine.ts's "$name"
//                                convention, just spelled the HCL way here)
//   [ expr, expr, ... ]       -> array of any of the above
function parseValue(raw: string): unknown {
  const v = raw.trim();
  if (v === "true") return true;
  if (v === "false") return false;
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  if (v.startsWith('"') && v.endsWith('"')) {
    return v
      .slice(1, -1)
      .replace(/\\"/g, '"')
      .replace(/\\\\/g, "\\");
  }
  if (v.startsWith("[") && v.endsWith("]")) {
    const inner = v.slice(1, -1).trim();
    if (!inner) return [];
    return splitTopLevelCommas(inner).map(parseValue);
  }
  // Bare reference expression, e.g. cloudlab_network.vpc_main.id
  const refMatch = /^cloudlab_[a-z0-9_]+\.([A-Za-z0-9_-]+)\.id$/.exec(v);
  if (refMatch) return `$${refMatch[1]}`;
  throw new ParseError(
    `cannot parse value "${v}" -- supported: "strings", numbers, true/false, [arrays], or a cloudlab_<type>.<name>.id reference`,
  );
}

function splitTopLevelCommas(s: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let inString = false;
  let cur = "";
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '"' && s[i - 1] !== "\\") inString = !inString;
    if (!inString) {
      if (c === "[") depth++;
      if (c === "]") depth--;
    }
    if (c === "," && depth === 0 && !inString) {
      parts.push(cur);
      cur = "";
    } else {
      cur += c;
    }
  }
  if (cur.trim()) parts.push(cur);
  return parts;
}

// Parses `key = value` lines inside a resource body. A value may itself
// span multiple lines only if it's an array (`[ ... ]` across lines) --
// handled by accumulating lines until brackets balance.
function parseBody(body: string): Record<string, unknown> {
  const attrs: Record<string, unknown> = {};
  const rawLines = body.split("\n");
  let pending = "";
  let bracketDepth = 0;
  for (const rawLine of rawLines) {
    const line = rawLine.trim();
    if (!line && !pending) continue;
    pending += (pending ? "\n" : "") + line;
    bracketDepth += (line.match(/\[/g) ?? []).length - (line.match(/\]/g) ?? []).length;
    if (bracketDepth > 0) continue; // wait for the closing bracket on a later line
    if (!pending.trim()) {
      pending = "";
      continue;
    }
    const eq = pending.indexOf("=");
    if (eq === -1) throw new ParseError(`expected "key = value", got: ${pending}`);
    const key = pending.slice(0, eq).trim();
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) throw new ParseError(`invalid attribute name "${key}"`);
    const valueRaw = pending.slice(eq + 1).trim();
    attrs[snakeToCamel(key)] = parseValue(valueRaw);
    pending = "";
  }
  if (pending.trim()) throw new ParseError(`unterminated attribute near: ${pending}`);
  return attrs;
}

export function parseTf(src: string): TfResourceBlock[] {
  const cleaned = stripComments(src);
  const blocks = splitResourceBlocks(cleaned);
  return blocks.map(({ header, body }) => {
    const [hclType, label] = header.split("::");
    if (!hclType.startsWith("cloudlab_")) {
      throw new ParseError(`unrecognized resource type "${hclType}" -- CloudLab resource types are spelled "cloudlab_<type>", e.g. "cloudlab_network"`);
    }
    const cloudlabType = hclType.slice("cloudlab_".length);
    return { cloudlabType, label, attrs: parseBody(body) };
  });
}

// Converts parsed HCL blocks into the shared engine's PlanResource[] shape.
// The HCL label doubles as BOTH the local reference key (what
// `cloudlab_network.vpc_main.id` resolves through) AND the resource's real
// `name` sent to the API -- the same simplification the JSON CLI's plain
// "name" field already makes, kept deliberately identical here so a `$name`
// reference always resolves against the same identifier a resource was
// created under. A `name = "..."` attribute inside the block is therefore
// rejected rather than silently accepted: allowing it to diverge from the
// label would let a reference resolve against the wrong string.
export interface PlanResourceLike {
  type: string;
  name: string;
  spec: Record<string, unknown>;
}

export function tfBlocksToPlanResources(blocks: TfResourceBlock[]): PlanResourceLike[] {
  return blocks.map((b) => {
    if ("name" in b.attrs) {
      throw new ParseError(
        `resource "cloudlab_${b.cloudlabType}" "${b.label}": don't set a "name" attribute -- the resource's real name IS its label ("${b.label}"), the same way scripts/cloudlab-cli.ts's JSON "name" field works`,
      );
    }
    return { type: b.cloudlabType, name: b.label, spec: b.attrs };
  });
}

# CloudLab — Architecture

CloudLab is a small, self-hosted "cloud platform simulator" that provisions
**real** local infrastructure (Docker containers and networks) behind a
GCP-like console, API, IAM system, and audit log. It exists to teach and
demonstrate cloud-platform concepts honestly: every resource it shows you is
either genuinely running or genuinely failed — never faked.

## System diagram

```
                        ┌─────────────────────────┐
   Browser  ───────────▶│  apps/api (Fastify)      │
   (plain JS SPA,       │  - REST API              │
    served as static    │  - JWT auth              │
    files by the API)   │  - IAM policy engine     │
                         │  - audit middleware      │──────┐
                         │  - WS hub (/ws)          │      │
                         │  - terminal (/ws/terminal)│     │
                         └───────────┬──────────────┘      │
                                     │ enqueue                │ pub/sub
                                     ▼                        │ (resource +
                         ┌──────────────────────────┐         │  operation
                         │  BullMQ queue (Redis)     │         │  events)
                         └───────────┬──────────────┘         │
                                     │ dequeue                │
                                     ▼                        │
                         ┌──────────────────────────┐         │
                         │  apps/worker (Node)       │─────────┘
                         │  - network.create/delete  │
                         │  - instance.create/       │
                         │    start/stop/delete      │
                         │  - health checks          │
                         └───────────┬──────────────┘
                                     │ Docker Engine API (dockerode)
                                     ▼
                         ┌──────────────────────────┐
                         │  Local Docker daemon      │
                         │  - real bridge networks   │
                         │  - real containers running│
                         │    cloudlab/guest:latest  │
                         └──────────────────────────┘

         ┌──────────────┐        ┌──────────────┐
         │  PostgreSQL   │        │    Redis      │
         │  (source of   │        │  (queue +     │
         │  truth: users,│        │  pub/sub bus) │
         │  resources,   │        └──────────────┘
         │  operations,  │
         │  audit log)   │
         └──────────────┘
```

## Why two processes (API + worker)

Every mutating API call (create/delete a network or instance) is
**asynchronous**: the route handler validates the request, writes a
`resources` row in `CREATING`, enqueues a BullMQ job, and returns
`202 { resource, operationId }` immediately. A separate worker process
dequeues the job and does the actual, potentially slow, real work (creating
a Docker network, starting a container, polling a health check). This
mirrors how real cloud APIs behave (an `Operation` you poll or watch) and
keeps the HTTP request/response cycle fast regardless of how long
provisioning takes.

Splitting these into two OS processes means they don't share memory, so two
plumbing problems had to be solved explicitly:

- **Cross-process live UI updates.** The worker publishes JSON events
  (`resource.update`, `operation.step`, `operation.update`) to a Redis pub/sub
  channel (`UPDATES_CHANNEL`) after every meaningful state change. The API
  subscribes to that channel and relays matching events to WebSocket clients
  scoped by `projectId` (`apps/api/src/ws/hub.ts`). This is how the console
  shows a network's status flipping from `CREATING` → `PROVISIONING` →
  `READY` live, without polling. The client-side dispatcher
  (`handleWsMessage()` in `apps/api/public/app.js`) routes each
  `resource.update` message to the right in-memory table via a single
  `RESOURCE_TYPE_TO_STATE_KEY` map covering every resource type this build
  has — see "Real bugs found and fixed in this layer" below for why that
  matters.
- **Shared DB schema without a shared package.** The worker imports the
  API's Drizzle schema and client via a relative cross-app path
  (`apps/worker/src/events.ts` imports `../../api/src/db/*.js`) rather than
  through `packages/shared`. This is a deliberate, documented simplification
  (see "Known limitations" below) — the two processes must actually run from
  the same monorepo checkout for this to work, which is true here but would
  need fixing before either process is deployed independently.

## Layers inside `apps/api`

- **`routes/`** — one file per resource family (auth, organizations,
  projects, networks, instances, operations, activity, audit, architecture).
  Every route file wraps its handlers in `app.register(async (app) => {...})`
  so its `authenticate` preHandler hook is Fastify-encapsulated and does not
  leak onto sibling routes (see "Known bugs found and fixed" in
  `TESTING.md` for why this matters).
- **`middleware/audit.ts`** — global `onRequest`/`onResponse` hooks plus the
  Fastify error handler. This is the mechanism that makes audit logging
  automatic rather than opt-in: it runs for every request, success or
  failure, whether or not the specific route handler ever thinks about
  auditing.
- **`iam/policy.ts`** — resolves a user's effective role for a project
  (project membership first, falling back to org membership) and evaluates
  glob-pattern allow/deny rules from `packages/shared`. As of Milestone 15,
  a second, narrower grant mechanism sits alongside this for exactly one
  purpose: a `shared_vpc_attachment` record scopes which specific service
  project may attach a resource to a host project's network — checked at
  attach time against a live grant row, not folded into the general
  role/policy engine, since it names a specific other *project*, not a role.
- **`resources/model.ts` / `resources/graph.ts`** — the generic resource
  CRUD + relationship bookkeeping, and the architecture graph builder that
  reads `resources` + `resource_relationships` fresh on every request.
- **`adapters/docker/`** — the only code in the API process that talks to
  Docker directly, and only for read-style operations (exec, logs). All
  provisioning/teardown happens in the worker.
- **`ws/`** — the live-updates hub and the real Tty-attached terminal proxy.

## Data flow for "create a network" (concrete example)

1. `POST /api/v1/projects/:id/networks {name, cidr}` →
   `requireProjectPermission` checks IAM → `createResource()` inserts a
   `resources` row with `status: "CREATING"` → `createOperation()` inserts
   an `operations` row → the job is enqueued on BullMQ → API responds
   `202 {resource, operationId}`.
2. `apps/worker` picks up the `network.create` job, calls
   `docker.createNetwork(...)` with a real IPAM subnet config, and on
   success calls `setResourceStatus(id, "READY", {dockerNetworkId, cidr})`
   and `addRelationship`/`publishResourceUpdate` as appropriate. On Docker
   failure (e.g. a genuine IPAM pool overlap), it calls
   `setResourceStatus(id, "FAILED", {error})` — this is not swallowed or
   retried silently.
3. The worker publishes a `resource.update` event to Redis; the API's WS
   hub relays it to any browser watching that project; the console's
   `handleWsMessage` patches the network's badge in place.
4. Independently of all of the above, the audit middleware has already
   written a `network.networks.create` row to `audit_logs` the moment the
   HTTP response was sent, with the `202` status, timing, and requester
   recorded.

## Provisioning methods beyond the console

The REST API described above is the one real backend every provisioning
method ultimately calls — the console is simply its first client. As of
Milestone 15 there are five ways to create the same real infrastructure,
all going through this same API, and all five now cover both the seven
"core services" (Milestone 14) and the nine platform/DevOps services added
in Milestone 15:

1. **Console** — the browser SPA described above.
2. **JSON CLI** (`scripts/cloudlab-cli.ts`) — a declarative `plan`/`apply`/
   `destroy` workflow reading a plain JSON desired-state file.
3. **Terraform-lab** (`terraform-lab/`) — the same plan/apply/destroy engine
   (extracted into `scripts/lib/iac-engine.ts` and shared with the JSON
   CLI), fed by a hand-rolled parser for a subset of real `.tf`/HCL syntax.
4. **gcloud-style CLI** (`gcloud-lab/gcloud.ts`) — a command surface shaped
   like real `gcloud`, with a locally cached account/project, talking only
   to CloudLab's own API.
5. **CI/CD pipeline** (`apps/worker/src/processors/pipelineRun.ts`) — a
   pipeline run's shell stages can call back into the real API from inside
   their ephemeral runner container via `host.docker.internal` plus a
   short-lived JWT minted for the run's owner.

None of these are separate backends or separate sources of truth — they are
five front ends for the one real resource model and operation pipeline
described above. See `ROADMAP.md`'s Milestone 7, Milestone 14, and Milestone
15 sections for why a real Hashicorp-loadable Terraform provider specifically
remains infeasible in this sandbox, and `terraform-lab/README.md` /
`gcloud-lab/README.md` / `cicd-lab/README.md` for each method's exact scope.

## Milestone 15: the platform/DevOps resource surface

Nine resource types were added on top of the same generic resource model,
IAM, audit, and worker-job machinery described above — no new subsystem,
no schema-level special-casing:

| Resource type | GCP mapping | Mechanism |
|---|---|---|
| `service_account` | IAM Service Account | real 2048-bit RSA keypair, private key AES-256-GCM-encrypted at rest (reuses Milestone 5's secrets envelope) |
| `instance_template` | Compute Engine Instance Template | a stored blueprint only — no infrastructure until referenced by a MIG |
| `managed_instance_group` | Compute Engine MIG | real containers from a template, kept at target size by a reconciler tick (same pattern as Milestone 6's k8s reconciler); can live-attach to a `load_balancer`'s backend list |
| `nat_gateway` | Cloud NAT | real host `iptables` MASQUERADE + `ip_forward` toggle on the network's bridge |
| `vpc_peering` | VPC Network Peering | real bidirectional `iptables FORWARD ACCEPT` between two networks' bridges |
| `shared_vpc_attachment` | Shared VPC | a real, narrowly-scoped cross-project grant, enforced at attach time (see `iam/policy.ts` note above) |
| `bigquery_dataset` | BigQuery | honest substitute: a real dedicated Postgres 16 server per dataset with a real ad-hoc SQL query endpoint |
| `composer_environment` | Cloud Composer | honest substitute: wraps a real `pipeline` on a real 5-field UTC cron scheduler tick |
| `cloud_run_service` | Cloud Run | real scale-to-zero: no container until the first Invoke, real idle-timeout stop |

Cloud SQL is deliberately *not* a new type — it's the existing `database`
resource (Milestone 5) under GCP's own name, a documentation decision, not
new code. Docker itself is documented as the infrastructure layer every
compute-shaped resource in this build actually runs on, not a GCP-mappable
service of its own. Full detail, fidelity ratings, and per-service creation/
test instructions for all nine: `test-results/CloudLab_Platform_Services_Report.pdf`.

## Real bugs found and fixed in this layer

Two genuine, previously-undiscovered production bugs surfaced while adding
Milestone 15 (both fixed, not merely worked around in a test script, per
this project's "no fake success" rule):

1. **`handleWsMessage()`'s resource-type routing was hardcoded to two
   types.** Before Milestone 15, the client-side WS dispatcher only ever
   patched `state.networks` or `state.instances` — every other resource
   type (all pre-existing types plus all nine new ones) only updated its
   console table on a manual refresh or reload, never live. This was a
   build-wide gap dating to Milestone 1, not something introduced by
   Milestone 15 — it just took nine more types to make it obvious. Fixed
   with the generic `RESOURCE_TYPE_TO_STATE_KEY` map referenced above.
2. **A real BigQuery query result would flash and vanish.** The console's
   universal `withErrorHandling()` button wrapper always calls a full
   `render()` immediately after a handler resolves; `renderBigquery()`'s
   "Run query" handler set its result on a local DOM node, which that
   rebuild then discarded on the very next tick. Fixed by moving query
   results into `state.bigqueryQueryResults`, which the render function
   now reads back explicitly.

## Known limitations (stated plainly, per the project's "no fake success" principle)

- No IPAM/quota-aware subnet allocator: CIDRs are user-supplied (the console
  suggests a random `/24` to reduce collisions, but a genuine overlap still
  surfaces as a real `FAILED` operation rather than being silently retried).
- Worker and API share the Postgres schema via a relative cross-app import,
  not a proper shared package — fine for this single-checkout deployment,
  a blocker for running them as independently-deployed services.
- A real Terraform *provider* (a genuine Hashicorp-loadable Go plugin) is
  not possible in this sandbox (no path to the `terraform` binary or to
  `terraform-plugin-go`'s dependency tree) — see "Provisioning methods
  beyond the console" above for the five real alternatives this build
  provides instead.
- The architecture graph renders as a simple box list, not a force-directed
  layout.
- The terminal (`/ws/terminal`) is a real Tty-attached `docker exec`, but
  the browser side sends whole lines (Enter-triggered), not raw keystroke-
  by-keystroke forwarding.
- BigQuery and Cloud Composer are documented honest substitutes (a real
  dedicated Postgres server and a real cron-triggered pipeline scheduler,
  respectively) rather than reimplementations of GCP's actual distributed
  query engine or Airflow-based DAG scheduler — see the Milestone 15
  mapping table above and `ROADMAP.md` for the reasoning.
- No OpenAPI/Swagger document is generated, despite the original spec
  wanting one.

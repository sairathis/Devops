# CloudLab — Infrastructure & Local Setup

CloudLab provisions **real** infrastructure on the machine it runs on: real
PostgreSQL, real Redis, a real Docker daemon, real Docker networks, and
real containers running a real (if minimal) Linux userland. There is no
mock/simulation layer standing in for any of this.

## Prerequisites

- Node.js 20+ and npm
- PostgreSQL (any recent version) reachable at `DATABASE_URL`
- Redis reachable at `REDIS_URL`
- A running Docker daemon reachable at `DOCKER_SOCKET`
  (`/var/run/docker.sock` by default)
- Go toolchain (only needed once, to build the guest image)

## One-time setup

```bash
# 1. Install dependencies (npm workspaces: apps/api, apps/worker, packages/shared)
npm install

# 2. Configure environment
cp .env.example .env
# edit .env if your Postgres/Redis/Docker socket aren't at the defaults

# 3. Create and migrate the database
createdb cloudlab   # or: psql -c "CREATE DATABASE cloudlab"
npm run db:migrate

# 4. Build the guest image (no external registry pull -- FROM scratch,
#    built entirely from a locally-compiled Go binary + apt's busybox-static)
bash infra/guest-image/build.sh
```

## Running it

Three long-running processes, each in its own terminal (or process
manager):

```bash
npm run dev:api      # Fastify API + static web console, on :4000
npm run dev:worker    # BullMQ worker: actually provisions/tears down Docker resources
```

Then open `http://localhost:4000`.

## Why the guest image is `FROM scratch`

The sandbox this was originally built in blocks egress to container
registries (Docker Hub, GHCR, etc. all return 403 through the proxy) but
allows the Ubuntu apt archives and the npm registry. Pulling any base image
(`alpine`, `busybox`, `debian-slim`, ...) was therefore not an option. The
guest image (`infra/guest-image/`) is instead built from nothing:

1. `guest-agent.go` — a small static Go HTTP server (`GET /` returns an
   HTML status page; `GET /healthz` returns `ok`) compiled with
   `CGO_ENABLED=0` so the resulting binary has zero dynamic library
   dependencies and runs directly under `FROM scratch`.
2. `busybox-static` (installed via `apt-get`, itself statically linked) is
   copied in and symlinked under ~25 common applet names (`sh`, `ls`,
   `cat`, `ps`, `hostname`, `ip`, `ping`, `nslookup`, ...), giving every
   container a genuine, if minimal, interactive shell and toolset — this
   is what makes the terminal (`/ws/terminal`) a real shell and not a
   canned response.
3. `docker build` assembles `rootfs/` into an ~11MB image entirely from
   local files — no network access needed at build time beyond the initial
   `apt-get install busybox-static`.

Run `bash infra/guest-image/build.sh` again any time you want to rebuild it
(e.g. after changing `guest-agent.go`).

## What the worker actually does to Docker

- **`network.create`**: `docker.createNetwork({Name, Driver: "bridge",
  IPAM: {Config: [{Subnet: cidr}]}})`. A genuine subnet overlap with an
  existing Docker network raises a real Docker error, which the worker
  writes back as the resource's `FAILED` status verbatim — it does not
  retry with a different subnet or hide the failure.
- **`network.delete`**: `network.remove()`, tolerating a 404 (already gone)
  so a delete is idempotent.
- **`instance.create`**: `docker.createContainer({Image: GUEST_IMAGE,
  HostConfig: {NetworkMode: <network's docker name>, PortBindings: ...},
  ExposedPorts: {"8080/tcp": {}}, RestartPolicy: {Name: "unless-stopped"}})`,
  then `container.start()`, then inspects the container for its assigned
  IP and (if published) host port, then polls
  `http://<ip>:8080/healthz` (guest agent) until it answers `ok` or a
  timeout is hit. Only then does the resource become `READY`.
- **`instance.start` / `instance.stop`**: `container.start()` /
  `container.stop()`.
- **`instance.delete`**: force-removes the container, tolerating 404.

Container and network **names** follow a fixed convention that both
processes must agree on (`containerNameFor(id) = cloudlab-vm-${id}`,
`networkNameFor(id) = cloudlab-net-${id}`) — duplicated in
`apps/api/src/adapters/docker/client.ts` and `apps/worker/src/docker.ts`
rather than shared, documented in-code as a known simplification.

## Cleaning up stray resources

Every `cloudlab-*`-prefixed container/network belongs to this app and is
safe to remove if you want a clean slate:

```bash
docker ps -a --format '{{.Names}}' | grep cloudlab-vm | xargs -r docker rm -f
docker network ls --format '{{.Name}}' | grep cloudlab-net | xargs -r docker network rm
```

## Environment variables (`.env`)

| var | default | purpose |
|---|---|---|
| `DATABASE_URL` | `postgresql://postgres:cloudlab@localhost:5432/cloudlab` | Postgres connection |
| `REDIS_URL` | `redis://localhost:6379` | BullMQ queue + pub/sub bus |
| `PORT` | `4000` | API/console HTTP port |
| `JWT_SECRET` | *(placeholder — override this)* | JWT signing secret |
| `JWT_EXPIRES_IN` | `12h` | token lifetime |
| `DOCKER_SOCKET` | `/var/run/docker.sock` | Docker Engine API socket |
| `GUEST_IMAGE` | `cloudlab/guest:latest` | image instances run |
| `INSTANCE_SUBNET_BASE` | `172.30.0.0/16` | documented convention for suggested CIDRs (not enforced/allocated automatically — see known limitations) |
| `PUBLIC_HOST` | `localhost` | host used when building `publicUrl` for published instance ports |

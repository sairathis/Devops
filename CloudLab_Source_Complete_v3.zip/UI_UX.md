# CloudLab — Web Console (UI/UX)

The console is a plain-JavaScript single-page app: no build step, no
framework, no bundler. It's served as static files by the API
(`apps/api/public/`) and loaded as an ES module (`<script type="module"
src="/app.js">`). This was a deliberate scope tradeoff for a first build
pass — no React/Vue toolchain to configure, no bundler output to keep in
sync, and every line of behavior is directly readable.

## Structure

- **`index.html`** — a near-empty shell (`<div id="app">`), IBM Plex Sans/
  Mono loaded from Google Fonts, `styles.css`.
- **`styles.css`** — a small hand-written design system: CSS custom
  properties for an ink/paper/accent (teal) palette plus semantic amber/
  red/blue, badge styles keyed by resource/operation status, and layout
  primitives (topbar, side nav, cards, tables, terminal, timeline, graph).
- **`app.js`** (~630 lines) — the entire application: state, rendering, and
  data loading, described below.

## Rendering model

There's no virtual DOM and no framework. `el(tag, attrs, children)` is a
small helper that builds real DOM nodes directly (supports `class`,
arbitrary attributes, and `onX` event handlers). Views are plain functions
(`renderDashboard()`, `renderNetworks()`, `renderInstanceDetail(id)`, ...)
that return a freshly-built DOM subtree from the current `state` object;
`renderMain()` replaces the main content area's children with whatever the
current tab's view function returns.

This is simple and easy to follow, but it has one real, known consequence:
a full re-render throws away any DOM the user was mid-interacting with
(e.g. typed but unsubmitted input in a create-resource form) if it happens
to fire at the wrong moment. Nav-tab switches are written to avoid
triggering this for the two tabs with create-forms (Networking, Compute) —
see the code comment at the nav `onclick` handler in `app.js` — but this is
a structural limitation of the "just re-render everything" approach, not
something fully solved.

## Live updates

`connectWs()` opens `GET /ws?token=...&projectId=...` on project load and
routes incoming messages through `handleWsMessage`:

- `resource.update` → patches the matching entry in `state.networks` /
  `state.instances` in place (by id) and re-renders — this is how a
  network/instance's badge flips from `CREATING` to `READY` live, without
  polling.
- `operation.step` → appends to `state.pendingOps[resourceId].steps`,
  rendered as a live step list under the resource it belongs to
  (`renderPendingPanel`).
- `operation.update` → updates the tracked operation's status; on a
  terminal state (`SUCCEEDED`/`FAILED`) it's kept visible briefly (4s) then
  cleared, so a fast success doesn't feel like nothing happened.

Nav-tab switches to Architecture/Activity/Audit/IAM additionally call
`refreshTabData()`, which re-fetches networks, instances, and the
architecture graph (and, per-tab, activity/audit/iam) before re-rendering —
these views aren't WS-patched, so without this they'd show a stale
snapshot from whenever the project was first opened. (This exact bug was
caught by the Playwright smoke test — see `TESTING.md`.)

## Navigation

Dashboard · Networking · Compute · Architecture · Activity · Audit Log ·
IAM, plus an org/project picker in the topbar. Clicking an instance opens
an in-page detail view (`state.tab = "instance:<id>"`) with an overview
table, a real exec-a-command panel, and a real interactive terminal
(`/ws/terminal`, Tty-attached `docker exec /bin/sh`) — genuinely
interactive, not a canned transcript.

## The architecture graph view

Rendered as a wrapped grid of boxes (one per resource, labeled with type +
status badge) plus a plain-text list of edges below (`A → kind → B`) —
not a force-directed/canvas graph layout. This was a deliberate scope
tradeoff: the graph is correctly *derived* (see `ARCHITECTURE.md`), but its
visual presentation is intentionally simple.

## Known UX rough edges

- No client-side form validation beyond "required" — server validation
  errors surface via a red error banner, which is functional but not
  polished.
- No pagination anywhere (activity/audit are capped server-side at
  200/500 rows respectively, which is generous enough for a demo but would
  need a real "load more" for long-lived projects).
- No dark mode.
- No optimistic UI on resource creation beyond the immediate `CREATING`
  row appearing — everything else genuinely waits for the worker/WS.

# Cloud Shell Lab — a gcloud-style CLI for CloudLab

`gcloud.ts` is a command-line tool shaped like real `gcloud`: the same
command-group structure (`compute networks create ...`), the same
`--flag=value` syntax, the same idea of a locally cached logged-in account
and active project (`gcloud auth login`, `gcloud config set project`) —
except every command genuinely calls CloudLab's own REST API and
provisions the exact same real Docker-backed infrastructure the console,
the JSON CLI, the Terraform-lab, and the CI/CD pipelines all provision.
Think of it as what a "Cloud Shell" session against CloudLab (instead of
real GCP) would feel like to type into.

## What this honestly is (and isn't)

This does **not** talk to any Google Cloud API, and it does not vendor or
wrap Google's real `gcloud` (a large Python codebase that itself talks to
dozens of real GCP services CloudLab doesn't have). It's CloudLab's own
small TypeScript CLI that mimics `gcloud`'s command shape for the seven
"core services" this cross-method lab covers, so that "create it with
gcloud" is a genuine, working option alongside the console, the JSON CLI,
Terraform-lab, and CI/CD — not just a description of what it would look
like.

Local state is limited to exactly what real `gcloud` caches locally: the
logged-in account's token and the active project id
(`gcloud-lab/.cloudshell/config.json`). Every `list`/`describe`/`create`/
`delete` queries or mutates CloudLab's real API on every call — there is no
local resource cache to go stale.

## Command surface

```
init                                            One-shot account + project setup (like real "gcloud init")
auth login --email=<e> --password=<p>           Log in and cache a token
auth list / auth revoke                         Show / clear cached credentials
config set project <id> / get-value project / list

compute networks create <name> --range=<cidr>
compute networks list|describe|delete <name>

compute networks subnets create <name> --network=<net> --range=<cidr>
compute networks subnets list|describe|delete <name>

compute firewall-rules create <name> --network=<net> --direction=INGRESS --action=ALLOW --rules=tcp:80 --source-ranges=0.0.0.0/0
compute firewall-rules list|describe|delete <name>

compute instances create <name> --network=<net> [--subnet=<sub>]
compute instances list|describe|delete <name>

compute disks create <name> [--size=<sizeGb>]
compute disks list|describe|delete <name>

storage buckets create gs://<name>
storage buckets list|describe|delete gs://<name>

sql instances create <name>
sql instances list|describe|delete <name>
```

`sql instances` is real `gcloud`'s own command group name for a managed
database instance (Cloud SQL) — used here for CloudLab's `database`
resource type for exactly that reason: it's the closest real-gcloud analog,
not a CloudLab invention.

Name flags (`--network=vpc-main`, `--subnet=subnet-web`) are resolved
client-side to that resource's real id by listing the target project's
resources of that type and matching on name — the same short-name
convenience real `gcloud` offers (there, resolved against a full resource
URL server-side; here, resolved directly against CloudLab's REST API since
there's exactly one "region" and one API to ask).

## Running it

```bash
npx tsx gcloud-lab/gcloud.ts init                      # registers a lab account + org + project, caches credentials
npx tsx gcloud-lab/gcloud.ts compute networks create vpc-main --range=10.0.0.0/24
npx tsx gcloud-lab/gcloud.ts compute networks subnets create subnet-web --network=vpc-main --range=10.0.0.0/25
npx tsx gcloud-lab/gcloud.ts compute firewall-rules create allow-http --network=vpc-main --direction=INGRESS --action=ALLOW --rules=tcp:80 --source-ranges=0.0.0.0/0
npx tsx gcloud-lab/gcloud.ts compute instances create web01 --network=vpc-main --subnet=subnet-web
npx tsx gcloud-lab/gcloud.ts compute disks create data01 --size=20
npx tsx gcloud-lab/gcloud.ts storage buckets create gs://uploads
npx tsx gcloud-lab/gcloud.ts sql instances create app-db

npx tsx gcloud-lab/gcloud.ts compute networks list
npx tsx gcloud-lab/gcloud.ts compute networks describe vpc-main

npx tsx gcloud-lab/gcloud.ts compute instances delete web01
# ...and so on in dependency order (see "verified end-to-end" below).
```

To use an already-existing CloudLab account/project instead of `init`'s
throwaway one: `auth login --email=... --password=...` then
`config set project <projectId>`.

## Verified end-to-end

All seven core services were created, listed, described, and deleted
through this CLI against a real project in this environment: `networks`,
`networks subnets`, `firewall-rules`, `instances`, `disks`, `storage
buckets`, and `sql instances` all reached real `READY` (an
`instances describe` shows the resource's genuine `dockerNetworkId`
metadata, confirming real Docker networking underneath, not a label), and
deleting them back down in dependency order removed every one cleanly.

Negative cases were exercised too: `describe` on an already-deleted
resource returns a clear `NOT_FOUND`; `create` with a required flag
missing (e.g. `compute networks create x` with no `--range`) fails before
ever calling the API; deleting a network that still has a subnet attached
fails with the real API's `409 DEPENDENCY_EXISTS`-style message (the exact
same "still used by ..." check every other front end hits — deleting the
subnet first and the network afterward succeeds); and running any command
before `init`/`auth login` fails with a clear "no active account" error
instead of a confusing network/auth error.

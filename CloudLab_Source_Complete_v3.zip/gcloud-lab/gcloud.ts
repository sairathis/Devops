#!/usr/bin/env -S npx tsx
// A gcloud-style command-line tool for CloudLab: the same command surface
// shape as real `gcloud` (command groups, `--flag=value` syntax, cached
// local credentials/project the way `gcloud auth login` / `gcloud config
// set project` behave), reading and writing real infrastructure through
// the exact same REST API the console, the JSON CLI, the Terraform-lab,
// and the CI/CD pipelines all use.
//
// This is CloudLab's own tool, not Google's `gcloud` -- it does not talk to
// any Google Cloud API, does not vendor the real `gcloud` Python codebase,
// and only implements the small slice of the real command surface listed
// in README.md (the seven "core services" this whole cross-method lab
// covers: networks, subnets, firewall rules, instances, disks, buckets,
// and (as `sql instances`, gcloud's own real name for managed databases)
// databases). Everything it prints is really queried from CloudLab's API on
// every call -- there is no local cache of resource state, only of the
// logged-in account and the active project, exactly like real `gcloud`.
//
// Usage:
//   npx tsx gcloud-lab/gcloud.ts init
//   npx tsx gcloud-lab/gcloud.ts auth login --email=x@y.com --password=...
//   npx tsx gcloud-lab/gcloud.ts config set project <projectId>
//   npx tsx gcloud-lab/gcloud.ts compute networks create vpc-main --range=10.0.0.0/24
//   npx tsx gcloud-lab/gcloud.ts compute networks list
//   ...(see README.md for the full command list)

import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = path.join(HERE, ".cloudshell");
const CONFIG_PATH = path.join(CONFIG_DIR, "config.json");
const API = process.env.CLOUDLAB_API_BASE ?? "http://localhost:4000/api/v1";

interface CloudShellConfig {
  account?: string;
  token?: string;
  project?: string;
}

function loadConfig(): CloudShellConfig {
  if (!existsSync(CONFIG_PATH)) return {};
  return JSON.parse(readFileSync(CONFIG_PATH, "utf8"));
}
function saveConfig(cfg: CloudShellConfig) {
  mkdirSync(CONFIG_DIR, { recursive: true });
  writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

async function api(p: string, opts: RequestInit = {}, token?: string) {
  const headers: Record<string, string> = { "content-type": "application/json", ...(opts.headers as Record<string, string> | undefined) };
  if (token) headers.authorization = `Bearer ${token}`;
  const res = await fetch(`${API}${p}`, { ...opts, headers });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`${opts.method ?? "GET"} ${p} -> ${res.status}: ${body?.message ?? text}`);
  return body;
}

// ---- flag parsing (real gcloud's --flag=value / --flag value / bare positional args) ----
function parseArgs(argv: string[]): { positional: string[]; flags: Record<string, string> } {
  const positional: string[] = [];
  const flags: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      if (eq >= 0) flags[a.slice(2, eq)] = a.slice(eq + 1);
      else flags[a.slice(2)] = argv[++i] ?? "true";
    } else {
      positional.push(a);
    }
  }
  return { positional, flags };
}

function requireAuth(cfg: CloudShellConfig): { token: string; project: string } {
  if (!cfg.token) {
    console.error('ERROR: (gcloud) You do not currently have an active account. Run "gcloud.ts auth login" (or "gcloud.ts init") first.');
    process.exit(1);
  }
  if (!cfg.project) {
    console.error('ERROR: (gcloud) The required property [project] is not currently set. Run "gcloud.ts config set project <projectId>" first.');
    process.exit(1);
  }
  return { token: cfg.token, project: cfg.project };
}

// ---- operation polling, same real-status semantics as every other front end ----
async function waitForOperation(project: string, token: string, operationId: string, timeoutMs = 60_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const op = await api(`/projects/${project}/operations/${operationId}`, {}, token);
    if (op.status === "SUCCEEDED" || op.status === "FAILED") return op;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`operation ${operationId} did not finish within ${timeoutMs}ms`);
}

// ---- resolve a "--network=vpc-main"-style name reference to that resource's real id ----
async function resolveIdByName(project: string, token: string, path: string, name: string, kindLabel: string): Promise<string> {
  const rows: Array<{ id: string; name: string; status: string }> = await api(`/projects/${project}/${path}`, {}, token);
  const match = rows.find((r) => r.name === name && r.status !== "DELETED");
  if (!match) throw new Error(`${kindLabel} named '${name}' not found in project ${project}`);
  return match.id;
}

function printTable(headers: string[], rows: string[][]) {
  const widths = headers.map((h, i) => Math.max(h.length, ...rows.map((r) => (r[i] ?? "").length)));
  const fmt = (cols: string[]) => cols.map((c, i) => c.padEnd(widths[i])).join("  ").trimEnd();
  console.log(fmt(headers));
  for (const r of rows) console.log(fmt(r));
}

function printYaml(obj: Record<string, unknown>, indent = 0) {
  const pad = "  ".repeat(indent);
  for (const [k, v] of Object.entries(obj)) {
    if (v && typeof v === "object" && !Array.isArray(v)) {
      console.log(`${pad}${k}:`);
      printYaml(v as Record<string, unknown>, indent + 1);
    } else if (Array.isArray(v)) {
      console.log(`${pad}${k}: [${v.join(", ")}]`);
    } else {
      console.log(`${pad}${k}: ${v}`);
    }
  }
}

// ============================================================================
// Resource registry -- one entry per "core service", each describing its
// gcloud-shaped command group, its CloudLab REST path, how `create`'s flags
// become an API spec (resolving any name references along the way), and how
// `list`/`describe` render a resource the way gcloud's own formatter would.
// ============================================================================
interface ResourceKind {
  group: string[]; // the gcloud command-group words, e.g. ["compute", "networks"]
  cloudlabPath: string; // REST path segment, e.g. "networks"
  createUsage: string;
  buildSpec: (project: string, token: string, name: string, flags: Record<string, string>) => Promise<Record<string, unknown>>;
  listColumns: string[];
  listRow: (r: any) => string[];
}

const KINDS: ResourceKind[] = [
  {
    group: ["compute", "networks"],
    cloudlabPath: "networks",
    createUsage: "compute networks create <name> --range=<cidr>",
    buildSpec: async (_p, _t, _name, flags) => {
      if (!flags.range) throw new Error("--range is required, e.g. --range=10.0.0.0/24");
      return { cidr: flags.range };
    },
    listColumns: ["NAME", "CIDR", "STATUS"],
    listRow: (r) => [r.name, r.spec?.cidr ?? "-", r.status],
  },
  {
    group: ["compute", "networks", "subnets"],
    cloudlabPath: "subnets",
    createUsage: "compute networks subnets create <name> --network=<network-name> --range=<cidr>",
    buildSpec: async (project, token, _name, flags) => {
      if (!flags.network) throw new Error("--network is required, e.g. --network=vpc-main");
      if (!flags.range) throw new Error("--range is required, e.g. --range=10.0.0.0/25");
      const networkId = await resolveIdByName(project, token, "networks", flags.network, "network");
      return { networkId, cidr: flags.range };
    },
    listColumns: ["NAME", "NETWORK_ID", "CIDR", "STATUS"],
    listRow: (r) => [r.name, r.spec?.networkId ?? "-", r.spec?.cidr ?? "-", r.status],
  },
  {
    group: ["compute", "firewall-rules"],
    cloudlabPath: "firewall-rules",
    createUsage:
      "compute firewall-rules create <name> --network=<network-name> --direction=INGRESS --action=ALLOW --rules=tcp:80 --source-ranges=0.0.0.0/0",
    buildSpec: async (project, token, _name, flags) => {
      for (const f of ["network", "direction", "action", "rules", "source-ranges"]) {
        if (!flags[f]) throw new Error(`--${f} is required`);
      }
      const networkResourceId = await resolveIdByName(project, token, "networks", flags.network, "network");
      const [protocol, portRange] = flags.rules.includes(":") ? flags.rules.split(":") : [flags.rules, undefined];
      return {
        networkResourceId,
        direction: flags.direction.toLowerCase(),
        action: flags.action.toUpperCase(),
        protocol,
        portRange,
        cidr: flags["source-ranges"],
      };
    },
    listColumns: ["NAME", "NETWORK_ID", "DIRECTION", "ACTION", "PROTOCOL", "PORT_RANGE", "SRC_RANGE", "STATUS"],
    listRow: (r) => [
      r.name,
      r.spec?.networkResourceId ?? "-",
      r.spec?.direction ?? "-",
      r.spec?.action ?? "-",
      r.spec?.protocol ?? "-",
      r.spec?.portRange ?? "*",
      r.spec?.cidr ?? "-",
      r.status,
    ],
  },
  {
    group: ["compute", "instances"],
    cloudlabPath: "instances",
    createUsage: "compute instances create <name> --network=<network-name> [--subnet=<subnet-name>]",
    buildSpec: async (project, token, _name, flags) => {
      if (!flags.network) throw new Error("--network is required, e.g. --network=vpc-main");
      const networkId = await resolveIdByName(project, token, "networks", flags.network, "network");
      let subnetId: string | undefined;
      if (flags.subnet) subnetId = await resolveIdByName(project, token, "subnets", flags.subnet, "subnet");
      return { networkId, subnetId };
    },
    listColumns: ["NAME", "MACHINE_TYPE", "NETWORK_ID", "STATUS"],
    listRow: (r) => [r.name, r.spec?.machineType ?? "e2-micro", r.spec?.networkId ?? "-", r.status],
  },
  {
    group: ["compute", "disks"],
    cloudlabPath: "disks",
    createUsage: "compute disks create <name> [--size=<sizeGb>]",
    buildSpec: async (_p, _t, _name, flags) => ({ sizeGb: flags.size ? Number(flags.size) : undefined }),
    listColumns: ["NAME", "SIZE_GB", "STATUS"],
    listRow: (r) => [r.name, String(r.spec?.sizeGb ?? "-"), r.status],
  },
  {
    group: ["storage", "buckets"],
    cloudlabPath: "buckets",
    createUsage: "storage buckets create gs://<name>",
    buildSpec: async () => ({}),
    listColumns: ["NAME", "STATUS"],
    listRow: (r) => [`gs://${r.name}`, r.status],
  },
  {
    group: ["sql", "instances"],
    cloudlabPath: "databases",
    createUsage: "sql instances create <name> [--database-version=POSTGRES]",
    buildSpec: async (_p, _t, _name, flags) => ({ databaseName: flags["database-name"] }),
    listColumns: ["NAME", "DATABASE_VERSION", "STATUS"],
    listRow: (r) => [r.name, r.spec?.engine ?? "postgres", r.status],
  },
  // ------------------------------------------------------------------------
  // Milestone 15: GCP Platform/DevOps architect pass. Command groups below
  // mirror real `gcloud`'s own naming as closely as this lab's simplified
  // resource model allows -- see gcloud-lab/README.md for exactly where
  // each one diverges from the real command (e.g. real `compute routers
  // nats create` needs a router object first; this lab's `nat-gateways`
  // attaches straight to a network).
  {
    group: ["iam", "service-accounts"],
    cloudlabPath: "service-accounts",
    createUsage: "iam service-accounts create <name> --account-id=<id>",
    buildSpec: async (_p, _t, _name, flags) => {
      if (!flags["account-id"]) throw new Error("--account-id is required, e.g. --account-id=ci-runner-sa");
      return { accountId: flags["account-id"] };
    },
    listColumns: ["NAME", "EMAIL", "STATUS"],
    listRow: (r) => [r.name, r.metadata?.email ?? "-", r.status],
  },
  {
    group: ["compute", "instance-templates"],
    cloudlabPath: "instance-templates",
    createUsage: "compute instance-templates create <name> [--image=<image>]",
    buildSpec: async (_p, _t, _name, flags) => ({ image: flags.image }),
    listColumns: ["NAME", "IMAGE", "STATUS"],
    listRow: (r) => [r.name, r.spec?.image ?? "-", r.status],
  },
  {
    group: ["compute", "instance-groups", "managed"],
    cloudlabPath: "managed-instance-groups",
    createUsage: "compute instance-groups managed create <name> --template=<template-name> --network=<net> --size=<n>",
    buildSpec: async (project, token, _name, flags) => {
      for (const f of ["template", "network"]) if (!flags[f]) throw new Error(`--${f} is required`);
      const instanceTemplateId = await resolveIdByName(project, token, "instance-templates", flags.template, "instance template");
      const networkId = await resolveIdByName(project, token, "networks", flags.network, "network");
      return { instanceTemplateId, networkId, targetSize: flags.size ? Number(flags.size) : 1 };
    },
    listColumns: ["NAME", "SIZE", "LIVE", "STATUS"],
    listRow: (r) => [r.name, String(r.spec?.targetSize ?? "-"), String(r.metadata?.liveCount ?? "-"), r.status],
  },
  {
    // Real gcloud models this as `compute routers create` + `compute routers
    // nats create --router=...`; simplified here to attach a NAT gateway
    // directly to a network (see README.md).
    group: ["compute", "nat-gateways"],
    cloudlabPath: "nat-gateways",
    createUsage: "compute nat-gateways create <name> --network=<net>",
    buildSpec: async (project, token, _name, flags) => {
      if (!flags.network) throw new Error("--network is required");
      return { networkResourceId: await resolveIdByName(project, token, "networks", flags.network, "network") };
    },
    listColumns: ["NAME", "NETWORK_ID", "STATUS"],
    listRow: (r) => [r.name, r.spec?.networkResourceId ?? "-", r.status],
  },
  {
    group: ["compute", "networks", "peerings"],
    cloudlabPath: "vpc-peerings",
    createUsage: "compute networks peerings create <name> --network=<netA> --peer-network=<netB>",
    buildSpec: async (project, token, _name, flags) => {
      for (const f of ["network", "peer-network"]) if (!flags[f]) throw new Error(`--${f} is required`);
      const networkAId = await resolveIdByName(project, token, "networks", flags.network, "network");
      const networkBId = await resolveIdByName(project, token, "networks", flags["peer-network"], "network");
      return { networkAId, networkBId };
    },
    listColumns: ["NAME", "NETWORK_A", "NETWORK_B", "STATUS"],
    listRow: (r) => [r.name, r.spec?.networkAId ?? "-", r.spec?.networkBId ?? "-", r.status],
  },
  {
    // Real gcloud: `compute shared-vpc associated-projects add
    // --host-project=X SERVICE_PROJECT`. Modeled here as a per-network grant
    // resource so it's visible/listable/deletable like everything else.
    group: ["compute", "shared-vpc"],
    cloudlabPath: "shared-vpc-attachments",
    createUsage: "compute shared-vpc create <name> --network=<net> --service-project=<projectId>",
    buildSpec: async (project, token, _name, flags) => {
      for (const f of ["network", "service-project"]) if (!flags[f]) throw new Error(`--${f} is required`);
      const networkResourceId = await resolveIdByName(project, token, "networks", flags.network, "network");
      return { networkResourceId, serviceProjectId: flags["service-project"] };
    },
    listColumns: ["NAME", "SERVICE_PROJECT", "STATUS"],
    listRow: (r) => [r.name, r.spec?.serviceProjectId ?? "-", r.status],
  },
  {
    // Real `bq` uses `mk`/`ls`/`rm`/`query` verbs, not gcloud's
    // create/list/describe/delete -- this lab aliases bq into the same
    // uniform verb set every other command group here uses, and adds a
    // dedicated `bq query` special command below for running real SQL.
    group: ["bq", "datasets"],
    cloudlabPath: "bigquery-datasets",
    createUsage: "bq datasets create <name> [--dataset-id=<id>]",
    buildSpec: async (_p, _t, _name, flags) => ({ datasetId: flags["dataset-id"] }),
    listColumns: ["NAME", "DATASET_ID", "STATUS"],
    listRow: (r) => [r.name, r.metadata?.datasetId ?? "-", r.status],
  },
  {
    group: ["composer", "environments"],
    cloudlabPath: "composer-environments",
    createUsage: 'composer environments create <name> --pipeline=<pipeline-name> --schedule="*/5 * * * *"',
    buildSpec: async (project, token, _name, flags) => {
      for (const f of ["pipeline", "schedule"]) if (!flags[f]) throw new Error(`--${f} is required`);
      const pipelineId = await resolveIdByName(project, token, "pipelines", flags.pipeline, "pipeline");
      return { pipelineId, schedule: flags.schedule };
    },
    listColumns: ["NAME", "SCHEDULE", "TRIGGERS", "STATUS"],
    listRow: (r) => [r.name, r.spec?.schedule ?? "-", String(r.metadata?.triggerCount ?? 0), r.status],
  },
  {
    group: ["run", "services"],
    cloudlabPath: "cloud-run-services",
    createUsage: "run services create <name> --network=<net> [--idle-timeout=<secs>]",
    buildSpec: async (project, token, _name, flags) => {
      if (!flags.network) throw new Error("--network is required");
      const networkId = await resolveIdByName(project, token, "networks", flags.network, "network");
      return { networkId, idleTimeoutSeconds: flags["idle-timeout"] ? Number(flags["idle-timeout"]) : undefined };
    },
    listColumns: ["NAME", "STATE", "STATUS"],
    listRow: (r) => [r.name, r.metadata?.state ?? "IDLE", r.status],
  },
];

function stripGsPrefix(name: string): string {
  return name.startsWith("gs://") ? name.slice(5) : name;
}

function findKind(words: string[]): { kind: ResourceKind; rest: string[] } | undefined {
  // Match the longest known group prefix (so "compute networks subnets" beats "compute networks").
  const sorted = [...KINDS].sort((a, b) => b.group.length - a.group.length);
  for (const kind of sorted) {
    if (kind.group.every((w, i) => words[i] === w)) return { kind, rest: words.slice(kind.group.length) };
  }
  return undefined;
}

async function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "help") return printHelp();

  const cfg = loadConfig();

  // ---- gcloud init: registers a fresh lab account + org + project in one step,
  // mirroring what real `gcloud init` does interactively (pick/create account,
  // pick/create project) but scripted, since there's no browser to open here. ----
  if (argv[0] === "init") {
    const { flags } = parseArgs(argv.slice(1));
    const stamp = Date.now();
    const email = flags.email ?? `cloudshell-${stamp}@cloudlab.dev`;
    const password = flags.password ?? "password123";
    const name = flags.name ?? "Cloud Shell Lab";
    console.log("Welcome! This command will guide you through configuring CloudLab's gcloud-style CLI.\n");
    console.log(`Creating a new account [${email}] ...`);
    const reg = await api("/auth/register", { method: "POST", body: JSON.stringify({ name, email, password }) });
    console.log("You are logged in as: [" + email + "]\n");
    console.log("Pick cloud project to use:");
    const org = await api("/organizations", { method: "POST", body: JSON.stringify({ name: `${name} Org` }) }, reg.token);
    const projectName = flags.project ?? `cloudshell-lab-${stamp}`;
    const project = await api("/projects", { method: "POST", body: JSON.stringify({ orgId: org.id, name: projectName }) }, reg.token);
    console.log(` [1] Create a new project: "${projectName}"`);
    console.log(`Your current project has been set to: [${project.id}]\n`);
    saveConfig({ account: email, token: reg.token, project: project.id });
    console.log("gcloud-lab has been configured. Credentials cached in gcloud-lab/.cloudshell/config.json");
    console.log(`\nRun 'npx tsx gcloud-lab/gcloud.ts config list' to see your active configuration.`);
    return;
  }

  if (argv[0] === "auth") {
    const sub = argv[1];
    if (sub === "login") {
      const { flags } = parseArgs(argv.slice(2));
      if (!flags.email || !flags.password) throw new Error("usage: auth login --email=<e> --password=<p>");
      const res = await api("/auth/login", { method: "POST", body: JSON.stringify({ email: flags.email, password: flags.password }) });
      saveConfig({ ...cfg, account: flags.email, token: res.token });
      console.log(`Logged in as [${flags.email}].`);
      return;
    }
    if (sub === "list") {
      console.log("Credentialed Accounts");
      console.log("ACTIVE  ACCOUNT");
      console.log(cfg.account ? `*       ${cfg.account}` : "(no accounts logged in)");
      return;
    }
    if (sub === "revoke") {
      saveConfig({});
      console.log("Revoked all cached credentials.");
      return;
    }
    throw new Error(`unknown auth subcommand '${sub}' -- try 'login', 'list', or 'revoke'`);
  }

  if (argv[0] === "config") {
    const sub = argv[1];
    if (sub === "set" && argv[2] === "project") {
      const projectId = argv[3];
      if (!projectId) throw new Error("usage: config set project <projectId>");
      saveConfig({ ...cfg, project: projectId });
      console.log(`Updated property [core/project] to [${projectId}].`);
      return;
    }
    if (sub === "get-value" && argv[2] === "project") {
      console.log(cfg.project ?? "(unset)");
      return;
    }
    if (sub === "list") {
      console.log("[core]");
      console.log(`account = ${cfg.account ?? "(unset)"}`);
      console.log(`project = ${cfg.project ?? "(unset)"}`);
      return;
    }
    throw new Error(`unknown config subcommand -- try 'set project <id>', 'get-value project', or 'list'`);
  }

  // ---- Milestone 15 special commands (real verbs gcloud's own tools use,
  // that don't fit the generic create/list/describe/delete shape) ----
  if (argv[0] === "compute" && argv[1] === "instance-groups" && argv[2] === "managed" && argv[3] === "resize") {
    const { token, project } = requireAuth(cfg);
    const { positional, flags } = parseArgs(argv.slice(4));
    const name = positional[0];
    if (!name || !flags.size) throw new Error("usage: compute instance-groups managed resize <name> --size=<n>");
    const id = await resolveIdByName(project, token, "managed-instance-groups", name, "managed instance group");
    const res = await api(`/projects/${project}/managed-instance-groups/${id}/resize`, { method: "POST", body: JSON.stringify({ targetSize: Number(flags.size) }) }, token);
    await waitForOperation(project, token, res.operationId);
    console.log(`Resized [${name}] to ${flags.size} -- reconciler will converge within 10s.`);
    return;
  }
  if (argv[0] === "iam" && argv[1] === "service-accounts" && argv[2] === "keys" && argv[3] === "create") {
    const { token, project } = requireAuth(cfg);
    const { positional } = parseArgs(argv.slice(4));
    const name = positional[0];
    if (!name) throw new Error("usage: iam service-accounts keys create <name>");
    const id = await resolveIdByName(project, token, "service-accounts", name, "service account");
    const key = await api(`/projects/${project}/service-accounts/${id}/key`, {}, token);
    console.log(`created key [${key.private_key_id}] for [${key.client_email}]\n`);
    console.log(JSON.stringify(key, null, 2));
    return;
  }
  if (argv[0] === "bq" && argv[1] === "query") {
    const { token, project } = requireAuth(cfg);
    const { positional, flags } = parseArgs(argv.slice(2));
    const sql = positional.join(" ");
    if (!flags.dataset || !sql) throw new Error('usage: bq query --dataset=<name> "SELECT ..."');
    const id = await resolveIdByName(project, token, "bigquery-datasets", flags.dataset, "dataset");
    const res = await api(`/projects/${project}/bigquery-datasets/${id}/query`, { method: "POST", body: JSON.stringify({ sql }) }, token);
    printTable(res.fields, res.rows.map((row: Record<string, unknown>) => res.fields.map((f: string) => String(row[f] ?? ""))));
    console.log(`\n(${res.rowCount} row(s) in ${res.tookMs}ms)`);
    return;
  }
  if (argv[0] === "run" && argv[1] === "services" && argv[2] === "invoke") {
    const { token, project } = requireAuth(cfg);
    const { positional } = parseArgs(argv.slice(3));
    const name = positional[0];
    if (!name) throw new Error("usage: run services invoke <name>");
    const id = await resolveIdByName(project, token, "cloud-run-services", name, "service");
    const res = await api(`/projects/${project}/cloud-run-services/${id}/invoke`, { method: "POST" }, token);
    console.log(res.coldStart ? "Cold start..." : "Warm invoke...");
    console.log(JSON.stringify(res, null, 2));
    return;
  }

  // ---- resource command groups: <group...> <create|list|describe|delete> [name] [--flags] ----
  const match = findKind(argv);
  if (!match) return printHelp();
  const { kind, rest } = match;
  const [action, ...actionRest] = rest;
  const { token, project } = requireAuth(cfg);

  if (action === "create") {
    const rawName = actionRest.find((a) => !a.startsWith("--"));
    if (!rawName) throw new Error(`usage: ${kind.createUsage}`);
    const name = stripGsPrefix(rawName);
    const { flags } = parseArgs(actionRest.filter((a) => a !== rawName));
    const spec = await kind.buildSpec(project, token, name, flags);
    console.log(`Creating ${kind.group.join(" ")} [${name}]...`);
    const res = await api(`/projects/${project}/${kind.cloudlabPath}`, { method: "POST", body: JSON.stringify({ name, ...spec }) }, token);
    const op = await waitForOperation(project, token, res.operationId);
    if (op.status !== "SUCCEEDED") {
      console.error(`ERROR: (gcloud.${kind.group.join(".")}.create) ${op.error?.message ?? "operation failed"}`);
      process.exit(1);
    }
    // Re-fetch so the printed row reflects the real post-provisioning state
    // (READY), not the CREATING snapshot the initial POST returned.
    const finalRow = await api(`/projects/${project}/${kind.cloudlabPath}/${res.resource.id}`, {}, token);
    console.log(`Created [${finalRow.id}].`);
    printTable(kind.listColumns, [kind.listRow(finalRow)]);
    return;
  }

  if (action === "list") {
    const rows = await api(`/projects/${project}/${kind.cloudlabPath}`, {}, token);
    const visible = (rows as any[]).filter((r) => r.status !== "DELETED");
    printTable(kind.listColumns, visible.map(kind.listRow));
    return;
  }

  if (action === "describe") {
    const rawName = actionRest[0];
    if (!rawName) throw new Error(`usage: ${kind.group.join(" ")} describe <name>`);
    const name = stripGsPrefix(rawName);
    const rows = await api(`/projects/${project}/${kind.cloudlabPath}`, {}, token);
    const match2 = (rows as any[]).find((r) => r.name === name && r.status !== "DELETED");
    if (!match2) throw new Error(`NOT_FOUND: ${kind.group.join(" ")} '${name}' not found in project ${project}`);
    printYaml(match2);
    return;
  }

  if (action === "delete") {
    const rawName = actionRest.find((a) => !a.startsWith("--"));
    if (!rawName) throw new Error(`usage: ${kind.group.join(" ")} delete <name>`);
    const name = stripGsPrefix(rawName);
    const id = await resolveIdByName(project, token, kind.cloudlabPath, name, kind.group.join(" "));
    console.log(`Deleting ${kind.group.join(" ")} [${name}]...`);
    const res = await api(`/projects/${project}/${kind.cloudlabPath}/${id}`, { method: "DELETE" }, token);
    const op = await waitForOperation(project, token, res.operationId);
    if (op.status !== "SUCCEEDED") {
      console.error(`ERROR: (gcloud.${kind.group.join(".")}.delete) ${op.error?.message ?? "operation failed"}`);
      process.exit(1);
    }
    console.log(`Deleted [${name}].`);
    return;
  }

  throw new Error(`unknown action '${action}' for '${kind.group.join(" ")}' -- try create, list, describe, or delete`);
}

function printHelp() {
  console.log(`CloudLab's gcloud-style CLI (Cloud Shell lab)

  init                                            One-shot account + project setup (like real "gcloud init")
  auth login --email=<e> --password=<p>           Log in and cache a token
  auth list / auth revoke                         Show / clear cached credentials
  config set project <id> / get-value project / list

  compute networks create <name> --range=<cidr>
  compute networks list|describe|delete <name>

  compute networks subnets create <name> --network=<net> --range=<cidr>
  compute networks subnets list|describe|delete <name>

  compute firewall-rules create <name> --network=<net> --direction=INGRESS --action=ALLOW --rules=tcp:80 --source-ranges=0.0.0.0/0
  compute firewall-rules list|describe|delete <name>

  compute instances create <name> --network=<net> [--subnet=<sub>]
  compute instances list|describe|delete <name>

  compute disks create <name> [--size=<sizeGb>]
  compute disks list|describe|delete <name>

  storage buckets create gs://<name>
  storage buckets list|describe|delete gs://<name>

  sql instances create <name>
  sql instances list|describe|delete <name>

  --- Milestone 15: GCP Platform/DevOps architect pass ---
  iam service-accounts create <name> --account-id=<id>
  iam service-accounts list|describe|delete <name>
  iam service-accounts keys create <name>

  compute instance-templates create <name> [--image=<image>]
  compute instance-templates list|describe|delete <name>

  compute instance-groups managed create <name> --template=<t> --network=<n> --size=<n>
  compute instance-groups managed list|describe|delete <name>
  compute instance-groups managed resize <name> --size=<n>

  compute nat-gateways create <name> --network=<net>
  compute nat-gateways list|describe|delete <name>

  compute networks peerings create <name> --network=<a> --peer-network=<b>
  compute networks peerings list|describe|delete <name>

  compute shared-vpc create <name> --network=<net> --service-project=<projectId>
  compute shared-vpc list|describe|delete <name>

  bq datasets create <name> [--dataset-id=<id>]
  bq datasets list|describe|delete <name>
  bq query --dataset=<name> "SELECT ..."

  composer environments create <name> --pipeline=<p> --schedule="*/5 * * * *"
  composer environments list|describe|delete <name>

  run services create <name> --network=<net> [--idle-timeout=<secs>]
  run services list|describe|delete <name>
  run services invoke <name>

See gcloud-lab/README.md for the full write-up.`);
}

main().catch((err) => {
  console.error(`ERROR: ${(err as Error).message}`);
  process.exit(1);
});

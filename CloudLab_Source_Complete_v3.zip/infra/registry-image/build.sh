#!/usr/bin/env bash
# Builds cloudlab/registry:latest entirely from local sources.
set -euo pipefail
cd "$(dirname "$0")"
rm -rf rootfs
mkdir -p rootfs/usr/bin rootfs/data
echo "[1/2] compiling registry (static)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o rootfs/usr/bin/registry registry.go
echo "[2/2] docker build"
docker build -t cloudlab/registry:latest .
echo "done: cloudlab/registry:latest"

// A minimal but real implementation of the Docker/OCI Distribution HTTP API
// v2 -- enough of it for a genuine `docker push` / `docker pull` to
// interoperate against it. No external dependencies (Go stdlib only), so it
// compiles to one static binary for a FROM-scratch image, same pattern as
// dns-resolver.go and lb-proxy.go.
//
// Deliberately NOT implemented (documented in ROADMAP.md rather than
// silently missing): chunked resumable upload state surviving a restart,
// authentication, content garbage collection, manifest lists/multi-arch.
// What IS implemented is real: content-addressable blob storage verified by
// SHA-256 digest, real manifest storage keyed by tag and by digest, and a
// real catalog/tags listing -- a genuine registry a real `docker` client can
// push to and pull from, not a stub that only looks like one over the API.
package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
)

const dataRoot = "/data"

var (
	mu      sync.Mutex
	uploads = map[string]*os.File{} // uuid -> temp file being written
)

func blobPath(digest string) string {
	// digest looks like "sha256:<hex>"
	parts := strings.SplitN(digest, ":", 2)
	return filepath.Join(dataRoot, "blobs", parts[0], parts[1])
}

func repoDir(name string) string {
	return filepath.Join(dataRoot, "repos", name)
}

func manifestPath(name, ref string) string {
	safe := strings.ReplaceAll(ref, ":", "_") // digests contain ':' -- keep filenames simple
	return filepath.Join(repoDir(name), "manifests", safe)
}

func tagPath(name, tag string) string {
	return filepath.Join(repoDir(name), "tags", tag)
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]any{
		"errors": []map[string]string{{"code": code, "message": message}},
	})
}

// GET /v2/ -- the API version check every registry client makes first.
func handleRoot(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Docker-Distribution-Api-Version", "registry/2.0")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("{}"))
}

// GET /v2/_catalog -- list every repository this registry knows about.
// Repository names can contain "/" (e.g. "myproject/web"), which on disk is
// just a nested directory -- so a repo is any directory that has its own
// "manifests" subdirectory, found by walking the whole repos/ tree rather
// than assuming one level of nesting.
func handleCatalog(w http.ResponseWriter, r *http.Request) {
	root := filepath.Join(dataRoot, "repos")
	names := []string{}
	filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || !d.IsDir() {
			return nil
		}
		if _, statErr := os.Stat(filepath.Join(path, "manifests")); statErr == nil {
			rel, relErr := filepath.Rel(root, path)
			if relErr == nil {
				names = append(names, rel)
			}
		}
		return nil
	})
	json.NewEncoder(w).Encode(map[string]any{"repositories": names})
}

// GET /v2/<name>/tags/list
func handleTagsList(w http.ResponseWriter, name string) {
	entries, _ := os.ReadDir(filepath.Join(repoDir(name), "tags"))
	tags := []string{}
	for _, e := range entries {
		tags = append(tags, e.Name())
	}
	json.NewEncoder(w).Encode(map[string]any{"name": name, "tags": tags})
}

func newUploadID() string {
	// A real Docker push fans out one upload per layer concurrently -- an id
	// derived from a shared counter read outside the lock (the original bug
	// here) can hand two concurrent uploads the same id, so the second one's
	// PATCH/PUT calls then fail with "unknown upload" once the first
	// finishes and deletes it. 16 random bytes has no such collision risk.
	buf := make([]byte, 16)
	rand.Read(buf)
	return hex.EncodeToString(buf)
}

// POST /v2/<name>/blobs/uploads/ -- start a resumable (here: file-backed) upload.
func handleStartUpload(w http.ResponseWriter, r *http.Request, name string) {
	os.MkdirAll(filepath.Join(dataRoot, "uploads"), 0o755)
	id := newUploadID()
	f, err := os.Create(filepath.Join(dataRoot, "uploads", id))
	if err != nil {
		writeError(w, 500, "UNKNOWN", err.Error())
		return
	}
	mu.Lock()
	uploads[id] = f
	mu.Unlock()

	// A monolithic single-PUT push sends the whole blob straight to this
	// POST's follow-up PUT; some clients send it inline on the POST itself.
	if r.ContentLength > 0 {
		io.Copy(f, r.Body)
	}

	loc := fmt.Sprintf("/v2/%s/blobs/uploads/%s", name, id)
	w.Header().Set("Location", loc)
	w.Header().Set("Docker-Upload-UUID", id)
	w.Header().Set("Range", "0-0")
	w.WriteHeader(http.StatusAccepted)
}

// PATCH /v2/<name>/blobs/uploads/<uuid> -- append a chunk.
func handlePatchUpload(w http.ResponseWriter, r *http.Request, name, id string) {
	mu.Lock()
	f := uploads[id]
	mu.Unlock()
	if f == nil {
		writeError(w, 404, "BLOB_UPLOAD_UNKNOWN", "unknown upload")
		return
	}
	n, err := io.Copy(f, r.Body)
	if err != nil {
		writeError(w, 500, "UNKNOWN", err.Error())
		return
	}
	info, _ := f.Stat()
	w.Header().Set("Location", fmt.Sprintf("/v2/%s/blobs/uploads/%s", name, id))
	w.Header().Set("Range", fmt.Sprintf("0-%d", info.Size()-1))
	w.Header().Set("Docker-Upload-UUID", id)
	_ = n
	w.WriteHeader(http.StatusAccepted)
}

// PUT /v2/<name>/blobs/uploads/<uuid>?digest=sha256:... -- finalize the blob.
func handleFinishUpload(w http.ResponseWriter, r *http.Request, name, id, digest string) {
	mu.Lock()
	f := uploads[id]
	delete(uploads, id)
	mu.Unlock()
	if f == nil {
		writeError(w, 404, "BLOB_UPLOAD_UNKNOWN", "unknown upload")
		return
	}
	if r.ContentLength > 0 {
		io.Copy(f, r.Body)
	}
	f.Close()

	tmpPath := f.Name()
	sum, err := sha256File(tmpPath)
	if err != nil {
		writeError(w, 500, "UNKNOWN", err.Error())
		return
	}
	computed := "sha256:" + sum
	if digest != "" && digest != computed {
		os.Remove(tmpPath)
		writeError(w, 400, "DIGEST_INVALID", fmt.Sprintf("expected %s, got %s", digest, computed))
		return
	}
	dest := blobPath(computed)
	os.MkdirAll(filepath.Dir(dest), 0o755)
	os.Rename(tmpPath, dest)

	w.Header().Set("Docker-Content-Digest", computed)
	w.Header().Set("Location", fmt.Sprintf("/v2/%s/blobs/%s", name, computed))
	w.WriteHeader(http.StatusCreated)
}

func sha256File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// HEAD/GET /v2/<name>/blobs/<digest>
func handleBlob(w http.ResponseWriter, r *http.Request, digest string) {
	path := blobPath(digest)
	info, err := os.Stat(path)
	if err != nil {
		writeError(w, 404, "BLOB_UNKNOWN", "blob not found")
		return
	}
	w.Header().Set("Docker-Content-Digest", digest)
	w.Header().Set("Content-Length", strconv.FormatInt(info.Size(), 10))
	if r.Method == http.MethodHead {
		w.WriteHeader(http.StatusOK)
		return
	}
	f, err := os.Open(path)
	if err != nil {
		writeError(w, 404, "BLOB_UNKNOWN", "blob not found")
		return
	}
	defer f.Close()
	io.Copy(w, f)
}

// PUT /v2/<name>/manifests/<reference>
func handlePutManifest(w http.ResponseWriter, r *http.Request, name, ref string) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		writeError(w, 500, "UNKNOWN", err.Error())
		return
	}
	sum := sha256.Sum256(body)
	digest := "sha256:" + hex.EncodeToString(sum[:])
	contentType := r.Header.Get("Content-Type")
	if contentType == "" {
		contentType = "application/vnd.docker.distribution.manifest.v2+json"
	}

	os.MkdirAll(filepath.Join(repoDir(name), "manifests"), 0o755)
	os.MkdirAll(filepath.Join(repoDir(name), "tags"), 0o755)

	record := map[string]string{"contentType": contentType}
	recordBytes, _ := json.Marshal(record)
	os.WriteFile(manifestPath(name, digest)+".meta", recordBytes, 0o644)
	os.WriteFile(manifestPath(name, digest), body, 0o644)

	// A tag reference also gets a pointer file so GET /manifests/<tag> resolves.
	if !strings.HasPrefix(ref, "sha256:") {
		os.WriteFile(tagPath(name, ref), []byte(digest), 0o644)
	}

	w.Header().Set("Docker-Content-Digest", digest)
	w.WriteHeader(http.StatusCreated)
}

// GET /v2/<name>/manifests/<reference>
func handleGetManifest(w http.ResponseWriter, r *http.Request, name, ref string) {
	digest := ref
	if !strings.HasPrefix(ref, "sha256:") {
		tagBytes, err := os.ReadFile(tagPath(name, ref))
		if err != nil {
			writeError(w, 404, "MANIFEST_UNKNOWN", "manifest not found")
			return
		}
		digest = string(tagBytes)
	}
	body, err := os.ReadFile(manifestPath(name, digest))
	if err != nil {
		writeError(w, 404, "MANIFEST_UNKNOWN", "manifest not found")
		return
	}
	contentType := "application/vnd.docker.distribution.manifest.v2+json"
	if metaBytes, err := os.ReadFile(manifestPath(name, digest) + ".meta"); err == nil {
		var meta map[string]string
		if json.Unmarshal(metaBytes, &meta) == nil && meta["contentType"] != "" {
			contentType = meta["contentType"]
		}
	}
	w.Header().Set("Content-Type", contentType)
	w.Header().Set("Docker-Content-Digest", digest)
	if r.Method == http.MethodHead {
		w.Header().Set("Content-Length", strconv.Itoa(len(body)))
		w.WriteHeader(http.StatusOK)
		return
	}
	w.Write(body)
}

// Route by path shape rather than a router package, to keep this dependency-free.
var (
	blobUploadStartRe = regexp.MustCompile(`^/v2/(.+)/blobs/uploads/$`)
	blobUploadIDRe    = regexp.MustCompile(`^/v2/(.+)/blobs/uploads/([a-zA-Z0-9]+)$`)
	blobRe            = regexp.MustCompile(`^/v2/(.+)/blobs/(sha256:[a-f0-9]+)$`)
	manifestRe        = regexp.MustCompile(`^/v2/(.+)/manifests/(.+)$`)
	tagsListRe        = regexp.MustCompile(`^/v2/(.+)/tags/list$`)
)

func router(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path
	switch {
	case path == "/v2/" || path == "/v2":
		handleRoot(w, r)
	case path == "/v2/_catalog":
		handleCatalog(w, r)
	case tagsListRe.MatchString(path):
		m := tagsListRe.FindStringSubmatch(path)
		handleTagsList(w, m[1])
	case r.Method == http.MethodPost && blobUploadStartRe.MatchString(path):
		m := blobUploadStartRe.FindStringSubmatch(path)
		handleStartUpload(w, r, m[1])
	case r.Method == http.MethodPatch && blobUploadIDRe.MatchString(path):
		m := blobUploadIDRe.FindStringSubmatch(path)
		handlePatchUpload(w, r, m[1], m[2])
	case r.Method == http.MethodPut && blobUploadIDRe.MatchString(path):
		m := blobUploadIDRe.FindStringSubmatch(path)
		handleFinishUpload(w, r, m[1], m[2], r.URL.Query().Get("digest"))
	case (r.Method == http.MethodGet || r.Method == http.MethodHead) && blobRe.MatchString(path):
		m := blobRe.FindStringSubmatch(path)
		handleBlob(w, r, m[2])
	case r.Method == http.MethodPut && manifestRe.MatchString(path):
		m := manifestRe.FindStringSubmatch(path)
		handlePutManifest(w, r, m[1], m[2])
	case (r.Method == http.MethodGet || r.Method == http.MethodHead) && manifestRe.MatchString(path):
		m := manifestRe.FindStringSubmatch(path)
		handleGetManifest(w, r, m[1], m[2])
	default:
		writeError(w, 404, "UNSUPPORTED", "no route for "+r.Method+" "+path)
	}
}

func main() {
	os.MkdirAll(dataRoot, 0o755)
	http.HandleFunc("/", router)
	log.Println("cloudlab-registry listening on :5000, data at", dataRoot)
	log.Fatal(http.ListenAndServe(":5000", nil))
}

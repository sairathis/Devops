package main

import (
	"fmt"
	"net/http"
	"os"
	"time"
)

func main() {
	start := time.Now()
	hostname, _ := os.Hostname()

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "<html><body style=\"font-family:monospace;padding:2rem\">"+
			"<h1>CloudLab guest agent</h1>"+
			"<p>host: %s</p><p>uptime: %s</p><p>path: %s</p>"+
			"</body></html>", hostname, time.Since(start).Round(time.Second), r.URL.Path)
	})
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		fmt.Fprint(w, "ok")
	})

	addr := ":8080"
	fmt.Printf("cloudlab guest-agent listening on %s (host=%s)\n", addr, hostname)
	if err := http.ListenAndServe(addr, mux); err != nil {
		fmt.Fprintln(os.Stderr, "guest-agent error:", err)
		os.Exit(1)
	}
}

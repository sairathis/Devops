#!/usr/bin/env bash
# Builds the cloudlab/guest:latest image entirely from local sources --
# no external registry pull required (the image FROM's `scratch`).
# Requires: go toolchain, busybox-static (apt), a running docker daemon.
set -euo pipefail
cd "$(dirname "$0")"

rm -rf rootfs
mkdir -p rootfs/bin rootfs/usr/bin rootfs/etc rootfs/tmp

echo "[1/3] compiling guest-agent (static)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o rootfs/usr/bin/guest-agent guest-agent.go

echo "[2/3] assembling busybox userland"
BUSYBOX_BIN="$(command -v busybox || echo /usr/bin/busybox)"
if [ ! -x "$BUSYBOX_BIN" ]; then
  echo "busybox not found -- installing busybox-static via apt" >&2
  apt-get update -y && apt-get install -y busybox-static
  BUSYBOX_BIN=/usr/bin/busybox
fi
cp "$BUSYBOX_BIN" rootfs/bin/busybox
for applet in sh ls cat echo ps id hostname uname sleep wget cp mv rm mkdir \
              ping ping6 nslookup ip route env grep head tail tar df du free \
              top vi wc find touch chmod kill; do
  ln -sf busybox "rootfs/bin/$applet"
done
echo "root:x:0:0:root:/root:/bin/sh" > rootfs/etc/passwd
echo "cloudlab guest image" > rootfs/etc/motd

echo "[3/3] docker build"
docker build -t cloudlab/guest:latest .
echo "done: cloudlab/guest:latest"

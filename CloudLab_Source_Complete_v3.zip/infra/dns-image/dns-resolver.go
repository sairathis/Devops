// Real minimal authoritative + forwarding DNS server for CloudLab.
//
// Serves custom A records that CloudLab users create (e.g. "app.internal"
// -> an instance's real container IP) from a JSON file on disk that the
// worker rewrites whenever a dns_record resource changes. Anything it
// doesn't have a record for, it forwards to Docker's embedded resolver at
// 127.0.0.11 (reachable from any container on a user-defined bridge
// network), so normal container-name resolution keeps working unchanged.
//
// This is a real DNS server speaking real DNS wire format over UDP -- not
// a stub -- built by hand (no external DNS library) to keep the binary
// static and dependency-free for a FROM-scratch image.
package main

import (
	"encoding/binary"
	"encoding/json"
	"log"
	"net"
	"os"
	"sync"
	"time"
)

type record struct {
	Name string `json:"name"` // fully-qualified, lowercase, no trailing dot
	IP   string `json:"ip"`
}

var (
	mu      sync.RWMutex
	records = map[string]string{} // name -> ip
)

const recordsPath = "/etc/cloudlab/dns-records.json"
const upstream = "127.0.0.11:53" // Docker's embedded per-network resolver

func loadRecords() {
	data, err := os.ReadFile(recordsPath)
	if err != nil {
		return
	}
	var list []record
	if err := json.Unmarshal(data, &list); err != nil {
		log.Printf("dns-resolver: bad records file: %v", err)
		return
	}
	next := map[string]string{}
	for _, r := range list {
		next[r.Name] = r.IP
	}
	mu.Lock()
	records = next
	mu.Unlock()
}

func watchRecords() {
	var lastMod time.Time
	for {
		if fi, err := os.Stat(recordsPath); err == nil {
			if fi.ModTime().After(lastMod) {
				lastMod = fi.ModTime()
				loadRecords()
				log.Printf("dns-resolver: reloaded %d record(s)", len(records))
			}
		}
		time.Sleep(1 * time.Second)
	}
}

// --- minimal DNS message parsing (just enough for A-record queries) -------

func parseQName(msg []byte, off int) (string, int) {
	name := ""
	for {
		if off >= len(msg) {
			return name, off
		}
		l := int(msg[off])
		if l == 0 {
			off++
			break
		}
		off++
		if off+l > len(msg) {
			return name, off
		}
		if name != "" {
			name += "."
		}
		name += string(msg[off : off+l])
		off += l
	}
	return name, off
}

func buildResponse(query []byte, qname string, ip net.IP) []byte {
	resp := make([]byte, len(query))
	copy(resp, query)
	binary.BigEndian.PutUint16(resp[2:], 0x8180) // standard response, no error
	binary.BigEndian.PutUint16(resp[6:], 1)      // ANCOUNT = 1

	answer := []byte{0xc0, 0x0c} // pointer to question name at offset 12
	answer = append(answer, 0x00, 0x01) // TYPE A
	answer = append(answer, 0x00, 0x01) // CLASS IN
	answer = append(answer, 0x00, 0x00, 0x00, 0x1e) // TTL 30s
	answer = append(answer, 0x00, 0x04) // RDLENGTH 4
	answer = append(answer, ip.To4()...)
	return append(resp, answer...)
}

func forward(query []byte) ([]byte, error) {
	conn, err := net.DialTimeout("udp", upstream, 2*time.Second)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(2 * time.Second))
	if _, err := conn.Write(query); err != nil {
		return nil, err
	}
	buf := make([]byte, 512)
	n, err := conn.Read(buf)
	if err != nil {
		return nil, err
	}
	return buf[:n], nil
}

func handle(pc net.PacketConn, addr net.Addr, query []byte) {
	if len(query) < 12 {
		return
	}
	qname, _ := parseQName(query, 12)
	mu.RLock()
	ip, ok := records[qname]
	mu.RUnlock()

	if ok {
		resp := buildResponse(query, qname, net.ParseIP(ip))
		pc.WriteTo(resp, addr)
		return
	}

	if resp, err := forward(query); err == nil {
		pc.WriteTo(resp, addr)
	}
}

func main() {
	loadRecords()
	go watchRecords()

	pc, err := net.ListenPacket("udp", ":53")
	if err != nil {
		log.Fatalf("dns-resolver: cannot listen on :53: %v", err)
	}
	log.Println("cloudlab-dns-resolver listening on udp/53")

	buf := make([]byte, 512)
	for {
		n, addr, err := pc.ReadFrom(buf)
		if err != nil {
			continue
		}
		query := make([]byte, n)
		copy(query, buf[:n])
		go handle(pc, addr, query)
	}
}

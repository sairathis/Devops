#!/usr/bin/env bash
# Builds cloudlab/dns-resolver:latest entirely from local sources.
set -euo pipefail
cd "$(dirname "$0")"
rm -rf rootfs
mkdir -p rootfs/usr/bin rootfs/etc/cloudlab
echo "[1/2] compiling dns-resolver (static)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o rootfs/usr/bin/dns-resolver dns-resolver.go
echo "[]" > rootfs/etc/cloudlab/dns-records.json
echo "[2/2] docker build"
docker build -t cloudlab/dns-resolver:latest .
echo "done: cloudlab/dns-resolver:latest"

#!/usr/bin/env bash
# Builds cloudlab/bucket-store:latest entirely from local sources.
set -euo pipefail
cd "$(dirname "$0")"
rm -rf rootfs
mkdir -p rootfs/usr/bin rootfs/data
echo "[1/2] compiling bucket-store (static)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o rootfs/usr/bin/bucket-store store.go
echo "[2/2] docker build"
docker build -t cloudlab/bucket-store:latest .
echo "done: cloudlab/bucket-store:latest"

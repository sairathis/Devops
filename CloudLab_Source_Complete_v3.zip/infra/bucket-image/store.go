// A minimal but real object-storage HTTP server -- CloudLab's own bucket
// protocol (not AWS SigV4/S3-API-compatible, documented as a limitation in
// ROADMAP.md), implemented with the Go standard library only so it compiles
// to a single static binary for a FROM-scratch image, the same pattern as
// dns-resolver.go, lb-proxy.go and registry.go.
//
// Real, not simulated: objects are written to and read from actual files on
// disk (content-addressed by bucket/key, not just tracked in a database row),
// ETags are genuine MD5 checksums of the stored bytes, and a real HTTP
// PUT/GET/DELETE/LIST round-trip (verifiable with plain `curl`) is what
// proves the bucket resource works -- not just that the platform's own API
// says so.
//
// Deliberately NOT implemented: multipart upload, versioning, bucket
// policies/ACLs beyond "the platform decides who may reach this container",
// and AWS request signing -- this is CloudLab's own object protocol, not a
// drop-in S3 replacement.
package main

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const dataRoot = "/data"

// A single bucket is served per container instance (the platform creates one
// bucket-store container per `bucket` resource), so every object path is
// just the key -- no bucket-name segment in the URL.
func objectPath(key string) (string, bool) {
	clean := filepath.Clean("/" + key)
	if clean == "/" || strings.Contains(clean, "..") {
		return "", false
	}
	return filepath.Join(dataRoot, "objects", clean), true
}

func writeError(w http.ResponseWriter, status int, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]string{"error": message})
}

type objectInfo struct {
	Key          string `json:"key"`
	SizeBytes    int64  `json:"sizeBytes"`
	ETag         string `json:"etag"`
	LastModified string `json:"lastModified"`
}

// GET / -- list every object currently stored, sorted by key. This is the
// real directory listing, not a cached index that could drift from disk.
func handleList(w http.ResponseWriter) {
	root := filepath.Join(dataRoot, "objects")
	objects := []objectInfo{}
	filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return nil
		}
		rel, relErr := filepath.Rel(root, path)
		if relErr != nil {
			return nil
		}
		info, statErr := d.Info()
		if statErr != nil {
			return nil
		}
		etag, _ := md5File(path)
		objects = append(objects, objectInfo{
			Key:          filepath.ToSlash(rel),
			SizeBytes:    info.Size(),
			ETag:         etag,
			LastModified: info.ModTime().UTC().Format("2006-01-02T15:04:05Z"),
		})
		return nil
	})
	sort.Slice(objects, func(i, j int) bool { return objects[i].Key < objects[j].Key })
	json.NewEncoder(w).Encode(map[string]any{"objects": objects})
}

func md5File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := md5.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// PUT /<key> -- store the request body as the object at <key>. Keys may
// contain "/" (nested "directories" on disk, mirroring how S3-style prefixes
// work), created on demand.
func handlePut(w http.ResponseWriter, r *http.Request, key string) {
	path, ok := objectPath(key)
	if !ok {
		writeError(w, 400, "invalid key")
		return
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		writeError(w, 500, err.Error())
		return
	}
	tmp := path + ".uploading"
	f, err := os.Create(tmp)
	if err != nil {
		writeError(w, 500, err.Error())
		return
	}
	h := md5.New()
	size, err := io.Copy(io.MultiWriter(f, h), r.Body)
	f.Close()
	if err != nil {
		os.Remove(tmp)
		writeError(w, 500, err.Error())
		return
	}
	if err := os.Rename(tmp, path); err != nil {
		writeError(w, 500, err.Error())
		return
	}
	etag := hex.EncodeToString(h.Sum(nil))
	w.Header().Set("ETag", etag)
	w.Header().Set("Content-Length", "0")
	w.WriteHeader(http.StatusCreated)
	log.Printf("PUT %s (%d bytes, etag %s)", key, size, etag)
}

// GET/HEAD /<key>
func handleGet(w http.ResponseWriter, r *http.Request, key string) {
	path, ok := objectPath(key)
	if !ok {
		writeError(w, 400, "invalid key")
		return
	}
	info, err := os.Stat(path)
	if err != nil {
		writeError(w, 404, "object not found: "+key)
		return
	}
	etag, _ := md5File(path)
	w.Header().Set("ETag", etag)
	w.Header().Set("Content-Length", strconv.FormatInt(info.Size(), 10))
	if r.Method == http.MethodHead {
		w.WriteHeader(http.StatusOK)
		return
	}
	f, err := os.Open(path)
	if err != nil {
		writeError(w, 404, "object not found: "+key)
		return
	}
	defer f.Close()
	io.Copy(w, f)
}

// DELETE /<key>
func handleDelete(w http.ResponseWriter, key string) {
	path, ok := objectPath(key)
	if !ok {
		writeError(w, 400, "invalid key")
		return
	}
	if err := os.Remove(path); err != nil {
		if os.IsNotExist(err) {
			writeError(w, 404, "object not found: "+key)
			return
		}
		writeError(w, 500, err.Error())
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func router(w http.ResponseWriter, r *http.Request) {
	key := strings.TrimPrefix(r.URL.Path, "/")
	if key == "" || r.URL.Path == "/" {
		if r.Method == http.MethodGet {
			handleList(w)
			return
		}
		writeError(w, 405, "method not allowed on /")
		return
	}
	switch r.Method {
	case http.MethodPut:
		handlePut(w, r, key)
	case http.MethodGet, http.MethodHead:
		handleGet(w, r, key)
	case http.MethodDelete:
		handleDelete(w, key)
	default:
		writeError(w, 405, "method not allowed")
	}
}

func main() {
	os.MkdirAll(filepath.Join(dataRoot, "objects"), 0o755)
	http.HandleFunc("/", router)
	log.Println("cloudlab-bucket-store listening on :6000, data at", dataRoot)
	log.Fatal(http.ListenAndServe(":6000", nil))
}

#!/usr/bin/env bash
# Builds cloudlab/lb-proxy:latest entirely from local sources.
set -euo pipefail
cd "$(dirname "$0")"
rm -rf rootfs
mkdir -p rootfs/usr/bin rootfs/etc/cloudlab
echo "[1/2] compiling lb-proxy (static)"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o rootfs/usr/bin/lb-proxy lb-proxy.go
echo "[]" > rootfs/etc/cloudlab/lb-backends.json
echo "[2/2] docker build"
docker build -t cloudlab/lb-proxy:latest .
echo "done: cloudlab/lb-proxy:latest"

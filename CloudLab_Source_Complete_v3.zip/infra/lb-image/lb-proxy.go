// Real HTTP load balancer for CloudLab. Round-robins requests across a
// backend list that the worker rewrites on disk whenever a load_balancer
// resource's backend set changes, and health-checks each backend's
// guest-agent /healthz endpoint every few seconds, taking unhealthy
// backends out of rotation -- a real health-checked reverse proxy, not a
// static list.
package main

import (
	"encoding/json"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

type backend struct {
	Name string `json:"name"`
	IP   string `json:"ip"`
	Port int    `json:"port"`
}

var (
	mu       sync.RWMutex
	backends []backend
	healthy  = map[string]bool{}
	counter  uint64
)

const configPath = "/etc/cloudlab/lb-backends.json"

func loadConfig() {
	data, err := os.ReadFile(configPath)
	if err != nil {
		return
	}
	var list []backend
	if err := json.Unmarshal(data, &list); err != nil {
		log.Printf("lb-proxy: bad config: %v", err)
		return
	}
	mu.Lock()
	backends = list
	mu.Unlock()
}

func watchConfig() {
	var lastMod time.Time
	for {
		if fi, err := os.Stat(configPath); err == nil {
			if fi.ModTime().After(lastMod) {
				lastMod = fi.ModTime()
				loadConfig()
				log.Printf("lb-proxy: reloaded %d backend(s)", len(backends))
			}
		}
		time.Sleep(1 * time.Second)
	}
}

func healthLoop() {
	client := &http.Client{Timeout: 1500 * time.Millisecond}
	for {
		mu.RLock()
		snapshot := append([]backend{}, backends...)
		mu.RUnlock()
		next := map[string]bool{}
		for _, b := range snapshot {
			url := "http://" + b.IP + ":8080/healthz"
			resp, err := client.Get(url)
			ok := err == nil && resp.StatusCode == 200
			if resp != nil {
				resp.Body.Close()
			}
			next[b.Name] = ok
		}
		mu.Lock()
		healthy = next
		mu.Unlock()
		time.Sleep(2 * time.Second)
	}
}

func pickBackend() *backend {
	mu.RLock()
	defer mu.RUnlock()
	if len(backends) == 0 {
		return nil
	}
	n := atomic.AddUint64(&counter, 1)
	for i := 0; i < len(backends); i++ {
		b := backends[(int(n)+i)%len(backends)]
		if healthy[b.Name] {
			return &b
		}
	}
	return nil
}

func proxyHandler(w http.ResponseWriter, r *http.Request) {
	b := pickBackend()
	if b == nil {
		http.Error(w, "503 no healthy backend", http.StatusServiceUnavailable)
		return
	}
	target := "http://" + net.JoinHostPort(b.IP, "8080") + r.URL.Path
	req, err := http.NewRequest(r.Method, target, r.Body)
	if err != nil {
		http.Error(w, "502 bad gateway", http.StatusBadGateway)
		return
	}
	req.Header = r.Header
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		http.Error(w, "502 bad gateway: "+err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	w.Header().Set("X-CloudLab-LB-Backend", b.Name)
	for k, vv := range resp.Header {
		for _, v := range vv {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}

func statusHandler(w http.ResponseWriter, r *http.Request) {
	mu.RLock()
	defer mu.RUnlock()
	w.Header().Set("Content-Type", "application/json")
	type row struct {
		Name    string `json:"name"`
		IP      string `json:"ip"`
		Healthy bool   `json:"healthy"`
	}
	rows := []row{}
	for _, b := range backends {
		rows = append(rows, row{Name: b.Name, IP: b.IP, Healthy: healthy[b.Name]})
	}
	json.NewEncoder(w).Encode(rows)
}

func main() {
	loadConfig()
	go watchConfig()
	go healthLoop()

	mux := http.NewServeMux()
	mux.HandleFunc("/__lb_status", statusHandler)
	mux.HandleFunc("/", proxyHandler)

	log.Println("cloudlab-lb-proxy listening on :8080")
	log.Fatal(http.ListenAndServe(":8080", mux))
}

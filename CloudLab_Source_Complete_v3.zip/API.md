# CloudLab — API Reference

Base URL: `http://localhost:4000/api/v1` (see `.env` → `PORT`). All request
and response bodies are JSON. Authenticated routes require
`Authorization: Bearer <token>`.

There is no OpenAPI/Swagger document generated for this build pass (see
"Known limitations" in `ARCHITECTURE.md`) — this file is the reference.

## Error shape

Every error (validation, auth, permission, conflict, or an unhandled
exception) returns the same envelope, per the spec's "explain what
happened, why, how to diagnose it, and how to fix it" requirement:

```json
{
  "code": "PERMISSION_DENIED",
  "message": "Permission denied for 'network.networks.delete'",
  "what": "Your role (developer) does not include 'network.networks.delete'.",
  "why": "IAM policy evaluation denied this action (explicit deny, or no matching allow rule).",
  "diagnose": "Check Project > IAM to see your current role and its allow/deny lists.",
  "fix": "Ask a project Owner or Admin to grant a role that allows this action.",
  "requestId": "XuCElx8JIrK0"
}
```

Codes in use: `VALIDATION_ERROR` (400), `AUTHENTICATION_FAILED` (401),
`PERMISSION_DENIED` (403), `RESOURCE_NOT_FOUND` (404), `RESOURCE_CONFLICT`
(409), `DEPENDENCY_EXISTS` (409), `INTERNAL_ERROR` (500).

A `404 RESOURCE_NOT_FOUND` is returned both when a resource genuinely
doesn't exist *and* when the caller has no visibility into it at all (no
org/project membership) — real cloud APIs hide existence the same way. A
`403 PERMISSION_DENIED` only happens once the caller is known to have
*some* role on the project, but that role doesn't allow the specific
action.

## Auth

| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/auth/register` | none | `{name, email, password (min 8 chars)}` → `201 {token, user}` |
| POST | `/auth/login` | none | `{email, password}` → `200 {token, user}` |
| GET | `/auth/me` | bearer | → `200 {id, email, name}` |

## Organizations

| Method | Path | Notes |
|---|---|---|
| POST | `/organizations` | `{name}` → `201`, creates the org and makes the caller its `owner` |
| GET | `/organizations` | orgs the caller belongs to, each with `myRole` |
| GET | `/organizations/:id` | requires membership |

## Projects

| Method | Path | Notes |
|---|---|---|
| POST | `/projects` | `{orgId, name}` → `201`; requires org role `owner` or `admin` |
| GET | `/projects?orgId=` | projects the caller belongs to, each with `myRole` |
| GET | `/projects/:id` | requires project or inherited org access |
| GET | `/projects/:id/iam` | `{roles: BUILTIN_ROLES, bindings}`; requires `iam.roles.read` |
| POST | `/projects/:id/iam/bindings` | `{userId, roleKey}`, upserts a project role binding; requires `iam.bindings.create` |

## Networking

| Method | Path | Notes |
|---|---|---|
| POST | `/projects/:projectId/networks` | `{name, cidr?}` → `202 {resource, operationId}`; `resource.status` starts `CREATING` |
| GET | `/projects/:projectId/networks` | list |
| GET | `/projects/:projectId/networks/:id` | detail |
| DELETE | `/projects/:projectId/networks/:id` | → `202 {operationId}`; `409 DEPENDENCY_EXISTS` if a non-deleted instance still attaches to it |

A `READY` network's `metadata` includes the real `dockerNetworkId` and the
`cidr` actually allocated by Docker.

## Compute

| Method | Path | Notes |
|---|---|---|
| POST | `/projects/:projectId/instances` | `{name, networkId, publish?}` → `202`; `409 RESOURCE_CONFLICT` if the target network isn't `READY` yet |
| GET | `/projects/:projectId/instances` | list |
| GET | `/projects/:projectId/instances/:id` | detail |
| POST | `/projects/:projectId/instances/:id/start` | → `202`, sets status `PROVISIONING` first |
| POST | `/projects/:projectId/instances/:id/stop` | → `202`, sets status `STOPPING` first |
| DELETE | `/projects/:projectId/instances/:id` | → `202`, sets status `DELETING` first |
| GET | `/projects/:projectId/instances/:id/logs` | real container stdout/stderr (tail 200 lines); empty string while still provisioning |
| POST | `/projects/:projectId/instances/:id/exec` | `{command}` → `200 {output, exitCode}`; one-shot non-Tty `docker exec` |

A `READY` instance's `metadata` includes the real `containerId`, container
`ip`, `hostPort` (if published), and a `publicUrl` you can actually curl.

## Operations

| Method | Path | Notes |
|---|---|---|
| GET | `/projects/:projectId/operations/:id` | `{id, type, status, steps: [...], error?}` — `status` is `PENDING → RUNNING → SUCCEEDED/FAILED`; `steps` is the same list broadcast live over WebSocket |

## Architecture, activity, audit

| Method | Path | Notes |
|---|---|---|
| GET | `/projects/:projectId/architecture` | `{nodes, edges}`, rebuilt from the DB on every call — never cached, never hand-drawn |
| GET | `/projects/:projectId/activity` | last 200 audit-log rows for the project, newest first (human-readable feed of the audit facts) |
| GET | `/projects/:projectId/audit` | last 500 audit-log rows, filterable by `?action=&status=&userId=` |

## WebSockets

- **`GET /ws?token=<jwt>&projectId=<id>`** — live event stream for a
  project. Messages: `{type: "resource.update", resource}`,
  `{type: "operation.step", operationId, resourceId, step}`,
  `{type: "operation.update", operationId, resourceId, status}`. Requires a
  valid token before the upgrade is accepted.
- **`GET /ws/terminal?token=<jwt>&instanceId=<id>`** — a real Tty-attached
  `docker exec /bin/sh` inside the instance's container, piped bidirectionally
  over the socket. This is a genuine interactive shell, not a simulation.

## Example: full vertical slice with curl

```bash
TOKEN=$(curl -s localhost:4000/api/v1/auth/register \
  -H 'content-type: application/json' \
  -d '{"name":"Ada","email":"ada@example.com","password":"password123"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")

ORG=$(curl -s localhost:4000/api/v1/organizations -H "authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"name":"My Org"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")

PROJ=$(curl -s localhost:4000/api/v1/projects -H "authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d "{\"orgId\":\"$ORG\",\"name\":\"demo\"}" \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")

curl -s localhost:4000/api/v1/projects/$PROJ/networks -H "authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"name":"vpc-main","cidr":"172.30.5.0/24"}'
```

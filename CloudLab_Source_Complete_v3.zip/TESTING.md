# CloudLab — Testing

Three layers, each testing something the others can't:

| layer | file(s) | what it checks | needs Docker? |
|---|---|---|---|
| Unit/API tests | `apps/api/test/*.test.ts` (Vitest) | IAM glob matching, auth flows, resource-creation validation, dependency-check logic — all in-process via Fastify's `.inject()` | no |
| Vertical-slice e2e | `scripts/e2e.ts` | The full real stack over real HTTP: provisions a real Docker network + container, execs into it, tears it down, and cross-checks every claim against actual `docker inspect` output | **yes** |
| UI smoke test | `scripts/ui-smoke.mjs` (Playwright) | Drives the actual web console in headless Chromium and fails on any console error or unreachable UI state | yes |
| Formal QA run | `scripts/qa-run.mjs` (Playwright) | 18 documented, numbered test cases (see below) driven against the real running console, each with a screenshot captured at its assertion point; results written to `test-results/results.json` | yes |

## Running the tests

```bash
# Unit/API tests -- needs Postgres running, does NOT need the worker or Docker
npm test                       # from repo root, runs apps/api's vitest suite

# Full vertical-slice e2e -- needs API + worker + Postgres + Redis + Docker all running
npm run e2e

# UI smoke test -- same prerequisites as e2e, plus a headless Chromium (already
# installed in this environment at /opt/pw-browsers)
node scripts/ui-smoke.mjs
```

## What `apps/api/test/*.test.ts` covers (20 tests)

- **`auth.test.ts`** — registration issues a bearer token; duplicate email
  is rejected with `409`; short passwords rejected with `400`; login
  succeeds/fails correctly; `GET /me` requires and honors the bearer token;
  every request (even a failed one) gets a `requestId`, proving the audit
  hooks ran.
- **`iam.test.ts`** — unit tests for `matchesPattern`/`isAllowed` from
  `packages/shared` (exact match, `*`, prefix wildcards, suffix wildcards,
  deny-overrides-allow, viewer read-only), plus HTTP-level enforcement: a
  user with zero membership gets `404` (not `403`); a bound `viewer` can
  list but not create; the project owner can do everything including
  binding roles to others.
- **`resources.test.ts`** — creating a network returns `202` with the
  resource in `CREATING`; creating an instance against a nonexistent
  network is rejected (never a fake success); every mutating call writes a
  matching audit-log row; `assertDeletable()` correctly ignores
  relationships to already-`DELETED` dependents but still blocks deletion
  when a live dependent exists.

Run against the real local Postgres (no mocking) — per the project's own
principle, IAM and the resource model are exactly the kind of logic that
shouldn't be tested against a fake.

## What `scripts/e2e.ts` covers (31 checks)

Registers a user, creates an org/project, confirms a stranger gets `404`
on a project they can't see, then:

1. Creates a real network, polls until `READY`, and runs
   `docker network inspect` on the `dockerNetworkId` the API reported —
   confirming the network genuinely exists on the daemon, not just in
   Postgres.
2. Creates a real instance on that network, polls until `READY`, and runs
   `docker inspect --format {{.State.Running}}` on the reported
   `containerId` — confirming the container is genuinely running.
3. Runs a real command via `POST .../exec` and checks for real output;
   separately curls the instance's real published `/healthz` endpoint.
4. Confirms the architecture graph includes both resources and the real
   `connects_to` edge between them.
5. Confirms the activity feed and audit log recorded the create actions.
6. Binds a `viewer` role to a second user and confirms they can list but
   not create.
7. Confirms deleting the network while the instance is still live is
   blocked with `409 DEPENDENCY_EXISTS`; deletes the instance, confirms
   both the DB status and the real Docker container are gone; only then
   deletes the network, and confirms both the DB status and the real
   Docker network are gone.

## What `scripts/ui-smoke.mjs` covers

Headless-Chromium walk through the actual console: register → create org →
create project → dashboard loads → create a network and watch it reach
`READY` in the UI → create an instance on it and watch it reach `READY` →
exec a command → open Architecture/Activity/Audit tabs and confirm they're
populated. Fails on any `pageerror` or `console.error` the page emits. Not
part of `npm test`/`npm run e2e` — it's a manual development aid, run
directly with `node scripts/ui-smoke.mjs`.

## What `scripts/qa-run.mjs` covers (18 numbered test cases, TC-01 .. TC-18)

A formally documented run intended for a human audience (a test report), not
just CI: registration, invalid-login rejection, org/project creation, real
network and instance provisioning through to `READY`, the exec panel, the
real interactive terminal, the auto-derived architecture graph, the activity
timeline, the audit log, the IAM role list, viewer-role enforcement (with
the denied attempt visible in the audit log), the existence-hiding 404,
delete-blocked-by-dependency, and the two-step teardown. Each test case
captures a full-page screenshot at its assertion point into
`test-results/screenshots/`, and every case's outcome is written to
`test-results/results.json`. Run with `node scripts/qa-run.mjs` (needs the
same live stack as `scripts/e2e.ts`).

## Real bugs these tests actually caught (kept here as evidence they're
worth running, not just present)

1. **Fastify hook-encapsulation leak.** Every protected route file
   originally called `app.addHook("preHandler", authenticate)` directly on
   the shared top-level `app`, which applies a hook globally in Fastify
   with no encapsulation boundary — this silently required auth on the
   public `/auth/register` and `/auth/login` routes too, breaking
   registration/login entirely. Found via manual curl testing before the
   formal suite existed; the regression is now permanently covered by
   `auth.test.ts`'s registration/login tests (which run against the whole
   built server, not an isolated handler).
2. **IAM wildcard segment-count bug.** The original `matchesPattern`
   required the pattern and the action to split into the same number of
   `.`-separated segments, so `*.list` (2 segments) never matched
   `compute.instances.list` (3 segments) — silently breaking the `viewer`
   role's entire read access. Covered by the dedicated regression test in
   `iam.test.ts`.
3. **Dependency-check bug.** `assertDeletable()` originally blocked
   deleting a resource if *any* relationship row pointed at it, even after
   the dependent resource itself was already `DELETED` — so deleting an
   instance and then its network still failed. Covered by both
   `resources.test.ts` (unit-level) and `scripts/e2e.ts` step 7
   (end-to-end, against the real Docker network's actual removal).
4. **Stale architecture graph on tab switch.** The console fetched the
   architecture graph once, on project load, and never again — switching
   to the Architecture tab after creating resources showed a stale (often
   near-empty) graph. Caught by `scripts/ui-smoke.mjs` reporting a node
   count of 1 when 3 were expected; fixed by refetching on switching to
   the Architecture/Activity/Audit/IAM tabs specifically (not
   Networking/Compute, to avoid a re-render race clobbering in-progress
   form input — see `UI_UX.md`).
5. **Empty-body JSON parser rejection on DELETE.** The web console's
   `api()` wrapper (and this project's own `scripts/e2e.ts`) always send
   `content-type: application/json`, including on bodyless `DELETE`
   requests. Fastify's default JSON body parser rejects an empty body
   under that content-type, which meant every delete button in the actual
   web UI was silently broken (`500 INTERNAL_ERROR`). Caught by
   `scripts/e2e.ts`'s teardown steps; fixed with a custom
   `addContentTypeParser` in `server.ts` that treats an empty body as "no
   body" instead of a parse error.
6. **Errors were silently swallowed inside the main console.** Every action
   inside the app (create/delete a resource, run an exec command, bind an
   IAM role) already routed failures into `state.error` via
   `withErrorHandling()`, but the `<div class="error-banner">` that
   displays it only existed on the pre-login, org-picker, and
   project-picker screens. Once past project selection, a permission
   denial, a blocked delete, or a failed exec produced *no visible
   feedback at all* — the request failed (visible only in the browser's
   network tab) while the UI looked exactly as if nothing had happened.
   Caught by `scripts/qa-run.mjs`'s TC-15 (deleting a network with a live
   dependent instance timed out waiting for an error that was being
   computed but never rendered). Fixed by rendering the same error banner
   inside the main layout (`apps/api/public/app.js`, `render()`).
7. **Running an exec command silently erased its own output and reset the
   live terminal.** The exec "Run" button's success path was wrapped in
   `withErrorHandling()`, which unconditionally calls the global `render()`
   at the end — rebuilding the entire instance-detail view from scratch.
   That discarded the just-appended exec output (visually, it never even
   flashed) and, because the same rebuild recreates the terminal panel's
   `<div>`, silently disconnected and reopened the real terminal's
   WebSocket underneath the user. Caught by `scripts/qa-run.mjs`'s TC-07
   (exec output always read back as just the initial `"$ "` prompt).
   Fixed by having the exec button manage its own try/catch and DOM update
   without triggering a page-wide re-render — the panel is self-contained
   and doesn't need one.

## Not yet covered

- WebSocket message delivery itself (the live-update path) has no test
  asserting exact message shapes — it's exercised implicitly by tests
  reaching `READY` badges and by `scripts/qa-run.mjs`'s TC-08 sending a
  real command through `/ws/terminal` and reading real shell output back.
- No load/concurrency testing.

## Known UI navigation gap (found during QA, not yet fixed)

`scripts/qa-run.mjs`'s TC-13 verifies IAM enforcement directly against the
API rather than by clicking through the console as a bound viewer, because
of a real gap: the console's org/project picker only ever lists projects
reached through an **org** membership (`GET /organizations` →
`GET /projects`). A user who holds only a **project-level** role binding —
exactly the shape `POST /projects/:id/iam/bindings` creates, and exactly
what the IAM engine's "project membership first, org membership as
fallback" design supports (see `SECURITY.md`) — has no path in the console
to ever reach that project, even though the API would serve them fine.
Severity: medium (a real, supported access pattern is invisible in the UI).
Not fixed in this pass since there's no invite/join flow to hang a fix off
of yet; the natural fix is a "projects shared with me directly" list
alongside the org-scoped one once such a flow exists.

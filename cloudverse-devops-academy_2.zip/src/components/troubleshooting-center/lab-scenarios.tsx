"use client";
import * as React from "react";
import { Search, BookOpen } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScenarioList, MODULE_LABEL } from "@/components/console-sim/scenario-list";
import { ALL_LAB_SCENARIOS, getLabModules } from "@/lib/console-sim/all-scenarios";
import { SimModule } from "@/lib/console-sim/types";

const MODULES = getLabModules();

export function LabScenarios() {
  const [query, setQuery] = React.useState("");
  const [module, setModule] = React.useState<SimModule | "all">("all");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return ALL_LAB_SCENARIOS.filter((s) => {
      if (module !== "all" && s.module !== module) return false;
      if (!q) return true;
      return (
        s.title.toLowerCase().includes(q) ||
        s.symptom.toLowerCase().includes(q) ||
        s.cause.toLowerCase().includes(q) ||
        (s.resourceType?.toLowerCase().includes(q) ?? false)
      );
    });
  }, [query, module]);

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="flex flex-col gap-3 pt-5 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search hands-on lab errors by symptom, cause, or resource…"
              className="pl-9"
            />
          </div>
          <Select value={module} onValueChange={(v) => setModule(v as SimModule | "all")}>
            <SelectTrigger className="w-full sm:w-56">
              <SelectValue placeholder="All labs" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All labs</SelectItem>
              {MODULES.map((m) => (
                <SelectItem key={m} value={m}>
                  {MODULE_LABEL[m]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        {filtered.length} of {ALL_LAB_SCENARIOS.length} lab scenarios shown — the same content you can trigger live
        with &quot;Simulate this error&quot; inside GCP Services, Terraform Lab, Docker Lab, and Kubernetes Lab.
      </p>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center text-sm text-muted-foreground">
            <BookOpen className="h-6 w-6" />
            No lab scenarios match &quot;{query}&quot;. Try a different search or lab.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="pt-3">
            <ScenarioList scenarios={filtered} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

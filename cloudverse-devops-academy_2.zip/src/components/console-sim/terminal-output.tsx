"use client";

import * as React from "react";
import { SimLogEntry } from "@/lib/console-sim/types";
import { cn } from "@/lib/utils";

// Literal class lookup — never construct Tailwind classes dynamically.
const LEVEL_CLASS: Record<SimLogEntry["level"], string> = {
  info: "text-slate-300",
  success: "text-emerald-400",
  warn: "text-amber-400",
  error: "text-red-400",
  command: "text-sky-300",
};

const LEVEL_PREFIX: Record<SimLogEntry["level"], string> = {
  info: " ",
  success: "✓",
  warn: "!",
  error: "✕",
  command: "$",
};

/**
 * Shared dark "terminal" surface used by the GCP Console, Terraform Lab,
 * Docker Lab, and Kubernetes Lab simulators so every hands-on lab feels
 * consistent. Auto-scrolls to the newest line as entries stream in.
 */
export function TerminalOutput({
  lines,
  emptyLabel = "Nothing has run yet.",
  className,
  heightClassName = "h-64",
}: {
  lines: SimLogEntry[];
  emptyLabel?: string;
  className?: string;
  heightClassName?: string;
}) {
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines.length]);

  return (
    <div
      ref={scrollRef}
      className={cn(
        "overflow-y-auto rounded-lg border border-border bg-[#0b0e14] p-3 font-mono text-xs leading-relaxed",
        heightClassName,
        className,
      )}
    >
      {lines.length === 0 ? (
        <p className="text-slate-500">{emptyLabel}</p>
      ) : (
        lines.map((line) => (
          <div key={line.id} className={cn("flex gap-2", LEVEL_CLASS[line.level])}>
            <span className="shrink-0 select-none text-slate-600">{line.ts}</span>
            <span className="shrink-0 select-none">{LEVEL_PREFIX[line.level]}</span>
            <span className="whitespace-pre-wrap break-words">{line.message}</span>
          </div>
        ))
      )}
    </div>
  );
}

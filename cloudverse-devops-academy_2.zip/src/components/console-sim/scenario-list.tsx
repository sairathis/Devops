"use client";

import * as React from "react";
import { AlertTriangle, Wrench, Lightbulb, PlayCircle } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ErrorScenario } from "@/lib/console-sim/types";

/**
 * Shared "what can go wrong here, and how to fix it" list used by the
 * GCP Console, Terraform Lab, Docker Lab, and Kubernetes Lab troubleshooting
 * tabs, and reused verbatim by the Troubleshooting Center's Reference
 * Library so every scenario looks the same wherever it appears.
 *
 * Pass onSimulate to render a "Simulate this error" button that replays the
 * scenario's cliOutput into the caller's terminal — omit it for a read-only
 * reference view (e.g. inside the Troubleshooting Center).
 */
export function ScenarioList({
  scenarios,
  onSimulate,
  emptyLabel = "No known issues for this resource yet.",
}: {
  scenarios: ErrorScenario[];
  onSimulate?: (scenario: ErrorScenario) => void;
  emptyLabel?: string;
}) {
  if (scenarios.length === 0) {
    return <p className="py-6 text-center text-sm text-muted-foreground">{emptyLabel}</p>;
  }

  return (
    <Accordion type="single" collapsible className="w-full">
      {scenarios.map((s) => (
        <AccordionItem key={s.id} value={s.id}>
          <AccordionTrigger className="text-sm">{s.title}</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3 pl-1">
              <p className="text-sm text-muted-foreground">{s.symptom}</p>

              <div className="flex items-start gap-2 text-sm">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-yellow" />
                <p>
                  <span className="font-medium text-foreground">Cause: </span>
                  {s.cause}
                </p>
              </div>

              <div className="flex items-start gap-2 text-sm">
                <Wrench className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-green" />
                <div>
                  <span className="font-medium text-foreground">Fix: </span>
                  <ol className="mt-1 list-decimal space-y-1 pl-4">
                    {s.fixSteps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </div>
              </div>

              {s.preventionTip && (
                <div className="flex items-start gap-2 text-sm">
                  <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gcp-blue" />
                  <p>
                    <span className="font-medium text-foreground">Prevent it: </span>
                    {s.preventionTip}
                  </p>
                </div>
              )}

              {onSimulate && (
                <Button size="sm" variant="outline" className="gap-1.5" onClick={() => onSimulate(s)}>
                  <PlayCircle className="h-3.5 w-3.5" /> Simulate this error
                </Button>
              )}

              {s.docsUrl && (
                <a
                  href={s.docsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-xs text-primary hover:underline"
                >
                  Read the official docs
                </a>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

// Literal Tailwind class map for module badges — reused by Troubleshooting Center.
export const MODULE_BADGE_CLASS: Record<ErrorScenario["module"], string> = {
  "gcp-services": "border-gcp-green/20 bg-gcp-green/10 text-gcp-green",
  terraform: "border-primary/20 bg-primary/10 text-primary",
  docker: "border-gcp-blue/20 bg-gcp-blue/10 text-gcp-blue",
  kubernetes: "border-gcp-red/20 bg-gcp-red/10 text-gcp-red",
};

export const MODULE_LABEL: Record<ErrorScenario["module"], string> = {
  "gcp-services": "GCP Services",
  terraform: "Terraform Lab",
  docker: "Docker Lab",
  kubernetes: "Kubernetes Lab",
};

export function ModuleBadge({ module }: { module: ErrorScenario["module"] }) {
  return <Badge className={MODULE_BADGE_CLASS[module]}>{MODULE_LABEL[module]}</Badge>;
}

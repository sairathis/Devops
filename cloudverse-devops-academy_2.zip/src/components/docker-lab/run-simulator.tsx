"use client";

import * as React from "react";
import { PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { DOCKER_SCENARIOS } from "@/lib/console-sim/scenarios-docker";
import { useDockerLabStore } from "@/store/docker-lab-store";

const NONE_SCENARIO_VALUE = "none";

export function RunSimulator({
  enabled,
  exposePort,
}: {
  enabled: boolean;
  exposePort?: string;
}) {
  const runContainer = useDockerLabStore((s) => s.runContainer);
  const containers = useDockerLabStore((s) => s.containers);

  const [image, setImage] = React.useState("app:latest");
  const [hostPort, setHostPort] = React.useState(3000);
  const [containerPort, setContainerPort] = React.useState<number>(() => Number(exposePort) || 3000);
  const [containerPortTouched, setContainerPortTouched] = React.useState(false);
  const [scenarioId, setScenarioId] = React.useState<string>(NONE_SCENARIO_VALUE);
  const [lastRunId, setLastRunId] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (containerPortTouched) return;
    const parsed = Number(exposePort);
    setContainerPort(Number.isFinite(parsed) && parsed > 0 ? parsed : 3000);
  }, [exposePort, containerPortTouched]);

  const lastRunContainer = containers.find((c) => c.id === lastRunId);

  const handleRun = () => {
    const scenario =
      scenarioId === NONE_SCENARIO_VALUE ? undefined : DOCKER_SCENARIOS.find((s) => s.id === scenarioId);
    const id = runContainer(image.trim() || "app:latest", hostPort, containerPort, scenario);
    setLastRunId(id);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Run container</CardTitle>
        <CardDescription>
          Run the image you just built and watch a simulated `docker run` sequence &mdash; pull, extract layers, and
          boot the app.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!enabled && (
          <p className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
            Simulate a build above first to enable running a container.
          </p>
        )}

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label htmlFor="run-image">Image</Label>
            <Input
              id="run-image"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              disabled={!enabled}
              placeholder="app:latest"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="run-host-port">Host port</Label>
            <Input
              id="run-host-port"
              type="number"
              min={1}
              max={65535}
              value={hostPort}
              onChange={(e) => setHostPort(Number(e.target.value) || 0)}
              disabled={!enabled}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="run-container-port">Container port</Label>
            <Input
              id="run-container-port"
              type="number"
              min={1}
              max={65535}
              value={containerPort}
              onChange={(e) => {
                setContainerPortTouched(true);
                setContainerPort(Number(e.target.value) || 0);
              }}
              disabled={!enabled}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="run-scenario">Simulate a failure</Label>
          <Select value={scenarioId} onValueChange={setScenarioId} disabled={!enabled}>
            <SelectTrigger id="run-scenario">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={NONE_SCENARIO_VALUE}>None &mdash; run normally</SelectItem>
              {DOCKER_SCENARIOS.map((scenario) => (
                <SelectItem key={scenario.id} value={scenario.id}>
                  {scenario.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button onClick={handleRun} disabled={!enabled} className="gap-1.5">
          <PlayCircle className="h-3.5 w-3.5" /> Run Container
        </Button>

        {lastRunContainer && (
          <div className="space-y-1.5">
            <Label>Latest run output</Label>
            <TerminalOutput lines={lastRunContainer.logs} heightClassName="h-48" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

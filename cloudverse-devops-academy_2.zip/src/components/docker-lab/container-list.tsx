"use client";

import * as React from "react";
import { Box, Play, ScrollText, Square, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ScenarioList } from "@/components/console-sim/scenario-list";
import { DOCKER_SCENARIOS } from "@/lib/console-sim/scenarios-docker";
import { cn } from "@/lib/utils";
import { useDockerLabStore, type ContainerStatus } from "@/store/docker-lab-store";

// Literal Tailwind class map — never construct these dynamically.
const STATUS_BADGE_CLASS: Record<ContainerStatus, string> = {
  running: "border-transparent bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  exited: "border-transparent bg-slate-500/15 text-slate-600 dark:text-slate-400",
  restarting: "border-transparent bg-amber-500/15 text-amber-600 dark:text-amber-400",
  crashloop: "border-transparent bg-red-500/15 text-red-600 dark:text-red-400",
};

const STATUS_LABEL: Record<ContainerStatus, string> = {
  running: "Running",
  exited: "Exited",
  restarting: "Restarting",
  crashloop: "Crash loop",
};

export function ContainerList() {
  const containers = useDockerLabStore((s) => s.containers);
  const stopContainer = useDockerLabStore((s) => s.stopContainer);
  const startContainer = useDockerLabStore((s) => s.startContainer);
  const removeContainer = useDockerLabStore((s) => s.removeContainer);
  const simulateScenario = useDockerLabStore((s) => s.simulateScenario);

  const [logsContainerId, setLogsContainerId] = React.useState<string | null>(null);
  const logsContainer = containers.find((c) => c.id === logsContainerId) ?? null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Running containers</CardTitle>
        <CardDescription>Everything you&apos;ve run from this Dockerfile, in one place.</CardDescription>
      </CardHeader>
      <CardContent>
        {containers.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed border-border py-10 text-center">
            <Box className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No containers yet &mdash; run one above to see it here.</p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {containers.map((container) => (
              <div key={container.id} className="rounded-lg border border-border p-3.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{container.name}</p>
                    <p className="truncate font-mono text-xs text-muted-foreground">{container.image}</p>
                  </div>
                  <Badge className={cn(STATUS_BADGE_CLASS[container.status])}>
                    {STATUS_LABEL[container.status]}
                  </Badge>
                </div>

                <Separator className="my-2.5" />

                <div className="space-y-1 text-xs text-muted-foreground">
                  <p>
                    Ports: <span className="font-mono text-foreground">{container.hostPort}:{container.containerPort}</span>
                  </p>
                  <p>Created: {new Date(container.createdAt).toLocaleTimeString([], { hour12: false })}</p>
                  {typeof container.exitCode === "number" && (
                    <p>
                      Exit code: <span className="font-mono text-foreground">{container.exitCode}</span>
                    </p>
                  )}
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {container.status === "exited" ? (
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => startContainer(container.id)}>
                      <Play className="h-3.5 w-3.5" /> Start
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5"
                      disabled={container.status === "restarting"}
                      onClick={() => stopContainer(container.id)}
                    >
                      <Square className="h-3.5 w-3.5" /> Stop
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setLogsContainerId(container.id)}>
                    <ScrollText className="h-3.5 w-3.5" /> View logs
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1.5 text-danger hover:text-danger"
                    onClick={() => removeContainer(container.id)}
                  >
                    <Trash2 className="h-3.5 w-3.5" /> Remove
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <Sheet open={logsContainer !== null} onOpenChange={(open) => !open && setLogsContainerId(null)}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-lg">
          {logsContainer && (
            <>
              <SheetHeader>
                <SheetTitle>{logsContainer.name}</SheetTitle>
                <SheetDescription className="font-mono">{logsContainer.image}</SheetDescription>
              </SheetHeader>

              <div className="mt-4 space-y-5">
                <TerminalOutput lines={logsContainer.logs} heightClassName="h-72" />

                <div>
                  <h4 className="mb-1.5 text-sm font-semibold">Simulate a failure on this container</h4>
                  <ScenarioList
                    scenarios={DOCKER_SCENARIOS}
                    onSimulate={(scenario) => simulateScenario(logsContainer.id, scenario)}
                  />
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </Card>
  );
}

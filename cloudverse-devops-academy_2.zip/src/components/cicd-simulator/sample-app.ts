/**
 * The "sample app" shipped by the CI/CD simulator.
 *
 * This is deliberately a single, small, pure function with clear branching
 * logic (a tiered pricing ladder plus an express surcharge) — simple enough
 * to read in one glance, but with enough branches that a learner can
 * introduce a realistic bug (an off-by-one tier boundary, a wrong
 * multiplier, a flipped condition) and immediately see a real unit test
 * fail in the pipeline below, rather than watching a dice roll.
 */

export const FUNCTION_NAME = "calculateShippingCost";

export const DEFAULT_APP_CODE = `function calculateShippingCost(weightKg, isExpress) {
  let baseCost;

  if (weightKg <= 1) {
    baseCost = 5;
  } else if (weightKg <= 5) {
    baseCost = 5 + (weightKg - 1) * 2;
  } else {
    baseCost = 13 + (weightKg - 5) * 1.5;
  }

  if (isExpress) {
    baseCost = baseCost * 1.75;
  }

  return Math.round(baseCost * 100) / 100;
}
`;

export type ShippingCostFn = (weightKg: number, isExpress: boolean) => number;

export interface TestCase {
  description: string;
  run: (fn: ShippingCostFn) => boolean;
}

export const TEST_CASES: TestCase[] = [
  {
    description: "1kg standard parcel costs $5.00 (base tier)",
    run: (fn) => fn(1, false) === 5,
  },
  {
    description: "3kg standard parcel costs $9.00 (light tier)",
    run: (fn) => fn(3, false) === 9,
  },
  {
    description: "5kg standard parcel costs $13.00 (light/heavy tier boundary)",
    run: (fn) => fn(5, false) === 13,
  },
  {
    description: "10kg standard parcel costs $20.50 (heavy tier)",
    run: (fn) => fn(10, false) === 20.5,
  },
  {
    description: "1kg express parcel applies a 1.75x surcharge -> $8.75",
    run: (fn) => fn(1, true) === 8.75,
  },
  {
    description: "5kg express parcel applies a 1.75x surcharge -> $22.75",
    run: (fn) => fn(5, true) === 22.75,
  },
];

export interface TestResult {
  description: string;
  passed: boolean;
  error?: string;
}

function describeError(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}

/**
 * Safely evaluates `code` looking for a top-level function named
 * FUNCTION_NAME, then runs every TEST_CASE against it. Never throws —
 * a syntax error, a missing function, or an exception thrown while a test
 * runs is all captured and reported as a failed test instead of crashing
 * the caller (the pipeline UI).
 */
export function runTests(code: string): TestResult[] {
  let extracted: unknown;
  try {
    extracted = new Function(`${code}\nreturn ${FUNCTION_NAME};`)();
  } catch (err) {
    return [
      {
        description: "Code compiles cleanly",
        passed: false,
        error: describeError(err),
      },
    ];
  }

  if (typeof extracted !== "function") {
    return [
      {
        description: "Code compiles cleanly",
        passed: false,
        error: `Expected a function named "${FUNCTION_NAME}" to be defined, but it was not found.`,
      },
    ];
  }

  const fn = extracted as ShippingCostFn;

  return TEST_CASES.map((test) => {
    try {
      const passed = test.run(fn);
      return { description: test.description, passed };
    } catch (err) {
      return { description: test.description, passed: false, error: describeError(err) };
    }
  });
}

"use client";

import * as React from "react";
import { Terminal, Play, Rocket, Flame, RefreshCw, AlertOctagon, BookOpenCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ScenarioList } from "@/components/console-sim/scenario-list";
import { ErrorScenario, SimLogEntry, SimLogLevel, makeLog } from "@/lib/console-sim/types";
import { TERRAFORM_SCENARIOS } from "@/lib/console-sim/scenarios-terraform";
import { parseResourceBlocks } from "@/lib/terraform-lab/plan-parser";
import { randomId } from "@/lib/utils";

interface TerminalSimulatorProps {
  code: string;
}

interface PendingLine {
  level: SimLogLevel;
  message: string;
}

const NO_FAILURE_VALUE = "none";

// Plausible placeholder attributes for synthetic `plan` output. These never
// need to match a real provider schema — they only need to look right.
const PLAN_FIELD_POOL: Array<[string, string]> = [
  ["id", "(known after apply)"],
  ["self_link", "(known after apply)"],
  ["creation_timestamp", "(known after apply)"],
  ["project", '"my-gcp-project"'],
  ["labels", "{}"],
  ["effective_labels", "(known after apply)"],
  ["location", '"us-central1"'],
  ["terraform_labels", "(known after apply)"],
];

function pickPlanFields(count: number): Array<[string, string]> {
  const shuffled = [...PLAN_FIELD_POOL].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

// cliOutput lines from a scenario are plain strings — infer a display level
// from their content so errors read red and context reads neutral.
function classifyScenarioLine(line: string): SimLogLevel {
  return /error/i.test(line) ? "error" : "info";
}

export function TerminalSimulator({ code }: TerminalSimulatorProps) {
  const [logs, setLogs] = React.useState<SimLogEntry[]>([]);
  const [running, setRunning] = React.useState(false);
  const [hasInit, setHasInit] = React.useState(false);
  const [hasPlanned, setHasPlanned] = React.useState(false);
  const [hasApplied, setHasApplied] = React.useState(false);
  const [selectedFailureId, setSelectedFailureId] = React.useState<string>(NO_FAILURE_VALUE);
  const [triggeredScenario, setTriggeredScenario] = React.useState<ErrorScenario | null>(null);

  const timeoutsRef = React.useRef<ReturnType<typeof setTimeout>[]>([]);
  const prevCodeRef = React.useRef(code);

  // Editing the HCL invalidates whatever init/plan/apply state applied to
  // the previous version of the code — you'd need to re-run the pipeline
  // against the new config, just like the real CLI workflow.
  React.useEffect(() => {
    if (prevCodeRef.current !== code) {
      prevCodeRef.current = code;
      setHasInit(false);
      setHasPlanned(false);
      setHasApplied(false);
    }
  }, [code]);

  React.useEffect(() => {
    const timeouts = timeoutsRef.current;
    return () => {
      timeouts.forEach(clearTimeout);
    };
  }, []);

  const scheduleAppend = React.useCallback((lines: PendingLine[], onDone?: () => void) => {
    if (lines.length === 0) {
      onDone?.();
      return;
    }
    let cumulative = 0;
    lines.forEach((line, idx) => {
      cumulative += 180 + Math.round(Math.random() * 140);
      const timeoutId = setTimeout(() => {
        setLogs((prev) => [...prev, makeLog(line.level, line.message)]);
        if (idx === lines.length - 1) onDone?.();
      }, cumulative);
      timeoutsRef.current.push(timeoutId);
    });
  }, []);

  const activeFailureScenario = React.useMemo(
    () => TERRAFORM_SCENARIOS.find((s) => s.id === selectedFailureId) ?? null,
    [selectedFailureId],
  );

  const runInit = () => {
    if (running) return;
    setRunning(true);
    setTriggeredScenario(null);
    const lines: PendingLine[] = [
      { level: "command", message: "terraform init" },
      { level: "info", message: "Initializing the backend..." },
      { level: "info", message: "Initializing provider plugins..." },
      { level: "info", message: '- Finding hashicorp/google versions matching "~> 5.0"...' },
      { level: "info", message: "- Installing hashicorp/google v5.31.0..." },
      { level: "success", message: "Terraform has been successfully initialized!" },
    ];
    scheduleAppend(lines, () => {
      setHasInit(true);
      setRunning(false);
    });
  };

  const runPlan = () => {
    if (running || !hasInit) return;
    setRunning(true);
    setTriggeredScenario(null);

    const resources = parseResourceBlocks(code);
    const failure = activeFailureScenario;
    const lines: PendingLine[] = [{ level: "command", message: "terraform plan" }];

    if (failure) {
      lines.push({ level: "info", message: "Refreshing Terraform state in-memory prior to this plan..." });
      failure.cliOutput.forEach((line) => lines.push({ level: classifyScenarioLine(line), message: line }));
    } else if (resources.length === 0) {
      lines.push({ level: "info", message: "No changes. Your infrastructure matches the configuration." });
    } else {
      resources.forEach((r) => {
        lines.push({ level: "success", message: `  + resource "${r.hclType}" "${r.hclName}" {` });
        const fieldCount = 2 + Math.floor(Math.random() * 3);
        pickPlanFields(fieldCount).forEach(([field, value]) => {
          lines.push({ level: "success", message: `      + ${field} = ${value}` });
        });
        lines.push({ level: "success", message: "    }" });
      });
      lines.push({ level: "info", message: `Plan: ${resources.length} to add, 0 to change, 0 to destroy.` });
    }

    scheduleAppend(lines, () => {
      setRunning(false);
      if (failure) {
        setTriggeredScenario(failure);
        setSelectedFailureId(NO_FAILURE_VALUE);
      } else {
        setHasPlanned(true);
      }
    });
  };

  const runApply = () => {
    if (running || !hasPlanned) return;
    setRunning(true);
    setTriggeredScenario(null);

    const resources = parseResourceBlocks(code);
    const failure = activeFailureScenario;
    const lines: PendingLine[] = [
      { level: "command", message: "terraform apply" },
      { level: "info", message: "Do you want to perform these actions?" },
      { level: "info", message: "  Terraform will perform the actions described above." },
      { level: "command", message: "  Enter a value: yes" },
    ];

    if (failure) {
      failure.cliOutput.forEach((line) => lines.push({ level: classifyScenarioLine(line), message: line }));
    } else if (resources.length === 0) {
      lines.push({ level: "info", message: "No changes to apply." });
    } else {
      resources.forEach((r) => {
        lines.push({ level: "info", message: `${r.hclType}.${r.hclName}: Creating...` });
        const seconds = 1 + Math.floor(Math.random() * 9);
        const resourceId = randomId(r.hclType.replace(/[^a-z0-9]/gi, ""));
        lines.push({
          level: "success",
          message: `${r.hclType}.${r.hclName}: Creation complete after ${seconds}s [id=${resourceId}]`,
        });
      });
      lines.push({
        level: "success",
        message: `Apply complete! Resources: ${resources.length} added, 0 changed, 0 destroyed.`,
      });
    }

    scheduleAppend(lines, () => {
      setRunning(false);
      if (failure) {
        setTriggeredScenario(failure);
        setSelectedFailureId(NO_FAILURE_VALUE);
      } else {
        setHasApplied(true);
      }
    });
  };

  const runDestroy = () => {
    if (running || !hasApplied) return;
    setRunning(true);
    setTriggeredScenario(null);

    const resources = parseResourceBlocks(code);
    const lines: PendingLine[] = [
      { level: "command", message: "terraform destroy" },
      { level: "info", message: "Do you really want to destroy all resources?" },
      { level: "command", message: "  Enter a value: yes" },
    ];

    if (resources.length === 0) {
      lines.push({ level: "info", message: "No resources to destroy." });
    } else {
      resources.forEach((r) => {
        lines.push({ level: "info", message: `${r.hclType}.${r.hclName}: Destroying...` });
        const seconds = 1 + Math.floor(Math.random() * 6);
        lines.push({ level: "success", message: `${r.hclType}.${r.hclName}: Destruction complete after ${seconds}s` });
      });
      lines.push({ level: "success", message: `Destroy complete! Resources: ${resources.length} destroyed.` });
    }

    scheduleAppend(lines, () => {
      setRunning(false);
      setHasApplied(false);
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-primary" />
            <div>
              <CardTitle>Terraform CLI simulator</CardTitle>
              <CardDescription>
                A realistic simulation of <code className="font-mono">init</code> /{" "}
                <code className="font-mono">plan</code> / <code className="font-mono">apply</code> /{" "}
                <code className="font-mono">destroy</code> for practice — no real binary, no real cloud calls.
              </CardDescription>
            </div>
          </div>
          {running && (
            <Badge variant="info" className="gap-1">
              <RefreshCw className="h-3 w-3 animate-spin" /> Running...
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm" onClick={runInit} disabled={running} title="Download providers and set up the backend">
            <Play className="h-3.5 w-3.5" /> terraform init
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={runPlan}
            disabled={running || !hasInit}
            title={hasInit ? "Preview the changes Terraform would make" : "Run terraform init first"}
          >
            <BookOpenCheck className="h-3.5 w-3.5" /> terraform plan
          </Button>
          <Button
            size="sm"
            onClick={runApply}
            disabled={running || !hasPlanned}
            title={hasPlanned ? "Create the planned resources" : "Run terraform plan first"}
          >
            <Rocket className="h-3.5 w-3.5" /> terraform apply
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={runDestroy}
            disabled={running || !hasApplied}
            title={hasApplied ? "Tear down everything this apply created" : "Run terraform apply first"}
          >
            <Flame className="h-3.5 w-3.5" /> terraform destroy
          </Button>

          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Simulate a failure</span>
            <Select value={selectedFailureId} onValueChange={setSelectedFailureId} disabled={running}>
              <SelectTrigger className="h-8 w-[260px] text-xs">
                <SelectValue placeholder="None — run normally" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NO_FAILURE_VALUE}>None — run normally</SelectItem>
                {TERRAFORM_SCENARIOS.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {activeFailureScenario && (
          <p className="flex items-center gap-1.5 text-xs text-warning">
            <AlertOctagon className="h-3.5 w-3.5" /> Queued: the next <code className="font-mono">plan</code> or{" "}
            <code className="font-mono">apply</code> will fail with &quot;{activeFailureScenario.title}&quot;.
          </p>
        )}

        <TerminalOutput
          lines={logs}
          heightClassName="h-72"
          emptyLabel='Nothing has run yet. Click "terraform init" to get started.'
        />

        {triggeredScenario && (
          <div className="rounded-xl border border-danger/30 bg-danger/5 p-3">
            <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-danger">
              <AlertOctagon className="h-4 w-4" /> That run failed — here&apos;s why and how to fix it
            </p>
            <ScenarioList scenarios={[triggeredScenario]} />
          </div>
        )}

        <Separator />

        <div>
          <p className="mb-1 text-sm font-semibold">Common Terraform errors</p>
          <p className="mb-2 text-xs text-muted-foreground">
            A reference library of realistic failures you can hit above, kept here even when you&apos;re not actively
            simulating one.
          </p>
          <ScenarioList scenarios={TERRAFORM_SCENARIOS} />
        </div>
      </CardContent>
    </Card>
  );
}

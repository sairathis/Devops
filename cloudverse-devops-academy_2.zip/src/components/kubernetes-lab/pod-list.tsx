"use client";
import * as React from "react";
import { Box } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useKubernetesLabStore } from "@/store/kubernetes-lab-store";
import type { PodPhase } from "@/store/kubernetes-lab-store";
import { k8sName } from "@/components/kubernetes-lab/yaml";
import { PodDetail } from "./pod-detail";

// Literal Tailwind class map — never construct these dynamically.
const PHASE_BADGE_CLASS: Record<PodPhase, string> = {
  Pending: "border-slate-400/30 bg-slate-400/10 text-slate-500",
  ContainerCreating: "border-amber-400/30 bg-amber-400/10 text-amber-600",
  Running: "border-emerald-400/30 bg-emerald-400/10 text-emerald-600",
  CrashLoopBackOff: "border-red-400/30 bg-red-400/10 text-red-600",
  ImagePullBackOff: "border-red-400/30 bg-red-400/10 text-red-600",
  OOMKilled: "border-red-400/30 bg-red-400/10 text-red-600",
  Error: "border-red-400/30 bg-red-400/10 text-red-600",
};

export function PodList({ deploymentName }: { deploymentName: string }) {
  const name = React.useMemo(() => k8sName(deploymentName), [deploymentName]);
  // Select the raw (stable) array from the store and filter locally — a selector
  // that returns a freshly-`.filter()`ed array on every call gives Zustand's
  // useSyncExternalStore a new reference each render, which triggers an
  // infinite re-render loop ("Maximum update depth exceeded").
  const allPods = useKubernetesLabStore((s) => s.pods);
  const pods = React.useMemo(() => allPods.filter((p) => p.deploymentName === name), [allPods, name]);
  const [selectedPodId, setSelectedPodId] = React.useState<string | null>(null);
  const selectedPod = pods.find((p) => p.id === selectedPodId) ?? null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pods</CardTitle>
        <CardDescription>Live pod status for this Deployment — click a pod to inspect it.</CardDescription>
      </CardHeader>
      <CardContent>
        {pods.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            No pods yet. Click &quot;kubectl apply&quot; above to deploy.
          </p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {pods.map((pod) => (
              <button
                key={pod.id}
                type="button"
                onClick={() => setSelectedPodId(pod.id)}
                className="flex flex-col items-start gap-2 rounded-lg border border-border bg-card p-3 text-left shadow-sm transition-colors hover:bg-accent focus-ring"
              >
                <div className="flex w-full items-center justify-between gap-2">
                  <Box className="h-4 w-4 shrink-0 text-gcp-green" />
                  <Badge className={PHASE_BADGE_CLASS[pod.phase]}>{pod.phase}</Badge>
                </div>
                <span className="w-full truncate font-mono text-xs text-foreground">{pod.podName}</span>
                <span className="text-[11px] text-muted-foreground">Restarts: {pod.restarts}</span>
              </button>
            ))}
          </div>
        )}
      </CardContent>

      <PodDetail
        pod={selectedPod}
        open={selectedPodId !== null}
        onOpenChange={(open) => {
          if (!open) setSelectedPodId(null);
        }}
      />
    </Card>
  );
}

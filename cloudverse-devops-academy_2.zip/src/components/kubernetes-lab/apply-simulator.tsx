"use client";
import * as React from "react";
import { PlayCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { KUBERNETES_SCENARIOS } from "@/lib/console-sim/scenarios-k8s";
import { makeLog } from "@/lib/console-sim/types";
import type { SimLogEntry } from "@/lib/console-sim/types";
import { useKubernetesLabStore } from "@/store/kubernetes-lab-store";
import { k8sName } from "@/components/kubernetes-lab/yaml";

const NONE_VALUE = "none";

/**
 * Simulates `kubectl apply -f deployment.yaml`: streams the resources-created lines one at a
 * time, then hands off to the Kubernetes Lab store so pods actually spin up (Pending ->
 * ContainerCreating -> Running, or a chosen failure) below in <PodList />.
 */
export function ApplySimulator({
  deploymentName,
  replicas,
  ingressEnabled,
}: {
  deploymentName: string;
  replicas: number;
  ingressEnabled: boolean;
}) {
  const applyDeployment = useKubernetesLabStore((s) => s.applyDeployment);
  const [logs, setLogs] = React.useState<SimLogEntry[]>([]);
  const [applying, setApplying] = React.useState(false);
  const [scenarioId, setScenarioId] = React.useState<string>(NONE_VALUE);
  const timeoutsRef = React.useRef<ReturnType<typeof setTimeout>[]>([]);

  React.useEffect(() => {
    return () => {
      timeoutsRef.current.forEach(clearTimeout);
    };
  }, []);

  const handleApply = () => {
    timeoutsRef.current.forEach(clearTimeout);
    timeoutsRef.current = [];

    const name = k8sName(deploymentName);
    const scenario = KUBERNETES_SCENARIOS.find((s) => s.id === scenarioId);

    const createdLines: string[] = [
      `deployment.apps/${name} created`,
      `service/${name} created`,
      ...(ingressEnabled ? [`ingress.networking.k8s.io/${name} created`] : []),
    ];

    setApplying(true);
    setLogs([makeLog("command", "kubectl apply -f deployment.yaml")]);

    createdLines.forEach((line, i) => {
      const t = setTimeout(
        () => {
          setLogs((prev) => [...prev, makeLog("success", line)]);
          if (i === createdLines.length - 1) {
            setApplying(false);
            applyDeployment(name, replicas, scenario);
          }
        },
        400 + i * 450,
      );
      timeoutsRef.current.push(t);
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Apply to cluster</CardTitle>
        <CardDescription>
          Simulates `kubectl apply` against a fake cluster — watch pods actually come up in the
          Pods panel below.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Select value={scenarioId} onValueChange={setScenarioId}>
            <SelectTrigger className="h-9 w-full sm:w-72">
              <SelectValue placeholder="Simulate a failure" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={NONE_VALUE}>None — run normally</SelectItem>
              {KUBERNETES_SCENARIOS.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={handleApply} disabled={applying} size="sm" className="gap-1.5 font-mono">
            {applying ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlayCircle className="h-3.5 w-3.5" />}
            kubectl apply -f deployment.yaml
          </Button>
        </div>
        <TerminalOutput
          lines={logs}
          emptyLabel='Click "kubectl apply" to deploy this configuration.'
          heightClassName="h-40"
        />
      </CardContent>
    </Card>
  );
}

"use client";
import * as React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TerminalOutput } from "@/components/console-sim/terminal-output";
import { ScenarioList } from "@/components/console-sim/scenario-list";
import { KUBERNETES_SCENARIOS } from "@/lib/console-sim/scenarios-k8s";
import { useKubernetesLabStore } from "@/store/kubernetes-lab-store";
import type { SimPod } from "@/store/kubernetes-lab-store";

export function PodDetail({
  pod,
  open,
  onOpenChange,
}: {
  pod: SimPod | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const simulateScenario = useKubernetesLabStore((s) => s.simulateScenario);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        {pod && (
          <>
            <DialogHeader>
              <DialogTitle className="font-mono text-base">{pod.podName}</DialogTitle>
              <DialogDescription className="font-mono text-xs">kubectl describe pod {pod.podName}</DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-3 gap-3 rounded-lg border border-border bg-muted/30 p-3 text-sm">
              <div>
                <div className="text-xs text-muted-foreground">Status</div>
                <div className="font-medium">{pod.phase}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Restarts</div>
                <div className="font-medium">{pod.restarts}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Node</div>
                <div className="font-medium">node-1</div>
              </div>
            </div>

            <div>
              <div className="mb-1.5 text-xs font-medium text-muted-foreground">Logs</div>
              <TerminalOutput lines={pod.logs} heightClassName="h-48" emptyLabel="No logs yet." />
            </div>

            <Separator />

            <div>
              <div className="mb-2 text-xs font-medium text-muted-foreground">Simulate a failure on this pod</div>
              <ScrollArea className="h-56 pr-3">
                <ScenarioList scenarios={KUBERNETES_SCENARIOS} onSimulate={(s) => simulateScenario(pod.id, s)} />
              </ScrollArea>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import { makeLog } from "@/lib/console-sim/types";
import type { ErrorScenario, SimLogEntry, SimLogLevel } from "@/lib/console-sim/types";

export type PodPhase =
  | "Pending"
  | "ContainerCreating"
  | "Running"
  | "CrashLoopBackOff"
  | "ImagePullBackOff"
  | "OOMKilled"
  | "Error";

export interface SimPod {
  id: string;
  deploymentName: string;
  podName: string;
  phase: PodPhase;
  restarts: number;
  logs: SimLogEntry[];
  createdAt: string;
}

// ErrorScenario (src/lib/console-sim/types.ts) is shared across every lab module and has no
// notion of a Kubernetes pod phase, so we keep our own scenario-id -> PodPhase mapping here.
// Scenarios that don't correspond to a literal pod lifecycle phase (a readiness probe, a
// Service selector mismatch, a stuck PVC) land on the generic "Error" phase — their own
// cliOutput/cause in the scenario data explains the real nuance in the pod detail view.
const SCENARIO_PHASE: Record<string, PodPhase> = {
  "k8s-image-pull-backoff": "ImagePullBackOff",
  "k8s-crash-loop-backoff": "CrashLoopBackOff",
  "k8s-oom-killed": "OOMKilled",
  "k8s-pod-pending-unschedulable": "Pending",
  "k8s-readiness-probe-failing": "Error",
  "k8s-service-no-endpoints": "Error",
  "k8s-pvc-pending": "Error",
};

// Scenarios whose real-world failure mode involves the container actually restarting.
const SCENARIO_BUMPS_RESTART = new Set(["k8s-crash-loop-backoff", "k8s-oom-killed"]);

function scenarioPhase(scenario: ErrorScenario): PodPhase {
  return SCENARIO_PHASE[scenario.id] ?? "Error";
}

function classifyLine(line: string): SimLogLevel {
  const trimmed = line.trim();
  if (trimmed.startsWith("$")) return "command";
  if (/warning|error|fail|denied|refused|not found/i.test(trimmed)) return "error";
  if (/successfully|started|bound|created/i.test(trimmed)) return "success";
  return "info";
}

function scenarioLogs(scenario: ErrorScenario): SimLogEntry[] {
  return scenario.cliOutput.map((line) => makeLog(classifyLine(line), line));
}

// Real pod names look like <deployment>-<replicaset-suffix>-<pod-suffix>; randomId() already
// mixes in Math.random(), we just borrow a short slice of it for a k8s-shaped suffix.
function randomSuffix(length: number): string {
  return randomId("x").split("-")[1]?.slice(0, length) ?? "abcde";
}

interface KubernetesLabState {
  pods: SimPod[];
  applyDeployment: (deploymentName: string, replicas: number, injectScenario?: ErrorScenario) => string[];
  simulateScenario: (podId: string, scenario: ErrorScenario) => void;
  resumeStuckStates: () => void;
}

export const useKubernetesLabStore = create<KubernetesLabState>()(
  persist(
    (set, get) => {
      // Drives one pod through Pending -> ContainerCreating -> Running (or a failing scenario
      // phase), appending realistic log lines along the way. Runs as a self-contained setTimeout
      // chain kicked off from applyDeployment (a user action), never during render.
      function runPodLifecycle(podId: string, podName: string, image: string, index: number, failScenario?: ErrorScenario) {
        const stagger = index * 220;
        const containerName = podName.split("-")[0] || "app";

        setTimeout(() => {
          set((state) => ({
            pods: state.pods.map((p) =>
              p.id === podId
                ? {
                    ...p,
                    phase: "ContainerCreating",
                    logs: [
                      ...p.logs,
                      makeLog("info", `Successfully assigned default/${podName} to node-1`),
                      makeLog("info", `Pulling image "${image}"`),
                    ],
                  }
                : p,
            ),
          }));
        }, 500 + stagger);

        setTimeout(() => {
          set((state) => ({
            pods: state.pods.map((p) =>
              p.id === podId
                ? {
                    ...p,
                    logs: [
                      ...p.logs,
                      makeLog("success", `Successfully pulled image "${image}"`),
                      makeLog("info", `Created container ${containerName}`),
                    ],
                  }
                : p,
            ),
          }));
        }, 1300 + stagger);

        setTimeout(() => {
          set((state) => ({
            pods: state.pods.map((p) => {
              if (p.id !== podId) return p;
              if (failScenario) {
                return {
                  ...p,
                  phase: scenarioPhase(failScenario),
                  restarts: SCENARIO_BUMPS_RESTART.has(failScenario.id) ? p.restarts + 3 : p.restarts,
                  logs: [...p.logs, ...scenarioLogs(failScenario)],
                };
              }
              return {
                ...p,
                phase: "Running",
                logs: [...p.logs, makeLog("success", `Started container ${containerName}`)],
              };
            }),
          }));
        }, 2000 + stagger);
      }

      return {
        pods: [],

        applyDeployment: (deploymentName, replicas, injectScenario) => {
          const remainingPods = get().pods.filter((p) => p.deploymentName !== deploymentName);
          const count = Math.max(1, Math.floor(replicas) || 1);
          const failIndex = injectScenario ? Math.floor(Math.random() * count) : -1;
          const image = `gcr.io/my-project/${deploymentName || "app"}:latest`;

          const newPods: SimPod[] = Array.from({ length: count }, () => {
            const podName = `${deploymentName}-${randomSuffix(5)}-${randomSuffix(5)}`;
            return {
              id: randomId("pod"),
              deploymentName,
              podName,
              phase: "Pending" as PodPhase,
              restarts: 0,
              logs: [makeLog("info", `Pod ${podName} created`)],
              createdAt: new Date().toISOString(),
            };
          });

          set({ pods: [...remainingPods, ...newPods] });

          newPods.forEach((pod, i) => {
            runPodLifecycle(pod.id, pod.podName, image, i, i === failIndex ? injectScenario : undefined);
          });

          return newPods.map((p) => p.id);
        },

        simulateScenario: (podId, scenario) => {
          set((state) => ({
            pods: state.pods.map((p) =>
              p.id === podId
                ? {
                    ...p,
                    phase: scenarioPhase(scenario),
                    restarts: SCENARIO_BUMPS_RESTART.has(scenario.id) ? p.restarts + 1 : p.restarts,
                    logs: [...p.logs, ...scenarioLogs(scenario)],
                  }
                : p,
            ),
          }));
        },

        resumeStuckStates: () => {
          set((state) => ({
            pods: state.pods.map((p) =>
              p.phase === "Pending" || p.phase === "ContainerCreating"
                ? {
                    ...p,
                    phase: "Running",
                    logs: [...p.logs, makeLog("success", `Started container ${p.deploymentName.split("-")[0] || "app"}`)],
                  }
                : p,
            ),
          }));
        },
      };
    },
    { name: "cloudverse-kubernetes-lab-store" },
  ),
);

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import { makeLog, type ErrorScenario, type SimLogEntry, type SimLogLevel } from "@/lib/console-sim/types";

export type ContainerStatus = "running" | "exited" | "restarting" | "crashloop";

export interface RunningContainer {
  id: string;
  name: string;
  image: string;
  hostPort: number;
  containerPort: number;
  status: ContainerStatus;
  exitCode?: number;
  logs: SimLogEntry[];
  createdAt: string;
}

const HEX_CHARS = "0123456789abcdef";

function randomHex(length: number): string {
  let out = "";
  for (let i = 0; i < length; i++) {
    out += HEX_CHARS[Math.floor(Math.random() * HEX_CHARS.length)];
  }
  return out;
}

const NAME_ADJECTIVES = ["eager", "sleepy", "nimble", "quirky", "brave", "silent", "jolly", "clever"];
const NAME_NOUNS = ["turing", "hopper", "lovelace", "curie", "darwin", "einstein", "franklin", "goodall"];

function randomContainerName(): string {
  const adjective = NAME_ADJECTIVES[Math.floor(Math.random() * NAME_ADJECTIVES.length)];
  const noun = NAME_NOUNS[Math.floor(Math.random() * NAME_NOUNS.length)];
  return `${adjective}_${noun}`;
}

function parseImage(image: string): { repo: string; tag: string } {
  const [repo, tag] = image.split(":");
  return { repo: repo || "myapp", tag: tag || "latest" };
}

/** Known "how this failure resolves the container" outcomes, keyed by scenario id. */
const SCENARIO_OUTCOME: Record<string, { status: "exited" | "crashloop"; exitCode: number }> = {
  "docker-port-already-allocated": { status: "exited", exitCode: 125 },
  "docker-pull-access-denied": { status: "exited", exitCode: 1 },
  "docker-pull-rate-limit": { status: "exited", exitCode: 1 },
  "docker-exits-immediately": { status: "exited", exitCode: 0 },
  "docker-oci-permission-denied": { status: "crashloop", exitCode: 126 },
  "docker-no-space-left": { status: "exited", exitCode: 1 },
  "docker-volume-permission-denied": { status: "crashloop", exitCode: 1 },
};

function scenarioOutcome(scenario: ErrorScenario): { status: "exited" | "crashloop"; exitCode: number } {
  return SCENARIO_OUTCOME[scenario.id] ?? { status: "exited", exitCode: 1 };
}

/** Classify a raw cliOutput line into a terminal log level for display. */
function classifyLine(line: string): SimLogLevel {
  if (line.startsWith("$")) return "command";
  if (/error|denied|failed|no space/i.test(line)) return "error";
  return "info";
}

interface DockerLabState {
  containers: RunningContainer[];
  runContainer: (
    image: string,
    hostPort: number,
    containerPort: number,
    injectScenario?: ErrorScenario,
  ) => string;
  stopContainer: (id: string) => void;
  startContainer: (id: string) => void;
  removeContainer: (id: string) => void;
  appendLog: (id: string, entry: SimLogEntry) => void;
  simulateScenario: (id: string, scenario: ErrorScenario) => void;
  resumeStuckStates: () => void;
}

export const useDockerLabStore = create<DockerLabState>()(
  persist(
    (set, get) => ({
      containers: [],

      appendLog: (id, entry) => {
        set({
          containers: get().containers.map((c) => (c.id === id ? { ...c, logs: [...c.logs, entry] } : c)),
        });
      },

      runContainer: (image, hostPort, containerPort, injectScenario) => {
        const id = randomId("ctr");
        const shortId = randomHex(12);
        const container: RunningContainer = {
          id,
          name: randomContainerName(),
          image,
          hostPort,
          containerPort,
          status: "running",
          logs: [],
          createdAt: new Date().toISOString(),
        };
        set({ containers: [container, ...get().containers] });

        const append = (level: SimLogLevel, message: string) => get().appendLog(id, makeLog(level, message));

        append("command", `docker run -d -p ${hostPort}:${containerPort} ${image}`);

        if (injectScenario) {
          const lines = injectScenario.cliOutput;
          lines.forEach((line, i) => {
            setTimeout(() => append(classifyLine(line), line), 220 * (i + 1));
          });
          const outcome = scenarioOutcome(injectScenario);
          setTimeout(() => {
            set({
              containers: get().containers.map((c) =>
                c.id === id ? { ...c, status: outcome.status, exitCode: outcome.exitCode } : c,
              ),
            });
          }, 220 * (lines.length + 1));
          return id;
        }

        const { repo, tag } = parseImage(image);
        const pullFrom = repo.includes("/") ? repo : `library/${repo}`;
        const layers = [randomHex(12), randomHex(12), randomHex(12)];

        const timeline: Array<{ level: SimLogLevel; message: string }> = [
          { level: "info", message: `Unable to find image '${image}' locally` },
          { level: "info", message: `${tag}: Pulling from ${pullFrom}` },
          ...layers.map((layer) => ({ level: "info" as const, message: `${layer}: Pull complete` })),
          { level: "info", message: `Digest: sha256:${randomHex(64)}` },
          { level: "success", message: `Status: Downloaded newer image for ${image}` },
          { level: "info", message: shortId },
          { level: "success", message: `Server listening on 0.0.0.0:${containerPort}` },
          { level: "success", message: "Application startup complete. Ready to accept connections." },
        ];

        timeline.forEach((entry, i) => {
          setTimeout(() => append(entry.level, entry.message), 220 * (i + 1));
        });

        return id;
      },

      stopContainer: (id) => {
        const container = get().containers.find((c) => c.id === id);
        if (!container) return;
        get().appendLog(id, makeLog("command", `docker stop ${id}`));
        get().appendLog(id, makeLog("info", `Container ${container.name} stopped`));
        set({
          containers: get().containers.map((c) =>
            c.id === id ? { ...c, status: "exited", exitCode: 0 } : c,
          ),
        });
      },

      startContainer: (id) => {
        const container = get().containers.find((c) => c.id === id);
        if (!container) return;
        get().appendLog(id, makeLog("command", `docker start ${id}`));
        set({
          containers: get().containers.map((c) =>
            c.id === id ? { ...c, status: "restarting", exitCode: undefined } : c,
          ),
        });

        setTimeout(() => {
          get().appendLog(id, makeLog("success", `Server listening on 0.0.0.0:${container.containerPort}`));
        }, 200);

        setTimeout(() => {
          get().appendLog(id, makeLog("success", "Application startup complete. Ready to accept connections."));
          set({
            containers: get().containers.map((c) => (c.id === id ? { ...c, status: "running" } : c)),
          });
        }, 420);
      },

      removeContainer: (id) => {
        set({ containers: get().containers.filter((c) => c.id !== id) });
      },

      simulateScenario: (id, scenario) => {
        const container = get().containers.find((c) => c.id === id);
        if (!container) return;

        const outcome = scenarioOutcome(scenario);
        scenario.cliOutput.forEach((line, i) => {
          setTimeout(() => {
            get().appendLog(id, makeLog(classifyLine(line), line));
          }, 200 * (i + 1));
        });

        setTimeout(() => {
          set({
            containers: get().containers.map((c) =>
              c.id === id ? { ...c, status: outcome.status, exitCode: outcome.exitCode } : c,
            ),
          });
        }, 200 * (scenario.cliOutput.length + 1));
      },

      resumeStuckStates: () => {
        set({
          containers: get().containers.map((c) => (c.status === "restarting" ? { ...c, status: "running" } : c)),
        });
      },
    }),
    { name: "cloudverse-docker-lab-store" },
  ),
);

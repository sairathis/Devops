import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ResourceConfig } from "@/types/gcp";
import { ErrorScenario, ResourceRuntimeStatus, SimLogEntry, SimLogLevel, makeLog } from "@/lib/console-sim/types";
import { randomId } from "@/lib/utils";

export interface ConsoleResource {
  id: string;
  type: string;
  name: string;
  config: ResourceConfig;
  status: ResourceRuntimeStatus;
  createdAt: string;
  logs: SimLogEntry[];
}

interface ProvisionStep {
  level: SimLogLevel;
  message: string;
}

// gcloud/gsutil-flavored command line shown as the first log line for each type.
function commandFor(type: string, config: ResourceConfig, name: string): string {
  switch (type) {
    case "vm":
      return `$ gcloud compute instances create ${name} --zone=${config.region}${config.zone} --machine-type=${config.machineType}`;
    case "gcs":
      return `$ gsutil mb -l ${config.location} -c ${String(config.storageClass ?? "standard").toLowerCase()} gs://${name}`;
    case "cloudsql":
      return `$ gcloud sql instances create ${name} --database-version=${config.engine} --tier=${config.tier} --region=${config.region}`;
    case "gke":
      return config.mode === "autopilot"
        ? `$ gcloud container clusters create-auto ${name} --region=${config.region}`
        : `$ gcloud container clusters create ${name} --region=${config.region} --num-nodes=${config.nodeCount}`;
    case "lb":
      return `$ gcloud compute forwarding-rules create ${name} --global --target-http-proxy=${name}-proxy --ports=${config.port}`;
    default:
      return `$ gcloud services create ${name}`;
  }
}

// The middle "what's actually happening" steps, flavored per resource type.
function provisioningSteps(type: string, config: ResourceConfig): ProvisionStep[] {
  switch (type) {
    case "vm":
      return [
        { level: "info", message: `Reserving network interface${config.publicIp ? " and external IP" : ""} in ${config.region}${config.zone}...` },
        { level: "info", message: `Attaching ${config.diskSizeGb}GB ${config.diskType} boot disk (${config.osImage})...` },
        { level: "info", message: "Booting instance and running startup scripts..." },
      ];
    case "gcs":
      return [
        { level: "info", message: "Checking global namespace for bucket name availability..." },
        { level: "info", message: `Provisioning ${config.storageClass} storage backend in ${config.location}...` },
        {
          level: "info",
          message: config.uniformAccess
            ? "Applying uniform bucket-level access policy..."
            : "Applying default object ACLs (uniform bucket-level access disabled)...",
        },
      ];
    case "cloudsql": {
      const steps: ProvisionStep[] = [
        { level: "info", message: `Allocating Cloud SQL instance (tier ${config.tier})...` },
        { level: "info", message: `Provisioning ${config.storageGb}GB storage and configuring networking...` },
      ];
      if (config.highAvailability) {
        steps.push({ level: "info", message: "Provisioning synchronous standby in a secondary zone for high availability..." });
      }
      return steps;
    }
    case "gke": {
      const steps: ProvisionStep[] = [
        { level: "info", message: `Reserving control plane in ${config.region}...` },
        {
          level: "info",
          message:
            config.mode === "autopilot"
              ? "Configuring Autopilot compute classes..."
              : `Provisioning node pool (${config.nodeCount} nodes/zone)...`,
        },
      ];
      if (config.workloadIdentity) {
        steps.push({ level: "info", message: "Binding Workload Identity pool (svc.id.goog)..." });
      }
      return steps;
    }
    case "lb":
      return [
        { level: "info", message: `Creating health check on port ${config.port} (${config.healthCheckPath})...` },
        { level: "info", message: `Registering backend service (${config.protocol}, session affinity ${config.sessionAffinity})...` },
        { level: "info", message: "Allocating global anycast IP address..." },
      ];
    default:
      return [{ level: "info", message: "Provisioning resource..." }];
  }
}

function successMessage(type: string, name: string): string {
  switch (type) {
    case "vm":
      return `Instance ${name} is RUNNING.`;
    case "gcs":
      return `Bucket gs://${name} created and ready.`;
    case "cloudsql":
      return `Instance ${name} state: RUNNABLE.`;
    case "gke":
      return `Cluster ${name} is RUNNING.`;
    case "lb":
      return `Load balancer ${name} is ACTIVE and serving traffic.`;
    default:
      return `${name} is ready.`;
  }
}

function logLevelForCliLine(line: string): SimLogLevel {
  return line.trim().startsWith("$") ? "command" : "error";
}

interface GcpConsoleState {
  resources: ConsoleResource[];
  firstSuccessAwarded: boolean;
  createResource: (type: string, config: ResourceConfig, injectScenario?: ErrorScenario) => string;
  appendLog: (id: string, entry: SimLogEntry) => void;
  setStatus: (id: string, status: ResourceRuntimeStatus) => void;
  startResource: (id: string) => void;
  stopResource: (id: string) => void;
  deleteResource: (id: string) => void;
  simulateScenario: (id: string, scenario: ErrorScenario) => void;
  resumeStuckStates: () => void;
  /** Returns true only the first time it is ever called (and records that it happened). */
  claimFirstSuccess: () => boolean;
}

export const useGcpConsoleStore = create<GcpConsoleState>()(
  persist(
    (set, get) => ({
      resources: [],
      firstSuccessAwarded: false,

      createResource: (type, config, injectScenario) => {
        const id = randomId(type);
        const name = String(config.name ?? type);
        const resource: ConsoleResource = {
          id,
          type,
          name,
          config,
          status: "provisioning",
          createdAt: new Date().toISOString(),
          logs: [makeLog("command", commandFor(type, config, name))],
        };
        set({ resources: [...get().resources, resource] });

        const steps = provisioningSteps(type, config);
        const delays = [500, 1100, 1800, 2400].slice(0, steps.length);

        steps.forEach((step, i) => {
          setTimeout(() => {
            if (!get().resources.some((r) => r.id === id)) return;
            get().appendLog(id, makeLog(step.level, step.message));
          }, delays[i]);
        });

        const finalDelay = (delays[delays.length - 1] ?? 500) + 800;
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          if (injectScenario) {
            injectScenario.cliOutput.forEach((line) => {
              get().appendLog(id, makeLog(logLevelForCliLine(line), line));
            });
            get().setStatus(id, "error");
          } else {
            get().appendLog(id, makeLog("success", successMessage(type, name)));
            get().setStatus(id, "running");
          }
        }, finalDelay);

        return id;
      },

      appendLog: (id, entry) => {
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, logs: [...r.logs, entry] } : r)),
        });
      },

      setStatus: (id, status) => {
        set({
          resources: get().resources.map((r) => (r.id === id ? { ...r, status } : r)),
        });
      },

      startResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res || res.status !== "stopped") return;
        get().setStatus(id, "starting");
        get().appendLog(id, makeLog("command", `$ gcloud ... start ${res.name}`));
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          get().appendLog(id, makeLog("success", `${res.name} is running again.`));
          get().setStatus(id, "running");
        }, 1200);
      },

      stopResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res || res.status !== "running") return;
        get().setStatus(id, "stopping");
        get().appendLog(id, makeLog("command", `$ gcloud ... stop ${res.name}`));
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          get().appendLog(id, makeLog("info", `${res.name} has stopped.`));
          get().setStatus(id, "stopped");
        }, 1000);
      },

      deleteResource: (id) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res) return;
        get().setStatus(id, "deleting");
        get().appendLog(id, makeLog("command", `$ gcloud ... delete ${res.name} --quiet`));
        setTimeout(() => {
          set({ resources: get().resources.filter((r) => r.id !== id) });
        }, 1200);
      },

      simulateScenario: (id, scenario) => {
        const res = get().resources.find((r) => r.id === id);
        if (!res) return;
        scenario.cliOutput.forEach((line) => {
          get().appendLog(id, makeLog(logLevelForCliLine(line), line));
        });
        get().setStatus(id, "error");
        setTimeout(() => {
          if (!get().resources.some((r) => r.id === id)) return;
          get().appendLog(id, makeLog("info", "Applying fix and re-checking resource health..."));
          get().appendLog(id, makeLog("success", `${res.name} recovered and is running normally.`));
          get().setStatus(id, "running");
        }, 3000);
      },

      resumeStuckStates: () => {
        set({
          resources: get()
            .resources.filter((r) => r.status !== "deleting")
            .map((r) => {
              if (r.status === "provisioning" || r.status === "starting") {
                return {
                  ...r,
                  status: "running" as ResourceRuntimeStatus,
                  logs: [...r.logs, makeLog("info", "Resumed after reload — the operation had completed in the background.")],
                };
              }
              if (r.status === "stopping") {
                return {
                  ...r,
                  status: "stopped" as ResourceRuntimeStatus,
                  logs: [...r.logs, makeLog("info", "Resumed after reload — the instance had finished stopping.")],
                };
              }
              return r;
            }),
        });
      },

      claimFirstSuccess: () => {
        if (get().firstSuccessAwarded) return false;
        set({ firstSuccessAwarded: true });
        return true;
      },
    }),
    { name: "cloudverse-gcp-console-store" },
  ),
);

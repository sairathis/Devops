import { create } from "zustand";
import { persist } from "zustand/middleware";
import { randomId } from "@/lib/utils";
import { DEFAULT_APP_CODE } from "@/components/cicd-simulator/sample-app";

export type DeployTarget = "cloud-run" | "gke" | "compute-engine";
export type DeploymentStatus = "success" | "failed" | "rolled-back";

export interface DeploymentEntry {
  id: string;
  version: number;
  timestamp: string;
  target: DeployTarget;
  status: DeploymentStatus;
  commitMessage: string;
  codeSnapshot: string;
}

interface CicdSimulatorState {
  code: string;
  deployments: DeploymentEntry[];
  setCode: (code: string) => void;
  recordDeployment: (entry: Omit<DeploymentEntry, "id" | "version" | "timestamp">) => void;
  rollbackTo: (id: string) => void;
  resetToDefault: () => void;
}

export const useCicdSimulatorStore = create<CicdSimulatorState>()(
  persist(
    (set, get) => ({
      code: DEFAULT_APP_CODE,
      deployments: [],

      setCode: (code) => set({ code }),

      recordDeployment: (entry) => {
        const { deployments } = get();
        const nextVersion = (deployments[0]?.version ?? 0) + 1;
        const newEntry: DeploymentEntry = {
          ...entry,
          id: randomId("deploy"),
          version: nextVersion,
          timestamp: new Date().toISOString(),
        };
        set({ deployments: [newEntry, ...deployments] });
      },

      rollbackTo: (id) => {
        const { deployments } = get();
        const target = deployments.find((d) => d.id === id);
        if (!target) return;
        const nextVersion = (deployments[0]?.version ?? 0) + 1;
        const rollbackEntry: DeploymentEntry = {
          id: randomId("deploy"),
          version: nextVersion,
          timestamp: new Date().toISOString(),
          target: target.target,
          status: "rolled-back",
          commitMessage: `Rollback to v${target.version} ("${target.commitMessage}")`,
          codeSnapshot: target.codeSnapshot,
        };
        set({
          code: target.codeSnapshot,
          deployments: [rollbackEntry, ...deployments],
        });
      },

      resetToDefault: () => set({ code: DEFAULT_APP_CODE, deployments: [] }),
    }),
    { name: "cloudverse-cicd-store" },
  ),
);

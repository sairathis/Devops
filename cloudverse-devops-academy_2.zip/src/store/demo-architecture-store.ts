import { create } from "zustand";
import { persist } from "zustand/middleware";

/**
 * Tracks which Demo Architecture bundles are currently "deployed" and which
 * gcp-console-store resource ids belong to each run.
 *
 * This used to live in plain useState inside DemoArchitectures — which meant
 * switching away from the Demos tab (Radix Tabs unmounts inactive
 * TabsContent by default) and back lost track of an active deployment even
 * though the underlying resources were still sitting in the Console. For a
 * tool whose whole point is presenting live to a client — switching to the
 * Console tab to show off the resources, then back to Demos — that's a real
 * problem: the card would offer "Deploy this architecture" again instead of
 * "Tear down", inviting duplicate resources. Persisting it here (and to
 * localStorage, so it also survives a page reload) fixes that.
 */

export interface DemoRun {
  resourceIds: string[];
  resourceCount: number;
  deployedAt: string;
}

interface DemoArchitectureState {
  runs: Record<string, DemoRun>;
  recordRun: (bundleId: string, resourceIds: string[]) => void;
  clearRun: (bundleId: string) => void;
}

export const useDemoArchitectureStore = create<DemoArchitectureState>()(
  persist(
    (set) => ({
      runs: {},
      recordRun: (bundleId, resourceIds) =>
        set((state) => ({
          runs: {
            ...state.runs,
            [bundleId]: {
              resourceIds,
              resourceCount: resourceIds.length,
              deployedAt: new Date().toISOString(),
            },
          },
        })),
      clearRun: (bundleId) =>
        set((state) => {
          const next = { ...state.runs };
          delete next[bundleId];
          return { runs: next };
        }),
    }),
    { name: "cloudverse-demo-architecture-store" },
  ),
);

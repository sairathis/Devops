"use client";
import * as React from "react";
import { FlaskConical, Info, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { SnippetLibrary } from "@/components/terraform-lab/snippet-library";
import { CodeEditor } from "@/components/terraform-lab/code-editor";
import { LiveExplanation } from "@/components/terraform-lab/live-explanation";
import { ValidationPanel } from "@/components/terraform-lab/validation-panel";
import { ConceptsSection } from "@/components/terraform-lab/concepts-section";
import { TerminalSimulator } from "@/components/terraform-lab/terminal-simulator";
import { STARTER_SNIPPET } from "@/components/terraform-lab/starter-snippet";
import { useProgressStore } from "@/store/progress-store";

export default function TerraformLabPage() {
  const [code, setCode] = React.useState(STARTER_SNIPPET);
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);
  const xpAwardedRef = React.useRef(false);

  React.useEffect(() => {
    setModuleProgress("terraform-lab", 20);
  }, [setModuleProgress]);

  const handleInsert = React.useCallback((snippet: string, mode: "append" | "replace") => {
    if (mode === "replace") {
      setCode(snippet);
      return;
    }
    setCode((prev) => (prev.trim().length > 0 ? `${prev.trimEnd()}\n\n${snippet}\n` : `${snippet}\n`));
  }, []);

  const handleValidateResult = React.useCallback(
    (allPass: boolean) => {
      if (allPass && !xpAwardedRef.current) {
        xpAwardedRef.current = true;
        addXp(15);
        toast.success("+15 XP — clean Terraform, all heuristic checks passed!");
      }
    },
    [addXp],
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <div className="mb-4">
        <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
          <FlaskConical className="h-6 w-6 text-primary" /> Terraform Lab
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          A learning sandbox for writing and understanding HCL: insert real resource snippets, watch a live
          explanation of what your code does, and run lightweight checks that flag common mistakes.
        </p>
      </div>

      <div className="mb-5 flex items-start gap-2 rounded-xl border border-info/30 bg-info/5 p-3 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-info" />
        <p>
          The terminal below is a realistic simulation of the <code className="font-mono">terraform</code> CLI for
          learning — it does not call the real Terraform binary or provision any real infrastructure. The
          &quot;Validate&quot; button also runs simple heuristic checks, not real HCL parsing.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[260px_1fr_360px]">
        <div className="lg:h-[640px]">
          <SnippetLibrary onInsert={handleInsert} />
        </div>

        <div className="space-y-5">
          <CodeEditor value={code} onChange={setCode} className="lg:h-[420px]" />
          <ValidationPanel code={code} onResult={handleValidateResult} />
        </div>

        <div className="lg:h-[640px]">
          <LiveExplanation code={code} />
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
        <Sparkles className="h-3.5 w-3.5 text-gcp-yellow" />
        Pass every heuristic check on Validate for the first time to earn +15 XP.
      </div>

      <div className="mt-6">
        <TerminalSimulator code={code} />
      </div>

      <div className="mt-6">
        <ConceptsSection />
      </div>
    </div>
  );
}

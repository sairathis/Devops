"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Play, RotateCcw, AlertTriangle, GitMerge, History, RefreshCcw, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { CodeBlock } from "@/components/code-block";
import { PipelineStepper } from "@/components/cicd-simulator/pipeline-stepper";
import { LogPanel, type LogEntry } from "@/components/cicd-simulator/log-panel";
import { ConceptsSection } from "@/components/cicd-simulator/concepts-section";
import { AppCodeEditor } from "@/components/cicd-simulator/app-code-editor";
import { CLOUDBUILD_YAML } from "@/components/cicd-simulator/cloudbuild-yaml";
import {
  PIPELINE_STAGES,
  DEPLOY_TARGET_FLAVORS,
  DEPLOY_TARGET_OPTIONS,
  type StageStatus,
  type DeployTarget,
} from "@/components/cicd-simulator/pipeline-config";
import { runTests, FUNCTION_NAME } from "@/components/cicd-simulator/sample-app";
import { useProgressStore } from "@/store/progress-store";
import {
  useCicdSimulatorStore,
  type DeploymentEntry,
  type DeploymentStatus,
} from "@/store/cicd-simulator-store";
import { cn } from "@/lib/utils";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function randomBetween(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

let logIdCounter = 0;
function nextLogId() {
  logIdCounter += 1;
  return `log-${logIdCounter}`;
}

const DEPLOY_STATUS_BADGE_VARIANT: Record<DeploymentStatus, "success" | "danger" | "warning"> = {
  success: "success",
  failed: "danger",
  "rolled-back": "warning",
};

const DEPLOY_STATUS_LABEL: Record<DeploymentStatus, string> = {
  success: "Success",
  failed: "Failed",
  "rolled-back": "Rolled back",
};

const DEPLOY_TARGET_BADGE_VARIANT: Record<DeployTarget, "info" | "secondary" | "warning"> = {
  "cloud-run": "info",
  gke: "secondary",
  "compute-engine": "warning",
};

function formatTimestamp(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function CicdSimulatorPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);
  const addXp = useProgressStore((s) => s.addXp);

  const code = useCicdSimulatorStore((s) => s.code);
  const setCode = useCicdSimulatorStore((s) => s.setCode);
  const deployments = useCicdSimulatorStore((s) => s.deployments);
  const recordDeployment = useCicdSimulatorStore((s) => s.recordDeployment);
  const rollbackTo = useCicdSimulatorStore((s) => s.rollbackTo);
  const resetToDefault = useCicdSimulatorStore((s) => s.resetToDefault);

  const [target, setTarget] = React.useState<DeployTarget>("cloud-run");
  const [statuses, setStatuses] = React.useState<StageStatus[]>(() => PIPELINE_STAGES.map(() => "pending"));
  const [logs, setLogs] = React.useState<LogEntry[]>([]);
  const [running, setRunning] = React.useState(false);
  const [failedIndex, setFailedIndex] = React.useState<number | null>(null);
  const [failureMessage, setFailureMessage] = React.useState<string | null>(null);
  const [, setHasEarnedXp] = React.useState(false);

  // Guards against duplicate/overlapping runs from double-clicks.
  const runTokenRef = React.useRef(0);

  React.useEffect(() => {
    setModuleProgress("cicd-simulator", 20);
  }, [setModuleProgress]);

  const appendLog = React.useCallback((text: string, tone: LogEntry["tone"]) => {
    setLogs((prev) => [...prev, { id: nextLogId(), text, tone }]);
  }, []);

  const runPipeline = React.useCallback(
    async (startIndex: number) => {
      const myToken = ++runTokenRef.current;
      setRunning(true);
      setFailureMessage(null);
      setFailedIndex(null);
      setStatuses((prev) => prev.map((s, i) => (i < startIndex ? s : "pending")));

      if (startIndex === 0) {
        setLogs([]);
        appendLog("Starting pipeline run for commit 4f2a9c1 on branch main...", "muted");
      } else {
        appendLog(`Retrying from stage "${PIPELINE_STAGES[startIndex].label}"...`, "muted");
      }

      const streamLines = async (lines: string[], totalMs: number): Promise<boolean> => {
        const perLineMs = Math.max(150, Math.floor(totalMs / (lines.length + 1)));
        for (const line of lines) {
          await sleep(perLineMs);
          if (runTokenRef.current !== myToken) return false;
          appendLog(line, "info");
        }
        await sleep(Math.max(0, totalMs - perLineMs * lines.length));
        return runTokenRef.current === myToken;
      };

      const failStage = (index: number, message: string) => {
        appendLog(message, "error");
        setStatuses((prev) => prev.map((s, idx) => (idx === index ? "failed" : s)));
        setFailedIndex(index);
        setFailureMessage(message);
        setRunning(false);
      };

      const succeedStage = (index: number, message: string) => {
        appendLog(message, "success");
        setStatuses((prev) => prev.map((s, idx) => (idx === index ? "success" : s)));
      };

      for (let i = startIndex; i < PIPELINE_STAGES.length; i++) {
        if (runTokenRef.current !== myToken) return; // a newer run superseded this one
        const stage = PIPELINE_STAGES[i];

        setStatuses((prev) => prev.map((s, idx) => (idx === i ? "running" : s)));
        appendLog(`Stage started: ${stage.label}`, "muted");

        const totalMs = randomBetween(stage.minMs, stage.maxMs);

        // --- Build: parse the user's edited source for real before ever rolling dice. ---
        if (stage.id === "build") {
          const ok = await streamLines(stage.runningLog, totalMs);
          if (!ok) return;

          try {
            new Function(code);
          } catch (err) {
            const detail = err instanceof Error ? err.message : String(err);
            failStage(i, `FAIL: Build failed — the app source does not parse (${detail})`);
            return;
          }

          const failed = Math.random() < stage.failChance;
          if (failed) {
            const message =
              stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ??
              `FAIL: ${stage.label} failed unexpectedly`;
            failStage(i, message);
            return;
          }
          succeedStage(i, stage.successLog);
          continue;
        }

        // --- Unit Tests: actually execute the user's edited code against real test cases. ---
        if (stage.id === "unit-tests") {
          const ok = await streamLines(stage.runningLog, totalMs);
          if (!ok) return;

          const results = runTests(code);
          for (const result of results) {
            if (runTokenRef.current !== myToken) return;
            const line = result.passed
              ? `PASS: ${result.description}`
              : `FAIL: ${result.description}${result.error ? ` — ${result.error}` : ""}`;
            appendLog(line, result.passed ? "success" : "error");
            await sleep(160);
          }

          const failing = results.find((r) => !r.passed);
          if (failing) {
            failStage(
              i,
              `FAIL: unit tests failed — ${failing.description}${failing.error ? ` (${failing.error})` : ""}`,
            );
            return;
          }
          succeedStage(i, `Tests complete — ${results.length} passed, 0 failed.`);
          continue;
        }

        // --- Deploy: flavor the log lines by the chosen target, keep the random outcome. ---
        if (stage.id === "deploy") {
          const flavor = DEPLOY_TARGET_FLAVORS[target];
          const ok = await streamLines(flavor.runningLog, totalMs);
          if (!ok) return;

          const failed = Math.random() < stage.failChance;
          if (failed) {
            const message =
              flavor.failureLogPool[Math.floor(Math.random() * flavor.failureLogPool.length)] ??
              `FAIL: Deploy to ${flavor.label} failed unexpectedly`;
            failStage(i, message);
            return;
          }
          succeedStage(i, flavor.successLog);
          continue;
        }

        // --- Everything else (Commit, Push, Smoke Test): unchanged lightweight randomness. ---
        const ok = await streamLines(stage.runningLog, totalMs);
        if (!ok) return;

        const failed = Math.random() < stage.failChance;
        if (failed) {
          const message =
            stage.failureLogPool[Math.floor(Math.random() * stage.failureLogPool.length)] ??
            `FAIL: ${stage.label} failed unexpectedly`;
          failStage(i, message);
          return;
        }
        succeedStage(i, stage.successLog);
      }

      appendLog("Pipeline finished — all stages succeeded.", "success");
      setRunning(false);
      setFailedIndex(null);

      recordDeployment({
        target,
        status: "success",
        commitMessage: `Update ${FUNCTION_NAME} logic`,
        codeSnapshot: code,
      });
      toast.success("Deployment recorded", {
        description: `${DEPLOY_TARGET_FLAVORS[target].label} is now serving the new revision.`,
      });

      setHasEarnedXp((already) => {
        if (!already) addXp(15);
        return true;
      });
    },
    [appendLog, addXp, code, target, recordDeployment],
  );

  const handleRun = () => {
    void runPipeline(0);
  };

  const handleRetry = () => {
    if (failedIndex === null) return;
    void runPipeline(failedIndex);
  };

  const handleRollback = (deployment: DeploymentEntry) => {
    rollbackTo(deployment.id);
    toast.success(`Rolled back to v${deployment.version}`, {
      description: "The editor now shows the code from that deployment.",
    });
  };

  const handleResetApp = () => {
    resetToDefault();
    toast.success("Reset to default app + history cleared");
  };

  const allSucceeded = statuses.every((s) => s === "success");
  const latestDeploymentId = deployments[0]?.id;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <GitMerge className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">CI/CD Simulator</h1>
          {allSucceeded && <Badge variant="success">All stages green</Badge>}
        </div>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Edit the app&apos;s source code, then watch a real deployment pipeline run stage by stage. Unit Tests
          actually executes your code against real test cases — break the logic and watch it fail for real, fix
          it and watch it pass. Every run is simulated client-side, so it is safe to break things.
        </p>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp}>
        <Card className="mb-5">
          <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
            <div>
              <CardTitle>Pipeline</CardTitle>
              <CardDescription>Commit → Build → Unit Tests → Push → Deploy → Smoke Test</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select value={target} onValueChange={(v) => setTarget(v as DeployTarget)} disabled={running}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="Deploy target" />
                </SelectTrigger>
                <SelectContent>
                  {DEPLOY_TARGET_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      Deploy target: {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {failedIndex !== null && !running && (
                <Button variant="outline" onClick={handleRetry}>
                  <RotateCcw className="h-4 w-4" /> Retry from failed stage
                </Button>
              )}
              <Button onClick={handleRun} disabled={running}>
                <Play className="h-4 w-4" /> {running ? "Running..." : "Run Pipeline"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <PipelineStepper statuses={statuses} />

            {failureMessage && (
              <div className="flex items-start gap-3 rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-danger">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <div className="min-w-0">
                  <p className="font-medium">Pipeline failed</p>
                  <p className="mt-0.5 break-words font-mono text-xs text-danger/90">{failureMessage}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={2} variants={fadeUp} className="mb-5">
        <Tabs defaultValue="pipeline">
          <TabsList>
            <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
            <TabsTrigger value="history">
              Deployment History
              {deployments.length > 0 && (
                <Badge variant="secondary" className="ml-1.5">
                  {deployments.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pipeline" className="space-y-5">
            <div className="grid gap-5 lg:grid-cols-2">
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-muted-foreground">
                    App source — <code className="font-mono">{FUNCTION_NAME}()</code>
                  </h2>
                  <Button variant="ghost" size="sm" onClick={handleResetApp} disabled={running}>
                    <RefreshCcw className="h-3.5 w-3.5" /> Reset app
                  </Button>
                </div>
                <AppCodeEditor value={code} onChange={setCode} filename="shipping-calculator.js" minHeight="18rem" />
              </div>
              <div>
                <h2 className="mb-2 text-sm font-medium text-muted-foreground">Pipeline as code</h2>
                <CodeBlock code={CLOUDBUILD_YAML} language="yaml" filename="cloudbuild.yaml" maxHeight="18rem" />
              </div>
            </div>

            <div>
              <h2 className="mb-2 text-sm font-medium text-muted-foreground">Live build log</h2>
              <LogPanel entries={logs} />
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader className="flex-row items-center gap-2 space-y-0">
                <History className="h-4 w-4 text-muted-foreground" />
                <div>
                  <CardTitle>Deployment History</CardTitle>
                  <CardDescription>Every successful pipeline run ships a new version — roll back any time.</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                {deployments.length === 0 ? (
                  <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                    No deployments yet. Run the pipeline to completion to ship the first version.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {deployments.map((d) => {
                      const isCurrent = d.id === latestDeploymentId;
                      return (
                        <li
                          key={d.id}
                          className={cn(
                            "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3",
                            isCurrent && "border-primary/40 bg-primary/5",
                          )}
                        >
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-mono text-sm font-medium">v{d.version}</span>
                              <Badge variant={DEPLOY_STATUS_BADGE_VARIANT[d.status]}>
                                {DEPLOY_STATUS_LABEL[d.status]}
                              </Badge>
                              <Badge variant={DEPLOY_TARGET_BADGE_VARIANT[d.target]}>
                                {DEPLOY_TARGET_FLAVORS[d.target].label}
                              </Badge>
                              {isCurrent && <Badge variant="outline">Current</Badge>}
                            </div>
                            <p className="mt-1 truncate text-xs text-muted-foreground">{d.commitMessage}</p>
                            <p className="mt-0.5 text-[11px] text-muted-foreground/70">{formatTimestamp(d.timestamp)}</p>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={isCurrent}
                            onClick={() => handleRollback(d)}
                          >
                            <Undo2 className="h-3.5 w-3.5" /> Rollback to this version
                          </Button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={3} variants={fadeUp}>
        <h2 className="mb-3 text-lg font-semibold tracking-tight">Concepts</h2>
        <ConceptsSection />
      </motion.div>
    </div>
  );
}

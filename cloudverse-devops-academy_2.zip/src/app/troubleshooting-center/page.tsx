"use client";
import * as React from "react";
import { motion } from "framer-motion";
import { Wrench, BookOpen, Stethoscope, FlaskConical } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { DiagnoseGame } from "@/components/troubleshooting-center/diagnose-game";
import { ReferenceLibrary } from "@/components/troubleshooting-center/reference-library";
import { LabScenarios } from "@/components/troubleshooting-center/lab-scenarios";
import { useProgressStore } from "@/store/progress-store";

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.35 } }),
};

export default function TroubleshootingCenterPage() {
  const setModuleProgress = useProgressStore((s) => s.setModuleProgress);

  React.useEffect(() => {
    setModuleProgress("troubleshooting-center", 20);
  }, [setModuleProgress]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">
      <motion.div initial="hidden" animate="show" custom={0} variants={fadeUp} className="mb-6 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gcp-red/10 text-gcp-red">
          <Wrench className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Troubleshooting <span className="gradient-text">Center</span>
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Diagnose realistic GCP production incidents, one symptom at a time — plus every error you can hit
            hands-on in the GCP Services Console, Terraform Lab, Docker Lab, and Kubernetes Lab.
          </p>
        </div>
      </motion.div>

      <motion.div initial="hidden" animate="show" custom={1} variants={fadeUp}>
        <Tabs defaultValue="diagnose">
          <TabsList>
            <TabsTrigger value="diagnose" className="gap-1.5">
              <Stethoscope className="h-3.5 w-3.5" /> Diagnose
            </TabsTrigger>
            <TabsTrigger value="reference" className="gap-1.5">
              <BookOpen className="h-3.5 w-3.5" /> Reference Library
            </TabsTrigger>
            <TabsTrigger value="labs" className="gap-1.5">
              <FlaskConical className="h-3.5 w-3.5" /> Hands-on Lab Errors
            </TabsTrigger>
          </TabsList>
          <TabsContent value="diagnose">
            <DiagnoseGame />
          </TabsContent>
          <TabsContent value="reference">
            <ReferenceLibrary />
          </TabsContent>
          <TabsContent value="labs">
            <LabScenarios />
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}

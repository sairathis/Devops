// Lightweight parser that extracts top-level `resource "type" "name" { ... }`
// blocks from the Terraform Lab editor's HCL text. This is intentionally not
// a real HCL parser — it's just enough structure to drive realistic-looking
// `terraform plan` / `apply` / `destroy` output in the simulator.

export interface ParsedResource {
  hclType: string;
  hclName: string;
}

const RESOURCE_BLOCK_RE = /resource\s+"([\w.]+)"\s+"([\w-]+)"\s*\{/g;

export function parseResourceBlocks(hcl: string): ParsedResource[] {
  const resources: ParsedResource[] = [];
  const re = new RegExp(RESOURCE_BLOCK_RE);
  let match: RegExpExecArray | null;

  while ((match = re.exec(hcl)) !== null) {
    resources.push({ hclType: match[1], hclName: match[2] });
  }

  return resources;
}

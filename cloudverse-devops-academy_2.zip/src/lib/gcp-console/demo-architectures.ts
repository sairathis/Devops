import { type LucideIcon, Building2, ShieldCheck, Boxes, Workflow } from "lucide-react";
import { ResourceConfig } from "@/types/gcp";

/**
 * One resource to create as part of a demo architecture bundle.
 *
 * `nameSuffix` is appended to a bundle-run-specific prefix (generated at deploy
 * time, e.g. "web-app-a1b2") to build the resource's final `name` — the naming
 * logic itself lives in the component, not here.
 */
export interface DemoResourceSpec {
  /** Exact GCP resource `type` string, matching `src/lib/gcp/*.ts` definitions. */
  type: string;
  /** Appended to the run prefix to build the final resource name, e.g. "-vpc". */
  nameSuffix: string;
  /** Overrides merged on top of the resource type's `defaultConfig` (never `name` — that's computed). */
  configOverrides?: Partial<ResourceConfig>;
}

export interface DemoArchitecture {
  /** Stable identifier for this bundle, used as a React key and run-tracking key. */
  id: string;
  /** Short kebab-case base used to build the per-deploy resource-name prefix, e.g. "web-app". */
  slug: string;
  /** Client-presentable name shown on the card. */
  name: string;
  /** One-sentence, client-presentable summary. */
  tagline: string;
  /** 2-3 sentences explaining the use case, written for a non-technical audience. */
  description: string;
  /** Icon shown on the bundle's card. */
  icon: LucideIcon;
  /** Ordered list of resources created (in this order) when the bundle is deployed. */
  resources: DemoResourceSpec[];
}

export const DEMO_ARCHITECTURES: DemoArchitecture[] = [
  {
    id: "three-tier-web-app",
    slug: "web-app",
    name: "Three-Tier Web App",
    tagline: "The architecture behind almost every production web app.",
    description:
      "A public-facing web application with a load-balanced compute tier and a managed database backend. This is the pattern most client workloads eventually converge on — it separates traffic handling, application logic, and data storage so each layer can scale and fail independently.",
    icon: Building2,
    resources: [
      {
        type: "vpc",
        nameSuffix: "-vpc",
        configOverrides: { description: "Network for the three-tier web application" },
      },
      {
        type: "subnet",
        nameSuffix: "-public-subnet",
        configOverrides: { ipCidrRange: "10.10.1.0/24", access: "public" },
      },
      {
        type: "lb",
        nameSuffix: "-lb",
      },
      {
        type: "mig",
        nameSuffix: "-web-mig",
        configOverrides: { minReplicas: 2, maxReplicas: 4 },
      },
      {
        type: "cloudsql",
        nameSuffix: "-db",
        configOverrides: { tier: "db-f1-micro", highAvailability: false, storageGb: 20 },
      },
    ],
  },
  {
    id: "secure-networking-hub",
    slug: "secure-net",
    name: "Secure Networking Hub",
    tagline: "An enterprise network foundation with locked-down outbound access and edge protection.",
    description:
      "A hardened networking foundation for private workloads: a custom VPC with a private subnet, outbound-only internet access via Cloud NAT, a WAF policy at the edge, and an encrypted VPN tunnel back to on-prem. This is what a security-conscious client's platform team asks for before anything else gets built.",
    icon: ShieldCheck,
    resources: [
      {
        type: "vpc",
        nameSuffix: "-vpc",
        configOverrides: { description: "Secure networking foundation VPC", routingMode: "GLOBAL" },
      },
      {
        type: "subnet",
        nameSuffix: "-private-subnet",
        configOverrides: { ipCidrRange: "10.20.1.0/24", access: "private", privateGoogleAccess: true, flowLogs: true },
      },
      {
        type: "router",
        nameSuffix: "-router",
      },
      {
        type: "nat",
        nameSuffix: "-nat",
        configOverrides: { minPortsPerVm: 32, loggingFilter: "ALL" },
      },
      {
        type: "armor",
        nameSuffix: "-armor-policy",
        configOverrides: { owaspRules: true, rateLimitThreshold: 100 },
      },
      {
        type: "vpn",
        nameSuffix: "-vpn",
        configOverrides: { vpnType: "HA" },
      },
    ],
  },
  {
    id: "containerized-microservices",
    slug: "microsvc",
    name: "Containerized Microservices",
    tagline: "A CI/CD-driven microservices platform running on managed Kubernetes.",
    description:
      "A modern container platform: a private GKE cluster on its own network, an Artifact Registry for built images, a Cloud Build pipeline to ship changes automatically, and Pub/Sub for decoupled service-to-service messaging. Perfect for demoing a full build-to-deploy story in one shot.",
    icon: Boxes,
    resources: [
      {
        type: "vpc",
        nameSuffix: "-vpc",
        configOverrides: { description: "Network for the containerized microservices platform" },
      },
      {
        type: "subnet",
        nameSuffix: "-gke-subnet",
        configOverrides: { ipCidrRange: "10.30.1.0/24", access: "private", privateGoogleAccess: true },
      },
      {
        type: "gke",
        nameSuffix: "-cluster",
        configOverrides: { mode: "autopilot", privateCluster: true },
      },
      {
        type: "artifact_registry",
        nameSuffix: "-images",
        configOverrides: { format: "DOCKER" },
      },
      {
        type: "cloud_build",
        nameSuffix: "-deploy-trigger",
        configOverrides: { repoOwner: "cloudverse-demo", repoName: "microservices-app" },
      },
      {
        type: "pubsub",
        nameSuffix: "-events",
        configOverrides: { deadLetterEnabled: true },
      },
    ],
  },
  {
    id: "event-driven-data-pipeline",
    slug: "data-pipeline",
    name: "Event-Driven Data Pipeline",
    tagline: "Ingest, queue, and serve data at scale — without managing a single server.",
    description:
      "A fully managed pipeline for event-driven data workloads: a Cloud Storage bucket for raw landing data, a Pub/Sub topic to queue events as they arrive, a Cloud SQL instance to persist processed results, and a Redis cache in front for low-latency reads. A great demo for clients thinking about analytics or IoT-style ingestion.",
    icon: Workflow,
    resources: [
      {
        type: "gcs",
        nameSuffix: "-raw-data",
        configOverrides: { location: "us-central1", storageClass: "STANDARD", lifecycleDays: 90 },
      },
      {
        type: "pubsub",
        nameSuffix: "-ingest-events",
        configOverrides: { messageRetentionDays: 3 },
      },
      {
        type: "cloudsql",
        nameSuffix: "-warehouse",
        configOverrides: { tier: "db-f1-micro", highAvailability: false, storageGb: 20 },
      },
      {
        type: "redis",
        nameSuffix: "-cache",
        configOverrides: { tier: "BASIC", memorySizeGb: 1 },
      },
    ],
  },
];

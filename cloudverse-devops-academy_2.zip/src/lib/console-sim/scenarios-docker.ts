// Realistic `docker run` / container-lifecycle failure scenarios for the Docker Lab.
// Shared shape with the other three modules — see src/lib/console-sim/types.ts.

import type { ErrorScenario } from "./types";

export const DOCKER_SCENARIOS: ErrorScenario[] = [
  {
    id: "docker-port-already-allocated",
    module: "docker",
    resourceType: "container",
    title: "Port is already allocated",
    symptom: "`docker run` fails immediately with a bind error and the container never starts.",
    cliOutput: [
      "$ docker run -d -p 3000:3000 myapp:latest",
      "docker: Error response from daemon: Bind for 0.0.0.0:3000 failed: port is already allocated.",
      "",
      "Run 'docker run --help' for more information",
    ],
    cause:
      "Another running container (or a process on the host) is already bound to host port 3000, so Docker can't map it a second time.",
    fixSteps: [
      "Run `docker ps` to see which container is already publishing that host port.",
      "Either stop that container (`docker stop <id>`) or free the port, or",
      "Pick a different host port for this container, e.g. `-p 3001:3000`.",
    ],
    preventionTip: "Give each service its own host port convention, or let Docker assign a random free port with `-P`.",
  },
  {
    id: "docker-pull-access-denied",
    module: "docker",
    resourceType: "image",
    title: "Pull access denied / repository does not exist",
    symptom: "`docker run` (or `docker pull`) fails before any layers download.",
    cliOutput: [
      "$ docker run -d myapp:latst",
      "Unable to find image 'myapp:latst' locally",
      "docker: Error response from daemon: pull access denied for myapp, repository does not exist or may require",
      "'docker login': denied: requested access to the resource is denied.",
    ],
    cause:
      "The image name or tag is misspelled, the repository is private and you're not authenticated, or the image was never pushed to that registry.",
    fixSteps: [
      "Double-check the spelling of the image name and tag (a typo like `latst` instead of `latest` is enough).",
      "Confirm the image exists and is public, e.g. by searching Docker Hub.",
      "If it's private, authenticate first with `docker login` (and `docker login <registry>` for a non-default registry).",
    ],
  },
  {
    id: "docker-pull-rate-limit",
    module: "docker",
    resourceType: "image",
    title: "Docker Hub pull rate limit exceeded",
    symptom: "Pulling a public image starts, then fails partway through with a rate-limit error.",
    cliOutput: [
      "$ docker run -d -p 8080:80 nginx:alpine",
      "Unable to find image 'nginx:alpine' locally",
      "alpine: Pulling from library/nginx",
      "docker: Error response from daemon: toomanyrequests: You have reached your pull rate limit. You may increase",
      "the limit by authenticating and upgrading: https://www.docker.com/increase-rate-limit",
    ],
    cause:
      "Docker Hub caps anonymous (and free authenticated) pulls per rolling 6-hour window per IP address, and that limit has been hit — common on shared office/CI networks.",
    fixSteps: [
      "Authenticate with `docker login` — logged-in pulls get a higher limit than anonymous ones.",
      "Wait for the rolling window to reset, or",
      "Use an authenticated mirror/cache registry instead of pulling directly from Docker Hub each time.",
    ],
  },
  {
    id: "docker-exits-immediately",
    module: "docker",
    resourceType: "container",
    title: "Container exits immediately (code 0)",
    symptom: "`docker run` returns right away and the container shows as `Exited (0)` in `docker ps -a`.",
    cliOutput: [
      "$ docker run -d myapp:latest",
      "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
      "$ docker ps",
      "CONTAINER ID   IMAGE     STATUS",
      "$ docker ps -a",
      "CONTAINER ID   IMAGE            STATUS",
      "a1b2c3d4e5f6   myapp:latest     Exited (0) 1 second ago",
    ],
    cause:
      "A container only stays alive as long as its main (PID 1) process keeps running in the foreground. If the Dockerfile's CMD/ENTRYPOINT finishes instantly, forks into the background, or was overridden on the command line with something non-blocking, Docker considers the job done and stops the container — even with exit code 0.",
    fixSteps: [
      "Check what actually ran with `docker logs <id>`.",
      "Make sure CMD/ENTRYPOINT starts a long-running foreground process (e.g. a web server), not a one-shot script or a backgrounded daemon.",
      "If you passed a command override on `docker run`, confirm it doesn't exit right away.",
    ],
  },
  {
    id: "docker-oci-permission-denied",
    module: "docker",
    resourceType: "container",
    title: "OCI runtime create failed: permission denied",
    symptom: "The container fails to start with an OCI runtime error mentioning the entrypoint.",
    cliOutput: [
      "$ docker run -d myapp:latest",
      "docker: Error response from daemon: failed to create task for container: failed to create shim task: OCI",
      'runtime create failed: runc create failed: unable to start container process: exec: "/app/entrypoint.sh":',
      "permission denied: unknown.",
    ],
    cause:
      "The entrypoint script was copied into the image without the executable bit set, so the container runtime can't exec it directly.",
    fixSteps: [
      "Run `chmod +x entrypoint.sh` on the host before it's copied into the image, or",
      "Add `RUN chmod +x /app/entrypoint.sh` as a Dockerfile instruction after the `COPY`.",
      "Rebuild the image and run it again.",
    ],
  },
  {
    id: "docker-no-space-left",
    module: "docker",
    resourceType: "daemon",
    title: "No space left on device",
    symptom: "A build or run fails partway through with a disk-write error from the Docker daemon.",
    cliOutput: [
      "$ docker run -d myapp:latest",
      "docker: Error response from daemon: mkdir /var/lib/docker/overlay2/a1b2c3d4e5f6...: no space left on device.",
    ],
    cause:
      "The host's Docker data directory has filled up, usually from years of accumulated build cache, dangling images, and stopped containers that were never cleaned up.",
    fixSteps: [
      "Check usage with `docker system df`.",
      "Reclaim space with `docker system prune -a` — note this removes all unused images, stopped containers, and build cache, not just the current project's, so confirm nothing important depends on them first.",
      "Retry the build or run once space is freed.",
    ],
    preventionTip: "Prune on a schedule, or use multi-stage builds to avoid piling up large intermediate layers.",
  },
  {
    id: "docker-volume-permission-denied",
    module: "docker",
    resourceType: "volume",
    title: "Volume mount permission denied",
    symptom: "The app starts but crashes (or logs errors) the moment it tries to write to a bind-mounted directory.",
    cliOutput: [
      "$ docker run -d -v $(pwd)/data:/app/data myapp:latest",
      "Server listening on 0.0.0.0:3000",
      "Error: EACCES: permission denied, open '/app/data/cache.db'",
    ],
    cause:
      "The process inside the container runs as a UID/GID that doesn't have write access to the host directory that's bind-mounted in — a very common mismatch when the image runs as a non-root user.",
    fixSteps: [
      "Check which UID the container runs as (e.g. `docker exec <id> id`) and compare it to the host directory owner.",
      "Align them: either change the host directory's ownership/permissions to match the container's user, or",
      "Set the container user's UID/GID to match the host directory owner (e.g. via `--user` or a build arg).",
    ],
  },
];

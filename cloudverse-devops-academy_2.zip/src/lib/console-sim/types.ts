// Shared types for every "hands-on" simulation surface across the platform:
// GCP Services Console, Terraform Lab terminal, Docker Lab, Kubernetes Lab.
// Keeping these in one place means the Troubleshooting Center can index
// error scenarios from all four modules with a single shared shape.

export type SimLogLevel = "info" | "success" | "warn" | "error" | "command";

export interface SimLogEntry {
  id: string;
  ts: string;
  level: SimLogLevel;
  message: string;
}

export type ResourceRuntimeStatus =
  | "provisioning"
  | "running"
  | "starting"
  | "stopping"
  | "stopped"
  | "deleting"
  | "error";

export type SimModule = "gcp-services" | "terraform" | "docker" | "kubernetes";

/**
 * A single realistic "thing that goes wrong" scenario. Every module owns its
 * own array of these (scenarios-gcp.ts, scenarios-terraform.ts,
 * scenarios-docker.ts, scenarios-k8s.ts) so agents can work without touching
 * a shared file; the Troubleshooting Center aggregates all four for its
 * Reference Library and Diagnose Game.
 */
export interface ErrorScenario {
  id: string;
  module: SimModule;
  /** Optional link to a specific GCP resource type / lab construct, e.g. "vm", "gcs", "gke". */
  resourceType?: string;
  title: string;
  /** What the user actually sees (a status, an error banner, a stuck state). */
  symptom: string;
  /** Realistic CLI/log output lines to render in a terminal when this scenario is simulated. */
  cliOutput: string[];
  cause: string;
  fixSteps: string[];
  preventionTip?: string;
  docsUrl?: string;
}

let counter = 0;
export function nextLogId(): string {
  counter += 1;
  return `log-${counter}-${Math.random().toString(36).slice(2, 8)}`;
}

export function makeLog(level: SimLogLevel, message: string): SimLogEntry {
  return {
    id: nextLogId(),
    ts: new Date().toLocaleTimeString([], { hour12: false }),
    level,
    message,
  };
}
